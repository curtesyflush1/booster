--
-- PostgreSQL database dump
--

\restrict SUGcbrgtXE1uztLa7TCxqzyx4WABQ8yPCpJmronw2DfjjevVAb5crY2XRX3Iugv

-- Dumped from database version 15.14
-- Dumped by pg_dump version 17.6

-- Started on 2025-09-04 22:29:18 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_product_id_foreign;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_role_updated_by_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_watch_pack_id_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_foreign;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_role_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_assigned_by_foreign;
ALTER TABLE ONLY public.url_candidates DROP CONSTRAINT url_candidates_retailer_id_foreign;
ALTER TABLE ONLY public.url_candidates DROP CONSTRAINT url_candidates_product_id_foreign;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_user_id_foreign;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_product_id_foreign;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_alert_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_product_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_category_id_foreign;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_category_id_foreign;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_parent_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_retailer_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_retailer_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_product_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_user_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_user_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_post_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_target_user_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_actor_user_id_foreign;
ALTER TABLE ONLY public.model_features DROP CONSTRAINT model_features_retailer_id_foreign;
ALTER TABLE ONLY public.model_features DROP CONSTRAINT model_features_product_id_foreign;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_reviewed_by_foreign;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_product_id_foreign;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_trained_by_foreign;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_product_id_foreign;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_foreign;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_alert_id_foreign;
ALTER TABLE ONLY public.drop_outcomes DROP CONSTRAINT drop_outcomes_retailer_id_foreign;
ALTER TABLE ONLY public.drop_outcomes DROP CONSTRAINT drop_outcomes_product_id_foreign;
ALTER TABLE ONLY public.drop_events DROP CONSTRAINT drop_events_retailer_id_foreign;
ALTER TABLE ONLY public.drop_events DROP CONSTRAINT drop_events_product_id_foreign;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_foreign;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_product_id_foreign;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_user_id_foreign;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_retailer_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_product_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_watch_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_user_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_retailer_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_product_id_foreign;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_alert_id_foreign;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_admin_user_id_foreign;
DROP INDEX public.webhooks_user_id_is_active_index;
DROP INDEX public.watches_user_id_is_active_index;
DROP INDEX public.watches_user_id_index;
DROP INDEX public.watches_product_id_index;
DROP INDEX public.watches_is_active_index;
DROP INDEX public.watch_packs_slug_index;
DROP INDEX public.watch_packs_is_active_index;
DROP INDEX public.users_verification_token_index;
DROP INDEX public.users_subscription_plan_id_index;
DROP INDEX public.users_role_index;
DROP INDEX public.users_role_created_at_index;
DROP INDEX public.users_reset_token_index;
DROP INDEX public.users_last_admin_login_index;
DROP INDEX public.users_email_index;
DROP INDEX public.user_watch_packs_watch_pack_id_index;
DROP INDEX public.user_watch_packs_user_id_index;
DROP INDEX public.user_sessions_user_id_index;
DROP INDEX public.user_sessions_refresh_token_index;
DROP INDEX public.user_sessions_is_active_index;
DROP INDEX public.user_sessions_expires_at_index;
DROP INDEX public.user_roles_user_id_is_active_index;
DROP INDEX public.user_roles_role_id_is_active_index;
DROP INDEX public.user_roles_expires_at_index;
DROP INDEX public.user_roles_assigned_by_index;
DROP INDEX public.unsubscribe_tokens_user_id_index;
DROP INDEX public.unsubscribe_tokens_token_index;
DROP INDEX public.unsubscribe_tokens_expires_at_index;
DROP INDEX public.trend_analysis_product_id_index;
DROP INDEX public.trend_analysis_product_id_analyzed_at_index;
DROP INDEX public.trend_analysis_analyzed_at_index;
DROP INDEX public.testimonials_user_id_index;
DROP INDEX public.testimonials_rating_index;
DROP INDEX public.testimonials_moderation_status_is_public_index;
DROP INDEX public.testimonials_is_featured_is_public_index;
DROP INDEX public.system_metrics_recorded_at_index;
DROP INDEX public.system_metrics_metric_type_recorded_at_index;
DROP INDEX public.system_metrics_metric_name_recorded_at_index;
DROP INDEX public.system_health_status_index;
DROP INDEX public.system_health_service_name_index;
DROP INDEX public.system_health_checked_at_index;
DROP INDEX public.social_shares_user_id_platform_index;
DROP INDEX public.social_shares_shared_at_index;
DROP INDEX public.social_shares_alert_id_index;
DROP INDEX public.seasonal_patterns_product_id_pattern_type_index;
DROP INDEX public.seasonal_patterns_pattern_name_index;
DROP INDEX public.seasonal_patterns_category_id_pattern_type_index;
DROP INDEX public.roles_level_index;
DROP INDEX public.roles_is_system_role_is_active_index;
DROP INDEX public.roles_created_by_index;
DROP INDEX public.retailers_slug_index;
DROP INDEX public.retailers_is_active_index;
DROP INDEX public.products_upc_index;
DROP INDEX public.products_slug_index;
DROP INDEX public.products_set_name_index;
DROP INDEX public.products_release_date_index;
DROP INDEX public.products_is_active_index;
DROP INDEX public.products_category_id_index;
DROP INDEX public.product_categories_slug_index;
DROP INDEX public.product_categories_parent_id_index;
DROP INDEX public.product_availability_retailer_id_index;
DROP INDEX public.product_availability_product_id_index;
DROP INDEX public.product_availability_last_checked_index;
DROP INDEX public.product_availability_in_stock_index;
DROP INDEX public.price_history_retailer_id_index;
DROP INDEX public.price_history_recorded_at_index;
DROP INDEX public.price_history_product_id_retailer_id_recorded_at_index;
DROP INDEX public.price_history_product_id_index;
DROP INDEX public.post_likes_user_id_index;
DROP INDEX public.post_likes_post_id_index;
DROP INDEX public.post_comments_user_id_index;
DROP INDEX public.post_comments_post_id_moderation_status_index;
DROP INDEX public.post_comments_created_at_index;
DROP INDEX public.permission_audit_log_target_user_id_created_at_index;
DROP INDEX public.permission_audit_log_created_at_index;
DROP INDEX public.permission_audit_log_actor_user_id_created_at_index;
DROP INDEX public.permission_audit_log_action_created_at_index;
DROP INDEX public.ml_training_data_status_data_type_created_at_index;
DROP INDEX public.ml_training_data_reviewed_by_index;
DROP INDEX public.ml_training_data_dataset_name_data_type_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_timeframe_days_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_index;
DROP INDEX public.ml_predictions_expires_at_index;
DROP INDEX public.ml_models_trained_by_index;
DROP INDEX public.ml_models_status_deployed_at_index;
DROP INDEX public.ml_models_name_status_created_at_index;
DROP INDEX public.ml_model_metrics_prediction_type_index;
DROP INDEX public.ml_model_metrics_model_name_model_version_index;
DROP INDEX public.ml_model_metrics_last_evaluated_at_index;
DROP INDEX public.idx_users_subscription_status;
DROP INDEX public.idx_users_stripe_customer;
DROP INDEX public.idx_users_push_subscriptions;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_url_candidates_retailer_status;
DROP INDEX public.idx_url_candidates_prod_retailer;
DROP INDEX public.idx_transactions_user_hash;
DROP INDEX public.idx_transactions_status;
DROP INDEX public.idx_transactions_retailer;
DROP INDEX public.idx_transactions_product;
DROP INDEX public.idx_model_features_split;
DROP INDEX public.idx_model_features_key;
DROP INDEX public.idx_drop_outcomes_prod_retailer_dropat;
DROP INDEX public.idx_drop_events_type_time;
DROP INDEX public.idx_drop_events_prod_retailer_time;
DROP INDEX public.idx_billing_events_type;
DROP INDEX public.idx_billing_events_subscription;
DROP INDEX public.idx_billing_events_invoice;
DROP INDEX public.idx_billing_events_customer;
DROP INDEX public.external_product_map_product_id_index;
DROP INDEX public.engagement_metrics_product_id_metrics_date_index;
DROP INDEX public.engagement_metrics_product_id_index;
DROP INDEX public.engagement_metrics_metrics_date_index;
DROP INDEX public.email_preferences_user_id_index;
DROP INDEX public.email_preferences_unsubscribe_token_index;
DROP INDEX public.email_delivery_logs_user_id_index;
DROP INDEX public.email_delivery_logs_sent_at_index;
DROP INDEX public.email_delivery_logs_message_id_index;
DROP INDEX public.email_delivery_logs_email_type_index;
DROP INDEX public.email_delivery_logs_alert_id_index;
DROP INDEX public.email_complaints_timestamp_index;
DROP INDEX public.email_complaints_message_id_index;
DROP INDEX public.email_bounces_timestamp_index;
DROP INDEX public.email_bounces_message_id_index;
DROP INDEX public.email_bounces_bounce_type_index;
DROP INDEX public.discord_servers_user_id_is_active_index;
DROP INDEX public.data_quality_metrics_product_id_data_source_index;
DROP INDEX public.data_quality_metrics_overall_quality_score_index;
DROP INDEX public.data_quality_metrics_assessed_at_index;
DROP INDEX public.csv_operations_user_id_operation_type_index;
DROP INDEX public.csv_operations_created_at_index;
DROP INDEX public.conversion_analytics_user_id_index;
DROP INDEX public.conversion_analytics_event_type_index;
DROP INDEX public.conversion_analytics_event_date_index;
DROP INDEX public.community_posts_user_id_index;
DROP INDEX public.community_posts_type_moderation_status_index;
DROP INDEX public.community_posts_is_featured_is_public_index;
DROP INDEX public.community_posts_created_at_index;
DROP INDEX public.comment_likes_user_id_index;
DROP INDEX public.comment_likes_comment_id_index;
DROP INDEX public.availability_snapshots_snapshot_time_index;
DROP INDEX public.availability_snapshots_retailer_id_snapshot_time_index;
DROP INDEX public.availability_snapshots_product_id_snapshot_time_index;
DROP INDEX public.alerts_watch_id_index;
DROP INDEX public.alerts_user_id_status_index;
DROP INDEX public.alerts_user_id_index;
DROP INDEX public.alerts_type_index;
DROP INDEX public.alerts_status_priority_created_at_index;
DROP INDEX public.alerts_status_index;
DROP INDEX public.alerts_scheduled_for_index;
DROP INDEX public.alerts_retailer_id_index;
DROP INDEX public.alerts_product_id_index;
DROP INDEX public.alerts_priority_index;
DROP INDEX public.alerts_created_at_index;
DROP INDEX public.alert_deliveries_status_index;
DROP INDEX public.alert_deliveries_sent_at_index;
DROP INDEX public.alert_deliveries_channel_index;
DROP INDEX public.alert_deliveries_alert_id_index;
DROP INDEX public.admin_audit_log_target_type_target_id_index;
DROP INDEX public.admin_audit_log_created_at_index;
DROP INDEX public.admin_audit_log_admin_user_id_created_at_index;
DROP INDEX public.admin_audit_log_action_created_at_index;
ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_pkey;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_product_id_unique;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_pkey;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_slug_unique;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_subscription_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_stripe_customer_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_pkey;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_refresh_token_unique;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_pkey;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_role_id_unique;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_pkey;
ALTER TABLE ONLY public.url_candidates DROP CONSTRAINT url_candidates_pkey;
ALTER TABLE ONLY public.url_candidates DROP CONSTRAINT uq_url_candidates_retailer_url;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_token_unique;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_pkey;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_pkey;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_pkey;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_pkey;
ALTER TABLE ONLY public.system_metrics DROP CONSTRAINT system_metrics_pkey;
ALTER TABLE ONLY public.system_health DROP CONSTRAINT system_health_pkey;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_stripe_price_id_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_slug_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_pkey;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_pkey;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_slug_unique;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_name_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_slug_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_upc_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_slug_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_slug_unique;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_pkey;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_retailer_id_unique;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_pkey;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_pkey;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_user_id_unique;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_pkey;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_pkey;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_pkey;
ALTER TABLE ONLY public.model_features DROP CONSTRAINT model_features_pkey;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_pkey;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_name_version_unique;
ALTER TABLE ONLY public.ml_model_metrics DROP CONSTRAINT ml_model_metrics_pkey;
ALTER TABLE ONLY public.knex_migrations DROP CONSTRAINT knex_migrations_pkey;
ALTER TABLE ONLY public.knex_migrations_lock DROP CONSTRAINT knex_migrations_lock_pkey;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_retailer_slug_external_id_unique;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_pkey;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_metrics_date_unique;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_pkey;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_unsubscribe_token_unique;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_pkey;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_pkey;
ALTER TABLE ONLY public.email_complaints DROP CONSTRAINT email_complaints_pkey;
ALTER TABLE ONLY public.email_bounces DROP CONSTRAINT email_bounces_pkey;
ALTER TABLE ONLY public.drop_outcomes DROP CONSTRAINT drop_outcomes_pkey;
ALTER TABLE ONLY public.drop_events DROP CONSTRAINT drop_events_pkey;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_server_id_unique;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_pkey;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_pkey;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_pkey;
ALTER TABLE ONLY public.conversion_analytics DROP CONSTRAINT conversion_analytics_pkey;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_user_id_unique;
ALTER TABLE ONLY public.billing_events DROP CONSTRAINT billing_events_pkey;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_pkey;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_pkey;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_pkey;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_pkey;
ALTER TABLE public.knex_migrations_lock ALTER COLUMN index DROP DEFAULT;
ALTER TABLE public.knex_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.webhooks;
DROP TABLE public.watches;
DROP TABLE public.watch_packs;
DROP TABLE public.users;
DROP TABLE public.user_watch_packs;
DROP TABLE public.user_sessions;
DROP TABLE public.user_roles;
DROP TABLE public.url_candidates;
DROP TABLE public.unsubscribe_tokens;
DROP TABLE public.trend_analysis;
DROP TABLE public.transactions;
DROP TABLE public.testimonials;
DROP TABLE public.system_metrics;
DROP TABLE public.system_health;
DROP TABLE public.subscription_plans;
DROP TABLE public.social_shares;
DROP TABLE public.seasonal_patterns;
DROP TABLE public.roles;
DROP TABLE public.retailers;
DROP TABLE public.products;
DROP TABLE public.product_categories;
DROP TABLE public.product_availability;
DROP TABLE public.price_history;
DROP TABLE public.post_likes;
DROP TABLE public.post_comments;
DROP TABLE public.permission_audit_log;
DROP TABLE public.model_features;
DROP TABLE public.ml_training_data;
DROP TABLE public.ml_predictions;
DROP TABLE public.ml_models;
DROP TABLE public.ml_model_metrics;
DROP SEQUENCE public.knex_migrations_lock_index_seq;
DROP TABLE public.knex_migrations_lock;
DROP SEQUENCE public.knex_migrations_id_seq;
DROP TABLE public.knex_migrations;
DROP TABLE public.external_product_map;
DROP TABLE public.engagement_metrics;
DROP TABLE public.email_preferences;
DROP TABLE public.email_delivery_logs;
DROP TABLE public.email_complaints;
DROP TABLE public.email_bounces;
DROP TABLE public.drop_outcomes;
DROP TABLE public.drop_events;
DROP TABLE public.discord_servers;
DROP TABLE public.data_quality_metrics;
DROP TABLE public.csv_operations;
DROP TABLE public.conversion_analytics;
DROP TABLE public.community_posts;
DROP TABLE public.comment_likes;
DROP TABLE public.billing_events;
DROP TABLE public.availability_snapshots;
DROP TABLE public.alerts;
DROP TABLE public.alert_deliveries;
DROP TABLE public.admin_audit_log;
DROP TYPE public.billing_period_enum;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pg_trgm;
--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4403 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4404 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1065 (class 1247 OID 17451)
-- Name: billing_period_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.billing_period_enum AS ENUM (
    'monthly',
    'yearly'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 17065)
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50),
    target_id character varying(255),
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT admin_audit_log_check CHECK ((((target_type IS NULL) AND (target_id IS NULL)) OR ((target_type IS NOT NULL) AND (target_id IS NOT NULL))))
);


--
-- TOC entry 229 (class 1259 OID 16747)
-- Name: alert_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id uuid NOT NULL,
    channel text NOT NULL,
    status text DEFAULT 'pending'::text,
    external_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alert_deliveries_channel_check CHECK ((channel = ANY (ARRAY['web_push'::text, 'email'::text, 'sms'::text, 'discord'::text]))),
    CONSTRAINT alert_deliveries_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'delivered'::text, 'failed'::text, 'bounced'::text])))
);


--
-- TOC entry 228 (class 1259 OID 16699)
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    watch_id uuid,
    type text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text,
    delivery_channels jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    sent_at timestamp with time zone,
    read_at timestamp with time zone,
    clicked_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alerts_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'urgent'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'failed'::text, 'read'::text]))),
    CONSTRAINT alerts_type_check CHECK ((type = ANY (ARRAY['restock'::text, 'price_drop'::text, 'low_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 238 (class 1259 OID 16922)
-- Name: availability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    stock_level integer,
    last_checked timestamp with time zone,
    snapshot_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 263 (class 1259 OID 17490)
-- Name: billing_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stripe_customer_id character varying(255) NOT NULL,
    subscription_id character varying(255),
    event_type character varying(100) NOT NULL,
    amount_cents integer,
    currency character varying(10),
    status character varying(50),
    invoice_id character varying(255),
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    raw_event jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 17342)
-- Name: comment_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 254 (class 1259 OID 17266)
-- Name: community_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.community_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    type text NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    images jsonb DEFAULT '[]'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    likes integer DEFAULT 0,
    comments_count integer DEFAULT 0,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT community_posts_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT community_posts_type_check CHECK ((type = ANY (ARRAY['success_story'::text, 'tip'::text, 'collection_showcase'::text, 'deal_share'::text, 'question'::text])))
);


--
-- TOC entry 264 (class 1259 OID 17505)
-- Name: conversion_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversion_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type character varying(255) NOT NULL,
    source character varying(255) DEFAULT 'direct'::character varying,
    medium character varying(255) DEFAULT 'organic'::character varying,
    campaign character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    event_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 251 (class 1259 OID 17194)
-- Name: csv_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csv_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    operation_type text NOT NULL,
    filename character varying(255),
    total_rows integer,
    successful_rows integer,
    failed_rows integer,
    errors jsonb DEFAULT '[]'::jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT csv_operations_operation_type_check CHECK ((operation_type = ANY (ARRAY['import'::text, 'export'::text]))),
    CONSTRAINT csv_operations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text])))
);


--
-- TOC entry 244 (class 1259 OID 17041)
-- Name: data_quality_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_quality_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    data_source character varying(255) NOT NULL,
    completeness_score numeric(5,2),
    freshness_hours numeric(8,2),
    accuracy_score numeric(5,2),
    missing_fields jsonb DEFAULT '[]'::jsonb,
    overall_quality_score numeric(5,2),
    recommendations jsonb DEFAULT '[]'::jsonb,
    assessed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 249 (class 1259 OID 17150)
-- Name: discord_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discord_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    server_id character varying(255) NOT NULL,
    channel_id character varying(255) NOT NULL,
    token text,
    alert_filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_alerts_sent integer DEFAULT 0,
    last_alert_sent timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 266 (class 1259 OID 17551)
-- Name: drop_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drop_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    signal_type character varying(255) NOT NULL,
    signal_value text,
    source character varying(255),
    confidence numeric(5,2),
    observed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 267 (class 1259 OID 17574)
-- Name: drop_outcomes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drop_outcomes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    drop_at timestamp with time zone NOT NULL,
    first_seen_at timestamp with time zone,
    first_instock_at timestamp with time zone,
    buy_window_sec integer,
    success_flag boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 16862)
-- Name: email_bounces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_bounces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    bounce_type text NOT NULL,
    bounce_sub_type character varying(255) NOT NULL,
    bounced_recipients jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_bounces_bounce_type_check CHECK ((bounce_type = ANY (ARRAY['permanent'::text, 'transient'::text])))
);


--
-- TOC entry 237 (class 1259 OID 16873)
-- Name: email_complaints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_complaints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    complained_recipients jsonb NOT NULL,
    feedback_type character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16841)
-- Name: email_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_delivery_logs (
    id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    alert_id uuid,
    email_type text NOT NULL,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message_id character varying(255),
    sent_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    bounced_at timestamp with time zone,
    complained_at timestamp with time zone,
    bounce_reason text,
    complaint_reason text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_delivery_logs_email_type_check CHECK ((email_type = ANY (ARRAY['alert'::text, 'welcome'::text, 'marketing'::text, 'digest'::text, 'system'::text])))
);


--
-- TOC entry 233 (class 1259 OID 16830)
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    alert_emails boolean DEFAULT true,
    marketing_emails boolean DEFAULT true,
    weekly_digest boolean DEFAULT true,
    unsubscribe_token character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 16989)
-- Name: engagement_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    watch_count integer DEFAULT 0,
    alert_count integer DEFAULT 0,
    click_count integer DEFAULT 0,
    click_through_rate numeric(5,2) DEFAULT '0'::numeric,
    search_volume integer DEFAULT 0,
    social_mentions integer DEFAULT 0,
    engagement_score numeric(5,2) DEFAULT '0'::numeric,
    trend_direction text DEFAULT 'stable'::text,
    metrics_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT engagement_metrics_trend_direction_check CHECK ((trend_direction = ANY (ARRAY['rising'::text, 'falling'::text, 'stable'::text])))
);


--
-- TOC entry 265 (class 1259 OID 17532)
-- Name: external_product_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_product_map (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    retailer_slug character varying(255) NOT NULL,
    external_id character varying(255) NOT NULL,
    product_id uuid NOT NULL,
    product_url character varying(255) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 16496)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- TOC entry 217 (class 1259 OID 16495)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4405 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 220 (class 1259 OID 16503)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- TOC entry 219 (class 1259 OID 16502)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4406 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 241 (class 1259 OID 16975)
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_model_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(255) NOT NULL,
    prediction_type text NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    mean_absolute_error numeric(10,4),
    root_mean_square_error numeric(10,4),
    training_data_size integer,
    prediction_count integer DEFAULT 0,
    avg_processing_time numeric(8,2),
    last_trained_at timestamp with time zone,
    last_evaluated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_model_metrics_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 246 (class 1259 OID 17086)
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    status text DEFAULT 'training'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    model_path character varying(500),
    training_started_at timestamp with time zone,
    training_completed_at timestamp with time zone,
    deployed_at timestamp with time zone,
    trained_by uuid,
    training_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_models_check CHECK (((status <> 'active'::text) OR (deployed_at IS NOT NULL))),
    CONSTRAINT ml_models_check1 CHECK (((status <> 'training'::text) OR (training_started_at IS NOT NULL))),
    CONSTRAINT ml_models_status_check CHECK ((status = ANY (ARRAY['training'::text, 'active'::text, 'deprecated'::text, 'failed'::text])))
);


--
-- TOC entry 240 (class 1259 OID 16957)
-- Name: ml_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_predictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    prediction_type text NOT NULL,
    prediction_data jsonb NOT NULL,
    timeframe_days integer,
    input_price numeric(10,2),
    confidence_score numeric(5,2),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_predictions_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 247 (class 1259 OID 17112)
-- Name: ml_training_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_training_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dataset_name character varying(200) NOT NULL,
    data_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_training_data_check CHECK (((status = 'pending'::text) OR ((reviewed_by IS NOT NULL) AND (reviewed_at IS NOT NULL)))),
    CONSTRAINT ml_training_data_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 268 (class 1259 OID 17594)
-- Name: model_features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_features (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    as_of timestamp with time zone NOT NULL,
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    label character varying(255),
    split_tag character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 17418)
-- Name: permission_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid NOT NULL,
    target_user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    permission_or_role character varying(100),
    old_value json,
    new_value json,
    reason text,
    ip_address character varying(45),
    user_agent text,
    metadata json DEFAULT '{}'::json,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 255 (class 1259 OID 17294)
-- Name: post_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    likes integer DEFAULT 0,
    is_public boolean DEFAULT true,
    moderation_status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT post_comments_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 256 (class 1259 OID 17321)
-- Name: post_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 16771)
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 224 (class 1259 OID 16594)
-- Name: product_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_availability (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean DEFAULT false,
    price numeric(10,2),
    original_price numeric(10,2),
    availability_status text,
    product_url character varying(255) NOT NULL,
    cart_url character varying(255),
    stock_level integer,
    store_locations jsonb DEFAULT '[]'::jsonb,
    last_checked timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_in_stock timestamp with time zone,
    last_price_change timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_availability_availability_status_check CHECK ((availability_status = ANY (ARRAY['in_stock'::text, 'low_stock'::text, 'out_of_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 222 (class 1259 OID 16545)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    parent_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16565)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    sku character varying(255),
    upc character varying(255),
    category_id uuid,
    set_name character varying(255),
    series character varying(255),
    release_date date,
    msrp numeric(10,2),
    image_url character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    popularity_score integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT products_popularity_score_check CHECK (((popularity_score >= 0) AND (popularity_score <= 1000)))
);


--
-- TOC entry 221 (class 1259 OID 16523)
-- Name: retailers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retailers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    website_url character varying(255) NOT NULL,
    api_type text NOT NULL,
    api_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    rate_limit_per_minute integer DEFAULT 60,
    health_score integer DEFAULT 100,
    last_health_check timestamp with time zone,
    supported_features jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT retailers_api_type_check CHECK ((api_type = ANY (ARRAY['official'::text, 'affiliate'::text, 'scraping'::text]))),
    CONSTRAINT retailers_health_score_check CHECK (((health_score >= 0) AND (health_score <= 100))),
    CONSTRAINT retailers_rate_limit_per_minute_check CHECK (((rate_limit_per_minute >= 1) AND (rate_limit_per_minute <= 10000)))
);


--
-- TOC entry 258 (class 1259 OID 17363)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    permissions json DEFAULT '[]'::json,
    is_system_role boolean DEFAULT false,
    categories json DEFAULT '[]'::json,
    level integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 17017)
-- Name: seasonal_patterns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasonal_patterns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    category_id uuid,
    pattern_type character varying(255) NOT NULL,
    pattern_name character varying(255) NOT NULL,
    avg_price_change numeric(5,2),
    availability_change numeric(5,2),
    demand_multiplier numeric(4,2) DEFAULT '1'::numeric,
    historical_occurrences integer DEFAULT 1,
    confidence numeric(5,2),
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 252 (class 1259 OID 17215)
-- Name: social_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    alert_id uuid,
    platform character varying(255) NOT NULL,
    share_type character varying(255) DEFAULT 'manual'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    shared_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 261 (class 1259 OID 17455)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    billing_period public.billing_period_enum NOT NULL,
    stripe_price_id character varying(255),
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    limits jsonb DEFAULT '{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT name_not_empty CHECK ((length(TRIM(BOTH FROM name)) > 0)),
    CONSTRAINT price_non_negative CHECK ((price >= (0)::numeric))
);


--
-- TOC entry 232 (class 1259 OID 16814)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    status text NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    message text,
    checked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_health_status_check CHECK ((status = ANY (ARRAY['healthy'::text, 'degraded'::text, 'down'::text])))
);


--
-- TOC entry 248 (class 1259 OID 17133)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type text NOT NULL,
    value numeric(15,6) NOT NULL,
    labels jsonb DEFAULT '{}'::jsonb NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['gauge'::text, 'counter'::text, 'histogram'::text, 'summary'::text])))
);


--
-- TOC entry 253 (class 1259 OID 17239)
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    rating integer NOT NULL,
    is_verified boolean DEFAULT false,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT testimonials_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- TOC entry 262 (class 1259 OID 17475)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_slug character varying(100) NOT NULL,
    rule_id uuid,
    user_id_hash character varying(200) NOT NULL,
    status character varying(32) NOT NULL,
    price_paid numeric(10,2),
    msrp numeric(10,2),
    qty integer DEFAULT 1 NOT NULL,
    alert_at timestamp with time zone,
    added_to_cart_at timestamp with time zone,
    purchased_at timestamp with time zone,
    lead_time_ms integer,
    failure_reason text,
    region character varying(64),
    session_fingerprint character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 16942)
-- Name: trend_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trend_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    price_trend numeric(10,6),
    availability_trend numeric(10,6),
    demand_score numeric(5,2),
    volatility_score numeric(5,2),
    analyzed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 16851)
-- Name: unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unsubscribe_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    email_type text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT unsubscribe_tokens_email_type_check CHECK ((email_type = ANY (ARRAY['all'::text, 'alerts'::text, 'marketing'::text, 'digest'::text])))
);


--
-- TOC entry 269 (class 1259 OID 17617)
-- Name: url_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.url_candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    pattern_id character varying(255),
    url text NOT NULL,
    status character varying(255) DEFAULT 'unknown'::character varying NOT NULL,
    score numeric(6,3),
    reason text,
    first_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_checked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 259 (class 1259 OID 17385)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assignment_reason text,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 16792)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    refresh_token character varying(255) NOT NULL,
    device_info character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 16673)
-- Name: user_watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    watch_pack_id uuid NOT NULL,
    customizations jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16477)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    subscription_tier character varying(20) DEFAULT 'free'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_verified boolean DEFAULT false,
    verification_token character varying(255),
    reset_token character varying(255),
    reset_token_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login timestamp with time zone,
    shipping_addresses jsonb DEFAULT '[]'::jsonb,
    payment_methods jsonb DEFAULT '[]'::jsonb,
    retailer_credentials jsonb DEFAULT '{}'::jsonb,
    notification_settings jsonb DEFAULT '{"sms": false, "email": true, "discord": false, "web_push": true}'::jsonb,
    quiet_hours jsonb DEFAULT '{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}'::jsonb,
    timezone character varying(255) DEFAULT 'UTC'::character varying,
    zip_code character varying(255),
    push_subscriptions jsonb DEFAULT '[]'::jsonb,
    role text DEFAULT 'user'::text NOT NULL,
    last_admin_login timestamp with time zone,
    admin_permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    preferences jsonb DEFAULT '{}'::jsonb,
    newsletter_subscription boolean DEFAULT false,
    terms_accepted boolean DEFAULT false,
    direct_permissions json DEFAULT '[]'::json,
    role_last_updated timestamp with time zone,
    role_updated_by uuid,
    permission_metadata json DEFAULT '{}'::json,
    stripe_customer_id character varying(255),
    subscription_id character varying(255),
    subscription_status character varying(50),
    subscription_start_date timestamp with time zone,
    subscription_end_date timestamp with time zone,
    trial_end_date timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    subscription_plan_id character varying(255),
    CONSTRAINT users_failed_login_attempts_check CHECK (((failed_login_attempts >= 0) AND (failed_login_attempts <= 10))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['user'::text, 'admin'::text, 'super_admin'::text])))
);


--
-- TOC entry 226 (class 1259 OID 16656)
-- Name: watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    product_ids jsonb NOT NULL,
    is_active boolean DEFAULT true,
    auto_update boolean DEFAULT true,
    update_criteria character varying(255),
    subscriber_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 16624)
-- Name: watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_ids jsonb DEFAULT '[]'::jsonb,
    max_price numeric(10,2),
    availability_type text DEFAULT 'both'::text,
    zip_code character varying(255),
    radius_miles integer,
    is_active boolean DEFAULT true,
    alert_preferences jsonb DEFAULT '{}'::jsonb,
    last_alerted timestamp with time zone,
    alert_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    auto_purchase jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT watches_availability_type_check CHECK ((availability_type = ANY (ARRAY['online'::text, 'in_store'::text, 'both'::text])))
);


--
-- TOC entry 250 (class 1259 OID 17171)
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret text,
    events jsonb NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb,
    retry_config jsonb DEFAULT '{"maxRetries": 3, "retryDelay": 1000, "backoffMultiplier": 2}'::jsonb,
    filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_calls integer DEFAULT 0,
    successful_calls integer DEFAULT 0,
    failed_calls integer DEFAULT 0,
    last_triggered timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3549 (class 2604 OID 16499)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3550 (class 2604 OID 16506)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 4373 (class 0 OID 17065)
-- Dependencies: 245
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, details, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4357 (class 0 OID 16747)
-- Dependencies: 229
-- Data for Name: alert_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_deliveries (id, alert_id, channel, status, external_id, metadata, sent_at, delivered_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4356 (class 0 OID 16699)
-- Dependencies: 228
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, product_id, retailer_id, watch_id, type, priority, data, status, delivery_channels, scheduled_for, sent_at, read_at, clicked_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4366 (class 0 OID 16922)
-- Dependencies: 238
-- Data for Name: availability_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_snapshots (id, product_id, retailer_id, in_stock, availability_status, stock_level, last_checked, snapshot_time) FROM stdin;
9c87138f-4a6e-45ed-826e-0abe187d6880	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
123187e5-71ba-44ff-b462-2a863888b545	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
9679ae16-18ac-4500-aeb9-5f935e639d65	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1094e3b4-b53c-4a40-a030-b4f9a304771b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
92f4c488-2692-48c1-9b6b-f16792e005e2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
6b84f9b2-4624-46df-b3b6-8e65a8851a56	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
fa590379-aa1c-4fcc-b075-4b530031d54f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
49015d20-bdc7-4404-885f-2ea345c96a16	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3773dd6c-9e52-4b7f-acc9-87230f25558b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
344695a9-4ad0-41f7-8b1a-2b7a493dd45b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
9f2fd2f2-3fc0-44e5-a926-fd10c28371d8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
07110a84-4845-4b85-8134-0157af9578ba	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
0a481c4c-cf2e-4712-95a9-dacf2164623a	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
0f13a33c-c851-4a62-bf81-a71de8859e86	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
37bfd542-6de8-4112-9370-cba9c407a1cf	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b31e8c7f-e790-4e03-982d-818b18dd595f	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
d8e0db87-62de-42e6-8165-af23d1950119	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
04972570-20a7-4dbf-9538-6fe8196de25d	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1476b1a0-0907-4f0c-935f-d869676a4d9a	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
98e6d0a3-e334-4256-a39f-2b960ee48571	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
77e34384-57ef-4e0d-ad44-7ec19b8c6473	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
109bf1ff-0466-4e38-9e22-3769e40eb321	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
69c73c7b-c251-415b-ad8d-7a7c0c975927	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2fabd751-0d68-4654-8d88-588761752bf2	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
c7b21583-13a1-40ea-b63d-ff2cb3f18e4a	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b308c378-3965-42b2-8711-2ca6045a012f	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3612e7a6-ef4e-4fe9-8882-982219801a0f	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1536aacd-2803-4416-83f2-11af3c20845e	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
9b630a57-f37f-44f5-99ac-2eb5d4c8fa45	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b6974d27-3a93-4947-bf5b-6b860dabac96	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b184ce78-c167-4ed5-b2d0-f0435ca227b3	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
ccc750f1-9dd3-4115-ae53-91037dda2371	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
0cea9d77-4da8-4266-a58c-d077a04208ec	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
6658c4c9-3441-4c22-aa13-99a919b8d829	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2ceb0970-797a-419a-978d-7e7bb937736e	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b28f40ba-cc00-4ee7-89fb-e5e039912a6b	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
7ac10723-88df-42e0-aa85-3737dd4bffde	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
17a0f8e9-52c9-4869-8468-0aa989be3baf	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
fb26770b-5c09-4796-a4b8-59c4a6675aca	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
ce615ff3-43c0-4797-b49c-0c257fc05516	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
729f01d0-687f-41e4-a6ec-994284db6b3b	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
f4cbd7b2-9157-4b78-a975-6d6ef5cc5539	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
4709ce36-9f5d-4748-9d71-954b4af7cec1	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
63429da5-7036-47f2-bedf-dbc2e1711a57	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
105356d8-315f-4eca-be95-bc8f1e5dcb11	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
c7934256-0e8f-41c0-bab5-928d14769839	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
12a4c13a-0744-4647-944e-cd6a21c538c8	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
df3c1fd9-bd49-4d40-9df6-15197dbba4f4	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
5e470a07-350c-48ef-8473-f06d6e010f38	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1928806e-03e0-4f42-9339-1bad8c20db64	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2798738c-dab5-4390-b288-36990df7f8cd	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
4daae8ae-2466-416e-b229-7bb7116c8dd5	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
8a663649-8201-450e-9aa5-2eae2b51fc29	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
a3a786dd-377d-42cc-bd79-8584d6cdcb9c	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b636ed77-efc3-4c15-a746-3da814f7a1ae	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
275895ba-f921-43e0-8755-50c9bb70a2f3	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
c0999e6e-e254-4410-b027-a106660e179a	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
8ba7bfcd-60e8-483f-acca-df2a88d34b61	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
00360ca9-0225-4a93-8eac-c0fee960288d	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2cf81dac-6240-4ddf-b188-d008577e0cf1	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
47fcca12-49d9-4ccc-a56f-8fbfe89e6c1c	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
e2e173db-4065-4ca8-ba8a-ee795cb4c181	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
cbd66c38-3a3d-4eb1-80f2-f166e8742023	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2403580d-f539-4d37-b89d-3cd17ce25860	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
849b6ecf-255b-4e38-b777-cac55028a377	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
70903372-9a91-4b38-ae2e-d542ecfe321c	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
518f960c-96a8-4715-8dd3-dd17dcd0e5bd	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
60fc8ddc-3bd8-4155-b140-a57878e77fac	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
58ef8d8a-d0c6-4e0f-823f-68d8eab37df1	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
5f34f7a7-9d9a-4dbe-abea-e9c566870351	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
7cfa2adb-a067-4299-99b1-3e18a163f7e0	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
fb9eb463-b52b-4424-bd26-c223e8ddf8fd	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b0e49bf1-53f1-42c6-900a-472b45ed381f	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2cb6f8f6-85d2-4040-9949-26d99e5a7ee4	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
f0a07c01-88f2-4703-a03d-86cedf57df92	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
f1aedbce-85c5-43f8-8903-d25ef3ec5532	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
405c2954-980a-48ca-a30e-ad9cd542d693	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3be17a73-0450-4fbc-b217-6c04f201177f	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
e9e4254a-3758-4818-9d62-b8c57ffcdd9a	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
c15ad960-cdd4-47ce-84d7-bacb6d7ae450	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
a6d62b57-9f03-444b-9209-8da01f14294b	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
f4f0bb3c-3fd2-4941-b06a-b7ed85fbd7a5	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
4d17709b-8c97-44ee-9693-0caf3cb01749	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
ea4123f9-9f04-4ef4-90be-e554f656a8e4	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
a234bac8-a7a1-467f-8254-9c5c63b553f5	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
fe5ff296-7498-4ce9-8a0b-15cfe516674d	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
8b5a0ec7-487f-4c4a-85cd-ef39972ef73e	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3ecda4f5-4009-40fd-9c83-145ba7dd7f7e	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
5949fce5-715c-4371-9c14-fc139e593fca	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
d500f408-bed4-47c8-b61a-af2c41696074	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
2ef1b923-827e-4dd0-8d8e-3d5ad3791f4d	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
4a4196df-b50e-44b2-b102-7156bbe43eb8	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
86b3c2a1-9fe2-4644-a3f2-6b1931e3249d	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3e631b19-5c49-441c-a158-c49ab0fe6ec5	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
5d81de85-2441-413d-8677-3e917e46601c	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
64b33dc0-02d4-4d9e-a814-ad709082f7b0	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
5ad51a12-2344-4515-a8b2-ad3387e64fae	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3eed8bcf-7508-49ad-9ae7-a910374ffa9e	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1b8221da-0b64-41d3-8c22-0668fb84cf28	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
ca38892b-64a9-4aa9-b202-2b386de22620	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
ff9de8d0-cc1e-41de-8b34-b52d8eb6fafd	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1c93b594-db3c-4ff8-81c2-b8b2accdeb28	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
114c8f5c-9ec1-405f-83c1-27f0d870ae9f	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
e92d4bf6-4cf9-4d64-b573-abb1eab79bbf	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
ba339d1b-ec50-4b50-8342-945217ad502a	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b384e930-6a8e-4de3-953f-10eafefc6169	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
be69d494-95fb-4662-a472-908ff8159ed7	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
d3a76c9f-ff1f-469c-86dc-df768e2b96d7	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
31974441-bb3c-47de-a9d8-6c40a0d91081	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
c3d720c6-929e-46f8-914a-99c6d22dd95e	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
8b522240-3bf8-4ca5-abb0-0e7961f7fc72	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
b9298651-691b-407e-a760-f1bb3bee2537	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
3c2e282a-5924-496d-8a46-711694312c73	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
e51c9a77-e0ed-45be-ad11-93d7add0fb54	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-03 23:00:00.843+00
1602fc2b-9c59-4165-8fa4-ba1bb3eae4a1	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
ac720edd-23e2-4ee0-80e5-d4f892ae7550	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
52db32f2-1ea8-4aad-8f12-7bb09f47aa1d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b4feba30-522c-4d5a-bb20-2ffbe7da5b8d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
5730d1b8-504f-43da-97f2-82fe90744709	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
56f4738e-09a9-4979-ac3d-add6467f8550	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
6033a149-8c0d-441f-8a18-83a11ad3b638	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
0b1c90c4-0d11-4699-8c45-746bc33d1ecb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
aa2e6bbc-a518-4cc9-82fd-8c37be6099ea	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b76ff4f6-db8a-4c6c-8637-b9f899a3e0bc	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
3d9b4a19-01a4-428e-bdf2-1cf0a4b0a58f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
2a9fd539-1081-4b43-97df-28a9685bd002	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
82680c21-6997-4fa0-9524-c4b742650e8b	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
cda1850a-053e-4737-83e3-6f06917778c4	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
2e38501d-2762-4b3f-aba4-e2885027e78f	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
95385e8e-e78c-4cee-adeb-94eacf109042	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b39ade8d-5d93-4d34-94c9-55c031f900b8	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
7d42e105-f187-4d00-baa6-eea001804851	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
a4031ed3-86af-4663-b36b-8c9ace600258	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
d143f652-f8d0-4c51-9454-2488bf074745	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
cda9282a-4014-43a8-9c1a-624bab03715a	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
53449515-b931-4acf-81dd-aa9e48ccf564	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
f0b07f69-9c36-4770-8e7d-120703e02fe9	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
d291285f-3abd-48dd-b0ad-353c42702bf2	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
6ad00a51-b43d-4895-bfdb-33cccb2c8932	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
7bbb5b9c-96b8-4b2c-a50c-014b5ae17b02	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
deab8f8d-24d6-47a1-8e44-63ee6528b9db	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
9e23e3b0-5d7c-4d10-997f-b150e194fad1	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
0fa98514-dfb6-4809-b9a6-41fb8e344cbf	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
38a1fd42-b14b-4dca-a8e3-99f258ab7cd7	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
1ca6dd8a-8784-4b41-9ac4-75da500d69f1	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
5176550a-cc01-428f-82bf-497589a61587	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
78a07978-3653-4a1e-923d-4c95e2051355	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
24442f9a-aab5-4c08-80fd-4dc0e8d33a79	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
00f2dd37-a137-402c-bbb3-31cfdd96fa98	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
1d9fe716-14d6-4f18-94f6-82f227619407	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
0812165c-cc90-4c7c-b365-47cec47fb101	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
de9b98c4-e81d-4cc0-82b2-646ba280dc4c	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b4b4e6ab-e61e-41bb-8fa0-a2c716d0fe94	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
62484089-7557-47d1-b19e-e56c3b8eb8b6	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
7f1c3afc-9df9-4a3a-aff8-d1ce6fe8565f	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
03b4004d-5cc2-4ea9-8117-93579f6f304a	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
26f084eb-853c-40a9-a00a-5144509303c4	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
879f079d-5469-4f8c-8f3b-8a3140ca4b32	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
815a6a42-226e-4982-88b6-fdd880b94619	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c6b3a61d-8529-44b8-a641-2d4392895e96	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
882f5c02-88fa-4ec1-91c6-a700ad895617	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
9dbd6acd-6ade-425b-9844-4b361fb15e49	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
4f53212a-8524-4a0e-9f40-828e7c9a658e	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
1a5463d6-dbd0-43f1-8602-9049eefeadf1	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
4f26c396-15b3-4bbe-956b-6151e8e79d58	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c58eb72f-3ca7-4cc7-a7a8-935e62b33133	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
e06eeded-b0f6-43d9-ae10-18cf44f6050f	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
5d9af10c-50e8-41c3-99af-694e58186c0b	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b8f19aeb-e613-49b4-9214-b16878231f2f	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
be900e74-6448-4245-9a8c-944dfad3b356	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
0ada1e6f-f694-4161-b69e-9fb9fac70e98	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b91318f5-1ede-4bae-bcf3-8c642e1fdc8f	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
fc163b0b-a9b7-41e0-8dcb-2cd4cd0bddba	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
30682852-303e-40c9-8337-cb4b52f167ca	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
26542791-1b5a-468a-84e4-ce57495e1042	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
2564b3fa-7dd8-4ecc-8e2b-4d31d00c2d01	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
dec5bf21-4a2c-422c-8924-f5f630026c2e	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
001674cb-6f80-4616-a2e6-6c6fc7dde985	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
3d7750f8-50eb-4264-ad87-90fe9cbf4a8f	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
5efb0b0e-5927-4bc3-8825-46f087373b59	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
27bf7b04-0c9a-40bb-af23-099749264d42	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
08a9929c-146f-401a-94d7-a84d7108de86	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
f72f3526-aa40-4cc4-a69f-c44c5b251150	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
084ca02f-4e3d-4ec8-b841-10cfd63d6a4b	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
f4a1fa51-62d5-42d1-93e6-0849beb2c89e	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
d6d1a84d-2ce4-4ff6-9b39-ffae48411ba7	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
bbfc185c-48c4-4555-982b-5baa52de5318	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c28d84be-a0b9-4212-8bf0-34a6171ca05e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
61dd880b-3ec3-41e8-b520-2c293a8c42a2	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
d9a14c13-9f5e-4163-8094-26a11303be0b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
876e83af-30c2-4f5c-8401-18a04bb17d12	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
8be65022-1c42-4efc-8146-9efdbacf98eb	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
919e4540-67f9-4ff2-8586-3307a7680a87	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
bad1e4b7-5c20-4e41-bd99-feeff3f44b66	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
163413ac-202d-497a-b624-8a90f0f21a87	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
51dbc6c0-517b-4411-a17d-06d8f275c7d5	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
85bfd9bd-b2e0-4c19-bb7f-71d3036d426e	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
a9aceba0-dc73-4c2c-89a6-698ff7127c33	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c31630bc-9cbe-40e4-b6ee-fb8153a8a03c	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
fd51be93-0508-43ed-8b6b-e9b16261d418	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
2a544761-864d-4651-8f2a-ed95694fbb7e	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
180433b6-b6fe-4795-a40b-07880831fe20	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
05a17151-076a-4afc-9aa1-1fe9b041ba3c	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
7f51e7b8-8286-416f-bcab-d4d174681254	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
87bb66a3-c913-4d02-a26f-b35f2a8f8781	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
2c9229fe-0aad-44b1-911f-4ba876e8f69d	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
a4b51143-0ed4-4f01-9108-23ab2c5d2148	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c9ed1ed5-c8cf-42bb-a0ba-4c49b8cdbc42	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
6e05b6cb-e43c-4753-9c4a-4d208361b218	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
64ce43ee-bf37-4df1-8665-4dcd19cdfa4c	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
b05c2f2c-4bd0-41cf-96ba-d7740d386918	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
d5e96319-b0a2-40b5-94c5-0ec0332bfb4f	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
1628a8be-13af-405c-b9de-c00f1983fa5f	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c26679e4-985b-40b8-8028-575a2573b91e	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
6425a57e-4503-432b-bd37-3a44bf4e35d7	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
54d02a13-f927-45d7-a815-d2a0ab9aba22	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
679ab8c1-0410-4526-b128-69d6088876f5	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
e796daca-4176-44a4-855c-993719c0f08e	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
10d3aaf8-dc35-46e4-98b7-a07d146a5230	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
68c3ef80-1071-41b0-8bcc-79438cfb46df	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
16e4491c-3e2f-4966-b208-7ffdf3f5a1a6	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
8743b519-27d2-4d5b-ba6c-d7859bf07fb0	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
db2916cb-5b61-4d9c-9282-ec5b69bf280c	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c6c54143-d65e-476b-bdc3-2b9110dfa6f7	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
d78f8c71-15ac-4875-bb51-21d10a1546c8	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
3a3b89eb-2be7-461d-8955-d846a3ed0f39	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
c51697bb-463f-42e8-a539-aaf7c57d0a6d	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
2e40aa4e-c29c-49a1-8f1c-04e5b7f58b35	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 13:00:00.408+00
28eaebf6-5071-4ea3-ad5c-27781f782ea0	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
adf599b4-9e33-418b-91ea-90e6c652f713	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
d1f80537-e212-4e4a-ba1b-dcddd17b479e	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
fc370cf2-5a08-4608-9801-d79ca27e9af1	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2d2715ff-94d6-4589-9d18-58e3c8c86729	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
9281ba54-ae09-4594-8902-35b01cef7974	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
bd251feb-c9d7-4d9b-bae4-28565e8d8141	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
b14cd337-30d2-441c-8767-e68097227e11	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
bf2744ef-0158-4b8a-8c42-08b53c295a74	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
9b228d87-fb36-43b8-b25a-df525c0b9a3f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
187cafb5-64ee-43e7-9dd6-add78e01c57d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
16f3e0a1-e9fb-492f-b37e-68f0f1561c22	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
01e30909-146c-42d1-b4f1-bdc367f98622	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
d289601d-a8b7-421b-9871-4392f42f1521	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
acf5f38a-14c0-4474-a485-38475118f6b6	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
f4de83c0-82d3-4f3d-8067-a8bcd548547c	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
10189e1d-6a9e-4745-9411-a1d5ebdeaf36	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
36c1ea72-1d38-4487-81b8-8dcc573a0c90	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
8b5e348f-3d92-4352-b75e-299d8f4c5b09	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
efddb72e-2f36-4001-a8e4-9a85ecd727a0	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
700b7e88-2c8c-4b16-90e6-d868d399a01c	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
8de69df4-340b-4f3d-b076-8a5ba86a223c	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
efa7ac9a-52bc-47b7-90b5-b5d7483366ee	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
681356f7-11a1-4132-842c-69fd0abfcc12	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
a155981d-b265-45a0-b99b-a447a76c3f58	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
81e546f4-0d11-430a-b888-86869d027415	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
d8fd5aa1-9413-4d66-a423-bcf51c3c6794	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
50820e1c-7bfb-4b24-9492-a152dca31d15	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
d64d3505-60a8-4434-b490-c968d3c2db44	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
196680ee-1b6e-4344-ae84-fa8b88cc4e4b	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
0b8a2670-09b2-4750-ac9a-2e38acaa6c33	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2494e03d-5b9c-4d80-976e-376ccd5acee3	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
a1a3fa3c-f2ac-4208-bf58-d12c7480d1a6	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
10098021-e7e9-4ada-b289-357d24510119	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
c71b5140-503b-4643-927f-95adbebfbfec	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
87b761a5-0bde-4ad9-b4c8-338ded7b8cf2	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
c9117862-e3bb-47ea-ae76-3b4a0c607a7c	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
dfcfbb80-a841-4fbc-b013-3b397eae3808	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
e744a760-5f70-4068-b718-ee97e5191fa0	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
dc7fe4df-1551-4129-b74c-cd04bf6cbd61	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
642ebbe0-d085-40e4-8ae9-fd1c65cfb01f	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
5ed31704-a97e-4f71-9cf8-1eeb38b36d33	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
4dff155f-d604-4f99-856c-e590c9828b50	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
31921aa8-7bd0-42d3-b4a1-6cd67c5d5eae	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
a17f2bcd-6b7e-40d1-99d1-38652d5adf5f	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
4769e992-1aff-4a25-81be-7b35182db05a	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
3f746f5a-fc98-4487-86ee-46ca85ae22ac	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
4adae805-ff9a-4f73-bc67-8fa4e1fffd8c	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
53feda4d-a7df-4354-9b89-2a61482c28c1	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
0a4ab40e-0d0c-4add-848e-7948d072efb9	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
91993721-4b6e-4899-b131-a3108f4ea9d4	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
0623340f-432a-4ece-af7d-5f0b4e5d4d87	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
b75662d0-8e10-4f01-9bf3-ee979cc2773f	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
8785f281-bab8-4b14-9807-2039eec9b86d	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
c2011b5b-61b3-4102-b68b-5b04a6a6f819	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
4a6d5ac7-4de4-41b3-9c39-b67d09e1230d	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
0784be2c-242e-4ae5-a25b-3c293d974426	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
ef7a9543-4b58-4266-a63d-334b72c37897	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2c766149-be44-42e6-b5ad-cf5597203455	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
68cc8fec-50a1-42d5-9596-95abfb4bb382	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
74741547-c859-42ba-88b3-b2b29f035b22	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
b80e4e68-3199-4721-8eb5-147f0b847eed	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
97f32a3b-9fb6-4855-b3bf-984ed0f1315a	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
cc4c364f-c049-49a0-853a-62656fd6c912	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
d638052f-dbbd-460b-8cc1-cf362fc89eb8	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
521922f7-c53a-4ee1-9777-8a67d656ca66	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
75c6fab0-206f-4ae6-a697-146079ea861e	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
b6cb88d1-6e17-401b-b13c-fa632dd61c39	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
65d98bde-515b-41b2-89cd-9be2e8a32680	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
e095ae9e-ed69-4c6d-9d82-04269056d54e	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2175f351-a89e-4aed-88dc-6a440afce6e8	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
86da14d0-1d04-471d-9128-59dc438b4951	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
9fa20aaf-f3eb-44c9-8766-a3fbb59ab4e2	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
c1c79744-6807-4764-8e98-3142decd5595	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
3cb429b3-40ba-4a1b-9dbf-c1620bfb97af	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
3fc00c4c-ee32-4efa-93f7-1f0a5ac30902	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
88111a73-c886-417f-a49d-d412709b12a5	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
fea9e150-da17-4f1c-9053-1006191864de	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
1aa8c93a-fdc8-4c2d-a005-54e92b973292	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
577a98c3-7959-4773-8a44-1975edf56a14	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
e9f93603-be71-4f48-8b53-9a22991ebdab	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
fc954839-992f-4417-b311-4a1af9c586c9	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
79e91446-11b5-4c9b-a9c2-89fdc8834e45	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
5e56b652-c4dc-454d-a790-5a8711bc710e	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
5c5ad6fe-e025-4c4b-8fa5-a250681d3daf	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
264542bc-cd72-498f-8622-bada4cbf189e	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
29267ee0-6bef-4252-803e-8b9e18f45060	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2e294616-7070-4cf8-9143-15f5ba4e5388	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
108be574-234d-4388-b2b4-6c837a00aee1	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
725e113c-585d-4046-9f3b-0f7bf63746c0	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
73f7e8e9-5189-4c1e-8b80-2a156f190597	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
c5479152-83d5-49ca-896a-02ea31753d78	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
9c1e30d3-167b-471a-bc7a-81368c2f06a7	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
38a940e4-1157-4c45-a03a-a3c3873e1bc7	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
4a9c9bf6-78f9-4bcd-bd91-8d7d106a8a73	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
14e36342-6841-45f6-8ec5-f99b71c74984	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
3569cda8-294a-4409-a887-dbf421bfe445	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
e4faeec1-de5e-4169-a461-3cca8cd99058	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
62d36456-97b8-40aa-b8f9-c3bb7a00f353	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
996b9006-2a8c-4878-ba21-3408e6b808e1	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
cfd0dd2a-9347-4fe4-a89a-aa0f1d225d57	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
80ff06c1-b622-4ee7-8c31-7321c24bac52	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
f35ae4ca-8354-4ee8-8e33-241a19128049	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
1a0349af-786c-4a8c-8a42-1ad20d9af1d4	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
a0a44093-d96b-4277-b294-94176479bd2f	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2202343f-9fce-40bc-9ad2-f53b424ebcc7	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
6ec4fc5e-c9d5-4063-8c92-1803acc3630f	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
278f45d8-a25a-45a9-8321-8b35c9dae018	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
b183b0ce-29a2-4c13-bbf3-f35389c972cd	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2828c659-7962-4aa1-b6bb-08719ad7ba24	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
1ec2ed01-8804-4e95-a8e8-e636f15f6310	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
2c93ce57-a1b1-41f6-b47c-4043ba4ce66d	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
96541301-de33-41d1-b169-f5eda780ff8e	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
b47d624e-6744-4069-938b-92c16f907028	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 14:00:00.983+00
cb8ba307-86bd-43e6-bec3-0153f314db90	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
8f3b4785-8f98-4cc3-af95-ee6d789f42f1	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
17e0d1e5-aa9b-4789-bd0c-4f5ed4de51d6	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
6042a691-4496-49fd-a99a-ee1136697960	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
04e95dfb-7fab-4941-b13d-3db12a2e4655	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
8619e0a8-5376-474b-b71e-e031ff869cfb	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
ff2ee44f-ccca-4ace-bd87-f809c74aaba2	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
91d14677-8bdc-4319-96bc-64161f79404d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
6a96b4be-4931-46f3-8dba-159a2e40261d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
8ffce357-1d96-4a21-8f29-4d812d285e25	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
0b20534d-49ba-4ec2-a2d2-2b1b405bf75c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
20af7dfc-1d91-40a2-8ddd-7ba368735403	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
861a7315-54f6-4fcd-b031-f5557d7cd56a	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
16293b2a-2853-4e8f-ab74-dc8aad67c570	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
f4b756b3-a28b-4c07-ae0b-ddecc863ea6d	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
b7f281c1-c824-464d-b09e-cf1caaf3cd86	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
c124918b-3250-464b-b5d8-d31ed99b0635	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
bb71bb5c-6afc-4272-8af2-c464eafb6ca2	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
3cb4fe61-5ce4-45bd-9cba-64d1679dcf2a	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
3b391fbf-417a-4b39-b5fa-705c8dc938ad	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
5e1dc639-75e7-414d-8116-577277c341a2	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
62edc682-3c0c-49b3-853d-2866253b685e	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
87b86c9e-e86b-4226-a6d9-249d48a25c07	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
b2704ffd-d0d4-46b3-a184-ee70222aac18	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
eedd28b5-8f72-428f-ab02-9ec7c86de143	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
67af580a-a774-48fa-bb4c-d757903e7e3f	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
3fc2a8a2-d680-4b58-bcbc-91da93acefdb	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
47c6d9e2-a466-493a-b148-2b656265a96d	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e921ac94-834f-43c2-85e5-6cfa99b38cbb	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
2d19d77b-f10f-4f1a-a73d-925d497e4ce8	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
53d4d3d0-bc3e-4dab-997d-c9ef82337a9a	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
6300d163-cb91-4e7f-b0b6-14017f618c42	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
58f1ecca-3d3d-47b3-bc24-68f9ccf0c0d2	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e2d28fa3-c1af-4b03-87b2-965e0a907f86	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
0a700e7c-8d34-4b9d-95f9-d7765b9ed755	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e6eb1e1b-57bf-41a8-94ce-387f6e36beeb	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
b2a4453e-46ea-42ba-a1aa-13a3b6821208	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
0877a8ad-e38e-40d2-a183-8e8ebde22058	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
4b3cbdaf-5919-4b79-8b89-e807534e1047	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
164a60c9-8853-4612-8e85-1eb5524e3ca2	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
d3dc39fa-76c4-48d8-813d-df764b47b4d1	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
ed6d0308-bc16-49d1-a140-f26cb534049c	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
7abd006f-170f-4c72-bd36-7028973c3d51	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
21949e7e-fdf8-4b69-b2fd-ac04cb5d65fb	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
b05022de-8747-4600-b7fe-5c815258df3a	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
4426ebd0-022d-4695-986f-c55fa55f6919	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
dd5db820-abef-4640-8d50-7cbff87ba2e5	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
72cb454c-c1de-41e4-b875-65a047449612	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
14bb6146-35e3-4735-86ed-ef916d05943b	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
8f4ae584-0865-4515-8aa0-7d944fb5d668	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
edb9dae2-04a0-4f10-a6ce-ed03f201a70c	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
430db457-80ae-4b62-a0b0-92be8157d201	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
5622fda5-d9cd-4a0d-b4ea-c4f7d6e125cc	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
a788590c-f826-4ae1-ada1-05a4dd46c01c	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
93dd98d4-c41f-441f-b2e9-be1edf10dbbc	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
f39ba81c-73df-4823-b408-6e785f6a9d35	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
25b47da1-6ef3-4201-9ff1-89a39f69a4e5	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
d5c1d8ed-9c21-4308-8811-f74afaba325c	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
d471141c-ae40-484d-8eea-780643adf207	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
dd6f4bf0-a1fd-48a2-a492-873ff96bd2e0	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e7cb9dc3-ad52-42b5-a32d-6ba4b1a76865	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
2e25dd93-9038-466d-aa40-16bf1bb77bc3	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
046121be-e9ac-4c4d-b2cd-dd6bbc2fc621	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
cac776ec-b427-470c-98ba-ebd8e25e85db	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e9749e00-967a-4336-97d5-c6014787b9b1	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
9d23dd32-66ac-4f79-8028-5aa6f89a7c57	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
ee293db6-1d7a-4862-bb8f-f58f1c30e126	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
7799109f-5768-4008-9024-60331ab7fb5a	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
3fdfd394-991f-42c0-a6e4-ebc85493a080	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
5f17e7b4-45f0-4401-8a0b-8877fedfdc04	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
a3bf660c-6742-4330-93cb-97ffd2c13ebd	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
3c47b459-ce3a-4c18-b92a-5b0750717a5e	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e8235c3d-54df-497d-9fea-574d3157ce70	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
bded14fc-80e7-4981-99a1-2736898d319b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
6f3dbf3a-bb17-4e0b-bceb-563fda668acc	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
fa16167f-dc3f-4981-8569-b1918a6d910b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
e1f9f6e5-7d02-4357-9447-d8bc28628d48	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
f3592933-ca87-47b5-b0f1-d61bae982b50	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
1cd74b5a-8ca4-4c0b-953f-834e58463fcc	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
67faae43-7705-4865-96a8-88772d65cdc6	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
edcacddd-dd50-45f5-8adb-47163e5c3919	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
84b541ef-c9f1-4bf9-bd5a-a0f49e508e52	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
0f85e9ac-8329-4329-92a9-35e53d468631	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
2c98d09c-1729-4e78-aef5-20e2bbfda4d4	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
cce21774-b559-4926-a2a1-f95274ffd3a4	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
1ffa1c82-6fc8-4f9f-aca8-2c7f68300679	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
1aba9cd9-a4c4-4852-a664-2367939c7153	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
4489d38d-e119-4a66-8426-8fffcadf8814	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
8cb83751-886c-4a6a-bea4-591288d94d9e	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
5f1501c5-18e6-4c2f-bd22-e1c73ad75254	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
49cafaf3-0d2f-4ac8-b3a2-397b5b2f1f61	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
0deb5580-ff5b-4da5-9378-5103398d903b	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
3463d255-e3d5-48b2-bf9d-0e1fff349e50	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
48513f77-5684-49ba-b5d4-a8787d10f838	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
34096f2b-0860-42ae-9025-d6e73c401c74	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
6f2574a7-13a0-48ec-bd46-5efbe71c7d7b	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
2f8dd97f-4f46-4f11-9241-6479c93975f0	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
4df5d004-f89e-45ef-979c-1778ecbd90a7	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
ae3d90c2-b6d8-4582-a43a-3897cccae903	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
50c56a5b-99f7-4336-a028-9f38245d4787	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
c88d91d0-9ffa-44e2-9d22-cef2955610e5	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
ca7c236a-5088-4db7-8f0c-fa9aba14182d	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
bbc00f4c-c845-4194-affa-ce5d52ab2ce7	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
89cc9149-74d7-4921-b59b-4e4586a4ee89	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
1a034b8b-a45a-49ac-b8f5-78a0e31a5d08	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
587dfd42-2ee1-4bba-b580-3263d3702c05	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
1b0ce9f9-6e78-4410-991c-65940a9dcafb	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
c326f94a-90fa-4dd2-8734-4baaddc49f3c	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
47a8fa9d-93fb-4f0d-aae2-37317df716f9	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
93fb4462-cf01-44d2-8713-9f7f6a447d17	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
247cd7cd-31c3-43ac-a175-2042de269562	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
4bbb1c39-47d1-4ce0-96ac-03a741ac5874	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
db4cb954-ffc9-4967-b21a-be325498da02	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
dd318091-3409-4beb-970c-7b313aede531	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 15:00:00.152+00
67e6bf05-5fcd-4e05-a9ad-092690c579f4	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.208+00	2025-09-04 16:00:00.898+00
ed06ba84-68dd-440b-8ef4-9b5fb0adbbc3	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.214+00	2025-09-04 16:00:00.898+00
9dbcf067-0066-40d1-b8ba-de25bed5719a	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.22+00	2025-09-04 16:00:00.898+00
4718bdaa-9106-429f-9019-df2b99b0a93a	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.23+00	2025-09-04 16:00:00.898+00
cb7bf571-b002-4ead-9a51-e87d70dd0076	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.234+00	2025-09-04 16:00:00.898+00
50440924-00b3-449a-ada8-5674a4b50b26	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.238+00	2025-09-04 16:00:00.898+00
7ca312c6-9f49-4e75-8275-953ad0575a57	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.242+00	2025-09-04 16:00:00.898+00
70cdcf2f-9a11-41ce-bfe4-48b21b8e7874	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.247+00	2025-09-04 16:00:00.898+00
6ac4e2a3-9e8b-4927-8475-74cba80b5543	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.251+00	2025-09-04 16:00:00.898+00
b9f8ddc0-367b-49df-9213-1703491bf435	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.26+00	2025-09-04 16:00:00.898+00
da88e993-ea01-4015-9c75-64ec86603201	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.265+00	2025-09-04 16:00:00.898+00
004bd804-af27-4e50-b93f-074cf0eb40fe	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.269+00	2025-09-04 16:00:00.898+00
196ac57d-e64d-42a5-baeb-43c45ec30c68	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.273+00	2025-09-04 16:00:00.898+00
7de67e15-fd02-46a6-b97b-e997028b8718	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.278+00	2025-09-04 16:00:00.898+00
d8e62b50-da23-421d-ada3-e7f1ee0c918d	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:02.154+00	2025-09-04 16:00:00.898+00
27372c48-3eb9-460f-b8c8-6e3b046a4b91	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.961+00	2025-09-04 16:00:00.898+00
c71346fc-cb5a-4e7a-8137-790c809e0eba	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.966+00	2025-09-04 16:00:00.898+00
7a153cfc-6725-4bb2-ad30-02afdb5a83e6	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.97+00	2025-09-04 16:00:00.898+00
2231fe0f-a8cf-4bca-9193-5e591143a4bb	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.975+00	2025-09-04 16:00:00.898+00
b648c240-b65c-4a87-9ba0-f8a7d6729961	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.979+00	2025-09-04 16:00:00.898+00
2ae5c48b-ea22-42c8-9c6e-a27d3a1900df	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:48.384+00	2025-09-04 16:00:00.898+00
1b170a5a-b9ca-4156-b9b9-20dcbafca5c6	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
62be2dad-5660-4a62-ae1e-8cc0f12500b2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
9a474a33-aacf-46f7-ae17-7d2f96a7220e	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
51bc9e9d-46dd-4c9f-9241-5e97de6b3e33	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
9fd61855-a7c9-4b4f-98da-c6268a87915d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
6ec89ff1-c1f4-4de7-8ca2-d71915708407	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
7f108a3f-3bea-4dc5-b708-ad68d50855e2	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
393c0440-d9e9-4174-a286-52e550b432d9	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
6aa4324b-e561-47b0-bc84-19a34dfa4a1e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
782ad9d5-1ec7-4815-b35c-ab8ecd17cf96	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f687bc64-41d3-460a-814e-b6ec409defcb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
be6a1d93-f37e-4182-ad25-e1f745fa1eed	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
6d978284-1d66-4e1d-b768-7509108a8b48	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
758b71e6-bdd6-4843-a7cf-aa1eb029fb42	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
6e680395-b006-400c-9f34-51c6e33aaf10	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f19e7c60-b058-42d8-be16-f6349aed6fc2	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f0bd8c32-e225-4409-9d6e-75dbb830f79a	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
e6933e0f-4260-4088-ad82-162593acfb15	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
af46f2bc-9818-4087-a906-f604ae62888d	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
ebc6a726-0530-4e3e-9543-27e42b2d1901	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
a3f99d55-0fd6-40c5-8d8b-d0ed004f6bdb	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
c4f727d1-14dc-4266-b8b8-f5d731c1e57d	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
011e4362-0f6f-47c3-bc63-8a7979cf17e0	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
3791fa74-20d2-4c3b-a5d2-7a1994e7a7d4	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
e97d6bfc-cd6d-4524-8ca5-fb4fa055ffab	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
7fa391d5-0e68-4466-a5c2-d0cad99c013c	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
7c3a1153-0bde-4ced-b184-b42168447886	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
8ef08a61-2f64-4b33-a1bc-a5d1b3e941b9	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
c90a56b8-09fb-45fd-84f8-2b77b1f3db55	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
be6a0b22-9f5e-4f2a-b215-bb7d289af4b8	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
e3c6db5d-875f-49ba-9c36-bf76fe58c45e	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
0f078110-d54a-4bd2-8846-88a4da9cb659	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
d4fa9318-52d7-4810-ab38-137818eb37a1	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
c0865878-dc94-44d4-9813-2184ac0d7ba9	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
d056c61e-bcda-4aca-bc99-39bc0098341a	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
0d772d1b-06ab-4a3b-bedb-bb3739bd7cee	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
0da88cea-d5a4-4fa6-b759-2348e1f39479	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
6c6085d5-5622-4eb3-8b01-581c790c26b7	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
b9abcca6-99bd-454f-8331-f71d52798763	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
1104def7-f556-4662-9e9c-9825cc09d6cb	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
8ea3fe17-4e65-4d7f-a26c-fbf74d3ad043	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
465be391-2fae-4766-a266-fee476a09ae7	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f3e35c80-0c0e-46d6-9100-88b425ed2d22	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
ed3587f3-c422-45af-9f87-2856ab4a70c1	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
abd11512-9c0a-435f-a562-3c70f08107b7	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
ada305c3-261a-4705-8c45-fb36cdf10969	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
43559949-fea5-4f23-8518-39b08e3cb973	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
32945a51-7da2-48ea-988f-63fe8b213150	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
35b65184-6148-49f5-9149-2efa2007fcd7	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
3d54c929-323d-4892-9cef-f5dd0c65341e	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
426c5916-c78b-44b0-8506-18c74496026b	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
655bfb15-ff44-49fb-849c-d8b7f4e7958f	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
c228c95a-c0bc-4662-974e-547c94f434d3	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
93239f0f-658d-4c64-af54-019d4514ac5c	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
d0eee75d-39e4-464c-9f1d-a2227e9d19e9	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
8439f43e-b5b6-49ca-ae9f-1cec875f7ef0	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
3e1f0cf0-ee41-451b-92f8-68d1f9eef9b9	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
31c122ff-8678-4834-9499-73ec9bc72a07	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
03bb4439-cd54-43ae-8890-e3a7d9dce311	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
3575a8e7-017b-4445-8ca5-a5eb864ce35d	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
16e7e49d-6b93-491c-8a82-b6c504913f10	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
eb8bb8d9-5661-4b87-bd3a-4655cc5f23ba	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
2208a5fc-3e7d-49dd-85eb-8d9cb1fe6a51	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f521db45-3d65-41a3-9710-20cb0cb89c93	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
6795d9d5-e345-473e-9953-c795ac56fc25	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
9af2576b-7256-4f82-ba26-f137b2842ecd	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
165850fa-43df-4b08-a32e-923153bf109c	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
8fc4a14b-b4ba-4da8-a2c9-f26c5d1b648c	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
2c9b821f-e99e-4e4b-b1f6-20462d9b820b	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
b6392d6e-7d84-4184-92cc-a80de86370c3	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
1a2d5300-2d94-4ebe-a58e-f839eabb3b46	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
0c81fbdc-5852-4744-898e-b696a5108560	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
089356cf-ed1f-4017-acc9-f9dda272354c	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
7e01edab-a68e-46f5-96e6-e56e40187509	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
938fc4af-332c-43db-a411-5d21f31772fe	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
1209ffe7-ee59-4597-9376-a086a8e88cb5	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
74fc2f8f-c215-4b8f-905c-193ef0a6aba0	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f88f7408-dd54-43cd-a21e-9a8ee94aa098	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
ae7747f1-f310-4281-9e3a-e05e57e53b4b	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
110bc22a-8939-4dab-b11e-947bac7040a6	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
84dfa62a-f1d0-4fc0-b6b5-75088b33df9a	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
185b2c48-5b34-4201-84fe-52abfba2e88b	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
baa37ab3-c26a-4fc5-b783-23f08e610af7	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
2d814604-945d-4379-8ea9-8347b03e2a46	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
e11a985d-6e24-4283-bd4b-2a324d53d95a	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
3b7dbc4d-e9d9-41e3-beae-20e9bc799881	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
fdf304aa-8781-44af-98e3-706826ce9073	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
5b0e685d-2312-4a61-a3a1-4a39896098b2	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
84ccb2a6-d642-43d1-a1b4-3f8f8332d8fd	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
f146ea92-68a2-4352-ac9b-433e4c5ce57b	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
3a8a2707-a55d-441c-91f4-9c0db6f1bb07	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
8c8d8dec-110b-405d-bd97-7677fa2ff5bd	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
09b4de43-7a72-4486-bb7e-f37a5a21a922	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
428423e2-02a0-45a3-9147-ef6228b389f9	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
663cb82f-513a-4d4a-8b21-9a23d9b873c2	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
c5e62bc4-8b31-4e10-80ac-8547f166a41a	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
ed95c066-1e64-4567-b21d-dd5d31ad259a	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
00360e73-d5c3-4f9d-a5b2-b52328a914ce	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
445f1c83-290c-489d-b6f1-402974260489	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
4994cce5-2a8f-4426-ab64-81617145f402	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
c7d18a57-196a-46a9-bbc2-7abda2bbc5c7	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
317ebaa0-cc27-4186-9619-2aab5e5cf0ae	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.898+00
8632daa1-aeec-4519-980c-7d4fadfd0f48	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
56ab1b01-4b62-4ae4-8efc-599169055521	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
7013629d-83b8-4350-9fe0-56e7b914835d	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
af599757-9715-4be5-b0fd-9fcffe7a1497	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
0cc45c9a-6726-4156-a1f2-55993a5429fd	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
afdfd5a4-f82d-432b-9417-f2a1fb628c96	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
f91f0206-adda-4aee-a599-665a8cd23891	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
e817dd38-fdea-4eec-81cf-844aeb8d5c31	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
2a418676-36a0-4f3c-9510-70abcba364a3	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
a0c4607a-bb6f-4cd4-9ecc-31dd0e078cd6	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
26021224-d82a-4b60-835d-bd50c0f3e07c	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
aa7768e1-455d-4dc6-9004-20633c687bb3	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 16:00:00.899+00
98ae0c5d-e13a-4ad1-85bf-2adfd4746341	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.208+00	2025-09-04 17:00:00.27+00
47559608-c458-4c56-810e-1a876107969f	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.214+00	2025-09-04 17:00:00.27+00
d4ed6b8c-737f-4313-a769-196e854b8228	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.22+00	2025-09-04 17:00:00.27+00
8b3b2b1f-b4f2-486a-b634-e051477fede0	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.23+00	2025-09-04 17:00:00.27+00
ffdb6bc0-4a29-4524-8aee-a3056a19715f	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.234+00	2025-09-04 17:00:00.27+00
9daaec6a-70d6-4782-83d7-1ffd12c50096	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.238+00	2025-09-04 17:00:00.27+00
e306f1d5-cc84-485b-af43-9cd51566f614	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.242+00	2025-09-04 17:00:00.27+00
b61e3749-8c9e-406c-b21a-80a2d5809508	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.247+00	2025-09-04 17:00:00.27+00
3156fef9-591b-4df6-afb5-d1664f36f77b	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.251+00	2025-09-04 17:00:00.27+00
d0d79a1b-5d99-4a23-a16f-c9e9057c97ac	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.26+00	2025-09-04 17:00:00.27+00
9bec6126-1f83-4a40-9d85-83d7e0242184	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.265+00	2025-09-04 17:00:00.27+00
032bda42-5d39-4274-9a76-f4bbafc0197c	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.269+00	2025-09-04 17:00:00.27+00
16427182-63c7-44f0-86d4-b15c556d7023	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.273+00	2025-09-04 17:00:00.27+00
1c25a3a1-8c98-4f32-86fa-6eda3279e0b5	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.278+00	2025-09-04 17:00:00.27+00
37a5e1ee-c948-4387-9f8b-fde8fae3a1c6	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:02.154+00	2025-09-04 17:00:00.27+00
d2636926-6cb9-4e10-b64d-448cf6e75b91	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.961+00	2025-09-04 17:00:00.27+00
5094582c-583f-4eae-8caa-1b868a918f67	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.966+00	2025-09-04 17:00:00.27+00
d9b995dc-93fb-4abb-bfe5-2349b2a4bb46	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.97+00	2025-09-04 17:00:00.27+00
498ece8a-3a69-42fb-ad41-5c92138adc43	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.975+00	2025-09-04 17:00:00.27+00
352bdfa5-bfb9-43b6-8b93-e2dc3bc94357	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.979+00	2025-09-04 17:00:00.27+00
71e170e8-a5ae-4f6f-8010-b776dee0a407	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:48.384+00	2025-09-04 17:00:00.27+00
ae5d7a40-ee69-4269-98f7-17b210768af7	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
19e720b0-aeb0-40f6-92f2-d17f6aabaac8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ba2b45bb-2f90-4b3b-a5f4-a0451dde95f0	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
2d6708ef-729c-4409-b11c-53b5884fedb1	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
11838ea1-66fc-4006-9637-4da9050cf3ff	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
c9dd040c-0d59-4068-b8df-c3cd787307f0	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
fcd016d3-4fa6-43bf-bfce-25fb0f051d91	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
31d0a932-0604-4b00-a345-27c9fb0a9b20	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
5827223a-cfec-441b-946d-944e4ff02f0b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
2b247e9d-4d0a-40b2-8c48-671495cd624a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
97773e2a-9ba2-4050-a85b-89e011c6a55c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ce76403a-1550-459f-8aeb-a673cbf2b4a7	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
b687b774-8ad0-472e-8ad6-f541ac5bb85a	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
742d8173-5b53-4984-b00a-5bfdc766448f	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
08ce6f69-8b10-4528-935a-c12343a674ba	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
5a2d9471-dde6-4537-bf69-e351a16556a5	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
82cee65b-f39c-40a9-bdd6-e69bed6d8529	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
5e252a73-d777-429c-8c09-d630a8be62f2	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
0c216eda-511c-4ff3-bd51-1c956a659b46	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
c2c0922a-3819-4d4a-8928-d5d4a7cd0958	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
3dd234ab-7b65-45e2-b878-b4f605f0dbe0	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
d24269e8-acd2-4559-a567-57905ba20109	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
c19a8a99-d794-489d-af1c-9415959aa79a	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
d77f024a-e99c-4338-866f-f62c76a67a4b	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
db467d2c-bf13-4bdf-8a91-e0dad26a9ba7	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
0d18c61e-53cf-492b-bb48-ec37dab6e61d	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
395d78ea-377d-4bd4-9499-789c438ea6a5	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
1d1ed60c-885e-45ea-85c6-a744b8673bd6	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
870e92cf-6f86-42ea-a095-f9096f174b0a	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
afab2dc3-86b4-4911-844a-5dacf42e1def	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
26041811-d1a4-457e-986c-ad308d98d788	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
d38b1003-e940-4aad-be20-c9f5f9ea5147	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
fefcb3ef-5f53-433e-8586-8f69c42f24f7	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
774af760-afce-4a5d-bec0-25b115d1b28a	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
86f7e11a-cb3e-4d94-bd14-363662194b89	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
1f63b318-172f-462c-b5d9-a99e7ee27367	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
b7b2b633-3075-47bd-ab31-805a91cf7a37	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
855cb00f-2730-46fb-8efd-410d2165bfb4	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
3cfe4263-a562-4e76-8610-ee0eea480b37	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
a3aaf92c-c29e-441b-8b71-62c419e236eb	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
d4a145af-5207-40db-87d0-39f1a5c03ecb	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
4b3152e2-df7d-4924-9436-721858b7158f	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
cf1421d1-c8fd-4bf6-af32-bfd44cb2eb3f	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
bd0f6601-adb8-4c9a-a816-44fcd3b8e755	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
96d2f35f-fd92-4987-a140-416ed239028e	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
1615c3c5-40f3-41c7-9807-d9b816aca660	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
0fd925e7-3b26-4bb1-bcfa-df8bba1ee3da	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
cfbe5854-9e94-4a01-8e3c-f8d91817b3ff	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
1fa9eb81-15aa-460a-9040-56d2665afa7d	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
22e418fa-19ac-4329-b973-d94fca2b3ee4	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
9fba7e1d-2cec-4571-88b5-e6ce152b83e5	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
1c160539-a601-455c-a19b-9052cda3cc88	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
3afe1295-abda-467e-90da-9e27d2f59cf9	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
d324e391-0b50-47e3-aa99-22ed3cd25cab	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
e013b59c-32c9-416c-86f9-5b74b3bc4fff	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ec3b50f4-2d89-404a-b47e-3c6345db8aed	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ee783b12-6ba1-440a-80b7-f16b96da530f	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
a21d7e3f-0c12-4bf4-bfd8-8ec812702c7b	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
e9a4f453-fa42-421a-96fa-3167f6485cb8	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
4c9a2008-49e0-4eeb-841b-da2c1b8aafe1	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
197c38f6-1487-4df8-a79b-d735b4f163da	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
de262686-8bec-4932-a6eb-b03573be6532	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
149684c1-d104-459d-bd7c-7754610af60b	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
28fb2ac9-159a-4c76-88ca-1addff513bf7	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
2f709219-9216-4147-b529-042a5b8b3aaf	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ec5a494c-f515-4631-9053-ac8f865ea6d3	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
f3afd538-2d75-4f89-ba6e-52238a8d9fb2	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
676f6571-d7b3-4e9c-9d79-6a493a692f4a	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
fa2bc5a6-b603-4a3e-be98-7557a6640194	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
c2709885-504e-4368-8596-126de2cebc08	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ad5c16d9-fb82-4950-abe7-ea10a6abb40f	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
8c908cd2-2692-4e85-b99a-db7bbaf143a1	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
f9833d59-b2e6-4841-8791-84fba7fcac21	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
f0a51afd-1e66-4c7a-818c-bc7aac012bb4	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
c469d6fc-0428-48c1-ae54-1c8a7c98717b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
29400b8c-7038-4a48-a62b-0955aa1b832f	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
18a34cb8-843e-4ad8-9a65-e21a46438ab1	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
dec5ecf1-4fb6-4df7-b5de-0005dd8c622a	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
d3cce12f-a96c-4fd1-9f5c-ee2f9d96003c	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
1b7cd2db-d293-4a54-aba6-13fd1ff74e94	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.27+00
ba84ea88-e724-41a3-8eee-d16a6642fa48	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
da78cd05-4742-4ea8-b7ce-c4dbfb3ad2b9	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
13d0bdeb-0cc7-4506-bb7f-3f3b34f4a49b	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
86469ecc-11c6-485c-a39f-027c3e7f8782	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
f6537e06-8056-41d0-b12f-17185301d47b	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
307eca1d-0fa4-4634-86bd-87348c2dc69a	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
66c26eb3-0e32-4a3d-a9c6-e52d9a6a09ea	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
3a7546a9-e602-44d3-b0d4-e2f097822099	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
1a605667-a026-4e35-bf91-93287a306a88	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
53b275ca-9b65-41ff-a237-10cd79d02067	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
0580676b-8079-4048-8e42-687e52cbecfe	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
f702c7c8-f320-40bd-a4a2-9fe6da7eae5d	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
478aaa8e-8469-4644-a645-dab309340576	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
3a2cbc99-4eca-4a0d-acbc-a87857f92440	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
b84f3acf-2561-4225-ba79-85b1849b6638	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
26070297-8195-4b80-87de-ce294398eb16	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
f44753b7-94a8-41a7-831d-5aaf740164bc	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
ed79774f-4d34-43e0-b6f3-a750b2813c09	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
2a0945b0-736d-4463-aaba-a6fc5bcec6b0	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
0ca6b5a3-79c4-4706-bc05-c0204f09777a	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
380cb30f-06c7-46e9-849a-8d67185a28a0	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
573039fe-c51e-426c-87e7-9116a8e7c788	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
ec05e717-2ad0-469e-943e-78f235cc54c5	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
329698dd-9854-48d3-afc4-acb1ed7b4df5	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
155bd242-c529-4acc-8f09-c9ea669f4215	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
2f8c1318-61d9-4dd9-b08d-dd7546290103	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
623a43b0-c3db-43d5-ae11-56f7ac6556da	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
efcc1d51-1eda-4ba8-a5be-de05eb43e740	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
cae85a35-f1c8-401e-99cf-ca138450c5c6	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
e8bf4100-b516-4df9-8ac9-efc37f32611e	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
83dbea28-573f-42fe-862a-3d6b8011a2e9	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
e8cc158f-85c7-45df-9e93-86aff415f468	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
a6d173ce-c12b-44f8-85df-42b4b58bc322	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
da53eaa2-68f6-403d-a446-d75e8eb2f7e2	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 17:00:00.271+00
234e24e5-b1ea-481c-ba08-29096b87b7e0	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.214+00	2025-09-04 19:00:00.383+00
d47473ca-3b9e-4450-8cf4-83ee5672f676	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.22+00	2025-09-04 19:00:00.383+00
8921a350-325e-431a-9cb9-d7e20f368e7e	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.23+00	2025-09-04 19:00:00.383+00
59cffbd2-a78b-4bc4-a338-33650bb310b0	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.234+00	2025-09-04 19:00:00.383+00
0df72a69-1a57-4d14-860a-d3034586f989	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.238+00	2025-09-04 19:00:00.383+00
8cbf0e3e-4f42-4c32-aac4-ab5e2811eccf	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.242+00	2025-09-04 19:00:00.383+00
9b5f90cf-b848-4909-adb5-bc5e56d40fa8	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.247+00	2025-09-04 19:00:00.383+00
0e394582-f222-46c4-8498-8b20b040974e	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.251+00	2025-09-04 19:00:00.383+00
2a26f403-a7ee-41bc-bfd4-888e7b01a31c	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.26+00	2025-09-04 19:00:00.383+00
095c9099-f262-4a28-85a5-0776f8ac239d	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.265+00	2025-09-04 19:00:00.383+00
a5c8adee-6c9d-4fd7-b925-1228c99e5ee0	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.269+00	2025-09-04 19:00:00.383+00
9b89dd98-485b-44d3-9c0b-8da14eddf950	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.273+00	2025-09-04 19:00:00.383+00
e1a612d9-6cd6-466f-b4e4-e70a56f2f2ed	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.278+00	2025-09-04 19:00:00.383+00
1a3c1c26-f273-491d-a604-9540a0bab9a3	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:02.154+00	2025-09-04 19:00:00.383+00
3ea4eae4-f611-4684-978b-fc967968c52e	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.961+00	2025-09-04 19:00:00.383+00
1577c558-03b5-4289-91ab-77f140a4422f	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.966+00	2025-09-04 19:00:00.383+00
f9301f2e-c662-4b51-aba6-93c0ee095cc2	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.97+00	2025-09-04 19:00:00.383+00
7df27d34-0b41-40cd-a09e-156ec902035c	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.975+00	2025-09-04 19:00:00.383+00
da668e7e-cfac-430e-8174-2e49cb39a3e7	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.979+00	2025-09-04 19:00:00.383+00
28bd08e5-a0b6-4e1d-9198-8ff72d000ab4	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 18:10:40.081+00	2025-09-04 19:00:00.383+00
374f8939-2292-4778-a26e-0118976b3df7	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:48.384+00	2025-09-04 19:00:00.383+00
42acb7ef-5c90-461a-a1bf-23eb1e183cde	cadea567-c448-4789-872d-49fa516ea9bb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 18:10:40.075+00	2025-09-04 19:00:00.383+00
e887efbb-941e-4d3e-ad3d-454d051f523d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
095c74ea-dad1-4a81-875d-488f66177e71	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7a1b852c-217a-4d72-a716-ea8f4ffd31cc	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
2b7038c2-4af8-4eff-acdd-743a0f6871bb	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
b58444e1-af9d-401a-a021-17c0fc1d1198	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
4dffa97d-cbbc-43c7-ad3e-cb97623b4b8b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
8340a826-db25-4783-b913-d2b6f2e7f66b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
be674139-181c-403a-aba1-bf39bb45d404	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
5f640647-a8e3-4d8a-82c7-94f97c7cf206	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
940ed880-bf1c-4554-b130-0e652db74be2	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3aa91973-08d0-46f2-a3cb-06af3eaf0883	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
da1b84cb-4c8e-4ec3-bc24-31b9535cf0fb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
fa96cdf5-774e-436f-931d-692106bef64f	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
f43c250a-e980-418a-af96-d6cafc459f6b	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
025e03fb-7e3c-4091-bb05-80b9ce865e27	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
e7fdc92f-0ef0-4f75-90d1-5ff4c7cd8aaa	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7eb438b5-8cd6-41ca-bb50-9f1c1e8fb19d	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7704aa73-0fe9-4f4c-9cf6-ac2771d7cd60	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
538d7495-10f3-49c6-a182-bfe5a3702440	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3985e63f-9d1c-49fd-93f1-3f4aae583b36	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
cc9b1241-7886-4b39-8839-8b71d44be176	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
df80395a-2160-4491-88e9-f53e70bd21a8	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
a66e3072-d00f-49e0-921b-f17be6e846d0	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
50996f7b-7194-44c4-bb8a-ef97f1c4d28e	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
75d74010-d259-4e76-9280-a56007d1f99e	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
fe568bd5-de2b-42ac-8037-c602c6602148	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
ef37acf5-bf7b-48c9-b7fc-08e1b5212bac	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
90e6fc3d-a95e-4f96-a09c-c373ee07e566	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
cc40b0cd-76dc-458b-b625-66c1fb30f171	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
b0414d56-1599-43bf-a633-44ae76934d2d	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
5f40f131-c193-408f-8296-e321d7e82026	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
6b57e163-32c4-466d-988c-333285ab4fca	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
cf7ecfc7-3615-4de7-b05c-922e86c5bfa7	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
54e82a25-47d8-42d3-85b8-774d9d6f5f99	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
2d7ea979-7c01-4a1a-b8b8-ce4bf819d731	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
04f7c714-8ffe-43a5-8ea2-6be4a00e3e77	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
139fa1c7-5ad0-431c-9419-da488a948ffb	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
0e12274f-607d-41ae-91de-e24b776697cc	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
82974097-b1fc-47d3-a3eb-7c215c89666c	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
eca89259-6224-4cae-977c-1cca8188b28e	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
6655627f-d9c8-46df-80de-d80f279f828d	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
b409afdc-d9b8-46dc-a3fa-5ffc2bbaa7ed	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
e9fcf807-0311-4055-8817-575c00f8101f	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
ac13833b-0841-48a8-b76a-2e6b6c6c910c	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
90eb3621-de34-4925-a4d0-16031ecf3405	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
36b90ad2-ffb8-4335-96fd-89bba683145e	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
655670d6-704a-45e6-a952-a1bc7a549063	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
f088431c-e5d0-4b61-a08d-7302e5f3bcd9	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
22ed3aed-e68b-4c80-be9c-09d5c7338bc9	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
f8c2279c-9463-4ca7-be48-cf77ccd76273	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
f6956bb3-7e0a-46f6-b0b7-e07182243c81	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
2e33d95a-5910-4250-a3ad-d59c0194c506	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
20b366d0-b43f-4e2f-bd8f-ed53840869c5	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
e744e4d8-b3d7-4850-b27d-6e10fd3e9746	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
99b64ad8-aa79-4da7-bdae-96962f295f36	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
0b45c405-40e5-404a-870e-8bbb48bc139e	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
47a592af-bc6d-41fa-ba3a-92ecfb91e78f	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
ea9416a8-62fd-4aa0-a7aa-f288756f65a6	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
85f0cc1a-272e-4901-b10f-ae7a6c9f3be4	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
49eff901-8ed0-4a24-b290-bb1ee9235290	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
80668c39-d238-4823-a2d5-a0c690d81751	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3f115bd9-bb6d-42d5-be49-f537dd436216	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
c65b02ca-77b0-443a-b6a9-86ecb922c49c	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
06655da8-4dd3-4f52-a4b5-d89e0f3360a0	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3755865f-2bd7-46ce-b849-ac7812e7a43d	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
476aa268-289f-4c73-a2b6-d0fd97de655e	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
b16f4f31-5609-466f-b3e3-94a59e0fff82	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3da8df78-eb82-49d2-9b33-c311d53ba765	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
57669c31-652e-4f0e-a5fd-c81b0e42c2d3	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7c9cd5ce-a001-4bb3-bf59-5b7158ae2ae9	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
91462273-21af-40bf-bb4d-21198c7ee3bd	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3d25f8e7-739f-4623-9e94-09db4b2f914b	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
6c137595-bdb5-405b-b15c-2f71417a51f5	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
a06fb16d-f83d-45b3-ac13-10456f80f6bc	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
c322a26d-f6e9-416c-a079-a6c2126e80f8	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7d7d0e05-0cd6-4dbe-ab18-1d49da745837	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
820d78bc-5651-4eb8-a4ca-fbafb54a209e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
6c1efd64-107a-4c27-b398-87a35c482839	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
a2f0fdb0-9a7a-45db-b873-44486adf021c	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
22e85df9-ea7c-44ef-82b9-26ac903e03b5	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
fd7c8c7a-7168-4397-b07a-f1a84cebabdb	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
75a0d3cc-cdbd-43a0-b673-0a26217505e7	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
f0e65ab5-77ea-40f6-ac42-45fed1226164	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
57821bc5-f269-44dd-867e-ac9b8f01eeab	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
0ed99bad-1b53-4c1d-8baf-cfb560c29c88	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
249cdd7b-d21f-4eef-8632-db7b698dfbcd	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
edb859d3-da4a-4abd-9ae4-2a9277b2f2d1	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
a3e9cf54-bb43-4603-ab66-21c8fa497c21	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
0649dc42-8df2-4b31-8ce8-ce7b5fa412d3	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
e639b742-c4f7-49eb-bc3d-24f208d383ac	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
f937aabf-cb80-4ba0-b015-8679d876535d	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
1a06b32c-7739-43a5-8b19-194fed881327	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3a195e79-9e08-42cf-a71c-bab11b7c02e4	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
094b5b2f-090d-4b23-915d-30f6771bfd85	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
0646025e-9fd9-458f-b219-abfe10272479	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
3bb5b1af-6592-4db6-b376-310a630170bc	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
12fbdcda-6107-4a88-a013-b3e6e40b9db8	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
2b813ad5-29ca-4cf6-a82c-5332f3e154e1	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
8de9c3ee-7d0c-4b0a-8f00-6482036a5ad6	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
b16183c0-d1cb-4d19-aa70-6255c3130ae9	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
89aee1c3-efb4-4b0f-a287-5556b7b506bc	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
872a01c8-1bcf-40d9-9c9a-cd81145e6602	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
13e87fbd-fa63-4da3-84d7-b484f2ca339a	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
437698f9-3c9f-4feb-a6f5-2dc5464f5274	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
8d6ad9d3-494d-43a7-8cfe-42b7d2e2709e	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
913a6480-e266-4c9b-ae57-05344ba5cae0	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
dc4be127-f1e2-47fe-822c-30ef543e6929	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7bd4a99b-c398-4df4-b541-88fc73418f8a	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
fa58bbf4-7eab-4348-bbdf-72204b1ea94d	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
7cbf6f52-1d41-44b9-9b34-e489bdb811f0	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
a380cebb-0454-4e93-bad3-d47af47e03e7	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
70dd8a1c-bb35-4d23-b587-8d0dd5c4dfa4	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
2a0ed1e4-8779-4b25-ae3e-7f1411018a57	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
00a72b78-f8c4-49b6-8357-1db9e2cef6dc	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 19:00:00.383+00
0072e736-83b4-4bfd-9caf-49330d38a419	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.214+00	2025-09-04 20:00:00.13+00
24a08aa0-56eb-452d-8ee8-39a72a4eb23c	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.22+00	2025-09-04 20:00:00.13+00
57405184-9ca5-4e70-956f-09375c2cffe6	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.23+00	2025-09-04 20:00:00.13+00
833cc543-ebbf-4001-b82a-a0c65481d0df	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.234+00	2025-09-04 20:00:00.13+00
a98ae080-db47-40b3-8836-1024ea9687a0	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.238+00	2025-09-04 20:00:00.13+00
4ef96216-0b31-4694-82a0-ceeb3cafd6d2	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.242+00	2025-09-04 20:00:00.13+00
aeb21142-0e76-41f7-bc3c-406887e1d14f	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.247+00	2025-09-04 20:00:00.13+00
b2fdea2a-faf5-4e55-bb4b-fd3414cb0408	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.251+00	2025-09-04 20:00:00.13+00
cf16419f-c790-4c7f-9a79-0561d16d28ae	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.26+00	2025-09-04 20:00:00.13+00
2e56deea-d0d7-494d-8a67-11162bfac200	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.265+00	2025-09-04 20:00:00.13+00
a282f920-3c81-43c1-9e8f-8d21e92f88a5	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	\N	2025-09-04 15:01:31.269+00	2025-09-04 20:00:00.13+00
8d0c90ff-8ad9-4156-8840-e15746dd6b6c	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.273+00	2025-09-04 20:00:00.13+00
ba64c768-2b99-4e22-b08a-dd224640cf69	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:01:31.278+00	2025-09-04 20:00:00.13+00
6e7bc5d6-4ead-4e89-aac3-3815d48b415d	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:02.154+00	2025-09-04 20:00:00.13+00
51581d4a-323d-44c0-961c-0e2ed1391d08	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.961+00	2025-09-04 20:00:00.13+00
a6ff81c9-2015-478e-b3e8-3214f04eedc2	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.966+00	2025-09-04 20:00:00.13+00
757ef266-8411-4314-8bcc-9a44099bf939	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.97+00	2025-09-04 20:00:00.13+00
a53e3610-5443-448e-924c-e0c87a213a40	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.975+00	2025-09-04 20:00:00.13+00
28786415-bd0e-4275-b564-21660f9a72c8	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:32.979+00	2025-09-04 20:00:00.13+00
3e4a31eb-7137-4605-bf1d-c16755009216	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 18:10:40.081+00	2025-09-04 20:00:00.13+00
fd70c927-553c-4acf-9cea-61acc55d30e1	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 15:02:48.384+00	2025-09-04 20:00:00.13+00
5c96edd9-8097-466e-8e04-c31cc8643897	cadea567-c448-4789-872d-49fa516ea9bb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	\N	2025-09-04 18:10:40.075+00	2025-09-04 20:00:00.13+00
17ab06f8-ed86-4678-ab0b-46befa4b6b52	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
81b23836-1a14-459f-aefe-1a5e2c7a96a4	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
fc20ef71-32d5-499e-a0e5-d5ea20168e99	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
b12d3e75-31b7-4579-98ad-e3d0c042b0ac	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
af418a84-1639-402c-a37c-4f43e64fa3f7	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	13	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
fed4ac55-4681-4abc-a4b7-7422137c5101	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
a1f54c7f-1d7a-4410-83c7-c5f3a08a5bde	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
c9c5fdda-8d5e-4b23-9c6a-cb09f5a251c6	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
a8891cf1-94d2-4ebe-9923-ccfa06447fd3	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
83faa7fe-645f-4447-a71b-e414747f6429	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
84c43ca1-8fde-4cfa-a2fb-1fd293d0f468	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
b4b1edd1-4ab1-40e8-8fa4-e51d015fae5a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
19e5362c-f5b1-46f9-99dc-a65f9d71fb59	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
a81c02ee-edaf-4962-8bb4-e10014063090	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
2b9a6de3-56ea-4d41-a1a4-c87a86a53206	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	9	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
0bb1eb58-0fbf-4dbb-a483-a556b5a2af2d	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
41f656c9-4eac-4451-b58f-c1f650385b52	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	30	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
79b8f01b-41f4-4188-a659-2691f5686e61	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
611a1fd1-7c13-451d-819d-b96043e25d8b	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
ae8b3184-ad87-4edd-9009-10b3fee31d79	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
be1a3b24-3790-40ab-833e-75aa0c10761c	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	43	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
7208330c-c7f6-4b46-8e7d-92d946fa3039	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
cecf7f56-6445-45c3-ad2c-96a5bef4f0c5	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d83b79ce-09db-45ac-b7cd-599c03156427	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
5200ff95-4cf7-43ce-aa1f-5479cda855a3	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	6	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
1c3e2c7d-ef31-43d8-992e-fcae335f4034	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
c7dfb1b1-fe9b-44a2-93cd-e5d2a0aee05f	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
11a0242d-2fc6-415c-a6c8-da1aaa14c01a	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
36109611-ecab-49ee-9c62-04af1561852e	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
ab1cf98a-2c0b-4089-87ef-cd7285067b4f	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
3c4d973b-06ae-4fe7-a6b5-262334cab21c	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
e991dca4-7357-4c6c-b0ae-0f197a49d4e0	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
66bd4efa-d1ba-4c78-a377-fe09bdfd2548	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	36	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
8cd06a65-dff6-4458-95ab-6af9f80be967	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
4beca29a-9c76-4715-8519-6f5a5e8a2f4c	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
2f45dc91-7f78-4187-975b-08a2ff2ba64e	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
5388c2db-b5a9-4691-93af-f8268af01663	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
a33eee1e-3786-435b-9c8b-e54d83c4bd74	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	12	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
dc142de9-a7b0-4ba8-a180-fe8cf59f4d1a	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	21	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
23c6db8d-c0e8-4710-8195-9c039cbc9549	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
031a549c-9ae9-4d69-92ad-a2c7fbd00156	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
01e264c1-86e0-4be8-bfee-325cb53e7a57	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
5bb03531-ffd7-4550-8a8a-e41673fd91d3	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
678e3916-46fa-4786-a0fc-ff9a22e25b25	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
7f64df46-acba-4e02-957f-dbc0fa63c849	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
ce8414ed-500b-4233-b7ec-e5d0d371fb30	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
64bddede-b02d-4bba-b918-8c8c8c3d3810	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	40	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
394879ab-832e-4036-bc9d-d18f832c69ad	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	31	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
907565a6-eb01-4e7f-8cdb-d10051a421a4	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
ef9c739b-91ee-4433-9477-b4e3447feec9	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
e2181c7e-eb03-4fdc-aa81-207ed1592e1d	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
843cc128-ed9c-434d-9016-fd7e03f4878a	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
880f0091-a993-4640-8fb0-679c950bd5a1	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	5	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
90d18762-14b9-44fe-b3d4-c3e589b104a8	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
5b985d5c-f3f9-4151-be99-276c1bd94bce	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	29	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
79fae4d3-ea33-4d08-8684-55a12dd85511	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	16	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
307f18b9-7811-421a-be3a-da24d7409392	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	7	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
27196ddc-2dce-4482-b12e-08ff5e4a2d43	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
5378011d-e655-4301-91d2-0815d0e219b4	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
395fab1b-6a8a-4042-808b-f400a88d145c	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
f2182b8a-efac-470c-8335-431a6bd9862f	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
41a11fe5-3a47-498f-ba88-805897881478	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
bf9d048f-68cf-4fc7-9ece-ae811b02cf19	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d0eb1437-0def-4de8-be2b-500a28649ed6	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	15	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
88cb520b-3460-450f-9eed-20f68086913d	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
6ddd0b32-beab-44c3-97bb-9421f14322e7	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
942b53cd-bab8-41ac-a5ff-d8b9d9c42fc4	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	18	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
a88d1944-9d6f-4408-aad1-6349f2e0c9a0	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
3093c06c-e93a-4425-9c90-e43e7f854c69	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	22	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
10bf26be-00e2-4581-80e9-9058a4c3b59b	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d653a753-d00e-4216-81b5-f34cda45a98a	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
f8f72085-5f40-476c-bcae-4d80b73c0dc3	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
abeee44b-27a4-4c25-87a4-eeab65fc5827	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
c9b5da25-49c2-4460-9c7c-a8a9f6718a30	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
42951234-bfdd-45c4-9ed4-b8f27383efbe	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
b69494b5-045b-4e96-af93-d8883b52412e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	24	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
8f0c3166-6863-4235-96ec-21f8d169ea5e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
ae8e0871-0259-4a6b-bd3c-26b76599b99c	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	1	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
fac4c7a0-d5e9-410c-810e-6bccd2e57cdb	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d3c56087-63c6-40a6-8be5-ae22ef7833fe	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
6bcd2942-ec93-4f5a-8fca-cc9a84051dd9	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	11	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
0328254f-567d-4620-93db-7e4d15499f82	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
cc0b8416-d5ad-4da7-a23a-941a3990882f	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	28	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
16860c00-b9fe-446b-a89d-c3e4603129df	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	low_stock	38	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
f7f282cd-3aaf-4fd7-8eb9-a3d2d9392d76	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
64df471e-6cca-47e5-9d14-6ba8dc8eec52	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
6d375a5e-449e-4989-b062-d6971ebc4d46	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
853e7ae6-db42-460e-9e10-a44c81605f88	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	50	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d380c22a-335c-4755-9954-7839356fce73	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	low_stock	27	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
b625ab89-4f28-4990-ad8b-0cff9d783259	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d799bd88-6740-45c4-9233-04842f3597b5	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
949c2eb4-3594-4abb-b6ac-851ab16f7552	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	low_stock	14	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
44de2a8d-d74b-4ad1-ad87-c82ac1e3638d	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	39	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
ca22abc9-6c00-48ab-a184-67dfcde1c43b	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d7906327-de62-4d88-89fe-f54562966730	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	37	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
c10413e7-f183-4abe-8d95-46746cea2f5a	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	49	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
4a9b3976-1dd4-46be-9343-0a4b30944494	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	20	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
b7149fc0-a557-4405-821c-64915e730ff5	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	in_stock	46	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
a1b9c970-3871-494d-a6fd-49e5434c3787	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
cd26606d-09f2-4555-bb08-c8891d2ec68e	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
92b665fa-dbb9-4c31-93f6-bf5a5789805d	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
f29c0571-53a8-4e0d-8952-c3567b76939e	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	2	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
91832493-55df-491e-90b2-5884a4b1a5b8	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
c86ab9db-4269-427a-92b5-60cc714fc62f	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
19fceb1f-c594-413d-8d76-f84d657752c5	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	low_stock	3	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
42940ff6-31e4-4f58-8c12-55fe9acc2fc0	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	low_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
561df9cb-9f8a-408c-a086-e2d87cacdc1e	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	23	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
cdcaf975-b56b-4c10-9dca-ab5594343275	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
78be1950-06c4-4c41-af56-bed89ebf642a	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	in_stock	19	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
f343963c-e9ce-45f3-8709-90f31a95b76b	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	out_of_stock	0	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
d394333b-77dc-490b-877b-a9f92a7a9a9c	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	in_stock	34	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
005ca556-4740-4533-bbf3-003e88fa74b6	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	in_stock	25	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
0019315e-9422-4c3b-8006-c757f0940750	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	in_stock	45	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
e4a86015-0f59-4128-a262-b045410ba5d5	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	in_stock	47	2025-09-03 22:19:06.323+00	2025-09-04 20:00:00.13+00
\.


--
-- TOC entry 4391 (class 0 OID 17490)
-- Dependencies: 263
-- Data for Name: billing_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_events (id, stripe_customer_id, subscription_id, event_type, amount_cents, currency, status, invoice_id, occurred_at, raw_event, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4385 (class 0 OID 17342)
-- Dependencies: 257
-- Data for Name: comment_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_likes (id, comment_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4382 (class 0 OID 17266)
-- Dependencies: 254
-- Data for Name: community_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.community_posts (id, user_id, user_name, user_avatar, type, title, content, images, tags, likes, comments_count, is_public, is_featured, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4392 (class 0 OID 17505)
-- Dependencies: 264
-- Data for Name: conversion_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversion_analytics (id, user_id, event_type, source, medium, campaign, metadata, event_date) FROM stdin;
\.


--
-- TOC entry 4379 (class 0 OID 17194)
-- Dependencies: 251
-- Data for Name: csv_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.csv_operations (id, user_id, operation_type, filename, total_rows, successful_rows, failed_rows, errors, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4372 (class 0 OID 17041)
-- Dependencies: 244
-- Data for Name: data_quality_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_quality_metrics (id, product_id, data_source, completeness_score, freshness_hours, accuracy_score, missing_fields, overall_quality_score, recommendations, assessed_at) FROM stdin;
\.


--
-- TOC entry 4377 (class 0 OID 17150)
-- Dependencies: 249
-- Data for Name: discord_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discord_servers (id, user_id, server_id, channel_id, token, alert_filters, is_active, total_alerts_sent, last_alert_sent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4394 (class 0 OID 17551)
-- Dependencies: 266
-- Data for Name: drop_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drop_events (id, product_id, retailer_id, signal_type, signal_value, source, confidence, observed_at, created_at, updated_at) FROM stdin;
52aa84d8-ba4b-453c-b2f0-64e6fcb5f904	b799d31f-424e-47c5-8dba-5d8a4af90512	a3d4e08f-d21d-4bad-b83c-8499566c2930	url_live	https://www.target.com/s?searchTerm=pok%2Bmon%2Btcg%2Belite%2Btrainer%2Bbox%2Bsurging%2Bsparks	url-candidate-checker	85.00	2025-09-04 16:16:20.079+00	2025-09-04 16:16:20.079+00	2025-09-04 16:16:20.079+00
\.


--
-- TOC entry 4395 (class 0 OID 17574)
-- Dependencies: 267
-- Data for Name: drop_outcomes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drop_outcomes (id, product_id, retailer_id, drop_at, first_seen_at, first_instock_at, buy_window_sec, success_flag, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4364 (class 0 OID 16862)
-- Dependencies: 236
-- Data for Name: email_bounces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_bounces (id, message_id, bounce_type, bounce_sub_type, bounced_recipients, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4365 (class 0 OID 16873)
-- Dependencies: 237
-- Data for Name: email_complaints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_complaints (id, message_id, complained_recipients, feedback_type, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4362 (class 0 OID 16841)
-- Dependencies: 234
-- Data for Name: email_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_delivery_logs (id, user_id, alert_id, email_type, recipient_email, subject, message_id, sent_at, delivered_at, bounced_at, complained_at, bounce_reason, complaint_reason, metadata, created_at, updated_at) FROM stdin;
email_1756919173617_bv7v21nkg	0b5d6a4f-8fd8-439b-9d75-6e0933be5b7e	\N	system	derekmihlfeith@gmail.com	Verify your email for BoosterBeacon	<8dfd01f4-f9d6-446a-c6fb-c6c23dc24dad@boosterbeacon.com>	2025-09-03 17:06:13.617+00	\N	\N	\N	\N	\N	{"category": "verification"}	2025-09-03 17:06:13.617743+00	2025-09-03 17:06:13.617743+00
\.


--
-- TOC entry 4361 (class 0 OID 16830)
-- Dependencies: 233
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_preferences (id, user_id, alert_emails, marketing_emails, weekly_digest, unsubscribe_token, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4370 (class 0 OID 16989)
-- Dependencies: 242
-- Data for Name: engagement_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.engagement_metrics (id, product_id, watch_count, alert_count, click_count, click_through_rate, search_volume, social_mentions, engagement_score, trend_direction, metrics_date, calculated_at) FROM stdin;
\.


--
-- TOC entry 4393 (class 0 OID 17532)
-- Dependencies: 265
-- Data for Name: external_product_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_product_map (id, retailer_slug, external_id, product_id, product_url, last_seen_at, created_at, updated_at) FROM stdin;
ada841fe-d9c7-47ba-92b1-997dcdea6957	best-buy	6548371	133cb1a8-1700-4717-a5e7-25a772ef5959	https://api.bestbuy.com/click/-/6548371/pdp	2025-09-04 15:02:32.958+00	2025-09-04 15:02:32.96+00	2025-09-04 15:02:32.96+00
ac1aede5-88d9-4c3f-ba81-85f9a26b3673	best-buy	6562098	e992a9bd-a88c-40a7-81e2-74094b08ffb0	https://api.bestbuy.com/click/-/6562098/pdp	2025-09-04 15:01:31.211+00	2025-09-04 15:01:31.213+00	2025-09-04 15:01:31.213+00
d81ba915-f814-4276-926d-499682d24a5e	best-buy	6548417	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	https://api.bestbuy.com/click/-/6548417/pdp	2025-09-04 15:01:31.216+00	2025-09-04 15:01:31.218+00	2025-09-04 15:01:31.218+00
94f0f666-22ee-4e07-a4ae-f03d34956f98	best-buy	6593879	f0353094-2fbd-42af-9333-6ed59071a433	https://api.bestbuy.com/click/-/6593879/pdp	2025-09-04 15:01:31.221+00	2025-09-04 15:01:31.223+00	2025-09-04 15:01:31.223+00
f65748fb-8888-4ea9-94e6-eddf36808047	best-buy	6642990	f0353094-2fbd-42af-9333-6ed59071a433	https://api.bestbuy.com/click/-/6642990/pdp	2025-09-04 15:01:31.226+00	2025-09-04 15:01:31.228+00	2025-09-04 15:01:31.228+00
9293a4cb-d54f-484e-a5ec-b13d167a73fc	best-buy	6500508	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	https://api.bestbuy.com/click/-/6500508/pdp	2025-09-04 15:01:31.231+00	2025-09-04 15:01:31.232+00	2025-09-04 15:01:31.232+00
96f558bd-4b83-467e-838b-6f2e8954725d	best-buy	6506756	d4708878-a77a-494e-9cfb-408546e56744	https://api.bestbuy.com/click/-/6506756/pdp	2025-09-04 15:01:31.235+00	2025-09-04 15:01:31.237+00	2025-09-04 15:01:31.237+00
d48b0be7-7c3d-4190-8aa1-6c5bb9f9375a	best-buy	6516474	d9b02003-c537-45a2-84d1-7d054a5419b4	https://api.bestbuy.com/click/-/6516474/pdp	2025-09-04 15:01:31.24+00	2025-09-04 15:01:31.241+00	2025-09-04 15:01:31.241+00
3a2ae370-7a51-45f2-a6ad-00e96a98f6aa	best-buy	6543916	b411b2ac-b68f-4a43-be65-2e4057d3e705	https://api.bestbuy.com/click/-/6543916/pdp	2025-09-04 15:01:31.244+00	2025-09-04 15:01:31.245+00	2025-09-04 15:01:31.245+00
8a4c5475-1fda-4a45-a6c8-4aa90c5d4692	best-buy	6569653	477d4790-531e-49f5-95eb-aba575e6ccdb	https://api.bestbuy.com/click/-/6569653/pdp	2025-09-04 15:01:31.249+00	2025-09-04 15:01:31.25+00	2025-09-04 15:01:31.25+00
26650820-fa91-4a40-9e56-28d6a5ab98ef	best-buy	6573891	69677974-4220-4141-8da6-b77681a0468a	https://api.bestbuy.com/click/-/6573891/pdp	2025-09-04 15:01:31.253+00	2025-09-04 15:01:31.259+00	2025-09-04 15:01:31.259+00
e3393c6d-70f1-47c9-a15b-f3445ec84b14	best-buy	6580252	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	https://api.bestbuy.com/click/-/6580252/pdp	2025-09-04 15:01:31.262+00	2025-09-04 15:01:31.264+00	2025-09-04 15:01:31.264+00
2cec643a-713b-4025-98c2-b439f4710ed6	best-buy	6580253	d8b06d4e-7869-44df-9d5e-35e7c771be57	https://api.bestbuy.com/click/-/6580253/pdp	2025-09-04 15:01:31.266+00	2025-09-04 15:01:31.268+00	2025-09-04 15:01:31.268+00
c4872ff8-6a8a-4f75-9a67-2e445e01c4cb	best-buy	6586142	468d4217-6c02-458f-aad7-5242437b2a7d	https://api.bestbuy.com/click/-/6586142/pdp	2025-09-04 15:01:31.271+00	2025-09-04 15:01:31.272+00	2025-09-04 15:01:31.272+00
70002a2e-f409-4158-9d94-57a8ad72ef4a	best-buy	6590380	939c25a1-fe07-46bf-87a4-d485be7c1857	https://api.bestbuy.com/click/-/6590380/pdp	2025-09-04 15:01:31.275+00	2025-09-04 15:01:31.276+00	2025-09-04 15:01:31.276+00
6d69ec99-dc28-4281-bd28-4db4b8a62452	barnes-noble	how-the-pokemon-trading-card	b799d31f-424e-47c5-8dba-5d8a4af90512	https://www.barnesandnoble.com/w/how-the-pokemon-trading-card-game-became-a-global-trading-card-game-phenomenon-and-how-to-earn-revenue-as-a-tcg-player-dr-harrison-sachs/1148048769?ean=2940184527086	2025-09-04 15:01:31.28+00	2025-09-04 15:01:31.281+00	2025-09-04 15:01:31.281+00
a5a4ca84-9acf-4eac-9e08-ebaaa5ed6da6	best-buy	6571897	45ad0421-328b-4b17-9690-4d44e691791f	https://api.bestbuy.com/click/-/6571897/pdp	2025-09-04 15:02:02.151+00	2025-09-04 15:02:02.153+00	2025-09-04 15:02:02.153+00
71bd39d2-8104-4264-93c4-8d69fadccde6	barnes-noble	pokemon-bw-rival-destinies	fa60ea0e-235c-4175-9f87-aac9e97776df	https://www.barnesandnoble.com/w/dvd-pokemon-bw-rival-destinies-pokemon-bw-rival-destinies-6pc-box/37473242;jsessionid=998AAC1D036792BE9365448DA71AB63D.prodny_store01-atgap07?ean=0782009246886	2025-09-04 15:02:02.156+00	2025-09-04 15:02:02.158+00	2025-09-04 15:02:02.158+00
fd97f2d9-0db4-4d8e-bfc7-ed024ff79b09	barnes-noble	pok-mon-primers-box-set	2876c949-9720-40fc-8b88-81dc37cdac38	https://www.barnesandnoble.com/w/pokemon-primers-simcha-whitehill/1144875913;jsessionid=998AAC1D036792BE9365448DA71AB63D.prodny_store01-atgap07?ean=9781604382204	2025-09-04 15:02:02.162+00	2025-09-04 15:02:02.163+00	2025-09-04 15:02:02.163+00
8d0b2a03-b8cc-4123-865b-b393c9101f5b	barnes-noble	pok-mon-primers-types-box-set	628a239b-b46f-473f-a7a0-31e32ac104b5	https://www.barnesandnoble.com/w/pokemon-primers-types-josh-bates/1143921927;jsessionid=998AAC1D036792BE9365448DA71AB63D.prodny_store01-atgap07?ean=9781604382402	2025-09-04 15:02:02.168+00	2025-09-04 15:02:02.161+00	2025-09-04 15:02:02.169+00
c7dea1c6-dfb9-4e9d-903c-ce784b0dac9d	barnes-noble	pok-mon-primers-type-box-set	be103772-ba92-41ac-bd86-cb1af3efd4c7	https://www.barnesandnoble.com/w/pokemon-primers-type-box-set-collection-volume-3-pikachu-press/1145008696;jsessionid=998AAC1D036792BE9365448DA71AB63D.prodny_store01-atgap07?ean=9781604382563	2025-09-04 15:02:02.171+00	2025-09-04 15:02:02.167+00	2025-09-04 15:02:02.172+00
d48b4fc6-1a52-4f97-9057-d25da31d20e0	barnes-noble	pokemon-battle-frontier-box	d53c1fbc-190a-4857-81ce-27c4d8593370	https://www.barnesandnoble.com/w/dvd-pokemon-battle-frontier-box-vol-2-pokemon-battle-frontier-box-2/15750003;jsessionid=998AAC1D036792BE9365448DA71AB63D.prodny_store01-atgap07?ean=0782009238805	2025-09-04 15:02:02.175+00	2025-09-04 15:02:02.177+00	2025-09-04 15:02:02.177+00
27a04909-86c9-4d02-885d-21acaffcb57e	barnes-noble	pokemon-palafin-ex-box	80eb95a5-6352-4a2c-a61a-a5d95d1bbb67	https://www.barnesandnoble.com/w/pokemon-palafin-ex-box-pokemon/1145767565;jsessionid=998AAC1D036792BE9365448DA71AB63D.prodny_store01-atgap07?ean=0097712562704	2025-09-04 15:02:02.179+00	2025-09-04 15:02:02.181+00	2025-09-04 15:02:02.181+00
f174abd7-445e-4fe1-9980-3c2bf45b8994	best-buy	6578901	b1f621a7-58f9-4331-89d8-30fef84cf142	https://api.bestbuy.com/click/-/6578901/pdp	2025-09-04 15:02:32.963+00	2025-09-04 15:02:02.147+00	2025-09-04 15:02:32.965+00
86593aa5-665e-4064-acda-fbd98739666a	best-buy	6587212	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	https://api.bestbuy.com/click/-/6587212/pdp	2025-09-04 15:02:32.967+00	2025-09-04 15:02:32.969+00	2025-09-04 15:02:32.969+00
f1254cf5-0c76-409f-947a-ffc133ba02ca	best-buy	6595705	66b0a163-79ec-4390-8e4f-9745ef86dc29	https://api.bestbuy.com/click/-/6595705/pdp	2025-09-04 15:02:32.972+00	2025-09-04 15:02:32.974+00	2025-09-04 15:02:32.974+00
2b675c02-6b44-48ee-a120-602125dfbbe5	best-buy	6584432	8302fac6-b536-46ab-aac6-377d9a88c360	https://api.bestbuy.com/click/-/6584432/pdp	2025-09-04 15:02:32.977+00	2025-09-04 15:02:32.978+00	2025-09-04 15:02:32.978+00
286927b5-0ad0-49b0-9061-5c65a8fe5590	best-buy	6607716	0933e019-c545-48ba-8ba1-854a9cfc84fa	https://api.bestbuy.com/click/-/6607716/pdp	2025-09-04 15:02:48.375+00	2025-09-04 15:02:48.383+00	2025-09-04 15:02:48.383+00
55755b86-0da9-4cac-9483-5072af679dc0	best-buy	6569648	cadea567-c448-4789-872d-49fa516ea9bb	https://api.bestbuy.com/click/-/6569648/pdp	2025-09-04 18:10:40.065+00	2025-09-04 18:09:54.554+00	2025-09-04 18:10:40.072+00
26713247-411b-4092-9f81-7aa59b470c05	best-buy	6506752	e48ccb10-a767-4605-a0ff-f23480597124	https://api.bestbuy.com/click/-/6506752/pdp	2025-09-04 18:10:40.078+00	2025-09-04 15:01:31.206+00	2025-09-04 18:10:40.08+00
\.


--
-- TOC entry 4346 (class 0 OID 16496)
-- Dependencies: 218
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	001_initial_schema.js	1	2025-09-03 16:36:02.672+00
2	20250826174814_expand_core_schema.js	1	2025-09-03 16:36:02.826+00
3	20250826180000_add_push_subscriptions.js	1	2025-09-03 16:36:02.828+00
4	20250827000001_email_system.js	1	2025-09-03 16:36:02.876+00
5	20250827130000_add_ml_tables.js	1	2025-09-03 16:36:02.937+00
6	20250827140000_add_user_roles.js	1	2025-09-03 16:36:02.98+00
7	20250827140001_add_missing_user_fields.js	1	2025-09-03 16:36:02.981+00
8	20250827140005_validate_admin_setup.js	1	2025-09-03 16:36:02.997+00
9	20250827140006_add_registration_fields.js	1	2025-09-03 16:36:02.998+00
10	20250827150000_add_community_integration_tables.js	1	2025-09-03 16:36:03.08+00
11	20250827160000_implement_granular_rbac.js	1	2025-09-03 16:36:03.122+00
12	20250829151931_create_subscription_plans_table.js	1	2025-09-03 16:36:03.132+00
13	20250901090000_create_transactions_and_billing_events.js	1	2025-09-03 16:36:03.15+00
14	20250901151600_add_conversion_analytics.js	1	2025-09-03 16:36:03.158+00
15	20250901152000_add_user_subscription_columns.js	1	2025-09-03 16:36:03.166+00
16	20250901154000_add_user_subscription_plan_id.js	1	2025-09-03 16:36:03.168+00
17	20250902140000_add_watch_auto_purchase.js	1	2025-09-03 16:36:03.174+00
18	20250904090000_add_drop_detection_tables.js	2	2025-09-04 15:31:50.915+00
\.


--
-- TOC entry 4348 (class 0 OID 16503)
-- Dependencies: 220
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- TOC entry 4369 (class 0 OID 16975)
-- Dependencies: 241
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_model_metrics (id, model_name, model_version, prediction_type, accuracy, "precision", recall, f1_score, mean_absolute_error, root_mean_square_error, training_data_size, prediction_count, avg_processing_time, last_trained_at, last_evaluated_at, created_at) FROM stdin;
\.


--
-- TOC entry 4374 (class 0 OID 17086)
-- Dependencies: 246
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, version, status, config, metrics, model_path, training_started_at, training_completed_at, deployed_at, trained_by, training_notes, created_at, updated_at) FROM stdin;
a139aaf0-9ce6-43d5-a308-130a64588316	price_prediction	v1.0	active	{"algorithm": "ARIMA", "forecast_days": 7, "lookback_days": 30}	{"mae": 2.34, "rmse": 3.12, "accuracy": 0.85}	\N	2025-08-27 16:53:58.369+00	2025-08-28 16:53:58.369+00	2025-08-28 16:53:58.369+00	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
b9f29bf2-92a8-4efe-8ed8-026c5fa19350	sellout_risk	v1.2	active	{"features": ["price_history", "availability_patterns", "user_engagement"], "algorithm": "Random Forest"}	{"recall": 0.94, "accuracy": 0.92, "precision": 0.89}	\N	2025-08-31 16:53:58.369+00	2025-09-01 16:53:58.369+00	2025-09-01 16:53:58.369+00	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
8a5afdf6-05e7-43e8-b368-a0840f42265f	roi_estimation	v0.8	training	{"algorithm": "LSTM", "hidden_units": 128, "sequence_length": 14}	{}	\N	2025-09-02 16:53:58.369+00	\N	\N	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
7d120a5d-9a8c-4157-b7c6-e067a4d7b0d0	price	v1	active	{}	{"r2": -18797776067574.453, "rows": 36}	/app/data/ml/price_model.json	2025-09-04 20:37:28.93+00	2025-09-04 20:37:28.975+00	2025-09-04 20:37:28.975+00	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	Triggered retraining from admin dashboard	2025-09-04 20:37:28.930206+00	2025-09-04 20:37:28.975+00
279a735b-bfbc-46ef-a0ff-185e11354d13	drop-windows	v1	active	{}	{"events_30d": 1, "feature_rows": 1, "retailers_30d": 1}	/app/data/ml/drop_window_model.json	2025-09-04 20:37:34.807+00	2025-09-04 20:37:34.816+00	2025-09-04 20:37:34.816+00	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	Triggered retraining from admin dashboard	2025-09-04 20:37:34.807752+00	2025-09-04 20:37:34.816+00
45e080ea-3c78-47ec-86ff-42ea1836145f	drop-windows	v2	active	{}	{"events_30d": 1, "feature_rows": 1, "retailers_30d": 1}	/app/data/ml/drop_window_model.json	2025-09-04 22:22:07.618+00	2025-09-04 22:22:07.643+00	2025-09-04 22:22:07.643+00	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	Triggered retraining from admin dashboard	2025-09-04 22:22:07.620024+00	2025-09-04 22:22:07.643+00
10a99a4b-5865-43d9-9205-458b7280bda7	price	v2	active	{}	{"r2": -18797776067574.453, "rows": 36}	/app/data/ml/price_model.json	2025-09-04 22:22:08.571+00	2025-09-04 22:22:08.607+00	2025-09-04 22:22:08.607+00	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	Triggered retraining from admin dashboard	2025-09-04 22:22:08.571635+00	2025-09-04 22:22:08.608+00
\.


--
-- TOC entry 4368 (class 0 OID 16957)
-- Dependencies: 240
-- Data for Name: ml_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_predictions (id, product_id, prediction_type, prediction_data, timeframe_days, input_price, confidence_score, expires_at, created_at) FROM stdin;
\.


--
-- TOC entry 4375 (class 0 OID 17112)
-- Dependencies: 247
-- Data for Name: ml_training_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_training_data (id, dataset_name, data_type, data, status, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
7dd8a9cc-9dc5-4404-91a5-c04bf1de9a6f	pokemon_tcg_prices_q4_2024	price_history	{"products": ["charizard_151", "pikachu_promo"], "date_range": "2024-10-01 to 2024-12-31", "price_points": 1250}	pending	\N	\N	\N	2025-09-03 16:53:58.374142+00	2025-09-03 16:53:58.374142+00
9ac0295c-1d42-455c-8436-e5d2097b0e45	availability_patterns_holiday_2024	availability_patterns	{"retailers": ["best_buy", "walmart", "costco"], "pattern_count": 890, "seasonal_factor": "holiday_rush"}	approved	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	2025-09-03 16:53:58.374142+00	\N	2025-09-03 16:53:58.374142+00	2025-09-03 16:53:58.374142+00
\.


--
-- TOC entry 4396 (class 0 OID 17594)
-- Dependencies: 268
-- Data for Name: model_features; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_features (id, product_id, retailer_id, as_of, features, label, split_tag, created_at, updated_at) FROM stdin;
886f7b9f-e88a-43cd-932a-ddbf8f99cff0	b799d31f-424e-47c5-8dba-5d8a4af90512	a3d4e08f-d21d-4bad-b83c-8499566c2930	2025-09-04 20:37:28.977+00	{"hours": {"in_stock": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "url_live": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], "url_seen": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "price_present": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "status_change": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}, "counts": {"in_stock": 0, "url_live": 1, "url_seen": 0, "price_present": 0, "status_change": 0}, "availability_ratio": 0}	\N	manual	2025-09-04 20:37:28.979+00	2025-09-04 20:37:28.979+00
78d611b6-c004-4b62-b290-e0db34d3711c	b799d31f-424e-47c5-8dba-5d8a4af90512	a3d4e08f-d21d-4bad-b83c-8499566c2930	2025-09-04 20:37:34.812+00	{"hours": {"in_stock": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "url_live": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], "url_seen": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "price_present": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "status_change": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}, "counts": {"in_stock": 0, "url_live": 1, "url_seen": 0, "price_present": 0, "status_change": 0}, "availability_ratio": 0}	\N	manual	2025-09-04 20:37:34.813+00	2025-09-04 20:37:34.813+00
e3bba95f-dc12-4f84-9935-414e2354bcc6	b799d31f-424e-47c5-8dba-5d8a4af90512	a3d4e08f-d21d-4bad-b83c-8499566c2930	2025-09-04 22:22:07.633+00	{"hours": {"in_stock": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "url_live": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], "url_seen": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "price_present": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "status_change": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}, "counts": {"in_stock": 0, "url_live": 1, "url_seen": 0, "price_present": 0, "status_change": 0}, "availability_ratio": 0}	\N	manual	2025-09-04 22:22:07.636+00	2025-09-04 22:22:07.636+00
cceaecfd-0e00-403c-900d-c5c2c633aff2	b799d31f-424e-47c5-8dba-5d8a4af90512	a3d4e08f-d21d-4bad-b83c-8499566c2930	2025-09-04 22:22:08.609+00	{"hours": {"in_stock": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "url_live": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], "url_seen": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "price_present": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], "status_change": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}, "counts": {"in_stock": 0, "url_live": 1, "url_seen": 0, "price_present": 0, "status_change": 0}, "availability_ratio": 0}	\N	manual	2025-09-04 22:22:08.611+00	2025-09-04 22:22:08.611+00
\.


--
-- TOC entry 4388 (class 0 OID 17418)
-- Dependencies: 260
-- Data for Name: permission_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_audit_log (id, actor_user_id, target_user_id, action, permission_or_role, old_value, new_value, reason, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4383 (class 0 OID 17294)
-- Dependencies: 255
-- Data for Name: post_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_comments (id, post_id, user_id, user_name, user_avatar, content, likes, is_public, moderation_status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4384 (class 0 OID 17321)
-- Dependencies: 256
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_likes (id, post_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4358 (class 0 OID 16771)
-- Dependencies: 230
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, product_id, retailer_id, price, original_price, in_stock, availability_status, recorded_at) FROM stdin;
e7b5996a-ee7b-4365-9330-5fb5e1d08cc2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-03 23:00:00.764+00
074629a2-dda9-46b6-a5ea-9033f7b14a21	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-03 23:00:00.764+00
a5d8f5ea-7b0a-4669-9b89-46c208e18d19	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-03 23:00:00.764+00
2f7c95ec-f9e7-4451-a0ef-9f76b8db2b27	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-03 23:00:00.764+00
854d4bc3-ea96-4e39-9b0a-68c0cbb6ef0a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-03 23:00:00.764+00
5ffc3629-8a3b-48bf-bf24-40893f3a698b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-03 23:00:00.764+00
566f500d-f40f-48a9-b589-18bf17b69069	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-03 23:00:00.764+00
10d03a1f-031e-4dbf-8b4e-8ce7ee4fd549	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-03 23:00:00.764+00
ff8283cd-8834-487f-9415-2ea4fc349a0b	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-03 23:00:00.764+00
7d3216b7-b650-4b77-9876-f71efe5e2f3c	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-03 23:00:00.764+00
8bfd4641-9671-49c1-b7a5-92eca4c741f7	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-03 23:00:00.764+00
020f436e-a803-4bec-a673-6cd95416fe5b	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-03 23:00:00.764+00
b9c35cc8-50a8-40d4-a111-a839e6415c1b	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-03 23:00:00.764+00
b0f625dd-8b44-431a-83bd-7c25bc634bad	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-03 23:00:00.764+00
218f28dc-ecfc-43ab-ace2-81ce8b5603ff	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-03 23:00:00.764+00
e910a6c2-7d8e-4e2f-ad60-ef9cb43fe981	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-03 23:00:00.764+00
7fe15469-bba7-4964-9a00-6c246d492b9a	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-03 23:00:00.764+00
3aafabc5-3446-45d3-a323-9503f1e7c34f	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-03 23:00:00.764+00
a177a219-107d-47f7-b9f0-8f6b29042acd	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-03 23:00:00.764+00
a928d341-a366-48fa-ba27-2b439d4038e9	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-03 23:00:00.764+00
f0ebf598-f181-4790-bb70-c444541f9aa0	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-03 23:00:00.764+00
3d345090-e51f-4286-8c10-96f39547fd4a	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-03 23:00:00.764+00
31ace85b-8998-4c02-901e-346ee1928ff9	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-03 23:00:00.764+00
248e0195-dbbd-4f68-b020-cfb5ecabac6c	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-03 23:00:00.764+00
2c5f62eb-5481-46f8-a022-3565be3b60fa	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-03 23:00:00.764+00
23616ffb-3610-42e3-8187-27e0afabb4d9	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-03 23:00:00.764+00
75ed83dc-9ecd-4e79-92ff-05aa27314878	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-03 23:00:00.764+00
43a43b1a-bffe-47d1-9532-49311cbc80be	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-03 23:00:00.764+00
d49bd616-9cc9-485d-803d-c5fff8ae0830	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-03 23:00:00.764+00
021dbcbd-d8f3-4f8b-9fdb-52db6236b089	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-03 23:00:00.764+00
89fcf7fd-8280-4ea5-b9a9-fcbd6c9cfbe7	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-03 23:00:00.764+00
6000e4c4-8114-4478-86b5-fff0d4affc14	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-03 23:00:00.764+00
dda379c5-1400-4fce-88b2-87e9d5b7ee1d	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-03 23:00:00.764+00
3ef92a33-a8ff-4ff3-bf6b-e63305fc4385	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-03 23:00:00.764+00
67b2a38e-623c-4033-82d3-f2887fc64a66	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-03 23:00:00.764+00
7941f58d-bcf3-425c-ae78-f579742ae1f3	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-03 23:00:00.764+00
9d7ffbb3-4e6a-4f6f-bae1-3e1fe0e282c5	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-03 23:00:00.764+00
f44a8390-51d2-4786-951f-e34893e5eee1	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-03 23:00:00.764+00
ffc23e81-c796-423f-9572-14dc0e0c9e9f	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-03 23:00:00.764+00
fe15c7ad-3d78-450f-94c9-2fade8ec7a3c	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-03 23:00:00.764+00
1ad5e913-d3e7-4cb5-8a7c-a19ca6054f4a	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-03 23:00:00.764+00
95f91f8a-0345-4e7f-942c-5ac17d563945	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-03 23:00:00.764+00
f8a84051-d769-470b-8a72-bea0a53f52fd	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-03 23:00:00.764+00
502aaae0-8044-4a68-b5b3-44ad5110a8a0	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-03 23:00:00.764+00
c0088dbd-d850-4812-a9c3-f054bf7ad533	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-03 23:00:00.764+00
c3828038-fe44-4ef3-b42b-ab9ee7c3a090	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-03 23:00:00.764+00
1b4bcbc3-c960-450f-9292-5f4815162b79	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-03 23:00:00.764+00
76355cff-a36e-40df-a190-bf5839f2d022	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-03 23:00:00.764+00
b2c4b611-8962-4483-8646-5e4d8e79deaf	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-03 23:00:00.764+00
ab16d3da-ea34-4ad8-a5e0-9839bd2647a5	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-03 23:00:00.764+00
3ff84f58-60a3-48be-99d4-610ad3f03849	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-03 23:00:00.764+00
d2c6bdb1-5f49-44d4-9197-d52ad01a6804	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-03 23:00:00.764+00
3123dd0e-a1de-491b-94f4-282ab4162b4b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-03 23:00:00.764+00
b88726c3-a255-4cdf-a76b-f968fb622908	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-03 23:00:00.764+00
c51cb202-9a5d-44f0-9f7b-9485f04a04f5	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-03 23:00:00.764+00
0c297566-9c47-42e7-89c0-e6e37b4bf74d	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-03 23:00:00.764+00
38eeb694-caa4-48cd-943f-075d45a2426a	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-03 23:00:00.764+00
dd9af54e-656c-4aff-a294-439826d1b4b7	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-03 23:00:00.764+00
30a2d5c3-8550-44ad-8aca-5e98f5bb8e03	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-03 23:00:00.764+00
80f95d77-bf2e-4839-b8d7-5eaa231fbd75	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-03 23:00:00.764+00
067fe965-71e1-42f6-8983-2597c0705c47	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-03 23:00:00.764+00
3b6ef80b-315f-4db6-ad47-58c1729340b5	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-03 23:00:00.764+00
b705adb5-5ce5-4826-a6f7-52f34c08a28b	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-03 23:00:00.764+00
c4fa9e0b-fe32-4d12-9f52-0951ce922c80	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-03 23:00:00.764+00
db69bdf7-998c-44cb-b3bb-4387c34664f2	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-03 23:00:00.764+00
94700682-8f67-4e68-969f-2fb36888d3f8	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-03 23:00:00.764+00
7557d187-dad8-4c5b-bae2-1353d160921b	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-03 23:00:00.764+00
684297af-9a1f-4366-8ca3-4d1d29642370	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-03 23:00:00.764+00
26ab2b1a-5769-4310-a4d0-86c4edcc6cfb	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-03 23:00:00.764+00
d830f9f2-5b20-4da2-bb3d-7731f22376ca	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-03 23:00:00.764+00
21aa5dbd-a224-434b-8c0f-9126919e3ccf	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-03 23:00:00.764+00
9ad35322-eff2-4431-9342-788cb10b52b3	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-03 23:00:00.764+00
eda5a205-e8f0-4f1d-aca1-ff7c47400258	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-03 23:00:00.764+00
e102cd52-b2ea-4aaf-bea2-0304fa9ab025	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-03 23:00:00.764+00
6efb03a5-b918-47e8-b43d-b4363a543720	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-03 23:00:00.764+00
4e5bf888-7c9a-4e65-865b-753d67f7dca9	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-03 23:00:00.764+00
1c156381-d5c2-4fa1-9852-ba93c7a0c0ec	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-03 23:00:00.764+00
f297ad1a-3a34-489c-b2ca-a14fc323171b	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-03 23:00:00.764+00
fd7a9dcc-d3b9-4ab5-91a4-0990f63754ea	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-03 23:00:00.764+00
3e449231-eeef-4401-a82a-ec5f046030bb	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-03 23:00:00.764+00
da1ec3f9-0abd-444d-80fa-e85a96619cf9	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
3c705422-9219-4ded-b077-72f515e48cfb	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	399.99	\N	t	in_stock	2025-09-04 17:00:00.232+00
75542b39-859e-4219-903b-3b71b871fd91	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
befb5115-0ad3-4bc5-8226-b1de1209c7f2	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	34.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
3aed925f-f3e7-4625-a529-e38ac00f0215	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	t	in_stock	2025-09-04 17:00:00.232+00
faec272c-f21e-4793-9248-eca8dcff73c2	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	29.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
327b4a99-fec3-49f9-9c8c-b449abaa35d1	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
90b1e2ba-63ce-46a2-a139-c9ac9925a2dd	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
1121dcee-4f5a-4a89-a6e1-f70d8c5e73a4	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
8891afcc-72d6-47ce-a466-5f2cd0772e62	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
97f39c88-a771-4238-a93e-2e1c0b60225e	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
4e76850a-379d-4bce-b6ca-d3de03b01ede	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	24.99	\N	t	in_stock	2025-09-04 17:00:00.232+00
32bebada-ef5a-4a5f-b786-dfd0605625ad	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
953d339a-8f20-4509-b266-7aa55927265a	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
1fe2a227-f2e1-4290-81e7-8ef25861091d	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
ebea4ccf-59c4-4402-bd69-e833f3e4010e	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
458517ef-d4d3-40b8-952d-1e02f80c6a93	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
27dc033b-7c3d-4321-b68d-ebe2ad09b4f4	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	14.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
dc7604e1-8ada-425f-8460-a515ee3a0d68	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	23.94	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
c145e0b8-cd5f-4b09-8efb-e1761e2f14d5	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
67d06522-d4e9-41be-a16e-d1b66a98dc0f	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	9.99	\N	f	out_of_stock	2025-09-04 17:00:00.232+00
b9343a60-dfb9-425d-a793-62d5402da50c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 17:00:00.232+00
a669464e-f0db-4624-9fb0-c7a2c043ef84	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 17:00:00.232+00
63ec0f71-7b8d-4724-ac20-2eced7a85c31	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 17:00:00.232+00
85b2dd4c-6075-48f0-9e65-1bbc67b9095d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 17:00:00.232+00
b2c74e3f-b953-4559-852a-d695e7121d87	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 17:00:00.232+00
3d16da79-8b41-496c-a0f8-4ff984a19311	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 17:00:00.232+00
0a3d9e65-2b10-41cd-8e44-dc3092884bd3	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 17:00:00.232+00
e4126c72-d946-4d15-9272-4e1b74a5dca8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 17:00:00.232+00
ae07d981-98ca-4807-aa71-6c7da7bf10bf	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 17:00:00.232+00
146b25e5-ab95-447d-ba27-577d899d0054	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 17:00:00.232+00
aa42c896-fbc0-415e-861e-5e9b31b16e7c	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 17:00:00.232+00
b0c0bc50-c796-4a5a-b02a-059cac238023	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 17:00:00.232+00
ec45cc4e-94d3-4a1d-b991-1a12074bb64f	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 17:00:00.232+00
241a18f3-3ea5-423b-8b0f-124f50bd27c5	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 17:00:00.232+00
b24d4f29-f4b0-47d0-b3f5-f03c4b16fdab	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 17:00:00.232+00
8af93261-d983-486a-b1bf-d211eda54769	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 17:00:00.232+00
11e9d28a-6c03-44df-9e4e-26fb524b8b7b	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 17:00:00.232+00
194dcf72-c8dd-41f6-b941-e12e054629a8	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 17:00:00.232+00
fa762c89-9fb4-49fc-960a-bcded53c3528	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 17:00:00.232+00
61e4b67f-4ac4-4442-b359-9f9db96ececf	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 17:00:00.232+00
cfc3a3d6-21c6-4a4d-9aff-013dfec608e4	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 17:00:00.232+00
4602a8c4-1fec-4d6d-b338-33263c8e9fbf	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 17:00:00.232+00
32437a59-0110-45ac-a234-796cdecf9332	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 17:00:00.232+00
22dfc3e2-7d68-496b-9812-24fd21b02436	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 17:00:00.232+00
0c18d526-2862-4435-9835-d2d5def76c50	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 17:00:00.232+00
1306933a-54cb-48c5-8e18-2e4d47ff3e3e	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 17:00:00.232+00
de357f14-8daf-4f40-af76-87da4bd1a13e	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 17:00:00.232+00
e8fac4fe-b833-435d-b2e8-49234bea6ae2	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 17:00:00.232+00
423d638b-d83c-4896-b8d9-49a2a57b759b	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 17:00:00.232+00
659de098-113b-410f-8222-6cccfca15bac	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 17:00:00.232+00
2fecc430-eb7d-464d-8c7c-62fba650f3b6	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 17:00:00.232+00
d5065adb-8416-44fa-a350-d07027781912	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 17:00:00.232+00
bc303b24-2e34-47e7-8f63-0e586d5f4d2c	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 17:00:00.232+00
41724a66-c8e9-49e4-833c-02287b0cc310	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 17:00:00.232+00
9b388ac3-5f66-4c27-a811-34ac827a6d0e	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 17:00:00.232+00
434ab32d-7566-47d4-9b91-453075c2ab94	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 17:00:00.232+00
ab03e9b9-789e-4bcd-bccd-eaa10c3a8095	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 17:00:00.232+00
2bf85d5e-54cb-47ca-91d2-7ae207758333	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 17:00:00.232+00
4c0b7835-5a03-450a-a524-3a908a9fd973	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 17:00:00.232+00
66b50b92-975c-4e63-849d-f89542ca801c	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 17:00:00.232+00
86cba114-8530-4ae7-9d51-4da6790d4bdd	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 17:00:00.232+00
1dc60b25-f73e-4646-9c01-fd04fc9a856e	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 17:00:00.232+00
8e8ca213-0754-4ba2-9ceb-c037a4364b89	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 17:00:00.232+00
1f361466-ff58-4839-b569-bfb1e30f6f1b	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 17:00:00.232+00
7dd08d0b-84b9-4546-b710-e93d8e02707b	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 17:00:00.232+00
1c976b72-2367-4ae8-a2ac-97508639865e	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 17:00:00.232+00
6674bb6b-677b-4842-9c3f-c7a7804f5062	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 17:00:00.232+00
af49854c-8de5-40a8-a047-2aab92fe8ef3	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 17:00:00.232+00
87874e85-de10-4f0f-b7b6-b531e99f6fa2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 13:00:00.347+00
66b32bc6-309d-4b26-8a5a-c94351fd78c9	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 13:00:00.347+00
635867c0-bfed-4d1d-a1d2-3ac74a738b61	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 13:00:00.347+00
d06dc8f7-a0eb-472d-b493-3cbeb720fb7b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 13:00:00.347+00
26e3cd53-7033-45e6-abc4-9fbee73a907d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 13:00:00.347+00
f90012f8-cb06-4cbd-a644-366b0fa91b8c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 13:00:00.347+00
db0a3895-c9a9-4ffd-905b-664e245df5e8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 13:00:00.347+00
4d9aff0d-1a7a-46b2-b656-4ccde8439b65	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 13:00:00.347+00
8023cace-6fe2-405a-9d5e-c7949aaaadf1	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 13:00:00.347+00
1accd08d-8f54-4ca2-936b-65ace5b37a72	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 13:00:00.347+00
dfdf6643-4761-404e-9730-55721985ee38	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 13:00:00.347+00
c7e76e87-bd96-4584-bec2-e05db6384b92	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 13:00:00.347+00
f8c5cacd-ba58-4004-8978-eb27cb26aec6	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 13:00:00.347+00
230615f7-3f5e-44a0-8a3d-0b64b2ce7900	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 13:00:00.347+00
f75bdb71-28b6-427d-85fe-89759c409b6d	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 13:00:00.347+00
68f7b8e7-5087-45ed-a9e3-b818125eb91f	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 13:00:00.347+00
fb09d44a-cfab-4efa-a93f-d11570023288	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 13:00:00.347+00
db53ef86-a7c6-4e06-973f-2c94fb5a85d2	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 13:00:00.347+00
fc44af08-4d08-446f-a3c5-fd915a6eabf8	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 13:00:00.347+00
9cadeedc-328e-4919-a796-3c769298a691	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 13:00:00.347+00
c9a25a9d-e591-4409-807d-3ad1bbc523cc	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 13:00:00.347+00
3c442d61-55a8-449f-a31b-1d46b414f049	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 13:00:00.347+00
8a6534ac-f396-4eb1-8ce1-7ef2bf9a4eca	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 13:00:00.347+00
d22eb310-3819-4137-aa1e-e2755a999950	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 13:00:00.347+00
bb30073d-d26c-43ad-9d3c-c17414312cba	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 13:00:00.347+00
e8f3c455-17c7-419f-b8d1-565866f7b277	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 13:00:00.347+00
fbe195dc-478a-4aef-8304-d0b82bad96d1	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 13:00:00.347+00
0ca83f4b-068c-478c-bc14-e07d701f3a3f	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 13:00:00.347+00
2da9d7e4-c48e-4cda-94d6-1b7b2cdff433	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 13:00:00.347+00
98d63981-3948-44e7-bfad-6aae38eb949f	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 13:00:00.347+00
095e3592-a6c2-44c0-8e5d-d0f233bed69d	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 13:00:00.347+00
a8462f79-3c57-47bb-bde2-48e4fb27e590	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 13:00:00.347+00
1ac02048-11ad-4cb6-985a-8a47f3c03301	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 13:00:00.347+00
1d0ced06-60b6-4b98-babc-10a9d8ba383d	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 13:00:00.347+00
dc46d576-abce-4e85-99c8-2c661a66708c	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 13:00:00.347+00
43c35eb4-2658-4c30-a4a9-67260cd891b3	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 13:00:00.347+00
88790358-b652-431a-9a14-878507d548e0	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 13:00:00.347+00
1922c589-4648-4a03-b285-5a7717cc7c7d	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 13:00:00.347+00
365efd74-4acf-46a3-a71f-60fa16772a80	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 13:00:00.347+00
e6114cf8-e6fb-4e9a-94ba-32e0ac7876b0	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 13:00:00.347+00
2ca73170-c630-473b-871c-e8474adfc461	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 13:00:00.347+00
697fe619-1f37-4c48-a696-c42b9ac3a267	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 13:00:00.347+00
c886c495-b5d4-463c-ac14-b8babcfa67a6	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 13:00:00.347+00
8955c929-86f8-41dc-86fb-1295f7d8a7f1	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 13:00:00.347+00
83296a1d-5b53-475a-a09b-5de18d88d09e	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 13:00:00.347+00
44256ff1-f729-4e34-956f-4463b4329bef	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 13:00:00.347+00
3faaf15a-8831-41fa-a766-740cb76a84d5	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 13:00:00.347+00
fba618f1-b34f-4d45-afde-9e48f9695750	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 13:00:00.347+00
5b5b3665-e491-42ed-9107-6712ab839b42	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 13:00:00.347+00
c4814008-72a5-452e-80e8-d5f15c959792	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 13:00:00.347+00
1911501f-89dc-434f-aa28-3e7fcb89b82e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 13:00:00.347+00
de1d123c-58b6-4df6-9892-3db9b3289d96	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 13:00:00.347+00
7c387bd5-6f05-4acc-a646-dd1aff1d5a6b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 13:00:00.347+00
938302ef-be91-4216-9116-fe5550ad34b3	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 13:00:00.347+00
a8a9d781-c1a2-43da-8ab5-e49bdbd202da	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 13:00:00.347+00
367a3ecc-4ad5-4319-a099-87a631cf7124	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 13:00:00.347+00
83af811c-4366-4de3-b6e5-f7e68c4952e4	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 13:00:00.347+00
557195cd-1875-4272-80dd-978043015f83	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 13:00:00.347+00
b039ad05-7a25-47ed-9431-09087565144f	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 13:00:00.347+00
eac8cc25-d1a1-48a0-a530-30aa3eb3f24c	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 13:00:00.347+00
7dcd6550-6b89-42c4-830e-0e7010e9b91a	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 13:00:00.347+00
05c5450c-61d0-48bd-9592-23a66bad82df	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 13:00:00.347+00
76b01c9e-8650-4b92-8bb1-73cd51aca326	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 13:00:00.347+00
0235f316-f4b9-4474-8bef-27200d8a1520	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 13:00:00.347+00
196f995b-2dd6-40f1-be98-2389f471a261	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 13:00:00.347+00
92170d0b-f4f6-44af-9e08-51cf2514dd4a	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 13:00:00.347+00
616d8e2f-0ccd-4561-884e-8eb534a9aae7	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 13:00:00.347+00
4bc2fec7-e4d4-4b53-ba67-a22761e9e055	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 13:00:00.347+00
8f21f17b-2b71-4834-8015-7e05bb625448	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 13:00:00.347+00
207e9709-543d-4c82-99b2-8405ccae0faf	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 13:00:00.347+00
a0b3b47a-f05b-4a3f-bfb4-48f0e82a8ff1	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 13:00:00.347+00
e57c1040-f9ad-4e5d-8192-b5f9395cf2bb	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 13:00:00.347+00
97c88446-2eb7-4f89-b0c1-12775f1f24c0	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 13:00:00.347+00
04ff4437-3d32-4ae6-95e0-f76c8963daac	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 13:00:00.347+00
5c22de56-d576-4241-b04b-bb0b28d9acd3	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 13:00:00.347+00
3cc8e849-58ee-4037-967f-c8fc747fdda7	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 13:00:00.347+00
943d1572-3073-4bba-8fe3-ee1f336bf519	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 13:00:00.347+00
bbc7d3aa-57fc-4461-9918-7cb59ef9e18c	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 13:00:00.347+00
2886f6c5-8b9a-454f-bb05-6aa1995e387b	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 13:00:00.347+00
3e4243c5-7e96-4953-b742-d5c56fa67cf3	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 13:00:00.347+00
f7eebaf7-08d3-43db-b099-e4d78fbe17cd	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 17:00:00.232+00
798a943a-3200-4550-90db-1d18218fcf35	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 17:00:00.232+00
3b8a4160-372a-4e6f-8ca3-989a35dad08e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 17:00:00.232+00
15679735-22ff-4d8b-9a47-6b6f734a2891	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 17:00:00.232+00
d8e0592b-3f55-4860-977b-7d070ae04fe5	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 17:00:00.232+00
fafcc831-4747-456d-9eb2-0c234a0bbd3f	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 17:00:00.232+00
8eab62bc-c3d7-4e59-bff7-28613494530e	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 17:00:00.232+00
28f8d888-7817-45ca-8f96-825a6367a025	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 17:00:00.232+00
45c905a7-68e1-4dc1-92fc-0a2bd5d1016f	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 17:00:00.232+00
c65d0cde-c42f-4ee3-94f2-9b7c732a0fa2	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 17:00:00.232+00
611a2d4d-6a68-41d5-8344-150807f81f29	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 17:00:00.232+00
fbb62b9f-0ee5-40b2-adbf-1c153f322c22	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 17:00:00.232+00
a8b48f51-669e-4fc7-9dc3-7801758b984a	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 17:00:00.232+00
3399a7ac-58de-4e35-aeb7-f2001004799c	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 17:00:00.232+00
b5f78bf1-c04d-488e-a3ed-0accf2020501	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 17:00:00.232+00
e53346cf-a651-4d84-b8b8-4a0f3a4bfd59	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 17:00:00.232+00
1398158f-b592-44b4-b465-dbd0bca5ffa7	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 17:00:00.232+00
e12f897c-dd1c-4238-8341-db8f0cb1a303	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 17:00:00.232+00
97e17620-5f16-4267-bad2-fade658fdf5e	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 17:00:00.232+00
12a28748-fd6b-4aa5-ba5a-2b062055ca2f	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 17:00:00.232+00
8606159d-8a3a-4348-b259-6f3d241c85c8	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 17:00:00.232+00
5423fa63-eeac-456c-b9e4-01c944e67b91	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 17:00:00.232+00
fa4ac7a6-df54-4b9c-8e61-1d6d6576c17b	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 17:00:00.232+00
714a2d18-56a8-4e58-964a-49c03b4adf5f	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 17:00:00.232+00
06eb799d-3d5c-4927-8f8a-6c1bb92303b1	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 17:00:00.232+00
f81fc0fd-d4eb-40b4-9065-6255fbf8d23e	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 17:00:00.232+00
b1789bbe-eb25-4158-a573-fe4d2fe110ce	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 17:00:00.232+00
22b27dcf-1632-4fc4-8fd3-5b57f4a52b10	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 17:00:00.232+00
4bae0d70-4631-4a7b-90de-10d3ee73dd2b	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 17:00:00.232+00
e39836cc-005e-4771-91f5-635c507a84bb	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 17:00:00.232+00
79a5c03a-223d-428c-8b5d-3d205188553b	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 17:00:00.232+00
d2f22e58-8883-4b12-9267-12f8105ac449	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 17:00:00.232+00
14913b68-2af5-4e5f-9648-325152fb1769	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
ddc74dda-0d5a-46e4-891a-409b224a859a	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	24.99	\N	t	in_stock	2025-09-04 20:00:00.085+00
55b91309-c36d-45b2-af29-b5cf0571fc2e	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
7c25d247-a05f-4234-a1e3-7b949f30fe8a	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
21c1e82e-975a-4ab1-ba54-fa8e981ace0a	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
e3bf80c8-b526-4d57-92ad-bcb235a23e37	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
4bb3b221-f6bc-4f3d-9e49-8254f0b68d0b	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
30476d2f-9de4-4607-bdb7-0cf5f671a64c	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	14.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
7ef57b6d-6039-4d50-8c76-2bf13fcde7b5	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	23.94	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
1394c1ff-1f39-464b-8cd0-285f541d7215	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
38b705db-c12b-4b7f-8b1c-ded9fd086acc	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
677cb989-6b91-4e70-99ff-bb7e3737528e	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	9.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
84f7f89d-1b3c-4da9-915f-6dfd365bf68c	cadea567-c448-4789-872d-49fa516ea9bb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	14.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
5854a26d-07c1-4d09-82f0-fa32022a16ac	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 20:00:00.085+00
d061abab-9cf0-41cd-9e49-f5cc3e559053	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 20:00:00.085+00
e86bf140-c7d0-4576-ab0b-71dd21119b64	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 20:00:00.085+00
869ffa29-8fac-476a-b4d3-0a476c914533	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 20:00:00.085+00
a249efeb-bfb9-4d67-97a2-af8679f0315a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 20:00:00.085+00
3daa5982-e2ea-43eb-ad4e-81d580e41a89	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 20:00:00.085+00
062f8116-a198-4d45-a5d1-b13a06f4ac21	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 20:00:00.085+00
dde8ff14-94a6-4424-87be-fcfb976ff2a4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 20:00:00.085+00
da160fa7-f955-457c-ae0a-795c19a97b20	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 20:00:00.085+00
bee37c54-d750-4c4a-a4c6-87edf6abb883	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 20:00:00.085+00
155902d3-0f0b-4f53-a8f9-c4cf6b341c8d	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 20:00:00.085+00
93f42099-46f0-4646-b0fb-cfafbce591b5	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 20:00:00.085+00
f9f9b3e4-9544-4994-823b-a608cb0075bf	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 20:00:00.085+00
23e5231d-9a2e-4da4-accc-f62acd648dfb	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 20:00:00.085+00
badddf46-9c9c-438f-a2a7-f669f9e4efd5	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 20:00:00.085+00
c4c88f11-a812-4f4f-bd6b-b96d7add0055	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 20:00:00.085+00
7c2fa7d1-80a5-415f-be0f-757fd2450174	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 20:00:00.085+00
4713bec0-3cf3-437c-9032-ff1e4920d470	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 20:00:00.085+00
198c5da4-7496-4509-8825-1acce4916a9d	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 20:00:00.085+00
7805db51-063f-463c-8a96-0be2dea4e70e	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 20:00:00.085+00
600a9d28-d00c-4a5a-8744-9f0c89d62e8f	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 20:00:00.085+00
55d01eca-0c28-4906-b160-fa83d5587ebc	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 20:00:00.085+00
68ddd563-f32d-4948-937c-a96139798cd1	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 20:00:00.085+00
d2d1aee2-b5d1-40ca-ada7-76d191dc010f	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 14:00:00.97+00
8e06ac35-43e3-4f43-8571-80a9d2717b37	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 14:00:00.97+00
ce31624c-1d03-4505-bbbf-62a7d5b57573	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 14:00:00.97+00
8d5f4bbb-6631-4c9f-9b2c-1f15aeacf03d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 14:00:00.97+00
bd35ec27-bdbc-4651-8dc5-2c9572410baf	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 14:00:00.97+00
226df2d2-e8f7-46f8-80ec-332d5c80382b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 14:00:00.97+00
bb6493be-973a-4444-b2cf-8785a5f83927	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 14:00:00.97+00
2b506f92-1172-4a53-8287-8fb42860ce6c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 14:00:00.97+00
4bff99b1-4fc5-4c30-8052-06dd4933d5f5	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 14:00:00.97+00
8cd2a24e-6191-4f6d-b6e2-72330c18455a	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 14:00:00.97+00
db4d3826-054b-47ce-9d85-a7fd6aab9d68	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 14:00:00.97+00
213a1cbb-a653-48ff-ac6e-1c8f4c89633c	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 14:00:00.97+00
ed92ffa5-fc33-4145-ad80-c28322797c64	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 14:00:00.97+00
1b3c57df-8e11-4a46-91ad-55b1e55e9013	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 14:00:00.97+00
1d5b03d2-5027-40d2-856a-5839fa4d86e8	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 14:00:00.97+00
58fc81ce-424e-4c58-9e75-cca3b69449e2	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 14:00:00.97+00
9cf5f730-7442-41d2-be8b-d10f175b1180	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 14:00:00.97+00
de33f4ba-cbd5-4f18-b09a-8b2c56d09163	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 14:00:00.97+00
af29aa36-4d17-4d27-9adb-a929bce85643	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 14:00:00.97+00
56132c67-fdf1-4744-a4f5-4952d4418dcf	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 14:00:00.97+00
9c31dd03-4a3d-436d-b113-31f5d4fdc856	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 14:00:00.97+00
41142d93-30a4-4259-9e24-c373428c1341	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 14:00:00.97+00
3bfc933b-74d1-4bfe-bd39-d005aefb5f8a	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 14:00:00.97+00
1539b355-2e5d-40e5-9bab-7c0ffee9c3ad	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 14:00:00.97+00
4a3da04e-6220-416a-98cb-c1d4ebe816e4	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 14:00:00.97+00
fa664f5f-d3ba-4426-b190-1482118a5e65	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 14:00:00.97+00
4bd51fb4-c841-4b86-bbb4-fec2b3bd58a0	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 14:00:00.97+00
115f56aa-d6f4-4c3a-b891-67439441178c	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 14:00:00.97+00
69247d2a-349f-4e3b-9ce0-a2a8317bdf1e	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 14:00:00.97+00
ec7708fc-0ff7-4974-8c7c-fa29892a389b	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 14:00:00.97+00
138fc49c-af8d-4577-ace3-50b6f28291b8	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 14:00:00.97+00
a89bfd56-0984-4203-932b-88f5565cae7a	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 14:00:00.97+00
a535e270-046d-4c50-ae75-fadd3da88505	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 14:00:00.97+00
e735520d-d2f4-413a-8918-1a20e771de2c	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 14:00:00.97+00
d37b80e0-e16b-495f-8e10-c7b2de39922f	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 14:00:00.97+00
b0896db2-7ce4-4bd9-894d-f8bffb3f1a17	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 14:00:00.97+00
a2678fd9-639d-4ded-8f36-6020a7efa92a	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 14:00:00.97+00
944322e1-7cd0-4f9a-a340-b208b0a52ea1	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 14:00:00.97+00
8fd906b0-fcf5-4962-92c1-202eb0349a88	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 14:00:00.97+00
8d89650f-ce3d-4ca7-85eb-2bac2feaee5c	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 14:00:00.97+00
e4168104-9e7d-4cec-8655-9047dcc52edb	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 14:00:00.97+00
24b39968-5bec-45e6-adcf-34ae8fd56931	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 14:00:00.97+00
5fec6fe4-41f8-439f-8ade-531d31e072fa	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 14:00:00.97+00
e0c920c7-0a7b-4a01-9a99-e7168476fa77	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 14:00:00.97+00
86c34e96-d74f-48b7-8ab5-ce3a6dca537b	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 14:00:00.97+00
c8e5c59b-9cc9-4984-9b01-361c1aa3333d	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 14:00:00.97+00
204eb2f9-22fa-4c68-84d4-74d1971b780b	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 14:00:00.97+00
847aadf1-bada-4791-b813-3d7e149b14c3	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 14:00:00.97+00
7f8026c1-374b-46c4-bcaa-7ad7912e70c8	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 14:00:00.97+00
81eaaeb4-139a-481a-8680-60b083b1caad	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 14:00:00.97+00
17ffbd28-d278-4436-b401-ef08e4693037	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 14:00:00.97+00
5cd8ef81-526c-4490-9f8a-47d1c6d953c6	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 14:00:00.97+00
32206974-d21b-4abc-ae4b-04fe831080ee	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 14:00:00.97+00
31cd1c62-7f49-4df8-898b-1fca1243f82b	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 14:00:00.97+00
75720caf-02a7-4633-ab7e-85b9450f70ae	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 14:00:00.97+00
89f6fb3c-1029-41f3-8c66-82002656af51	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 14:00:00.97+00
bd47e5b8-4bdc-43ac-81bb-768124873e2b	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 14:00:00.97+00
8934f2a2-f794-4e20-bbcc-1c0c5571a93a	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 14:00:00.97+00
3a159161-db4b-4203-9773-5002c45fe8b0	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 14:00:00.97+00
914a1b1e-e7c8-4a1a-935c-1df7f73d5eae	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 14:00:00.97+00
72e31b51-65da-4e72-a051-b937bead1cea	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 14:00:00.97+00
2283c6ad-6b5f-473c-b222-4646541b8435	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 14:00:00.97+00
874a13db-4e65-4605-916e-083c0ad856be	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 14:00:00.97+00
96b02733-180c-472f-b4c6-35294054fe84	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 14:00:00.97+00
2aae70c3-0da5-4b22-adaf-e4bcdf647d8b	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 14:00:00.97+00
60930312-5fd1-478e-9b72-f113ffa9cb39	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 14:00:00.97+00
4333162f-c167-48d6-a25b-fbbdb827544b	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 14:00:00.97+00
9d07f1d0-0923-485c-becd-01510d4229b9	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 14:00:00.97+00
60957e62-4f58-4b4e-bc3a-b7860bd6afcc	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 14:00:00.97+00
4525a95d-b15a-4f5e-b3e5-690906fa164c	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 14:00:00.97+00
8d446a30-72f7-4e9a-8121-0ba304e778f4	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 14:00:00.97+00
0ac6a0c4-3f50-499f-9edf-8b3982cc124b	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 14:00:00.97+00
f8b8c67f-7dcd-42e5-92f6-9e16a527a383	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 14:00:00.97+00
4cf954d1-7727-4eb4-921d-fb4d284b61bb	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 14:00:00.97+00
0b727731-f320-4ab6-b3bf-4eaac9b8d8ff	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 14:00:00.97+00
27418585-8f18-4d24-9a59-c32a18fc931a	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 14:00:00.97+00
ca8a01cb-b40c-4940-8f49-3eca1260a1f0	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 14:00:00.97+00
6c8eb4f9-0cf9-43ac-a3d6-9fccd88029cf	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 14:00:00.97+00
29e0077e-fae5-455f-b4eb-57cfb4f7cfd6	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 14:00:00.97+00
9e85d286-1e58-4099-99b7-4d9e9c4b2a67	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 14:00:00.97+00
294e47ad-af60-45de-a63c-11fe634075e5	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	399.99	\N	t	in_stock	2025-09-04 19:00:00.273+00
c76b7022-7597-48bf-9ff6-6adf872d1f1e	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
a44e8b3a-6d93-4a12-aeba-7e938e24c651	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	34.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
38c7d1cb-27a0-42f7-86d7-81de844c47d4	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	t	in_stock	2025-09-04 19:00:00.273+00
a41d85d7-d8fb-419b-88e1-d17614c43e80	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	29.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
07519ddf-7305-4c74-913f-dff90998d784	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
4385b07e-f16a-4cfc-9a3b-350eaa8c167d	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
68214e80-62a6-41ac-9272-7a7b2c04ac4b	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
742caafc-3983-4950-a0e0-c262b2eb7518	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
4dfd62ed-26af-406a-b0eb-116c5fdca1cb	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
ffd22893-f7b1-4b17-947f-4aaafdab47dc	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	24.99	\N	t	in_stock	2025-09-04 19:00:00.273+00
ca7ff487-1eb5-4dc9-84f7-8ee924806ebb	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
516d63d7-ea4f-4547-a2a9-3e357310b3c5	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
d2831399-db4c-46a8-b92a-665e76272b8f	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
b9c5304f-441b-4c67-a938-8ba20f49ea84	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
f5ddd265-b5e4-41bf-bd61-f9c7c3374d08	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
1f8898cf-9d1b-4891-ad79-8e538e79612e	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	14.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
b340794f-bbf2-41e2-81b8-2a1a66b0d9ce	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	23.94	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
c18f4d42-ca15-40a3-83cb-bec059589345	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
6bcec9bc-12b2-4813-bdc7-d7de3c030003	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
66fc86d8-9a57-49cd-aa30-e96b1c884a73	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	9.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
d834ea1f-3b40-41e4-9002-0b6e4c1dd33d	cadea567-c448-4789-872d-49fa516ea9bb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	14.99	\N	f	out_of_stock	2025-09-04 19:00:00.273+00
6abf7eed-e525-4b41-a99d-11cea984df2b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 19:00:00.273+00
7cd97ce6-e585-46c0-9ca4-4e2718fec2fa	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 19:00:00.273+00
a50f8309-3c11-421c-8f5e-a38bf3512bdd	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 19:00:00.273+00
9b0f47f9-6807-4d2c-aeab-8745daf2a6fb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 19:00:00.273+00
d42fe5ac-b7b6-48ee-885c-9d29f9ad7dc6	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 19:00:00.273+00
d90fc089-205e-4a1c-885e-759965d741fc	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 19:00:00.273+00
6b237294-0441-496d-a826-93ea02fd5b3a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 19:00:00.273+00
934dd880-af33-4a0c-be25-a83a2d60c53e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 19:00:00.273+00
86b37b17-29ef-4f85-9b56-1d6e12d62f70	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 19:00:00.273+00
890822d6-f935-44a6-a697-dd61c36b1fff	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 19:00:00.273+00
fc4f6780-e8a9-43f3-bdf9-99a2c33357fa	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 19:00:00.273+00
bd70cd8d-94ea-4245-94c7-f3196fa5336c	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 19:00:00.273+00
94acbdb1-a1f4-46b0-87b4-03b27e67bdef	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 19:00:00.273+00
e5b740bb-f35d-40ae-9d5f-269993631d2b	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 19:00:00.273+00
5b829e9a-299b-449c-b5ab-df501a542ac2	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 19:00:00.273+00
be9c08b8-524e-4b66-9ecc-42da5ff5f328	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 19:00:00.273+00
0c5c3072-fb06-4ba8-8c1f-81841b85edcc	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 19:00:00.273+00
40d26730-6cee-4c0f-9c22-35a34ab44c7a	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 19:00:00.273+00
f25f6cdd-cb71-49ae-aaa2-b7235645a2a2	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 19:00:00.273+00
a8039343-f628-4692-a64a-f246714d74bc	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 19:00:00.273+00
6050fdc3-09ea-43dc-b5ce-2ced39097c55	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 19:00:00.273+00
a4979fbc-d6e3-4fc7-91a0-c2a2e71fcb48	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 19:00:00.273+00
e5b5a3ce-c0be-47ea-895b-36704e0ebe82	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 19:00:00.273+00
a49bc3bd-a19c-41bf-8686-d67b300ad661	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 19:00:00.273+00
5af0864e-8adc-45bc-b311-c5a88e5e3dc9	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 19:00:00.273+00
a1e33807-c070-451d-981d-be7befb4c1f0	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 19:00:00.273+00
af3527f8-aae5-47c6-94c1-e951cf75d592	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 19:00:00.273+00
a3753d4a-0963-4111-94d9-65fb25300d24	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 19:00:00.273+00
81193813-f617-4ce9-bf47-23faedf91b7e	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 19:00:00.273+00
cafad87f-2079-4146-8f2d-c9673ec45aaa	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 19:00:00.273+00
e62f8f30-6ed8-49a8-a81a-a1acb09e1c57	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 19:00:00.273+00
defb257d-65fd-446f-96c0-9845e99950a8	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 19:00:00.273+00
31374dff-171d-4293-a12c-77b153692e1f	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 19:00:00.273+00
71e2d7df-0ea4-4065-9c76-4738bc778b7d	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 19:00:00.273+00
0db33612-853a-4e05-8ba9-62dade47178c	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 19:00:00.273+00
6c9a7976-5776-48f0-9e4e-96c018897547	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 19:00:00.273+00
29a8cf4c-cc08-4044-b3db-951e2014349e	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 19:00:00.273+00
62afead5-d91d-40a9-a7ee-0e35631e6af4	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 19:00:00.273+00
ffb9bb36-8ab2-48da-9450-475084051ae3	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 19:00:00.273+00
e2ceaf24-d8b4-48e1-a213-1bb781caebe9	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 19:00:00.273+00
e4b63f8d-3344-48c6-8ca1-e59538db6d24	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 19:00:00.273+00
7860ab0c-b44e-4394-9f7c-d3c897d8fc3f	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 19:00:00.273+00
01cdc6af-d064-4337-b7a9-80c57b46af8d	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 19:00:00.273+00
719afd3a-10f4-4250-a462-47dd5bf7342a	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 19:00:00.273+00
56d2c3a7-c13f-42f2-830e-42627715c2ff	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 19:00:00.273+00
bbbf3022-b9eb-426b-b421-c64bf4ccac46	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 19:00:00.273+00
bf214251-a955-456c-b728-006617fc7393	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 19:00:00.273+00
bf62f1e2-647b-4214-9ee8-302d34e64c0a	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 15:00:00.124+00
c0d06171-3576-4f13-8639-f8e7eeca21a0	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 15:00:00.124+00
2d299774-e350-44b0-993d-63946d77eb9c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 15:00:00.124+00
7b90bca0-3117-47d0-9b1a-f64e32744365	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 15:00:00.124+00
d5203fbf-2a68-4fe4-b774-4c7ed64095f5	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 15:00:00.124+00
8dec0e41-fa32-4bec-aea0-123391568c37	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 15:00:00.124+00
43dad1d7-a17a-4e73-83ab-1f0942aa120d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 15:00:00.124+00
e08b7254-f6ab-4a09-9638-07a1e2f22914	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 15:00:00.124+00
84fcd582-7f5f-4f8a-a5fd-2a781e34fef6	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 15:00:00.124+00
c1f66671-2748-44ab-96b4-66f26e3b5b9f	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 15:00:00.124+00
3243fe23-9a42-4cb3-9d41-b6ed9757760e	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 15:00:00.124+00
eaf07640-a27f-41a5-aeef-bb92e74ba66e	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 15:00:00.124+00
ed9e743a-bfdc-4c88-a267-8e96f6acd752	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 15:00:00.124+00
d96925a9-aec8-4e98-9a54-02dacf44d5a8	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 15:00:00.124+00
0acc39cf-2dd9-4a2b-a556-c0b42ec4cf8d	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 15:00:00.124+00
c92c8652-f0e9-4625-90be-71572dcdc3f5	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 15:00:00.124+00
bb35973d-222f-4390-b865-205ebf7eb37e	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 15:00:00.124+00
48647329-efbe-474a-9027-ce99abd14d60	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 15:00:00.124+00
ae56b78b-4dc4-446f-ba19-f4a2d39458b2	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 15:00:00.124+00
7c2fad49-0f32-46b3-b116-0005745ae5ca	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 15:00:00.124+00
e16c1117-652b-4e78-b10c-366cf1f861a5	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 15:00:00.124+00
034db040-d9cb-492f-9839-e4733ccef271	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 15:00:00.124+00
27fd7aa0-c10b-4199-95a3-def272ffc368	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 15:00:00.124+00
d9e298b2-36ba-4c26-8a67-b84eb5246ac2	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 15:00:00.124+00
a36b9de8-d634-434c-ae6e-8b0377db4a58	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 15:00:00.124+00
590309cd-9a09-4635-aec3-f739ce0efca7	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 15:00:00.124+00
35f00d09-7f49-4d83-9969-8847dcc1679a	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 15:00:00.124+00
e518e20e-5ca2-49b5-bed9-1ac5659bd13f	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 15:00:00.124+00
2cdbbe55-81e9-40b5-a92d-7f1aac44746d	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 15:00:00.124+00
423db482-6295-476e-826c-4bc943945ec0	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 15:00:00.124+00
5059e4dc-6c7f-4b47-a088-e26414b6a725	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 15:00:00.124+00
3d87f5e2-30b1-4d42-883b-96298ef28fd3	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 15:00:00.124+00
34dc1087-0aac-4389-a26c-a95e6dfc5a0f	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 15:00:00.124+00
28cd8bab-cad8-4791-820c-6f95bb0bb632	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 15:00:00.124+00
7f22c9f7-91b6-401f-9a9c-087156fc36e2	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 15:00:00.124+00
84f64b88-5710-4d03-a459-26c86d0439e5	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 15:00:00.124+00
721aa720-fb9d-4bfd-a104-c4dcce1f708c	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 15:00:00.124+00
5df903ac-5d91-4fe6-9f65-05fd7293c679	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 15:00:00.124+00
6b9b6f2b-1782-4830-8f5d-2b337d1f3d5a	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 15:00:00.124+00
a80e25fa-17f4-437c-98cc-b5018dd359f8	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 15:00:00.124+00
8b4dc736-868d-453d-bc23-cd19edab3a08	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 15:00:00.124+00
e2e629e9-fd84-445f-90b0-bfdd257d356c	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 15:00:00.124+00
a4598b90-f3e4-4725-8fd2-997ae5bc658c	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 15:00:00.124+00
f706f2e4-5dfe-4045-a4fc-9868494e5220	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 15:00:00.124+00
eb71c82d-2466-49fe-968d-c61e063a0a41	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 15:00:00.124+00
752d7dc8-ba10-4e46-b3b2-cd713c1d9f1c	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 15:00:00.124+00
3eb589ec-4ce9-42a2-a7ff-a838510c78ea	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 15:00:00.124+00
b37c413a-003d-43c6-b939-5b170286adea	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 15:00:00.124+00
a6ab7c0e-54fc-40a2-88d2-6058bc2faea7	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 15:00:00.124+00
3ec7daa5-b27c-4737-ab68-f2560aa5f297	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 15:00:00.124+00
9d761163-97c6-464b-8edd-0bf7503eec99	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 15:00:00.124+00
b965af10-0a9b-40d0-a903-6874738a1606	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 15:00:00.124+00
aa0ec4b2-f2ee-4c5b-b8cc-5d73a9be7fab	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 15:00:00.124+00
727bef35-a4bd-42e1-ad01-b52043d5860f	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 15:00:00.124+00
a0ced28f-6285-4bc5-9846-841b8ca4dd27	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 15:00:00.124+00
48d6f669-cfd9-418b-9059-82b8f5398ada	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 15:00:00.124+00
8056dc77-4e97-4b1d-a4c5-6c2621b8da10	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 15:00:00.124+00
0dedc890-650e-49ce-9b8b-95b388305c41	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 15:00:00.124+00
3a8898a0-009c-4e35-a11c-3f812c8ce5a0	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 15:00:00.124+00
1e228042-e911-41d8-a159-7af247477a0b	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 15:00:00.124+00
069af242-4fa3-401f-acb3-6a3c0be53f17	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 15:00:00.124+00
b78121fc-3312-4feb-8939-9dbf0632a4dd	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 15:00:00.124+00
198e87a0-3545-4560-bca5-891c678af8d3	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 15:00:00.124+00
69865ff7-6eec-4292-bc5e-7f1ed49df414	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 15:00:00.124+00
fab5bc46-7d4e-46f9-b35c-d96d418774fe	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 15:00:00.124+00
f4327ae6-93d6-4a48-b3e5-c809c60db8b7	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 15:00:00.124+00
26ce7d32-22e3-4d7d-b7a2-722841876b26	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 15:00:00.124+00
3a08a98e-790b-47d4-8787-6f931216339b	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 15:00:00.124+00
fecc4712-ee0d-47be-8e98-6355955a2d50	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 15:00:00.124+00
3d2c02d8-0bfc-4bdf-ac4a-45cb8e8948f6	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 15:00:00.124+00
60b6c45c-5aaf-4709-b220-affa824e3ed2	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 15:00:00.124+00
5dd2f2bc-a025-4a2c-a7df-1e67a4585ee7	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 15:00:00.124+00
8f191ffb-969c-4c68-913d-0bb0b675865d	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 15:00:00.124+00
3e165fa0-4394-44fb-9f9b-6281d45a989f	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 15:00:00.124+00
1bb68a23-ce69-4274-b46a-9af0b111ed16	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 15:00:00.124+00
97455455-2a2c-486d-9321-622aa81e2fe5	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 15:00:00.124+00
7a663c29-b663-4963-ba81-f8b4ccc432df	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 15:00:00.124+00
891e510f-2928-44f3-9487-8ee56fe8f015	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 15:00:00.124+00
51c15402-f80c-4f1d-9a70-4afdcdfcfe7b	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 15:00:00.124+00
dcedd997-ea67-43ef-b659-17cff84650d2	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 15:00:00.124+00
6ceb7508-4f0a-482d-993e-fdadfe8b795f	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 19:00:00.273+00
305d14ee-f627-4a1a-afef-4c2ccf93ab8e	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 19:00:00.273+00
2d6c9dc6-9674-492e-82ba-4edfa4e45bc9	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 19:00:00.273+00
145038a4-e3e4-482f-8804-d15d13df24ce	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 19:00:00.273+00
4d7ee308-2c1f-4239-ab9c-ae06c263c959	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 19:00:00.273+00
d969927c-4f7d-4db6-97a4-3e353d295dde	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 19:00:00.273+00
2093d744-0418-4f90-9234-4a22098fbfe6	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 19:00:00.273+00
c53a29ba-dd64-4a4a-b73c-90f208fea475	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 19:00:00.273+00
9a4f16dd-db85-41d7-ba13-dee423f11f3b	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 19:00:00.273+00
dc88299f-4e71-45df-a964-f8ac042bff1e	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 19:00:00.273+00
6e71b97b-e5c3-4b45-b0ef-c753d0aacc6e	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 19:00:00.273+00
5823cf8b-1fdb-4111-9561-f2af7b5d7fc5	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 19:00:00.273+00
557ea134-c186-429c-a4e0-15e73b138e2c	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 19:00:00.273+00
21b8cba1-3dad-4592-b9d1-08f49ca49ae1	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 19:00:00.273+00
cba98ed2-5b82-4592-8721-c6702634825d	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 19:00:00.273+00
d2d48e06-2a45-4d7a-9e8a-8ce67293e231	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 19:00:00.273+00
b3452585-210e-4643-87d8-fc329d987aa4	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 19:00:00.273+00
caf60d75-9cc1-457c-9d33-c9d17b439d6e	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 19:00:00.273+00
f6fc7147-ee8c-42f0-86ef-c93c8719fdef	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 19:00:00.273+00
c72eb030-adc8-4efb-9a3e-11a376dd4e5f	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 19:00:00.273+00
2a436ca5-9fb5-48ec-abae-ccbfcd5f4ea0	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 19:00:00.273+00
ffb392ee-2ebb-463b-918e-843a31fafe05	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 19:00:00.273+00
2f8df8e3-8a4d-4a8f-a03c-9a19c80f1ac7	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 19:00:00.273+00
149e352b-34f4-45ee-9e68-9ad59b87e595	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 19:00:00.273+00
33d9fb51-aaaa-4b03-80f9-c4b78016c26e	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 19:00:00.273+00
a0689034-badc-49c9-ba18-7d284a3725fb	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 19:00:00.273+00
899b229a-98b8-4aba-b05d-bca6ea9752ac	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 19:00:00.273+00
1e516c04-78be-4390-a5fb-af2ddeba9a15	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 19:00:00.273+00
b6f2b44a-7a48-40e5-ab31-3afed0164dca	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 19:00:00.273+00
fe1b7eb3-a95f-49b2-bf61-6fbc87e5f938	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 19:00:00.273+00
04881522-23a6-46fe-bd65-9a60e7f202a9	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 19:00:00.273+00
9bd529dc-5219-4386-a36c-79998f8fd678	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 19:00:00.273+00
341e52e3-fad6-43cc-a87b-818e0cb31b7c	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 19:00:00.273+00
d21fc740-b4fe-4943-8e20-ff363f75d9f4	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 20:00:00.085+00
cf79085f-b728-47e4-9c92-5fc2fe821d25	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 20:00:00.085+00
662a5180-878b-4436-88e9-e08a0be07f55	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 20:00:00.085+00
f426327a-dc58-4a54-975a-6e366cffb449	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 20:00:00.085+00
26d61f0b-065b-439c-99e3-f1dbe7118f5d	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 20:00:00.085+00
88961449-26e2-49c1-8725-77dad1911eba	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 20:00:00.085+00
e28e1366-1312-496f-bd57-b12b77a6e2c7	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 20:00:00.085+00
e0abf85f-304d-41bb-8066-5aff56a66a7e	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 20:00:00.085+00
af27ea5e-a138-428e-bb11-9fc8de8b364b	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 20:00:00.085+00
7f275ec7-4110-49dd-9c3b-63b79d404146	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 20:00:00.085+00
a167a90a-02f7-41e4-bb45-f9b88f6439bc	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 20:00:00.085+00
955d30c7-a6e9-4f01-9f6c-551aedfd9431	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 20:00:00.085+00
8b6c5ff3-e53e-41d8-8ec8-17ec4ce77819	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 20:00:00.085+00
c92d5921-1595-42c8-9299-8f8270420614	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 20:00:00.085+00
a5a16e82-d34d-4a2d-86f2-e54ddb8442e1	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 20:00:00.085+00
d25ae7bd-d69b-4b88-b4c4-9d5f563fa314	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 20:00:00.085+00
d983ed97-5642-4e81-8cf7-8e8cdadc11c4	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 20:00:00.085+00
d1b7fb3a-c9fe-422b-9209-474ba65ff2ff	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 20:00:00.085+00
d2ada378-52be-4347-a245-10bc30f3c4b8	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 20:00:00.085+00
4d0fa3ce-431f-4322-b70e-1e4f9316fa8e	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 20:00:00.085+00
bc6c675b-9d82-42ef-b890-6559f1e17119	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 20:00:00.085+00
572e2462-cf97-42a7-8344-870a50063d1b	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 20:00:00.085+00
540ebe47-6436-45d5-80c1-44b663ace83e	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 20:00:00.085+00
f5a14fc7-eeb6-43eb-b223-e3ea4c3aa4c7	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 20:00:00.085+00
bc0c040f-014e-418c-84f4-478fa10f3261	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 20:00:00.085+00
dc017b49-4696-443d-9d00-f7880df1ed80	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 20:00:00.085+00
49022ad3-b5b3-4d92-a687-f5e0f8ca09b0	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 20:00:00.085+00
ab64f6f9-d443-4260-89f9-40fe99d50e4e	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 20:00:00.085+00
d56c419e-b4fb-4139-9457-7e88589b1db8	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 20:00:00.085+00
b7576a81-3c48-4676-a842-b2db74db2d14	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 20:00:00.085+00
9000f877-22f2-44b6-ba89-6ab0b9646711	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 20:00:00.085+00
2d62d461-8375-401e-bb8b-25cba7bdb57e	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 20:00:00.085+00
8baefa69-846c-4b88-b0f4-8be646b6d040	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 20:00:00.085+00
af47dd86-0bcf-472f-91d5-50ee4eaeb69f	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 20:00:00.085+00
ab4bb3b1-c915-43dd-9c7d-6a6cae22c8c4	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 20:00:00.085+00
3436750b-753f-4952-b926-c4ae0067e38d	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
526ae52a-31ef-47be-8204-6b120ceed74b	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	399.99	\N	t	in_stock	2025-09-04 16:00:00.862+00
8c03dd03-0a58-474c-b8d8-b5e8dd2f053f	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
f5820321-315a-4405-b87b-2d3fb0ca3b09	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	34.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
28f47b57-818a-43ad-833a-ecb9e0eee204	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	t	in_stock	2025-09-04 16:00:00.862+00
0a31ebfc-c1a4-4e55-bf60-9fc7e661e6b3	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	29.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
788eee54-e394-468f-96f1-3b83d688120b	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
d084aef4-30fd-4ebb-8c61-ab34a798951a	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
a235ea6e-a804-415c-bd60-418e9da629fb	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
469d029d-9ee6-4cc1-809c-22347b49c322	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
cefb1b7c-3416-490e-bf39-f0ceb675a5d5	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
7217dbc4-b27a-4793-b66c-89eb8658db44	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	24.99	\N	t	in_stock	2025-09-04 16:00:00.862+00
a1bf4db1-efcf-4d88-a922-03f6857ce57e	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
99972ed5-176c-43f9-a27e-04f2f5231597	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
7e77f5bc-1425-448b-89ba-82454895038c	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
0c69d15b-084d-401a-a7a3-4dd42e0c36b1	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
7be68d89-c436-4857-b258-ac59b104901c	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	160.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
b4966025-c988-4710-a98c-c45abfe754f0	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	14.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
4bcddae2-29f2-4c23-8eca-c9f7a8fdbe26	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	23.94	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
03031adb-2bee-4030-9392-58dffe4e9468	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	26.94	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
7649c4ac-6cfd-4ea2-b332-e15c552bad84	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	9.99	\N	f	out_of_stock	2025-09-04 16:00:00.862+00
f23ecf3e-5324-451c-813a-489f5e08cb2f	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	132.97	143.64	t	in_stock	2025-09-04 16:00:00.862+00
7601e8f2-7fe1-49a3-af7e-ccd37acc745a	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	157.65	143.64	t	in_stock	2025-09-04 16:00:00.862+00
ee98af95-55be-4acf-82db-edcea9e621de	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.29	143.64	t	in_stock	2025-09-04 16:00:00.862+00
9e309fdc-2d1d-4ecf-b462-5883a3aa28ec	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.04	143.64	t	in_stock	2025-09-04 16:00:00.862+00
62f0adea-60ac-45e9-bf97-9d87394cdb60	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.37	143.64	t	in_stock	2025-09-04 16:00:00.862+00
3119b173-0d2a-464e-a676-118ef6ce23cf	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	144.92	143.64	t	in_stock	2025-09-04 16:00:00.862+00
63314c06-5784-4564-a6cd-f10a291b9dc3	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	139.87	143.64	t	in_stock	2025-09-04 16:00:00.862+00
7ac10592-4d9c-4cef-8b5b-af8106195ea2	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	139.55	143.64	t	in_stock	2025-09-04 16:00:00.862+00
5fc4dd43-234e-48dd-ae39-185a70270018	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	48.91	49.99	t	in_stock	2025-09-04 16:00:00.862+00
a575b863-ba90-4868-8a08-6628f1567606	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	47.53	49.99	t	low_stock	2025-09-04 16:00:00.862+00
18bb0ae7-727a-43fd-8288-038de6d3b4dc	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.78	49.99	t	in_stock	2025-09-04 16:00:00.862+00
31dec6fe-5292-4981-b898-932d1493ba32	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	117.02	119.99	t	in_stock	2025-09-04 16:00:00.862+00
54a077de-1b95-4193-afdd-ac939fc6ca8e	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	125.73	119.99	t	low_stock	2025-09-04 16:00:00.862+00
6d8183ad-a466-4330-b1d2-b905195472de	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	127.02	119.99	t	in_stock	2025-09-04 16:00:00.862+00
454853c4-664e-46b0-bbab-c3d00c85eace	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	4.22	3.99	t	in_stock	2025-09-04 16:00:00.862+00
e6178363-6bda-4d91-a049-b635efbf5f99	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	3.60	3.99	t	in_stock	2025-09-04 16:00:00.862+00
d105e512-9e0b-4bf1-b8b8-fb19c7af1a86	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	3.67	3.99	t	in_stock	2025-09-04 16:00:00.862+00
64f4eaf4-441e-429f-9d06-00de1e94baef	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	3.99	3.99	t	in_stock	2025-09-04 16:00:00.862+00
193e7d49-3ef9-4c3e-9331-dd93f636f49e	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	4.32	3.99	t	in_stock	2025-09-04 16:00:00.862+00
c1e50ecc-1091-4e1c-8393-061b61f810c3	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.88	143.64	t	in_stock	2025-09-04 16:00:00.862+00
ad4c65ae-5afc-4b5c-8565-b4aca0ab7f90	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	147.76	143.64	t	in_stock	2025-09-04 16:00:00.862+00
e2266e80-df0d-49ad-ac61-225b15b0c16a	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	147.83	143.64	t	in_stock	2025-09-04 16:00:00.862+00
779db2f7-059f-4a91-a39c-74ab78a9aee9	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.79	143.64	t	in_stock	2025-09-04 16:00:00.862+00
d5474152-c56f-44ba-8f34-730ca694b31a	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	132.69	143.64	t	in_stock	2025-09-04 16:00:00.862+00
6dfab38a-4d0d-4f39-866e-99648ed01922	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	142.03	143.64	t	in_stock	2025-09-04 16:00:00.862+00
81f573e5-5768-4cab-ace0-c84fdbe219d0	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	156.31	143.64	t	in_stock	2025-09-04 16:00:00.862+00
49a97111-aec4-4b74-a0bd-490d49fb8006	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.51	49.99	t	low_stock	2025-09-04 16:00:00.862+00
6ec8cab0-1ac4-46ba-bee0-bd456cfe7408	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	47.89	49.99	t	in_stock	2025-09-04 16:00:00.862+00
9d0022bc-d872-4a1d-ae29-f3cd1ebe1373	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.99	143.64	t	in_stock	2025-08-04 22:19:06.331+00
643935b3-0291-42df-87b6-6d174dfae012	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.18	143.64	t	in_stock	2025-08-05 22:19:06.331+00
957b10df-f040-460c-9ad9-fdf6a7d8684a	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	142.10	143.64	t	in_stock	2025-08-06 22:19:06.331+00
cd540b93-8aa3-4ab5-893e-ac0fdea4b63f	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.61	143.64	t	in_stock	2025-08-07 22:19:06.331+00
4fb162a2-4dd6-4368-ad11-f4339adb35fc	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	148.03	143.64	t	in_stock	2025-08-08 22:19:06.331+00
98f33b2d-ad51-444c-8db4-bad20759c6b8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.60	143.64	t	in_stock	2025-08-09 22:19:06.331+00
9253327b-7b3c-447e-a73a-790d14f8ee70	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.60	143.64	f	out_of_stock	2025-08-10 22:19:06.331+00
0d3e0964-2223-4301-87f7-b3a734381b63	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.03	143.64	t	in_stock	2025-08-11 22:19:06.331+00
3ebf660e-65c8-42fe-8068-bb3dfc9af130	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	151.77	143.64	t	in_stock	2025-08-12 22:19:06.331+00
aaa06d84-b5d3-4569-9fed-8438a1a156e5	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	142.14	143.64	f	out_of_stock	2025-08-13 22:19:06.331+00
661e8f59-2e34-44c8-b72d-a399b11348af	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.57	143.64	t	in_stock	2025-08-14 22:19:06.331+00
f54c1d77-1f17-43fe-bb2e-6908715a642d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.94	143.64	f	out_of_stock	2025-08-15 22:19:06.331+00
22275355-c7b2-4f75-9fda-2888a6e02e64	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	141.47	143.64	f	out_of_stock	2025-08-16 22:19:06.331+00
cc6c56c7-3353-409e-85ae-30061bc029f2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.52	143.64	t	in_stock	2025-08-17 22:19:06.331+00
def71e1e-24ef-4fbf-9d52-2a09a778d4f3	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	148.79	143.64	t	in_stock	2025-08-18 22:19:06.331+00
716993d2-e011-4104-bc62-7312cb237d85	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.87	143.64	t	in_stock	2025-08-19 22:19:06.331+00
ff641899-ed5e-4fc6-a9d5-2ccad97de66c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	141.83	143.64	t	in_stock	2025-08-20 22:19:06.331+00
01facaca-3ad0-4cc2-9d8b-67653e6841f2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.77	143.64	t	in_stock	2025-08-21 22:19:06.331+00
0037d3d1-e4bd-456e-9076-224185b85f96	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.03	143.64	f	out_of_stock	2025-08-22 22:19:06.331+00
2a39ae57-8c39-4a11-ad76-0b83aef5bc32	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	148.54	143.64	t	in_stock	2025-08-23 22:19:06.331+00
e6639c01-2d9f-4d6d-a5c7-a54c0349e34c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	149.59	143.64	t	in_stock	2025-08-24 22:19:06.331+00
dee793dd-2e19-4454-a339-f3c5aad169f8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.81	143.64	f	out_of_stock	2025-08-25 22:19:06.331+00
cd6a793a-de9f-4929-a2d6-9e856c4bd49c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.54	143.64	f	out_of_stock	2025-08-26 22:19:06.331+00
e985ad18-57ab-49c6-9bda-1ac138058e26	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.42	143.64	t	in_stock	2025-08-27 22:19:06.331+00
fdb1fc4a-040c-41e2-9610-8f004ad5604c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.43	143.64	t	in_stock	2025-08-28 22:19:06.331+00
c85d088c-8671-404e-ad9c-c381d87af216	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	149.27	143.64	f	out_of_stock	2025-08-29 22:19:06.331+00
9af7647a-a8ff-45d3-b6e0-c12b01cba7ef	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.47	143.64	f	out_of_stock	2025-08-30 22:19:06.331+00
f7b4cae6-9fa3-45f5-b955-e834ef3d1c13	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	133.44	143.64	f	out_of_stock	2025-08-31 22:19:06.331+00
d3319606-89a0-4cbf-899d-56f04a2ae026	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.72	143.64	t	in_stock	2025-09-01 22:19:06.331+00
6aa99a88-8c9d-466b-81a1-2f01984df763	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.47	143.64	t	in_stock	2025-09-02 22:19:06.331+00
209893d3-e608-4223-8426-113ed2cd3d88	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.40	143.64	t	in_stock	2025-09-03 22:19:06.331+00
e9cf1473-f0c5-4efc-8e41-4f8479f292d6	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.27	143.64	f	out_of_stock	2025-08-04 22:19:06.331+00
7aa837f5-8e9e-46cf-889f-87cf003dab7d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.01	143.64	t	in_stock	2025-08-05 22:19:06.331+00
5f3799bb-5933-4bb7-88f3-1d7106af96c8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	148.84	143.64	t	in_stock	2025-08-06 22:19:06.331+00
13d6ab99-d8c6-4844-afcc-a7f876fd431b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	133.18	143.64	f	out_of_stock	2025-08-07 22:19:06.331+00
85d7ae7e-9efd-408f-b1f9-9d43cd72dbad	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	141.80	143.64	t	in_stock	2025-08-08 22:19:06.331+00
9af0dba8-0970-48ce-a838-143b344994a8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	145.02	143.64	t	in_stock	2025-08-09 22:19:06.331+00
395b4217-d531-4ae1-809d-82a4b33e6615	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	151.39	143.64	t	in_stock	2025-08-10 22:19:06.331+00
f6ae7047-8869-46f3-b6d8-48ac8279f464	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	150.70	143.64	t	in_stock	2025-08-11 22:19:06.331+00
312de2f7-de46-4870-9f48-803da4636256	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	152.12	143.64	t	in_stock	2025-08-12 22:19:06.331+00
3d96f92e-b9ea-4264-a906-652d54867513	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.08	143.64	f	out_of_stock	2025-08-13 22:19:06.331+00
da677e32-2d0d-48b8-8a31-113709f9ccf4	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.37	143.64	t	in_stock	2025-08-14 22:19:06.331+00
1e61b67f-76e5-4be9-9419-70da6240b540	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	137.51	143.64	f	out_of_stock	2025-08-15 22:19:06.331+00
5f0ddb79-c29d-4bcd-a9b6-cea989c6d885	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	149.53	143.64	t	in_stock	2025-08-16 22:19:06.331+00
9f0e6c5e-cf22-469d-9ec2-4faf516b30e3	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	142.69	143.64	f	out_of_stock	2025-08-17 22:19:06.331+00
c3bc64a6-94b0-41b2-b954-ec7288298289	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	137.94	143.64	t	in_stock	2025-08-18 22:19:06.331+00
1aec2112-60d0-492e-b85c-0d0168b6853c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	146.21	143.64	t	in_stock	2025-08-19 22:19:06.331+00
f9da48e6-eb89-450f-b719-6aed629970eb	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	134.04	143.64	t	in_stock	2025-08-20 22:19:06.331+00
314ff4be-3b7e-4de3-bb85-e516ffcefb03	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	143.13	143.64	t	in_stock	2025-08-21 22:19:06.331+00
a0203598-e885-46d4-9e3d-06da1cbe49a9	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	150.14	143.64	t	in_stock	2025-08-22 22:19:06.331+00
9bb7a9e2-c284-403b-975d-6c23ae5f4dca	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	134.09	143.64	t	in_stock	2025-08-23 22:19:06.331+00
3b09b250-1891-405e-adbf-37580e8c4d4b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	136.22	143.64	t	in_stock	2025-08-24 22:19:06.331+00
562e6995-80cd-45e6-a427-42bfb3d45ca3	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.28	143.64	f	out_of_stock	2025-08-25 22:19:06.331+00
388d101d-e1cd-4e9b-bcb2-3dcc41580b62	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	147.20	143.64	t	in_stock	2025-08-26 22:19:06.331+00
846a1650-68d9-41f5-80f3-d5926f533739	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.21	143.64	t	in_stock	2025-08-27 22:19:06.331+00
6e81a8d6-96db-4447-9ff6-23aab18f54c7	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	150.00	143.64	f	out_of_stock	2025-08-28 22:19:06.331+00
a7197b2e-3fda-49ed-8099-37bf39e0bed8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.70	143.64	t	in_stock	2025-08-29 22:19:06.331+00
86cf77b1-929c-4262-aa39-f5704992d1a0	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.72	143.64	f	out_of_stock	2025-08-30 22:19:06.331+00
b978680e-b20a-439e-891e-07d5b790214e	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	145.62	143.64	f	out_of_stock	2025-08-31 22:19:06.331+00
9b7874a9-e215-4751-ac78-00513d49484d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	143.43	143.64	t	in_stock	2025-09-01 22:19:06.331+00
9e9f2d89-f7dc-4ce7-af0b-6b198eba4072	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	146.66	143.64	t	in_stock	2025-09-02 22:19:06.331+00
44041188-b69c-4e64-b5f1-ec4312826dd2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	146.61	143.64	t	in_stock	2025-09-03 22:19:06.331+00
97614e24-445c-4219-b9df-855ccf58ad75	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.45	143.64	t	in_stock	2025-08-04 22:19:06.331+00
34ffe844-24ce-4932-b898-fab6969b9b35	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.88	143.64	t	in_stock	2025-08-05 22:19:06.331+00
499abb94-2630-4bf5-a752-1107af8ea38c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.09	143.64	t	in_stock	2025-08-06 22:19:06.331+00
71127820-b9ef-44e5-8e30-8e330f95a0ef	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.43	143.64	t	in_stock	2025-08-07 22:19:06.331+00
29e976dd-b4bb-46c0-872c-5341e5358be4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.17	143.64	t	in_stock	2025-08-08 22:19:06.331+00
e54503ed-ff3a-402b-8676-543896da1e46	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	138.49	143.64	t	in_stock	2025-08-09 22:19:06.331+00
8f03726a-0c4d-497e-a8f5-ef9d6a04b27c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.18	143.64	t	in_stock	2025-08-10 22:19:06.331+00
8e9c2344-792b-41b2-b947-509001443a10	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.17	143.64	t	in_stock	2025-08-11 22:19:06.331+00
7346f0a8-4060-49eb-a56d-2038daf84a1f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	138.52	143.64	t	in_stock	2025-08-12 22:19:06.331+00
f4aec007-57f6-422b-899f-b5d94b28398b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.86	143.64	t	in_stock	2025-08-13 22:19:06.331+00
de119d47-ebd6-444e-97a6-625b4724f06a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	134.10	143.64	t	in_stock	2025-08-14 22:19:06.331+00
d15d8c97-6182-432b-9f9e-904d90fb7473	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.77	143.64	t	in_stock	2025-08-15 22:19:06.331+00
4c022adf-c043-4a4f-afce-8cd20b428ea0	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.50	143.64	t	in_stock	2025-08-16 22:19:06.331+00
3dd31735-6f55-4363-9794-7a05588f5e09	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.16	143.64	t	in_stock	2025-08-17 22:19:06.331+00
f5522396-6646-4069-9c1b-22a1bac797ff	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.48	143.64	t	in_stock	2025-08-18 22:19:06.331+00
9f014a9c-9a77-421b-930d-89861b47aaa1	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.05	143.64	t	in_stock	2025-08-19 22:19:06.331+00
92f3324a-bc7e-4a6b-b072-d130445fd6ae	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.51	143.64	f	out_of_stock	2025-08-20 22:19:06.331+00
e480994a-4a85-4169-b2ca-e4081e8c4a24	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.24	143.64	f	out_of_stock	2025-08-21 22:19:06.331+00
ee35214c-be08-4d20-8332-b0a58d55d7d0	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.37	143.64	t	in_stock	2025-08-22 22:19:06.331+00
18397c15-c524-4f42-a8de-9237051f2f88	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.97	143.64	t	in_stock	2025-08-23 22:19:06.331+00
45743b8e-71f4-4c1f-8604-f49723aab324	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.35	143.64	f	out_of_stock	2025-08-24 22:19:06.331+00
c4a091c2-32b8-4139-8604-ddb3d97d6d0e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	147.47	143.64	t	in_stock	2025-08-25 22:19:06.331+00
e1b4aa09-2aae-40c4-83dd-4718f37c7afd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	138.53	143.64	t	in_stock	2025-08-26 22:19:06.331+00
c0d41b83-d6a3-4ce9-85a7-3cd6f02f9ba4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	149.88	143.64	t	in_stock	2025-08-27 22:19:06.331+00
0bc4339e-fa5e-4068-906f-3998359bee7a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	141.57	143.64	f	out_of_stock	2025-08-28 22:19:06.331+00
6e9e0e26-0247-422f-90f3-543f4d19191e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.27	143.64	t	in_stock	2025-08-29 22:19:06.331+00
53502d3c-9d5a-4e0c-8b39-2708581b85dd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.37	143.64	f	out_of_stock	2025-08-30 22:19:06.331+00
ec4256a6-1c6a-4510-939f-69876694b7cb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.10	143.64	t	in_stock	2025-08-31 22:19:06.331+00
aed9ef86-65ef-42cc-b6f8-b090c019a6da	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.93	143.64	t	in_stock	2025-09-01 22:19:06.331+00
60beb62f-1140-4a54-9710-2133e874347f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.40	143.64	t	in_stock	2025-09-02 22:19:06.331+00
d3d83209-d85b-4f42-857f-dd4a3e431ca3	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.40	143.64	t	in_stock	2025-09-03 22:19:06.331+00
4ebebc97-988d-4b62-a7da-92742608d859	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	151.59	143.64	f	out_of_stock	2025-08-04 22:19:06.331+00
a1bc3aee-ae43-4102-8299-bf7d1f58edcf	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	153.77	143.64	t	in_stock	2025-08-05 22:19:06.331+00
40efe2c7-5907-415e-9269-9b81387c99e7	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	140.98	143.64	t	in_stock	2025-08-06 22:19:06.331+00
dc1e393a-31c2-4fb4-af28-b735e8e2f5ea	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	133.92	143.64	t	in_stock	2025-08-07 22:19:06.331+00
e0b0f67f-2956-4cc5-9c61-386591c10cbd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	136.41	143.64	f	out_of_stock	2025-08-08 22:19:06.331+00
e79f63e8-b809-4e9b-b410-c67bf70b9304	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.83	143.64	f	out_of_stock	2025-08-09 22:19:06.331+00
2ff91897-9ee6-4552-bdd9-d4d1ae0393f9	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	151.17	143.64	t	in_stock	2025-08-10 22:19:06.331+00
bc8a8430-a641-4c14-8687-8e60cb69ab6a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	144.36	143.64	t	in_stock	2025-08-11 22:19:06.331+00
f8f41804-7269-4095-b0ad-d70e7e4785dc	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	146.52	143.64	t	in_stock	2025-08-12 22:19:06.331+00
c1ace185-60c6-4b2b-be36-55f9fddb89d1	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	144.79	143.64	t	in_stock	2025-08-13 22:19:06.331+00
c8a42534-de91-4a8b-8c77-7f26e49e6534	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	153.66	143.64	f	out_of_stock	2025-08-14 22:19:06.331+00
7a47d2e9-6871-47c6-b365-e87ea32e634d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.80	143.64	t	in_stock	2025-08-15 22:19:06.331+00
bf72ee8b-cde6-42aa-855c-82dbe3ab0b36	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.66	143.64	t	in_stock	2025-08-16 22:19:06.331+00
1c47f0d3-162e-4f42-a1a1-1fcb7124d34c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	140.88	143.64	t	in_stock	2025-08-17 22:19:06.331+00
402605aa-2444-4c8e-b56c-2b86e1bd6513	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	140.50	143.64	t	in_stock	2025-08-18 22:19:06.331+00
0e241e99-321c-46e2-9168-d27ed8718ea8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.57	143.64	t	in_stock	2025-08-19 22:19:06.331+00
d4641f3f-c222-4fc3-a6c2-c586f1f49f41	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	145.15	143.64	t	in_stock	2025-08-20 22:19:06.331+00
b06fc73d-e9a2-48a5-861a-9f33082a7b8a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	146.96	143.64	t	in_stock	2025-08-21 22:19:06.331+00
00c57ca7-c1fd-401a-8046-5c0d245fbbb8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	138.64	143.64	t	in_stock	2025-08-22 22:19:06.331+00
d6e1cb14-8bfb-4f0e-a914-64795d6068b4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	149.26	143.64	t	in_stock	2025-08-23 22:19:06.331+00
c86aac61-dee9-4d31-8791-b4de17d8b992	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	154.40	143.64	t	in_stock	2025-08-24 22:19:06.331+00
43eb599f-f5eb-4895-b025-c983a7047739	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	136.17	143.64	f	out_of_stock	2025-08-25 22:19:06.331+00
63cd3547-20b5-4c18-bbc1-36f449c8b226	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	148.40	143.64	t	in_stock	2025-08-26 22:19:06.331+00
909ef2b9-a8e2-46ca-ad9b-18ce60d07f0d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	145.48	143.64	t	in_stock	2025-08-27 22:19:06.331+00
ca464ae9-76db-4fc7-b5a6-9d9568f30a8b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.58	143.64	t	in_stock	2025-08-28 22:19:06.331+00
b5b354cf-17ba-495b-8d7d-1c3f7408e8fd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	148.46	143.64	f	out_of_stock	2025-08-29 22:19:06.331+00
ee640082-8d18-4f7d-b9bf-38005db55078	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	148.04	143.64	t	in_stock	2025-08-30 22:19:06.331+00
99899ea4-87f1-4fd8-9288-db1aca9431b7	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	150.20	143.64	t	in_stock	2025-08-31 22:19:06.331+00
d02b6526-efea-4d48-842e-acd4d37aa560	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	143.82	143.64	t	in_stock	2025-09-01 22:19:06.331+00
7f1a9a87-6302-4b45-a7df-23f30b1c0f2e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	152.68	143.64	t	in_stock	2025-09-02 22:19:06.331+00
d40a2662-5325-44ad-9bbc-eb746de46eaf	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	142.27	143.64	t	in_stock	2025-09-03 22:19:06.331+00
07e4eba8-18fa-417e-89da-1445e848ba5d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.62	49.99	t	in_stock	2025-08-04 22:19:06.331+00
90f937e6-154f-4f13-91ec-08a7354cb8fb	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.27	49.99	t	in_stock	2025-08-05 22:19:06.331+00
c61e66b9-5dbe-4887-b4a7-1a7eafcd9559	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.44	49.99	t	in_stock	2025-08-06 22:19:06.331+00
d3768220-c25b-4049-b68b-0e2f3e2af30d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.43	49.99	t	in_stock	2025-08-07 22:19:06.331+00
aa8c90ab-44e8-44a5-a179-5906d0e508bd	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.40	49.99	t	in_stock	2025-08-08 22:19:06.331+00
4673c99d-9c4d-44e2-bc8f-d298d2fdf671	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.89	49.99	t	in_stock	2025-08-09 22:19:06.331+00
133f32e1-143f-4522-9c93-6b989de55849	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.52	49.99	t	in_stock	2025-08-10 22:19:06.331+00
8dda4fe3-70a3-4c6d-9009-362de7d64bad	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.56	49.99	f	out_of_stock	2025-08-11 22:19:06.331+00
354f39fd-7ffa-44cc-8686-19eed8b7185a	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	48.33	49.99	t	in_stock	2025-08-12 22:19:06.331+00
e2d58c88-86f4-481c-b875-8d3a637adfa5	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.72	49.99	t	in_stock	2025-08-13 22:19:06.331+00
f24fd931-40d0-4afc-b8db-7de0b6f9224d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.25	49.99	t	in_stock	2025-08-14 22:19:06.331+00
2d90f174-b7b5-486d-8f6b-705f2c7dfd72	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.24	49.99	t	in_stock	2025-08-15 22:19:06.331+00
68f5af67-d94e-4e53-b9bd-c407107a34c4	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	50.80	49.99	f	out_of_stock	2025-08-16 22:19:06.331+00
74091727-f03e-46f4-9e0b-c4a5add48d33	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.04	49.99	f	out_of_stock	2025-08-17 22:19:06.331+00
d86bca4b-ac4c-4cfb-bd52-e443f3781533	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.44	49.99	t	in_stock	2025-08-18 22:19:06.331+00
9c9cb844-92d0-4125-9865-48a36a6b2c58	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.97	49.99	f	out_of_stock	2025-08-19 22:19:06.331+00
fb1a2417-b57f-42c4-a6b0-92aab84381ba	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	48.74	49.99	t	in_stock	2025-08-20 22:19:06.331+00
179802bc-3306-4bfe-be30-f9ea84b8f01e	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.73	49.99	t	in_stock	2025-08-21 22:19:06.331+00
f4c260cd-a674-4492-b89c-2eefa771cc10	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.36	49.99	t	in_stock	2025-08-22 22:19:06.331+00
55f5cc51-4282-4806-9e8e-2f28ce46a1c7	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.80	49.99	t	in_stock	2025-08-23 22:19:06.331+00
e35fd47c-55bb-4766-a47a-fac1bb180e5c	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.49	49.99	t	in_stock	2025-08-24 22:19:06.331+00
de40523b-1e4b-41e4-8cae-1e8a8f637e07	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	48.55	49.99	t	in_stock	2025-08-25 22:19:06.331+00
4ea7c0d9-cade-4bc4-ba38-71283fe6ec47	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.60	49.99	t	in_stock	2025-08-26 22:19:06.331+00
4ac38a81-c5af-43c0-adf0-7bde65d87400	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	50.73	49.99	t	in_stock	2025-08-27 22:19:06.331+00
1e2a4b2f-5e5a-43ae-a347-ba3f5f581dc5	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.73	49.99	f	out_of_stock	2025-08-28 22:19:06.331+00
72c5324f-c3a6-4409-af11-378bfd05e774	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.42	49.99	t	in_stock	2025-08-29 22:19:06.331+00
26b2659d-5327-46f8-a7fe-a7e9d9cd33e1	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.93	49.99	t	in_stock	2025-08-30 22:19:06.331+00
92f8c47a-6cf0-4a6c-aad7-aa354e989aa4	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	50.83	49.99	t	in_stock	2025-08-31 22:19:06.331+00
d1af2f88-8b6a-47a2-8caa-b25dc83fb25c	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.20	49.99	t	in_stock	2025-09-01 22:19:06.331+00
5545c3f1-2745-4b6f-8605-b79052c22aa9	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.46	49.99	t	in_stock	2025-09-02 22:19:06.331+00
2c0e894f-2a3e-407c-97ac-b8a0077246d4	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.47	49.99	t	in_stock	2025-09-03 22:19:06.331+00
7404d600-a064-4e41-b04d-bc2395ebd0ff	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	50.66	49.99	f	out_of_stock	2025-08-04 22:19:06.331+00
d1b0c466-517a-47cb-85fd-b08fe598dc96	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.24	49.99	f	out_of_stock	2025-08-05 22:19:06.331+00
21413ca8-a64a-48ae-a181-9d4dbbdc1837	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.81	49.99	t	in_stock	2025-08-06 22:19:06.331+00
60645df0-0c81-47dd-a87b-7784aab568fc	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.16	49.99	t	in_stock	2025-08-07 22:19:06.331+00
23b1face-399d-4adc-ae59-eb0853d9ebcc	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	46.73	49.99	t	in_stock	2025-08-08 22:19:06.331+00
ebedaa01-4b0b-48d3-9070-ed314811734b	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.52	49.99	f	out_of_stock	2025-08-09 22:19:06.331+00
cd52a24b-6db2-436c-af86-b885195f4293	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.70	49.99	t	in_stock	2025-08-10 22:19:06.331+00
d94b16d3-0da4-41c9-8887-dcb8d216b1d3	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.46	49.99	t	in_stock	2025-08-11 22:19:06.331+00
8e4f6b22-8ae0-4a0c-bcd8-987ebc43ac87	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.87	49.99	f	out_of_stock	2025-08-12 22:19:06.331+00
b42050db-63ef-411f-b1ef-64b446e8e3a8	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.40	49.99	f	out_of_stock	2025-08-13 22:19:06.331+00
f9e78760-c468-4577-82d3-ef41d4d13d1a	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.75	49.99	t	in_stock	2025-08-14 22:19:06.331+00
791333cb-44ea-4496-94e7-3896f4217078	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	49.04	49.99	f	out_of_stock	2025-08-15 22:19:06.331+00
0dd02a72-6604-499f-819d-a38b66a642c5	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.14	49.99	t	in_stock	2025-08-16 22:19:06.331+00
a3495341-560b-4ddb-9003-d27a2c4d0374	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.87	49.99	t	in_stock	2025-08-17 22:19:06.331+00
d3bf95e6-b978-48b2-a97f-6bcebe32c348	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.08	49.99	t	in_stock	2025-08-18 22:19:06.331+00
e39d1a01-91c3-4ef8-a6f9-c230ef03d8a6	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.29	49.99	f	out_of_stock	2025-08-19 22:19:06.331+00
66315280-3300-42d1-bbe6-7ddc0e108918	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.49	49.99	f	out_of_stock	2025-08-20 22:19:06.331+00
1b2ca5ff-668b-4917-9f2d-cfbc4802cee5	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	49.93	49.99	t	in_stock	2025-08-21 22:19:06.331+00
4121cb25-9adf-4edc-b58c-4d4945f18ce6	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	46.46	49.99	t	in_stock	2025-08-22 22:19:06.331+00
c3d83fe8-2647-4f6d-bea6-e6f4a10d76f0	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	49.08	49.99	f	out_of_stock	2025-08-23 22:19:06.331+00
d8b8ccec-ce10-43ea-a320-ed732f6c8c84	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.04	49.99	t	in_stock	2025-08-24 22:19:06.331+00
b14d3dbf-791d-4ebc-91b0-7732ae5ef6f2	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	50.26	49.99	t	in_stock	2025-08-25 22:19:06.331+00
beb98c68-5fcd-45ac-8419-5992bdcb6f4a	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.73	49.99	f	out_of_stock	2025-08-26 22:19:06.331+00
910a30ab-67b2-4d4f-a12a-1cdcde100adc	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	46.61	49.99	t	in_stock	2025-08-27 22:19:06.331+00
de13197f-1cb7-40c6-b3ef-6dde28640dde	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	53.20	49.99	t	in_stock	2025-08-28 22:19:06.331+00
02f21c74-b547-4e42-bc37-2275ebc83b56	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	53.69	49.99	t	in_stock	2025-08-29 22:19:06.331+00
6dbfd2da-c224-4085-9c02-bd5fd19f1b0a	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	50.66	49.99	t	in_stock	2025-08-30 22:19:06.331+00
60635248-b7dc-479e-9390-433b277d5fe4	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.59	49.99	t	in_stock	2025-08-31 22:19:06.331+00
b7cfd952-1b2b-41ef-a1d0-a1e197121bb9	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.03	49.99	t	in_stock	2025-09-01 22:19:06.331+00
b07c2822-34ec-42dc-bb05-7dd178f5e714	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.19	49.99	f	out_of_stock	2025-09-02 22:19:06.331+00
ecbce80d-2ced-45f0-a613-6525d2065be7	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.63	49.99	t	in_stock	2025-09-03 22:19:06.331+00
bf537877-e47c-4e75-8668-e0c0eeeb9843	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.92	49.99	t	in_stock	2025-09-04 16:00:00.862+00
03a50718-b7b8-4241-84ff-18a5da1242cf	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	48.15	49.99	t	in_stock	2025-09-04 16:00:00.862+00
2aa58b1a-0f3d-4645-b081-912cf45d2d75	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	52.33	49.99	t	in_stock	2025-09-04 16:00:00.862+00
7ee657d9-e7e7-4d88-8a80-a962f2485f6b	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	49.77	49.99	t	in_stock	2025-09-04 16:00:00.862+00
3f9275d3-d1fd-4524-adc0-8baf07620c56	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.40	143.64	t	in_stock	2025-09-04 16:00:00.862+00
75ba49f9-56e3-4235-a6f6-ab2a5a98d407	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	132.82	143.64	t	in_stock	2025-09-04 16:00:00.862+00
79c8695d-c3f1-46f2-8cf9-0faed365bc55	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	135.12	143.64	t	in_stock	2025-09-04 16:00:00.862+00
73190a66-f287-4b75-8aec-99e9d1b10e0b	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	51.96	49.99	t	in_stock	2025-09-04 16:00:00.862+00
d2bb35aa-251c-47ea-8a1d-0d76898c55b4	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	50.63	49.99	t	low_stock	2025-09-04 16:00:00.862+00
8c9cde13-1044-4cb1-86ef-7fc809377714	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	52.38	49.99	t	in_stock	2025-09-04 16:00:00.862+00
1b91d622-12b7-4fd7-a829-c0eb513d5b4a	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	53.54	49.99	t	in_stock	2025-09-04 16:00:00.862+00
26d7e1d6-61c2-497b-8185-c78764ef995e	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	49.31	49.99	t	in_stock	2025-09-04 16:00:00.862+00
16fa2066-4f99-4ecc-ac7b-0373da81e3af	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	131.53	143.64	t	in_stock	2025-09-04 16:00:00.862+00
0e3b3dde-3020-42d6-b6b3-5e8074fdad48	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	135.92	143.64	t	low_stock	2025-09-04 16:00:00.862+00
7c38d979-b1ea-4906-85b8-c1ae5960eac3	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	153.70	143.64	t	in_stock	2025-09-04 16:00:00.862+00
ff00de15-864e-4045-ac9c-b0d34c039ae4	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.29	143.64	t	in_stock	2025-09-04 16:00:00.862+00
7ce68f03-b68b-4a65-90ba-db2dbe153f07	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.74	143.64	t	in_stock	2025-09-04 16:00:00.862+00
6d292cf0-480b-4bcd-997b-004dc46325fd	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.44	143.64	t	in_stock	2025-09-04 16:00:00.862+00
37227288-e74b-4e91-a967-b30a50a1863e	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	135.90	143.64	t	in_stock	2025-09-04 16:00:00.862+00
3f3d7f65-d057-40a7-898f-4c56b28f6fc1	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.20	143.64	t	in_stock	2025-09-04 16:00:00.862+00
b2bd6536-c0e2-4a9e-a87f-5c6ff5cd8921	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	132.53	143.64	t	in_stock	2025-09-04 16:00:00.862+00
006851c2-4909-40af-abbb-9d6e3e634938	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.33	143.64	t	in_stock	2025-09-04 16:00:00.862+00
62a8cb81-3673-43db-b226-c166c51b217c	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.89	143.64	t	in_stock	2025-09-04 16:00:00.862+00
d663cf41-9436-4a57-bc22-24379330b846	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	145.77	143.64	t	in_stock	2025-09-04 16:00:00.862+00
49fe001c-1a3e-4bed-9442-f45e43fdac55	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	131.43	143.64	t	low_stock	2025-09-04 16:00:00.862+00
b38dde17-1a80-4935-869f-c68f22849d9a	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	148.22	143.64	t	in_stock	2025-09-04 16:00:00.862+00
abd6ccbc-352d-4f4d-8e36-d91230783d13	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	142.64	143.64	t	in_stock	2025-09-04 16:00:00.862+00
6a2832ef-ff06-41d7-b1a5-c419504d8897	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	130.54	143.64	t	in_stock	2025-09-04 16:00:00.862+00
62f94772-9fc6-4cff-a0c6-1777daee0dbc	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	152.66	143.64	t	in_stock	2025-09-04 16:00:00.862+00
cff3b9c4-e41c-47d3-b98c-cae525c4f777	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	137.64	143.64	t	in_stock	2025-09-04 16:00:00.862+00
26a2bf8c-ce2a-4bc5-a700-c734bcbca76b	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 16:00:00.862+00
34d6bcd9-f032-4ebd-a126-2ba11bd66cd6	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 16:00:00.862+00
a764a00a-62b9-4698-b560-7e6d3f7f6279	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 16:00:00.862+00
faada742-9cbc-47de-8a9e-c478160d45a6	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 16:00:00.862+00
8b972c55-78d0-4f01-89b7-477db160c446	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 16:00:00.862+00
f7067a0f-66ed-4bdf-9181-1c9ee4ce289b	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 16:00:00.862+00
b20b4efb-f8db-4f41-9630-36a9a20808c3	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 16:00:00.862+00
0c327a04-9ba1-4b45-86af-62d680d37135	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 16:00:00.862+00
49aa2ee4-395f-4ee1-8602-74800ce503e5	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 16:00:00.862+00
e0e8ab5e-af7f-404c-9960-360462a29836	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 16:00:00.862+00
5fbcb56e-6365-477e-94bf-7cf2e7ba352c	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 16:00:00.862+00
429968b1-4d90-487c-8580-c3f511e9dafd	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 16:00:00.862+00
e069007a-9ebe-42ea-a17c-f959d2b58396	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 16:00:00.862+00
1e062823-6f84-41f6-9a3d-a397147750a6	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 16:00:00.862+00
0a528bf4-34b4-41e3-a025-f5ee30bf1a66	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 16:00:00.862+00
7a2e9dee-22ee-48e7-a79e-10c4746409a4	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 16:00:00.862+00
67777cc1-3826-47e1-8c7d-861a432e280e	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 16:00:00.862+00
d8f06054-2f03-4644-a0ab-25c67ca2ea9f	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 16:00:00.862+00
1b893989-7395-49f6-bb77-82214731f21f	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 16:00:00.862+00
d8c0a60f-53b1-47f3-ae7e-ca94ffa13e1e	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 16:00:00.862+00
03af6089-ece7-4154-be92-ebdab11a9836	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 16:00:00.862+00
ffd71c44-305e-438c-9468-b87a455d4632	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 16:00:00.862+00
ff31dc5f-2740-483f-b6f8-6c9e2b7330f3	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	399.99	\N	t	in_stock	2025-09-04 20:00:00.085+00
b69198a9-5828-4dfc-8e1d-fff851e4a51e	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
21242037-cdf1-4e06-94cc-991d496203ff	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	34.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
92b62e35-db85-46dc-b1b6-308634b4044d	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	t	in_stock	2025-09-04 20:00:00.085+00
19188909-d53d-4a86-8a01-644d36be31e3	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	29.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
ffebe652-1af3-469c-bc8a-44da93b6d612	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	19.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
ae502796-d8fb-41aa-b048-d927d1ba43ff	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
14d8d59d-385d-456a-8519-0df5c5f629b1	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
a03948da-9738-4f26-9d3b-c8f522768b86	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	21.99	\N	f	out_of_stock	2025-09-04 20:00:00.085+00
a5baf448-a4c9-4cfc-9538-a7348374d355	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	131.75	143.64	t	low_stock	2025-09-04 20:00:00.085+00
325a7ea1-a575-4711-8823-f23fa05e0298	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.06	143.64	t	in_stock	2025-09-04 20:00:00.085+00
2cd83477-a13d-4bd5-889c-15971d6fb444	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	145.11	143.64	t	low_stock	2025-09-04 20:00:00.085+00
c02275c0-c43f-401a-aa03-3db0bdf58d53	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	133.45	143.64	t	in_stock	2025-09-04 20:00:00.085+00
a95aac95-7d34-452a-9648-942612259286	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	146.50	143.64	t	in_stock	2025-09-04 20:00:00.085+00
c7faec5e-3f2f-4062-9363-4ec6a33e40ea	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	152.88	143.64	t	low_stock	2025-09-04 20:00:00.085+00
cc2c64dd-dfe6-43bf-996a-a221a45271db	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	50.16	49.99	t	low_stock	2025-09-04 20:00:00.085+00
0d1ed140-8df1-49ce-a3b2-26d12c19cc74	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	50.90	49.99	t	low_stock	2025-09-04 20:00:00.085+00
a61a8ba6-43eb-4583-90ef-7b2b4c0ee5df	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	51.51	49.99	t	in_stock	2025-09-04 20:00:00.085+00
fcb5945f-6d76-4858-8628-a78bb6957cb5	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	51.32	49.99	t	in_stock	2025-09-04 20:00:00.085+00
8ed4f639-099a-4430-b233-3c00e3223503	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.38	49.99	t	in_stock	2025-09-04 20:00:00.085+00
b45eb2f1-2f07-4e0a-9cac-b32d9bd00ad3	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	53.61	49.99	t	in_stock	2025-09-04 20:00:00.085+00
5742338c-1007-4e0a-a1d8-c9b64b7df34c	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	47.87	49.99	t	in_stock	2025-09-04 20:00:00.085+00
42a375c7-347b-43f5-80b5-a19660f2288a	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	46.89	49.99	t	in_stock	2025-09-04 20:00:00.085+00
a831092e-c038-4230-a98e-860026655e64	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	54.93	49.99	t	low_stock	2025-09-04 20:00:00.085+00
5d078944-5fe5-4182-91ac-6b462bb9fbcb	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	46.01	49.99	t	low_stock	2025-09-04 20:00:00.085+00
0971a930-f71d-47b0-8d69-7a4abea56596	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	53.54	49.99	t	in_stock	2025-09-04 20:00:00.085+00
19328a3a-8de5-4ac7-ae1f-f941713f069c	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.90	143.64	t	in_stock	2025-09-04 20:00:00.085+00
c2e2a8e2-fa89-4349-b8ea-5798f39a16d2	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	141.85	143.64	t	in_stock	2025-09-04 20:00:00.085+00
fb8b3254-a5f2-493c-958d-0ea4207d1216	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	154.17	143.64	t	in_stock	2025-09-04 20:00:00.085+00
daecaca2-d39a-46c4-a12b-ad383ecc9d36	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	133.40	143.64	t	in_stock	2025-09-04 20:00:00.085+00
ddf79bda-8787-47e5-8d55-059927aad552	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	130.01	143.64	t	in_stock	2025-09-04 20:00:00.085+00
\.


--
-- TOC entry 4352 (class 0 OID 16594)
-- Dependencies: 224
-- Data for Name: product_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_availability (id, product_id, retailer_id, in_stock, price, original_price, availability_status, product_url, cart_url, stock_level, store_locations, last_checked, last_in_stock, last_price_change, created_at, updated_at) FROM stdin;
0f6c7988-57dc-46c8-8c36-5a33e2767169	e992a9bd-a88c-40a7-81e2-74094b08ffb0	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	399.99	\N	in_stock	https://api.bestbuy.com/click/-/6562098/pdp	https://www.bestbuy.com/cart?skuId=6562098	\N	[]	2025-09-04 15:01:31.214+00	\N	\N	2025-09-04 15:01:31.215+00	2025-09-04 15:01:31.214+00
7d3fe81c-a244-495c-9f89-31f28d9bb551	a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	49.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6548417/pdp	https://www.bestbuy.com/cart?skuId=6548417	\N	[]	2025-09-04 15:01:31.22+00	\N	\N	2025-09-04 15:01:31.22+00	2025-09-04 15:01:31.22+00
ba18fb11-39b3-43a4-8cec-89c653486cf2	f0353094-2fbd-42af-9333-6ed59071a433	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	34.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6642990/pdp	https://www.bestbuy.com/cart?skuId=6642990	\N	[]	2025-09-04 15:01:31.23+00	\N	\N	2025-09-04 15:01:31.225+00	2025-09-04 15:01:31.23+00
8258f182-d7bc-41d8-9076-00477db5008e	614ae820-afe1-4f1d-9f77-b40a8a4b95fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	19.99	\N	in_stock	https://api.bestbuy.com/click/-/6500508/pdp	https://www.bestbuy.com/cart?skuId=6500508	\N	[]	2025-09-04 15:01:31.234+00	\N	\N	2025-09-04 15:01:31.234+00	2025-09-04 15:01:31.234+00
52700671-5fd6-46c7-97b9-9f668056f7bd	d4708878-a77a-494e-9cfb-408546e56744	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	29.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6506756/pdp	https://www.bestbuy.com/cart?skuId=6506756	\N	[]	2025-09-04 15:01:31.238+00	\N	\N	2025-09-04 15:01:31.238+00	2025-09-04 15:01:31.238+00
eb7b376d-0b90-41e5-87ad-295d9a961094	d9b02003-c537-45a2-84d1-7d054a5419b4	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	19.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6516474/pdp	https://www.bestbuy.com/cart?skuId=6516474	\N	[]	2025-09-04 15:01:31.242+00	\N	\N	2025-09-04 15:01:31.243+00	2025-09-04 15:01:31.242+00
46412ad5-1d8f-4972-b985-31a5624a827f	b411b2ac-b68f-4a43-be65-2e4057d3e705	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	21.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6543916/pdp	https://www.bestbuy.com/cart?skuId=6543916	\N	[]	2025-09-04 15:01:31.247+00	\N	\N	2025-09-04 15:01:31.247+00	2025-09-04 15:01:31.247+00
96bd4acd-550a-47e5-a281-c6d19822cd06	477d4790-531e-49f5-95eb-aba575e6ccdb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	49.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6569653/pdp	https://www.bestbuy.com/cart?skuId=6569653	\N	[]	2025-09-04 15:01:31.251+00	\N	\N	2025-09-04 15:01:31.252+00	2025-09-04 15:01:31.251+00
e21a5760-114e-4101-8523-e495640517bc	69677974-4220-4141-8da6-b77681a0468a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	21.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6573891/pdp	https://www.bestbuy.com/cart?skuId=6573891	\N	[]	2025-09-04 15:01:31.26+00	\N	\N	2025-09-04 15:01:31.261+00	2025-09-04 15:01:31.26+00
e918b491-143c-469b-8a27-f948c1420813	70dbe682-bead-4c05-98f3-afb3f9d5fa9c	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	21.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6580252/pdp	https://www.bestbuy.com/cart?skuId=6580252	\N	[]	2025-09-04 15:01:31.265+00	\N	\N	2025-09-04 15:01:31.265+00	2025-09-04 15:01:31.265+00
52c0fdab-15ef-4f70-b209-c3f34a6f011a	d8b06d4e-7869-44df-9d5e-35e7c771be57	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	24.99	\N	in_stock	https://api.bestbuy.com/click/-/6580253/pdp	https://www.bestbuy.com/cart?skuId=6580253	\N	[]	2025-09-04 15:01:31.269+00	\N	\N	2025-09-04 15:01:31.269+00	2025-09-04 15:01:31.269+00
6e839d41-4323-4a61-861b-178075f81878	468d4217-6c02-458f-aad7-5242437b2a7d	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	49.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6586142/pdp	https://www.bestbuy.com/cart?skuId=6586142	\N	[]	2025-09-04 15:01:31.273+00	\N	\N	2025-09-04 15:01:31.274+00	2025-09-04 15:01:31.273+00
9b9bcc06-e408-4296-ba27-5093898d9faa	939c25a1-fe07-46bf-87a4-d485be7c1857	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	21.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6590380/pdp	https://www.bestbuy.com/cart?skuId=6590380	\N	[]	2025-09-04 15:01:31.278+00	\N	\N	2025-09-04 15:01:31.278+00	2025-09-04 15:01:31.278+00
1d4b1601-f8c6-4658-baa5-3754b3c57594	45ad0421-328b-4b17-9690-4d44e691791f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	160.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6571897/pdp	https://www.bestbuy.com/cart?skuId=6571897	\N	[]	2025-09-04 15:02:02.154+00	\N	\N	2025-09-04 15:02:02.154+00	2025-09-04 15:02:02.154+00
941ec806-59df-438c-b291-3a21714c2e45	133cb1a8-1700-4717-a5e7-25a772ef5959	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	26.94	\N	out_of_stock	https://api.bestbuy.com/click/-/6548371/pdp	https://www.bestbuy.com/cart?skuId=6548371	\N	[]	2025-09-04 15:02:32.961+00	\N	\N	2025-09-04 15:02:32.962+00	2025-09-04 15:02:32.961+00
b46485e3-d987-4237-a2c4-498c8b1da4c8	b1f621a7-58f9-4331-89d8-30fef84cf142	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	160.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6578901/pdp	https://www.bestbuy.com/cart?skuId=6578901	\N	[]	2025-09-04 15:02:32.966+00	\N	\N	2025-09-04 15:02:02.149+00	2025-09-04 15:02:32.966+00
8b1ac179-79dc-48ec-807d-483b515e87e8	cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	14.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6587212/pdp	https://www.bestbuy.com/cart?skuId=6587212	\N	[]	2025-09-04 15:02:32.97+00	\N	\N	2025-09-04 15:02:32.971+00	2025-09-04 15:02:32.97+00
4f92097c-4f30-4cae-9563-8fc846746b83	66b0a163-79ec-4390-8e4f-9745ef86dc29	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	23.94	\N	out_of_stock	https://api.bestbuy.com/click/-/6595705/pdp	https://www.bestbuy.com/cart?skuId=6595705	\N	[]	2025-09-04 15:02:32.975+00	\N	\N	2025-09-04 15:02:32.975+00	2025-09-04 15:02:32.975+00
4e35b60a-579a-44a8-80b1-9a8499e272ee	8302fac6-b536-46ab-aac6-377d9a88c360	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	26.94	\N	out_of_stock	https://api.bestbuy.com/click/-/6584432/pdp	https://www.bestbuy.com/cart?skuId=6584432	\N	[]	2025-09-04 15:02:32.979+00	\N	\N	2025-09-04 15:02:32.98+00	2025-09-04 15:02:32.979+00
63c947fc-ac08-4655-a1b4-02f7a9856e07	e48ccb10-a767-4605-a0ff-f23480597124	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	49.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6506752/pdp	https://www.bestbuy.com/cart?skuId=6506752	\N	[]	2025-09-04 18:10:40.081+00	\N	\N	2025-09-04 15:01:31.209+00	2025-09-04 18:10:40.081+00
10c89250-323b-47c9-aa33-c8764d884470	0933e019-c545-48ba-8ba1-854a9cfc84fa	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	9.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6607716/pdp	https://www.bestbuy.com/cart?skuId=6607716	\N	[]	2025-09-04 15:02:48.384+00	\N	\N	2025-09-04 15:02:48.385+00	2025-09-04 15:02:48.384+00
0bf8fb32-fc97-439a-a0f6-939b69af9755	cadea567-c448-4789-872d-49fa516ea9bb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	14.99	\N	out_of_stock	https://api.bestbuy.com/click/-/6569648/pdp	https://www.bestbuy.com/cart?skuId=6569648	\N	[]	2025-09-04 18:10:40.075+00	\N	\N	2025-09-04 18:09:54.559+00	2025-09-04 18:10:40.075+00
55ccd58f-fac1-4999-8943-e7100fbfa0bf	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c07d2d13-331a-4543-9e1b-a71d35558b0e	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bab64c86-c85c-4301-89f5-b18ab6dbfb2a	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	132.97	143.64	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-base-booster-box	\N	11	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b0db8cae-8e90-42b1-af88-57e6029354ce	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6064a3c3-cd21-4f95-859a-63cedfdd95b7	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	157.65	143.64	in_stock	https://www.gamestop.com/products/pokemon-scarlet-violet-base-booster-box	\N	13	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4f656adc-7f9c-458e-87ed-1895afaf2bb6	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	130.29	143.64	in_stock	https://www.target.com/products/pokemon-scarlet-violet-base-booster-box	\N	2	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bb7f7f54-388d-489a-aa74-83dc0a986cc5	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	150.04	143.64	in_stock	https://www.bestbuy.com/products/pokemon-paldea-evolved-booster-box	https://www.bestbuy.com/cart/add/SV02-BB-EN	30	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
fda132f8-a809-4d56-b0cd-a2922dd7cc7d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	147.37	143.64	in_stock	https://www.walmart.com/products/pokemon-paldea-evolved-booster-box	\N	12	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
474b2348-cd4d-4ac8-b6fd-94f9fdd8c5bb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	144.92	143.64	in_stock	https://www.costco.com/products/pokemon-paldea-evolved-booster-box	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c6197be8-8d5f-49c1-ad0c-d94b4c6ee5cb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	139.87	143.64	in_stock	https://www.samsclub.com/products/pokemon-paldea-evolved-booster-box	\N	30	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b1f27949-6362-4e81-ae18-e0c4e7be493c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-paldea-evolved-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3b3c961b-b7f6-49ef-96c2-8c262f41fc38	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	139.55	143.64	in_stock	https://www.target.com/products/pokemon-paldea-evolved-booster-box	\N	40	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8e9343df-6017-416c-a709-510a85a37f1d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4a0d01f0-5bd2-439a-b7fa-dccf79c90f61	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
281892bb-68af-4efb-b2c9-a73be181fe0a	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	48.91	49.99	in_stock	https://www.costco.com/products/pokemon-151-elite-trainer-box	\N	9	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
5b70cb09-762b-4495-80d1-185daf203217	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	47.53	49.99	low_stock	https://www.samsclub.com/products/pokemon-151-elite-trainer-box	\N	23	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6a5f8af4-e74c-4750-97a7-14acc110656b	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	52.78	49.99	in_stock	https://www.gamestop.com/products/pokemon-151-elite-trainer-box	\N	30	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
72352e94-c265-4e16-b884-0008c31d949d	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c00066b5-2bc5-42f4-b6de-5c32b9dd825b	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	119.99	out_of_stock	https://www.bestbuy.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6666351f-59b8-4fdd-b1a0-9f6d0f5a7f09	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	117.02	119.99	in_stock	https://www.walmart.com/products/charizard-ex-super-premium-collection	\N	5	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
0d406ba2-3618-4126-a305-1b42db974d97	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	125.73	119.99	low_stock	https://www.costco.com/products/charizard-ex-super-premium-collection	\N	43	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7937ec1f-21e8-4acf-994a-b56bddf2ebf8	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	127.02	119.99	in_stock	https://www.samsclub.com/products/charizard-ex-super-premium-collection	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b45486e6-0425-48b3-9123-6ab73c569254	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	119.99	out_of_stock	https://www.gamestop.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
ff7f1bb5-a0c9-4739-b9f3-7796526c113c	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	119.99	out_of_stock	https://www.target.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
65d1aedd-0ddf-4533-9ec5-c790519d787e	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	4.22	3.99	in_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-booster-pack	https://www.bestbuy.com/cart/add/SV01-BP-EN	6	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
81539360-5698-495a-baaa-e1e08a812174	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	3.60	3.99	in_stock	https://www.walmart.com/products/pokemon-scarlet-violet-booster-pack	\N	34	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7ecd3091-0b02-4e05-9768-bc34c35d32c7	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	3.67	3.99	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-booster-pack	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3ee7880f-d0b0-449e-8ec7-a78b9d1a5a0c	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	3.99	out_of_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-booster-pack	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
69c700a1-7444-499f-828a-25c3ce05ca87	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	3.99	3.99	in_stock	https://www.gamestop.com/products/pokemon-scarlet-violet-booster-pack	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d6841827-1f97-4735-9153-db3857054ed3	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	4.32	3.99	in_stock	https://www.target.com/products/pokemon-scarlet-violet-booster-pack	\N	31	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
758838e4-0ed3-4c57-9346-b739f76849ca	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	152.88	143.64	in_stock	https://www.bestbuy.com/products/pokemon-obsidian-flames-booster-box	https://www.bestbuy.com/cart/add/SV03-BB-EN	7	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
9b0784cc-01f9-4394-95b5-8e2043ab70df	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8c3bcac6-b103-465a-b14c-efc19210e703	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	147.76	143.64	in_stock	https://www.costco.com/products/pokemon-obsidian-flames-booster-box	\N	36	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
a312b277-4dec-43cd-b42c-42d9e510689f	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	147.83	143.64	in_stock	https://www.samsclub.com/products/pokemon-obsidian-flames-booster-box	\N	20	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7debe415-89b6-4ae5-ab43-12aa334905d8	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
efc289df-8629-447e-b07b-a611ced65e31	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	130.79	143.64	in_stock	https://www.target.com/products/pokemon-obsidian-flames-booster-box	\N	49	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
e758c56f-2afa-4e84-a33f-34c19f10d82e	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	132.69	143.64	in_stock	https://www.bestbuy.com/products/pokemon-paradox-rift-booster-box	https://www.bestbuy.com/cart/add/SV04-BB-EN	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6e442a19-27f0-425d-aacb-4e5aaa8914f3	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	142.03	143.64	in_stock	https://www.walmart.com/products/pokemon-paradox-rift-booster-box	\N	12	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
f37d2b64-8acc-4f3c-8cb0-bd2023306421	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	156.31	143.64	in_stock	https://www.costco.com/products/pokemon-paradox-rift-booster-box	\N	21	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
933aabab-3279-4927-984a-7c33a915ae74	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
19736ac6-7c80-4cd4-8290-41e4056675b6	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
ade73d0e-bf73-460e-b7e3-74bf3f2a46da	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
ccc4af21-2966-45b4-b7cd-4e897e85548e	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	46.51	49.99	low_stock	https://www.bestbuy.com/products/pokemon-paldean-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SV4.5-ETB-EN	14	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
0fdf6702-9eb7-423d-9045-6e44ec34dbb7	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	47.89	49.99	in_stock	https://www.walmart.com/products/pokemon-paldean-fates-elite-trainer-box	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
2cffaca6-1e20-4d15-9f2c-e995a56f715a	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	47.92	49.99	in_stock	https://www.costco.com/products/pokemon-paldean-fates-elite-trainer-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
482baf31-8697-4e4c-bedf-43a217eec385	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	48.15	49.99	in_stock	https://www.samsclub.com/products/pokemon-paldean-fates-elite-trainer-box	\N	7	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6c5c6162-6c23-4462-8661-c42723030017	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	52.33	49.99	in_stock	https://www.gamestop.com/products/pokemon-paldean-fates-elite-trainer-box	\N	40	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4c447098-5fd6-4428-b7a9-52b5f5bc58c0	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	49.77	49.99	in_stock	https://www.target.com/products/pokemon-paldean-fates-elite-trainer-box	\N	31	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c33f83a7-d856-426f-86c1-f6bc04d239eb	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	140.40	143.64	in_stock	https://www.bestbuy.com/products/pokemon-temporal-forces-booster-box	https://www.bestbuy.com/cart/add/SV05-BB-EN	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
974c379c-eea2-43d3-bee5-cfcdea784242	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
fe76c309-73e9-4f9a-bf00-0c2fef2745d5	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
a0b39052-b70b-4161-9baa-da0637e039ba	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	132.82	143.64	in_stock	https://www.samsclub.com/products/pokemon-temporal-forces-booster-box	\N	1	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
9b69c258-4396-40ef-abd2-158f9b2efdbf	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	135.12	143.64	in_stock	https://www.gamestop.com/products/pokemon-temporal-forces-booster-box	\N	5	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bc7209b1-16f2-4906-a741-8fc76c1d477e	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
cab811c8-e408-4f76-bea7-7a28e6b83c3b	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	51.96	49.99	in_stock	https://www.bestbuy.com/products/pokemon-crown-zenith-elite-trainer-box	https://www.bestbuy.com/cart/add/SWSH12.5-ETB-EN	29	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
735c25c9-2f61-4e79-89af-697e37286f6a	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	50.63	49.99	low_stock	https://www.walmart.com/products/pokemon-crown-zenith-elite-trainer-box	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4b0a0598-8e94-48c2-8941-0c0008110db4	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	52.38	49.99	in_stock	https://www.costco.com/products/pokemon-crown-zenith-elite-trainer-box	\N	7	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
adf22a30-edd8-4866-bdef-12b2b80a5949	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	53.54	49.99	in_stock	https://www.samsclub.com/products/pokemon-crown-zenith-elite-trainer-box	\N	19	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6de93453-fc5d-48c0-9469-e156e5d6a621	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	49.31	49.99	in_stock	https://www.gamestop.com/products/pokemon-crown-zenith-elite-trainer-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
87d993f6-1051-4595-9ff7-e43e3e604578	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
15bdfe17-b06a-4a83-a7da-8aeab712d80f	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	131.53	143.64	in_stock	https://www.bestbuy.com/products/pokemon-evolving-skies-booster-box	https://www.bestbuy.com/cart/add/SWSH07-BB-EN	18	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
20fc0afb-5bcf-4180-934b-439fb8516590	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	135.92	143.64	low_stock	https://www.walmart.com/products/pokemon-evolving-skies-booster-box	\N	19	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1e1bc821-2db0-4410-a84e-7873a7a4e13d	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	153.70	143.64	in_stock	https://www.costco.com/products/pokemon-evolving-skies-booster-box	\N	39	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7187dd93-8e6d-4669-8788-cd072d69dac2	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	145.29	143.64	in_stock	https://www.samsclub.com/products/pokemon-evolving-skies-booster-box	\N	15	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
97201f01-a992-42e9-81ff-717100ee81a2	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	133.74	143.64	in_stock	https://www.gamestop.com/products/pokemon-evolving-skies-booster-box	\N	1	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
44080dab-9f4b-4e28-91c8-fe05cc74208b	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-evolving-skies-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8df92241-53a6-4168-93f2-e563cb26af35	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	135.44	143.64	in_stock	https://www.bestbuy.com/products/pokemon-brilliant-stars-booster-box	https://www.bestbuy.com/cart/add/SWSH09-BB-EN	18	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4951c3c8-f89d-4b3f-a0c3-176a7805912b	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bfc382d9-d6b8-4f11-a3cc-87a066ea49bc	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	135.90	143.64	in_stock	https://www.costco.com/products/pokemon-brilliant-stars-booster-box	\N	22	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
f5b06944-64d6-458b-b1ee-36a00ec40e79	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1f14ab6b-7eb8-4b27-a341-ec375fed0f14	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	152.20	143.64	in_stock	https://www.gamestop.com/products/pokemon-brilliant-stars-booster-box	\N	38	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
821cf8a9-a0df-4c2d-800d-4e3027e5a53b	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	132.53	143.64	in_stock	https://www.target.com/products/pokemon-brilliant-stars-booster-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6ac17680-d507-4188-9f6f-3f37d952ee57	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	153.33	143.64	in_stock	https://www.bestbuy.com/products/pokemon-lost-origin-booster-box	https://www.bestbuy.com/cart/add/SWSH11-BB-EN	38	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
9dea4669-9c8f-4167-b63a-255141108085	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-lost-origin-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
719faf06-8215-42a3-b5ea-9a9266b63596	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	141.89	143.64	in_stock	https://www.costco.com/products/pokemon-lost-origin-booster-box	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d3b482ef-691f-43a9-97d9-15568115e019	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	145.77	143.64	in_stock	https://www.samsclub.com/products/pokemon-lost-origin-booster-box	\N	24	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c5c6bae2-f487-46d6-b719-709d9ca2f423	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	131.43	143.64	low_stock	https://www.gamestop.com/products/pokemon-lost-origin-booster-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
966d3a37-afa0-4a36-8ae2-883e4d5d2ae9	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	148.22	143.64	in_stock	https://www.target.com/products/pokemon-lost-origin-booster-box	\N	1	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
93f5b611-9635-4a11-a7d0-7c219d8d235b	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-astral-radiance-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c412ffd7-c5f4-445c-b557-c5f06fea2757	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	142.64	143.64	in_stock	https://www.walmart.com/products/pokemon-astral-radiance-booster-box	\N	50	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
5cf20179-7b75-4040-a339-f2b5e49390e1	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	130.54	143.64	in_stock	https://www.costco.com/products/pokemon-astral-radiance-booster-box	\N	11	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
69723fb3-4ae3-45eb-bddf-d9f53d050274	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	152.66	143.64	in_stock	https://www.samsclub.com/products/pokemon-astral-radiance-booster-box	\N	49	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
02ff6648-bea4-4c07-83ca-76aab0870739	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	137.64	143.64	in_stock	https://www.gamestop.com/products/pokemon-astral-radiance-booster-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
35d84216-051a-4da9-bce2-2d8843a47887	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	131.75	143.64	low_stock	https://www.target.com/products/pokemon-astral-radiance-booster-box	\N	38	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b052660d-a1c8-40fc-8f74-fce6dea467db	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	139.06	143.64	in_stock	https://www.bestbuy.com/products/pokemon-fusion-strike-booster-box	https://www.bestbuy.com/cart/add/SWSH08-BB-EN	39	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8f5bf13e-fcb5-49d0-ab26-55f9d5a6eef0	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	145.11	143.64	low_stock	https://www.walmart.com/products/pokemon-fusion-strike-booster-box	\N	20	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6d697ef4-19c8-4d6c-bf36-2220301955bf	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	133.45	143.64	in_stock	https://www.costco.com/products/pokemon-fusion-strike-booster-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3101265b-700c-4118-97f5-5df25503f708	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	146.50	143.64	in_stock	https://www.samsclub.com/products/pokemon-fusion-strike-booster-box	\N	50	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d9cdfbdb-4898-4af6-b09d-c546da87f1f8	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	152.88	143.64	low_stock	https://www.gamestop.com/products/pokemon-fusion-strike-booster-box	\N	27	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8b3bd26b-d365-433a-9ac3-715641481160	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
0bc51b33-0714-44f0-bae2-4582af177551	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
dad4e73b-7ed9-4e93-87f9-ade3d2cd5957	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	50.16	49.99	low_stock	https://www.walmart.com/products/pokemon-celebrations-elite-trainer-box	\N	14	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
79b200a4-be4f-428e-8515-fb5a5919e4ae	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	50.90	49.99	low_stock	https://www.costco.com/products/pokemon-celebrations-elite-trainer-box	\N	39	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
78a1a747-2569-4b71-af6c-6e1d420948d5	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d330b6f4-32ad-4df1-bb99-f3a31ffef54c	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	51.51	49.99	in_stock	https://www.gamestop.com/products/pokemon-celebrations-elite-trainer-box	\N	37	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7f14f6ec-fa01-4f6f-9238-6dd10a329211	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	51.32	49.99	in_stock	https://www.target.com/products/pokemon-celebrations-elite-trainer-box	\N	49	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
21789672-f1e0-4ae1-8873-b61dee06b33e	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	53.38	49.99	in_stock	https://www.bestbuy.com/products/pokemon-shining-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SWSH4.5-ETB-EN	20	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8f4ca2ce-e514-4d14-a6e2-516abf8314a4	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	53.61	49.99	in_stock	https://www.walmart.com/products/pokemon-shining-fates-elite-trainer-box	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bb7e6214-77c0-41b4-856a-01e22e6f37f8	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	47.87	49.99	in_stock	https://www.costco.com/products/pokemon-shining-fates-elite-trainer-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
94595486-ffd0-4c85-8e44-e510a53d9d35	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-shining-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6c57100d-4391-4e1d-8d55-6e932a0ae820	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	49.99	out_of_stock	https://www.gamestop.com/products/pokemon-shining-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b8f6f6e6-bac5-4dc9-a4ba-059d6a207036	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	46.89	49.99	in_stock	https://www.target.com/products/pokemon-shining-fates-elite-trainer-box	\N	2	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
33edd7bd-540f-4a21-9ad2-01ea47bced21	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
108b36bd-e4f6-4a93-ab2d-9e64de239ec5	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1317b3c9-3683-4a68-a260-bfdcf8eade84	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	54.93	49.99	low_stock	https://www.costco.com/products/pokemon-hidden-fates-elite-trainer-box	\N	3	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3710b062-294a-4f4d-9910-d3e7521cec80	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	46.01	49.99	low_stock	https://www.samsclub.com/products/pokemon-hidden-fates-elite-trainer-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4e8ee146-b44e-42fe-b35c-2dc9f7cf820b	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	53.54	49.99	in_stock	https://www.gamestop.com/products/pokemon-hidden-fates-elite-trainer-box	\N	23	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
526d9c8c-1043-4f3d-aeea-e3dae2d58e08	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
70340da9-f972-4b74-a1c0-807b99aa1827	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	146.90	143.64	in_stock	https://www.bestbuy.com/products/pokemon-chilling-reign-booster-box	https://www.bestbuy.com/cart/add/SWSH06-BB-EN	19	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
46be8e13-3293-42a9-9ea7-11d79169f0cd	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-chilling-reign-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1c0743a4-71ab-4152-826d-69fdbc41fce2	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	141.85	143.64	in_stock	https://www.costco.com/products/pokemon-chilling-reign-booster-box	\N	34	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
dc32dab1-47b2-4fef-b773-8298df686c59	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	154.17	143.64	in_stock	https://www.samsclub.com/products/pokemon-chilling-reign-booster-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3b9771b2-ac94-484c-a292-3271c8d2b4ba	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	133.40	143.64	in_stock	https://www.gamestop.com/products/pokemon-chilling-reign-booster-box	\N	45	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
37eac3e3-ce71-499e-b3a0-216c93d9a787	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	130.01	143.64	in_stock	https://www.target.com/products/pokemon-chilling-reign-booster-box	\N	47	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
\.


--
-- TOC entry 4350 (class 0 OID 16545)
-- Dependencies: 222
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name, slug, description, parent_id, sort_order, created_at, updated_at) FROM stdin;
9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Booster Boxes	booster-boxes	Complete booster boxes containing multiple booster packs	\N	1	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
74f7c000-1c1a-4d83-bae0-387388e8f517	Booster Packs	booster-packs	Individual booster packs	\N	2	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
9cecfdc2-8343-41e2-b988-c85781aa3d84	Elite Trainer Boxes	elite-trainer-boxes	Elite Trainer Boxes with booster packs and accessories	\N	3	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
8a65f1e2-a485-43c8-b89f-124eb057914f	Collection Boxes	collection-boxes	Special collection boxes and premium products	\N	4	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
3cfd90d9-067a-4acc-9916-36cd81d9168c	Starter Decks	starter-decks	Theme decks and starter products	\N	5	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
\.


--
-- TOC entry 4351 (class 0 OID 16565)
-- Dependencies: 223
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, slug, sku, upc, category_id, set_name, series, release_date, msrp, image_url, description, metadata, is_active, popularity_score, created_at, updated_at) FROM stdin;
0c302b6d-ebd4-44f9-8be4-4b0402d170cc	Pokémon Scarlet & Violet Base Set Booster Box	pokemon-scarlet-violet-base-booster-box	SV01-BB-EN	820650850011	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	143.64	https://images.pokemontcg.io/sv1/logo.png	Scarlet & Violet Base Set Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV01", "pack_count": 36, "cards_per_pack": 11, "rarity_distribution": {"common": 7, "uncommon": 3, "rare_or_higher": 1}}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.134+00
36d49c84-21d3-4c4a-b3f6-a55db2f359c7	Pokémon Paldea Evolved Booster Box	pokemon-paldea-evolved-booster-box	SV02-BB-EN	820650850028	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Paldea Evolved	Scarlet & Violet	2023-06-09	143.64	https://images.pokemontcg.io/sv2/logo.png	Paldea Evolved Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV02", "pack_count": 36, "cards_per_pack": 11}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.137+00
57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	Pokémon Chilling Reign Booster Box	pokemon-chilling-reign-booster-box	SWSH06-BB-EN	0820650458858	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Chilling Reign	Sword & Shield	2021-06-18	143.64	https://images.pokemontcg.io/swsh6/logo.png	Chilling Reign Booster Box featuring the Calyrex forms	{"language": "English", "set_code": "SWSH06", "pack_count": 36, "cards_per_pack": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.141+00
89730910-09ee-4454-acb5-b5979e0d4ab7	Pokémon Temporal Forces Booster Box	pokemon-temporal-forces-booster-box	SV05-BB-EN	0820650852519	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Temporal Forces	Scarlet & Violet	2024-03-22	143.64	https://images.pokemontcg.io/sv5/logo.png	Temporal Forces Booster Box with 36 booster packs	{"language": "English", "set_code": "SV05", "pack_count": 36, "cards_per_pack": 11}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.145+00
8ed8702f-15d5-4cf3-9555-3972d88e6c23	Pokémon Hidden Fates Elite Trainer Box	pokemon-hidden-fates-elite-trainer-box	SM11.5-ETB-EN	0820650451491	9cecfdc2-8343-41e2-b988-c85781aa3d84	Hidden Fates	Sun & Moon	2019-09-20	49.99	https://images.pokemontcg.io/sm115/logo.png	Hidden Fates Elite Trainer Box with the iconic shiny vault	{"language": "English", "pack_count": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.145+00
9948cf7e-41d4-4863-b36e-ec6372a7118b	Charizard ex Super Premium Collection	charizard-ex-super-premium-collection	SV-CHAR-SPC	820650852001	8a65f1e2-a485-43c8-b89f-124eb057914f	Special Collection	Scarlet & Violet	2023-12-01	119.99	https://images.pokemontcg.io/sv-promo/charizard-ex.png	Charizard ex Super Premium Collection with exclusive cards and accessories	{"includes": ["1 foil promo card featuring Charizard ex", "1 foil promo card featuring Charmander", "1 foil promo card featuring Charmeleon", "16 Pokémon TCG booster packs", "1 playmat featuring Charizard ex", "65 card sleeves featuring Charizard ex", "1 metal coin featuring Charizard ex", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "1 collector's box"], "language": "English", "set_code": "SV-PROMO", "pack_count": 16}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.145+00
cadea567-c448-4789-872d-49fa516ea9bb	Trading Card Game: 2023 Pokémon TCG World Championships Deck - Styles May Vary	trading-card-game-2023-pok-mon-tcg-world-championships-deck-styles-may-vary	6569648	\N	3cfd90d9-067a-4acc-9916-36cd81d9168c	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6569/6569648_sd.jpg	\N	{}	t	5	2025-09-04 18:09:54.548+00	2025-09-04 20:00:00.15+00
234ee314-1f17-4753-be1b-c868e441db7e	Pokémon Shining Fates Elite Trainer Box	pokemon-shining-fates-elite-trainer-box	SWSH4.5-ETB-EN	0820650457448	9cecfdc2-8343-41e2-b988-c85781aa3d84	Shining Fates	Sword & Shield	2021-02-19	49.99	https://images.pokemontcg.io/swsh45/logo.png	Shining Fates Elite Trainer Box featuring shiny vault cards	{"language": "English", "pack_count": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.136+00
23f77789-99f9-4d89-a7f6-b48f9578c04f	Pokémon Celebrations Elite Trainer Box	pokemon-celebrations-elite-trainer-box	SWSH25-ETB-EN	0820650459299	9cecfdc2-8343-41e2-b988-c85781aa3d84	Celebrations	Sword & Shield	2021-10-08	49.99	https://images.pokemontcg.io/swsh45/logo.png	25th Anniversary Celebrations Elite Trainer Box with special mini-packs	{"language": "English", "pack_count": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.136+00
090cb184-ca13-4246-9db9-a923c68ade86	Pokémon Brilliant Stars Booster Box	pokemon-brilliant-stars-booster-box	SWSH09-BB-EN	0820650459541	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Brilliant Stars	Sword & Shield	2022-02-25	143.64	https://images.pokemontcg.io/swsh9/logo.png	Brilliant Stars Booster Box featuring the Trainer Gallery subset	{"language": "English", "set_code": "SWSH09", "pack_count": 36, "cards_per_pack": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.109+00
454b81ef-7486-4fa8-b4f7-12284cec758a	Pokémon Crown Zenith Elite Trainer Box	pokemon-crown-zenith-elite-trainer-box	SWSH12.5-ETB-EN	0820650852625	9cecfdc2-8343-41e2-b988-c85781aa3d84	Crown Zenith	Sword & Shield	2023-01-20	49.99	https://images.pokemontcg.io/swsh12pt5/logo.png	Crown Zenith Elite Trainer Box featuring special Galarian Gallery cards	{"language": "English", "set_code": "SWSH12.5", "pack_count": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.138+00
6ef2d0a5-7263-4206-9db1-e5520e8abc0a	Pokémon Paradox Rift Booster Box	pokemon-paradox-rift-booster-box	SV04-BB-EN	820650850066	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Paradox Rift	Scarlet & Violet	2023-11-03	143.64	https://images.pokemontcg.io/sv4/logo.png	Paradox Rift Booster Box with 36 booster packs	{"language": "English", "set_code": "SV04", "pack_count": 36, "cards_per_pack": 11}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.143+00
d8b06d4e-7869-44df-9d5e-35e7c771be57	Pokémon - Trading Card Game: Battle Academy (2024)	pok-mon-trading-card-game-battle-academy-2024	6580253	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6580/6580253_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.266+00	2025-09-04 20:00:00.153+00
d9b02003-c537-45a2-84d1-7d054a5419b4	Pokémon - Trading Card Game: Virizion V Box	pok-mon-trading-card-game-virizion-v-box	6516474	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6516/6516474_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.24+00	2025-09-04 20:00:00.153+00
e1074fa4-1fd7-44c7-a55f-96fa0402aca5	Pokémon Obsidian Flames Booster Box	pokemon-obsidian-flames-booster-box	SV03-BB-EN	820650850059	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Obsidian Flames	Scarlet & Violet	2023-08-11	143.64	https://images.pokemontcg.io/sv3/logo.png	Obsidian Flames Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV03", "pack_count": 36, "cards_per_pack": 11}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.154+00
e992a9bd-a88c-40a7-81e2-74094b08ffb0	Pokémon - Trading Card Game Classic	pok-mon-trading-card-game-classic	6562098	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6562/6562098_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.211+00	2025-09-04 20:00:00.154+00
b799d31f-424e-47c5-8dba-5d8a4af90512	How The Pokemon Trading Card…	how-the-pokemon-trading-card	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:01:31.28+00	2025-09-04 20:00:00.149+00
d4708878-a77a-494e-9cfb-408546e56744	Pokémon - Trading Card Game: Trainers Toolkit 2022	pok-mon-trading-card-game-trainers-toolkit-2022	6506756	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6506/6506756_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.235+00	2025-09-04 20:00:00.151+00
d4cab033-1755-4548-b385-6ab1a9376a85	Pokémon Astral Radiance Booster Box	pokemon-astral-radiance-booster-box	SWSH10-BB-EN	0820650460134	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Astral Radiance	Sword & Shield	2022-05-27	143.64	https://images.pokemontcg.io/swsh10/logo.png	Astral Radiance Booster Box featuring Hisuian Pokémon	{"language": "English", "set_code": "SWSH10", "pack_count": 36, "cards_per_pack": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.152+00
e48ccb10-a767-4605-a0ff-f23480597124	Pokémon - Trading Card Game: Pokemon GO Premium Collection - Radiant Eevee	pok-mon-trading-card-game-pokemon-go-premium-collection-radiant-eevee	6506752	\N	8a65f1e2-a485-43c8-b89f-124eb057914f	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6506/6506752_sd.jpg	\N	{}	t	5	2025-09-04 15:01:31.2+00	2025-09-04 20:00:00.154+00
f0353094-2fbd-42af-9333-6ed59071a433	Pokémon - Trading Card Game: Trainer's Toolkit	pok-mon-trading-card-game-trainer-s-toolkit	6642990	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/c39f1e31-b289-49b5-a801-1fea950570fb.png	\N	{}	t	1	2025-09-04 15:01:31.221+00	2025-09-04 20:00:00.154+00
f94dae6d-305a-4948-8a58-0b93e0739f94	Pokémon 151 Elite Trainer Box	pokemon-151-elite-trainer-box	SV3.5-ETB-EN	820650851001	9cecfdc2-8343-41e2-b988-c85781aa3d84	Pokémon 151	Scarlet & Violet	2023-09-22	49.99	https://images.pokemontcg.io/sv3pt5/logo.png	Pokémon 151 Elite Trainer Box with 9 booster packs and accessories	{"includes": ["9 Pokémon 151 booster packs", "65 card sleeves", "45 Energy cards", "Player's guide", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "Collector's box"], "language": "English", "set_code": "SV3.5", "pack_count": 9, "cards_per_pack": 11}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.155+00
fa60ea0e-235c-4175-9f87-aac9e97776df	Pokemon: BW Rival Destinies	pokemon-bw-rival-destinies	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:02:02.156+00	2025-09-04 20:00:00.155+00
d78dec22-022a-4177-b8be-026905a38689	Pokémon Evolving Skies Booster Box	pokemon-evolving-skies-booster-box	SWSH07-BB-EN	0820650453693	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Evolving Skies	Sword & Shield	2021-08-27	143.64	https://images.pokemontcg.io/swsh7/logo.png	Evolving Skies Booster Box featuring Eeveelutions and Dragon-type Pokémon	{"language": "English", "set_code": "SWSH07", "pack_count": 36, "cards_per_pack": 10}	t	2	2025-09-03 22:19:06.313785+00	2025-09-04 22:29:15.703+00
468d4217-6c02-458f-aad7-5242437b2a7d	Pokémon - Trading Card Game: Holiday Calendar (2024)	pok-mon-trading-card-game-holiday-calendar-2024	6586142	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6586/6586142_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.271+00	2025-09-04 20:00:00.139+00
477d4790-531e-49f5-95eb-aba575e6ccdb	Pokémon - Trading Card Game: Paldea Adventure Chest	pok-mon-trading-card-game-paldea-adventure-chest	6569653	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6569/6569653_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.249+00	2025-09-04 20:00:00.14+00
614ae820-afe1-4f1d-9f77-b40a8a4b95fa	Pokémon - Trading Card Game: Battle Academy 2022	pok-mon-trading-card-game-battle-academy-2022	6500508	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6500/6500508_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.231+00	2025-09-04 20:00:00.141+00
0933e019-c545-48ba-8ba1-854a9cfc84fa	Pokémon - Trading Card Game: Scarlet & Violet - Prismatic Evolutions 2-Pack Blister	pok-mon-trading-card-game-scarlet-violet-prismatic-evolutions-2-pack-blister	6607716	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/5e025c31-e5bb-4ef0-9fb5-e7b8bf2fa494.jpg	\N	{}	t	1	2025-09-04 15:02:48.375+00	2025-09-04 20:00:00.129+00
133cb1a8-1700-4717-a5e7-25a772ef5959	Pokémon - Trading Card Game: 151 6pk Booster Bundle	pok-mon-trading-card-game-151-6pk-booster-bundle	6548371	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6548/6548371_sd.jpg	\N	{}	t	1	2025-09-04 15:02:32.958+00	2025-09-04 20:00:00.135+00
2876c949-9720-40fc-8b88-81dc37cdac38	Pokémon Primers: Box Set…	pok-mon-primers-box-set	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:02:02.162+00	2025-09-04 20:00:00.137+00
45ad0421-328b-4b17-9690-4d44e691791f	Pokémon - Trading Card Game: Scarlet & Violet— Temporal Forces Booster Box - 36 Packs	pok-mon-trading-card-game-scarlet-violet-temporal-forces-booster-box-36-packs	6571897	\N	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6571/6571897_sd.jpg	\N	{}	t	1	2025-09-04 15:02:02.151+00	2025-09-04 20:00:00.139+00
628a239b-b46f-473f-a7a0-31e32ac104b5	Pokémon Primers Types: Box Set…	pok-mon-primers-types-box-set	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:02:02.159+00	2025-09-04 20:00:00.142+00
66b0a163-79ec-4390-8e4f-9745ef86dc29	Pokémon - Trading Card Game - Crown Zenith 6 Pk Booster Bundle	pok-mon-trading-card-game-crown-zenith-6-pk-booster-bundle	6595705	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/d226d512-df26-4258-9e2c-14d31e5f0a96.jpg	\N	{}	t	1	2025-09-04 15:02:32.972+00	2025-09-04 20:00:00.142+00
69677974-4220-4141-8da6-b77681a0468a	Pokémon - Trading Card Game: Grafaiai ex Box	pok-mon-trading-card-game-grafaiai-ex-box	6573891	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6573/6573891_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.253+00	2025-09-04 20:00:00.142+00
70dbe682-bead-4c05-98f3-afb3f9d5fa9c	Pokémon - Trading Card Game: Palafin ex Box	pok-mon-trading-card-game-palafin-ex-box	6580252	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6580/6580252_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.262+00	2025-09-04 20:00:00.144+00
80eb95a5-6352-4a2c-a61a-a5d95d1bbb67	Pokemon Palafin EX Box	pokemon-palafin-ex-box	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:02:02.179+00	2025-09-04 20:00:00.144+00
8302fac6-b536-46ab-aac6-377d9a88c360	Pokémon - Trading Card Game: Scarlet & Violet - Shrouded Fable 6pk Booster Bundle	pok-mon-trading-card-game-scarlet-violet-shrouded-fable-6pk-booster-bundle	6584432	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6584/6584432_sd.jpg	\N	{}	t	1	2025-09-04 15:02:32.977+00	2025-09-04 20:00:00.144+00
939c25a1-fe07-46bf-87a4-d485be7c1857	Pokémon - Trading Card Game: Houndstone ex Box	pok-mon-trading-card-game-houndstone-ex-box	6590380	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/ecc651e4-5b29-41fe-aef8-d3db0162ead4.jpg	\N	{}	t	1	2025-09-04 15:01:31.275+00	2025-09-04 20:00:00.145+00
a20787ab-a10c-4a12-bf6e-89e42e8b9ff9	Pokémon - Trading Card Game: Holiday Calendar	pok-mon-trading-card-game-holiday-calendar	6548417	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6548/6548417_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.216+00	2025-09-04 20:00:00.147+00
a9337f94-3157-4709-8026-5454ead6d708	Pokémon Scarlet & Violet Booster Pack	pokemon-scarlet-violet-booster-pack	SV01-BP-EN	820650850035	74f7c000-1c1a-4d83-bae0-387388e8f517	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	3.99	https://images.pokemontcg.io/sv1/pack.png	Single Scarlet & Violet Base Set booster pack	{"language": "English", "set_code": "SV01", "cards_per_pack": 11}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.148+00
b0cfc9f0-5aad-471b-809d-aab2c03485e1	Pokémon Lost Origin Booster Box	pokemon-lost-origin-booster-box	SWSH11-BB-EN	0820650460233	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Lost Origin	Sword & Shield	2022-09-09	143.64	https://images.pokemontcg.io/swsh11/logo.png	Lost Origin Booster Box featuring the Lost Zone mechanic	{"language": "English", "set_code": "SWSH11", "pack_count": 36, "cards_per_pack": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.148+00
be103772-ba92-41ac-bd86-cb1af3efd4c7	Pokémon Primers Type Box Set…	pok-mon-primers-type-box-set	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:02:02.165+00	2025-09-04 20:00:00.149+00
b1f621a7-58f9-4331-89d8-30fef84cf142	Pokémon - Trading Card Game: Twilight Masquerade Booster Box - 36 Packs	pok-mon-trading-card-game-twilight-masquerade-booster-box-36-packs	6578901	\N	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/4a2252c2-a9ea-45e4-be1d-b6ab0efc8014.jpg	\N	{}	t	1	2025-09-04 15:02:02.141+00	2025-09-04 20:00:00.148+00
b411b2ac-b68f-4a43-be65-2e4057d3e705	Pokémon - Trading Card Game: Annihilape ex Box	pok-mon-trading-card-game-annihilape-ex-box	6543916	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6543/6543916_sd.jpg	\N	{}	t	1	2025-09-04 15:01:31.244+00	2025-09-04 20:00:00.149+00
cd48f66e-2e5c-4756-b2f0-f358eaac01da	Pokémon Fusion Strike Booster Box	pokemon-fusion-strike-booster-box	SWSH08-BB-EN	0820650459275	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Fusion Strike	Sword & Shield	2021-11-12	143.64	https://images.pokemontcg.io/swsh8/logo.png	Fusion Strike Booster Box featuring Mew VMAX and Gengar VMAX	{"language": "English", "set_code": "SWSH08", "pack_count": 36, "cards_per_pack": 10}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.15+00
cf6f9cc0-0d57-46f1-9f7e-37350e05d9bf	Pokémon - Trading Card Game: Trick or Trade BOOster Bundle (2024)	pok-mon-trading-card-game-trick-or-trade-booster-bundle-2024	6587212	\N	\N	\N	\N	\N	\N	https://pisces.bbystatic.com/prescaled/500/500/image2/BestBuy_US/images/products/6587/6587212_sd.jpg	\N	{}	t	1	2025-09-04 15:02:32.967+00	2025-09-04 20:00:00.151+00
d3399ef0-4d30-475a-940c-1d1b11481b37	Pokémon Paldean Fates Elite Trainer Box	pokemon-paldean-fates-elite-trainer-box	SV4.5-ETB-EN	0820650852441	9cecfdc2-8343-41e2-b988-c85781aa3d84	Paldean Fates	Scarlet & Violet	2024-01-26	49.99	https://images.pokemontcg.io/sv4pt5/logo.png	Paldean Fates Elite Trainer Box including 9 booster packs and accessories	{"includes": ["9 Paldean Fates booster packs", "Card sleeves", "Energy cards", "Dice", "Markers"], "language": "English", "set_code": "SV4.5", "pack_count": 9}	t	0	2025-09-03 22:19:06.313785+00	2025-09-04 20:00:00.151+00
d53c1fbc-190a-4857-81ce-27c4d8593370	Pokemon Battle Frontier Box,…	pokemon-battle-frontier-box	\N	\N	\N	\N	\N	\N	\N	\N	\N	{}	t	1	2025-09-04 15:02:02.175+00	2025-09-04 20:00:00.152+00
\.


--
-- TOC entry 4349 (class 0 OID 16523)
-- Dependencies: 221
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retailers (id, name, slug, website_url, api_type, api_config, is_active, rate_limit_per_minute, health_score, last_health_check, supported_features, created_at, updated_at) FROM stdin;
c3755fe7-87a1-41c0-aee4-d2c90170d47f	Best Buy	best-buy	https://www.bestbuy.com	official	{"api_key": "placeholder", "base_url": "https://api.bestbuy.com/v1"}	t	60	95	\N	["cart_links", "inventory_check", "price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
d6856801-fdef-4480-bacb-739d0f8eeade	Walmart	walmart	https://www.walmart.com	affiliate	{"api_key": "placeholder", "affiliate_id": "placeholder"}	t	100	90	\N	["affiliate_links", "price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	Costco	costco	https://www.costco.com	scraping	{"base_url": "https://www.costco.com", "user_agent": "BoosterBeacon/1.0"}	t	30	85	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
74a9feae-664a-4c3d-9d09-e77cbc978fa0	Sam's Club	sams-club	https://www.samsclub.com	scraping	{"base_url": "https://www.samsclub.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
5da1a13c-803f-4e97-ad09-006ef8b1c2de	GameStop	gamestop	https://www.gamestop.com	scraping	{"base_url": "https://www.gamestop.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
a3d4e08f-d21d-4bad-b83c-8499566c2930	Target	target	https://www.target.com	scraping	{"base_url": "https://www.target.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
\.


--
-- TOC entry 4386 (class 0 OID 17363)
-- Dependencies: 258
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, slug, description, permissions, is_system_role, categories, level, is_active, created_by, created_at, updated_at) FROM stdin;
9425e23e-c63c-434e-a688-0e786cd19608	Super Administrator	super_admin	Full system access with all permissions	[]	t	["user_management","system_administration","ml_operations","analytics","content_management","security","billing","monitoring"]	100	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6fc7d6b5-cde0-4c33-9206-d20f107f1906	Administrator	admin	Administrative access with most permissions	[]	t	["user_management","system_administration","analytics","content_management","security","monitoring"]	80	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
96520317-38af-41b0-b46e-3890d4d99f25	User Manager	user_manager	Manage users and basic administrative tasks	[]	t	["user_management","analytics"]	60	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
8c185a4e-5962-4d59-af7f-56b68fda06df	Content Manager	content_manager	Manage products, retailers, and content	[]	t	["content_management","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6814f358-63ad-4530-a185-9c5cd7dbf0c2	ML Engineer	ml_engineer	Manage machine learning models and data	[]	t	["ml_operations","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
7dff1611-3ec6-4d08-bc90-2d5db769de78	Analyst	analyst	View and analyze system data and metrics	[]	t	["analytics"]	40	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
58b9d7f9-b295-4b7a-8abc-9e650d4586b2	Support Agent	support_agent	Provide customer support and basic user management	[]	t	["user_management"]	30	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
cf9919c8-4c2f-4768-8c0c-3bc770a34e5b	Billing Manager	billing_manager	Manage billing, subscriptions, and financial data	[]	t	["billing","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
4c762ab2-3f74-43ec-906b-bfdb46b58b21	Security Officer	security_officer	Manage security, audit logs, and compliance	[]	t	["security","monitoring"]	70	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
2d0c24b1-6468-4cd9-833e-fc310409aea1	User	user	Standard user with no administrative permissions	[]	t	[]	0	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
\.


--
-- TOC entry 4371 (class 0 OID 17017)
-- Dependencies: 243
-- Data for Name: seasonal_patterns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasonal_patterns (id, product_id, category_id, pattern_type, pattern_name, avg_price_change, availability_change, demand_multiplier, historical_occurrences, confidence, last_updated) FROM stdin;
\.


--
-- TOC entry 4380 (class 0 OID 17215)
-- Dependencies: 252
-- Data for Name: social_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_shares (id, user_id, alert_id, platform, share_type, metadata, shared_at) FROM stdin;
\.


--
-- TOC entry 4389 (class 0 OID 17455)
-- Dependencies: 261
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, slug, description, price, billing_period, stripe_price_id, features, limits, is_active, trial_days, created_at, updated_at) FROM stdin;
55fa1671-a03e-4b75-a836-84c1f5a88b84	Free	free	Basic alerts for casual collectors	0.00	monthly	\N	["Up to 2 product watches", "Basic email alerts", "Web push notifications", "Community support"]	{"max_watches": 2, "api_rate_limit": 1000, "max_alerts_per_day": 50}	t	0	2025-09-03 22:19:06.350966+00	2025-09-03 22:19:06.350966+00
ada80866-db4e-4443-81b5-69793f42e7d9	Pro	pro-monthly	Advanced features with limited auto-purchase and ML insights	40.00	monthly	price_1S2uGyCR3n2urghaaMu0rJcf	["Up to 10 product watches", "Higher alert priority", "SMS & Discord notifications", "Auto-purchase (limited capacity)", "ML insights (limited: basic price trend + risk)", "Extended price history (12 months)", "Advanced filtering", "Browser extension access"]	{"max_watches": 10, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-09-03 22:19:06.350966+00	2025-09-03 22:19:06.350966+00
394eb3e5-5f5f-45be-8914-b762ae9f25d4	Premium	premium-monthly	Full auto-purchase, full ML, and highest queue priority	100.00	monthly	price_1S2uIkCR3n2urghaSnHaGzow	["Unlimited product watches", "Fastest alert delivery and queue priority", "SMS & Discord notifications", "Auto-purchase (full capacity & priority)", "Full ML: price predictions, sellout risk, ROI", "Full price history access", "Advanced filtering", "Browser extension access", "Premium support", "One-time $300 setup fee"]	{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-09-03 22:19:06.350966+00	2025-09-03 22:19:06.350966+00
\.


--
-- TOC entry 4360 (class 0 OID 16814)
-- Dependencies: 232
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, service_name, status, metrics, message, checked_at) FROM stdin;
1980b98b-f183-45aa-ae57-8b4025e3e0d7	api_server	healthy	{"error_rate": 0.02, "response_time": 45, "uptime_percentage": 99.8}	\N	2025-09-03 16:53:58.37726+00
d19c69f7-49b0-40da-bead-8047cd9d2350	database	healthy	{"query_time": 12, "connection_pool": 8, "uptime_percentage": 99.9}	\N	2025-09-03 16:53:58.37726+00
b541cf95-9c8a-4394-8df5-b5d30cbb0958	retailer_monitoring	healthy	{"success_rate": 98.5, "avg_check_time": 2.3, "active_monitors": 4}	\N	2025-09-03 16:53:58.37726+00
\.


--
-- TOC entry 4376 (class 0 OID 17133)
-- Dependencies: 248
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_metrics (id, metric_name, metric_type, value, labels, recorded_at) FROM stdin;
3c802948-0f8e-492d-88c0-dff25cdf27e4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:36.212+00
1695bdb1-2765-4c19-a26e-084c4d42b365	uptime	gauge	309.459464	{}	2025-09-03 16:36:36.212+00
0d1258c5-8d93-468e-a339-4b355ed35026	memory_usage	gauge	75.570000	{}	2025-09-03 16:36:36.212+00
9a2765b6-8abb-4553-84e9-8869a040d12b	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:36.212+00
4e3a89f2-6edb-4eed-a9ad-e7cadac60073	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:58.34+00
d2c8d491-5e7f-48fc-922f-0ee7ca343eb7	uptime	gauge	248.100242	{}	2025-09-03 16:36:58.341+00
4de06082-95a8-4707-9774-4ee6b4bf76fd	memory_usage	gauge	75.680000	{}	2025-09-03 16:36:58.34+00
efe07c33-9f0c-405b-9cd3-a904a9d646fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:58.341+00
31fe1c93-cb08-4c5f-9d97-5d675f8a84af	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:36.212+00
65f93504-e136-41de-b03c-b19121f38d51	memory_usage	gauge	75.830000	{}	2025-09-03 16:37:36.212+00
b0af6be9-90c2-43f0-b255-6ef5f650c0de	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:36.212+00
8d116f32-15ae-4daf-847f-b4d379c6ba64	uptime	gauge	369.458978	{}	2025-09-03 16:37:36.212+00
0f03de57-b8e4-400e-a640-1501056f4f1b	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:58.346+00
4605f34f-cf0b-44ed-b844-bc8e987d994f	memory_usage	gauge	75.730000	{}	2025-09-03 16:37:58.346+00
19f45d60-ddb5-4ed0-9807-26a7668c7571	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:58.346+00
733ca3c5-1cfc-4bc9-bf30-dd81e206c078	uptime	gauge	308.106181	{}	2025-09-03 16:37:58.346+00
958dd4cc-7532-44e4-ba8d-838bd699454b	memory_usage	gauge	75.930000	{}	2025-09-03 16:38:36.213+00
738e7053-9eb8-491b-b6a2-1535a9e381cd	cpu_usage	gauge	6.000000	{}	2025-09-03 16:38:36.213+00
5a32f3df-c841-456b-a22d-0c72a9bec3e4	disk_usage	gauge	45.200000	{}	2025-09-03 16:38:36.213+00
3f609f44-0d80-45fb-81f7-d4f7f2485ce7	uptime	gauge	429.459813	{}	2025-09-03 16:38:36.213+00
629e4293-0840-4cec-8c5e-79d45cc5adb7	memory_usage	gauge	75.930000	{}	2025-09-03 16:38:58.346+00
4df21ba8-6dd4-49dd-a86c-f3c81dd84201	cpu_usage	gauge	6.000000	{}	2025-09-03 16:38:58.346+00
12aa3cc5-432f-4469-a8a0-31e38175a772	disk_usage	gauge	45.200000	{}	2025-09-03 16:38:58.346+00
b0ed47cc-8c9f-45c8-a501-98293f4638f3	uptime	gauge	368.105434	{}	2025-09-03 16:38:58.346+00
71d54afb-aac6-4432-8cd0-71b9c4982fb1	cpu_usage	gauge	6.000000	{}	2025-09-03 16:39:36.213+00
ae2d401b-1291-4057-aa2b-3a67f13fb897	memory_usage	gauge	75.900000	{}	2025-09-03 16:39:36.213+00
13c332bc-38e6-4e89-819e-04020f0e47c5	disk_usage	gauge	45.200000	{}	2025-09-03 16:39:36.213+00
b65a6867-ae3b-49e8-9390-b270da074d94	uptime	gauge	489.460450	{}	2025-09-03 16:39:36.213+00
52842366-5165-4db4-ad63-b1a94130c9fc	cpu_usage	gauge	6.000000	{}	2025-09-03 16:39:58.346+00
02c0af50-cfee-413e-a1fe-bc06ee7e1340	memory_usage	gauge	75.830000	{}	2025-09-03 16:39:58.346+00
47d5cbd7-c46d-4fa5-82da-c8b24ea758a8	disk_usage	gauge	45.200000	{}	2025-09-03 16:39:58.346+00
16e09ad7-92b4-460d-bafe-9da2e98615a0	uptime	gauge	428.105690	{}	2025-09-03 16:39:58.346+00
5e16855a-b10b-4afc-809d-15877c8ffaaf	cpu_usage	gauge	6.000000	{}	2025-09-03 16:40:36.213+00
bfc21ada-d92e-4ef9-af68-a06a7fa569d6	memory_usage	gauge	75.990000	{}	2025-09-03 16:40:36.213+00
b93f937c-72e6-4ec2-8fc2-c5bfec91ae32	disk_usage	gauge	45.200000	{}	2025-09-03 16:40:36.213+00
d1dd662c-78a9-4d84-af8e-cc17c7b140f2	uptime	gauge	549.460244	{}	2025-09-03 16:40:36.213+00
7badb281-dae4-49e2-955d-ef3c67f158f1	cpu_usage	gauge	6.000000	{}	2025-09-03 16:40:58.346+00
2df7574f-ce2f-4ea7-931b-8056f102f90e	memory_usage	gauge	76.020000	{}	2025-09-03 16:40:58.346+00
94674ee2-bfcb-42bb-b3b0-828a8ec51737	disk_usage	gauge	45.200000	{}	2025-09-03 16:40:58.346+00
870d6935-e945-4049-989d-5b636d9b2d74	uptime	gauge	488.105702	{}	2025-09-03 16:40:58.346+00
44735896-2136-437b-bf84-411ddd6d46d3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:41:36.213+00
a3ac4b27-dada-4bd7-b96f-a13d79d532dc	memory_usage	gauge	75.880000	{}	2025-09-03 16:41:36.213+00
17aeab3b-688f-4154-9c21-6e04d2959ec3	disk_usage	gauge	45.200000	{}	2025-09-03 16:41:36.213+00
817d2778-a9b1-4b9b-9870-8ca825a8fb62	uptime	gauge	609.460277	{}	2025-09-03 16:41:36.213+00
4038caa6-ca99-4948-8017-dd6ae2f543b9	cpu_usage	gauge	6.000000	{}	2025-09-03 16:41:58.346+00
02810cab-8f02-4a7d-a786-d729238f29df	memory_usage	gauge	75.910000	{}	2025-09-03 16:41:58.347+00
e84ac495-6a7c-43b2-860e-7cdc8379178d	disk_usage	gauge	45.200000	{}	2025-09-03 16:41:58.347+00
1b637501-a490-46ad-90da-e754be0f073c	uptime	gauge	548.106349	{}	2025-09-03 16:41:58.347+00
dd6b7556-51c4-48d8-98e2-8a71f68db110	cpu_usage	gauge	6.000000	{}	2025-09-03 16:42:36.213+00
4391b6c3-769a-4c2e-9d49-9fac9464ed21	memory_usage	gauge	75.910000	{}	2025-09-03 16:42:36.213+00
21b3f84e-8814-4e4f-a2d2-c62d1eef7db0	disk_usage	gauge	45.200000	{}	2025-09-03 16:42:36.213+00
7329560b-4969-4bf3-975e-8b0ea63c3a95	uptime	gauge	669.459834	{}	2025-09-03 16:42:36.213+00
1856b91f-77f7-439f-bdfb-cad6c82778aa	cpu_usage	gauge	6.000000	{}	2025-09-03 16:42:58.347+00
42fac545-50c7-4494-9212-52c57bbcffe7	memory_usage	gauge	75.820000	{}	2025-09-03 16:42:58.347+00
0b5b211a-1beb-4f85-9446-a7b9ddbd51a6	disk_usage	gauge	45.200000	{}	2025-09-03 16:42:58.347+00
72b4e205-7f2b-4753-9e75-34da9755cbbc	uptime	gauge	608.106409	{}	2025-09-03 16:42:58.347+00
395d88e8-bf58-44bb-bbc0-343919cfcd53	memory_usage	gauge	75.880000	{}	2025-09-03 16:43:36.213+00
796d50e7-9a0f-4677-b6ab-cacf2b1fc3ae	disk_usage	gauge	45.200000	{}	2025-09-03 16:43:36.214+00
fd7a9466-6660-46fa-8228-4c35986f5f1b	uptime	gauge	729.460647	{}	2025-09-03 16:43:36.214+00
b9ebe36f-8f5a-4ccb-819d-172c839bdd23	cpu_usage	gauge	6.000000	{}	2025-09-03 16:43:36.213+00
84d7944e-c9c9-48b2-8511-5232c7b13bd4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:43:58.347+00
b22138ba-261c-46a8-a771-7622db63083e	memory_usage	gauge	75.810000	{}	2025-09-03 16:43:58.347+00
d2ee125c-534b-4090-9a1b-d59c62af5be4	disk_usage	gauge	45.200000	{}	2025-09-03 16:43:58.347+00
b35f23a8-9e5c-43b5-9e1b-15148ae5d822	uptime	gauge	668.107077	{}	2025-09-03 16:43:58.347+00
29b31041-a25a-4f93-a0db-2e410bd0af3a	cpu_usage	gauge	6.000000	{}	2025-09-03 16:44:36.213+00
f147b249-208b-4b70-9698-eb928b5a3959	memory_usage	gauge	76.420000	{}	2025-09-03 16:44:36.213+00
ac034995-408a-43f7-a2de-360e97bc1f54	disk_usage	gauge	45.200000	{}	2025-09-03 16:44:36.213+00
911970f2-e565-4605-8944-6bb280464432	uptime	gauge	789.460514	{}	2025-09-03 16:44:36.213+00
d4efed9c-0fca-4a01-bea4-e5798bb20fce	cpu_usage	gauge	6.000000	{}	2025-09-03 16:44:58.347+00
8948a660-8d0f-418d-9fd3-99564d799fcc	memory_usage	gauge	76.340000	{}	2025-09-03 16:44:58.347+00
f71e7e15-8ea2-4972-9048-ff53638c7c73	disk_usage	gauge	45.200000	{}	2025-09-03 16:44:58.348+00
dd6ced7e-cafc-4022-94bd-3a4515aecf3d	uptime	gauge	728.107637	{}	2025-09-03 16:44:58.348+00
8202453b-2d7b-4785-b8dd-1dab0cb72740	cpu_usage	gauge	6.000000	{}	2025-09-03 16:45:36.213+00
6904bba2-bde0-41c3-b463-062551afb48e	memory_usage	gauge	76.750000	{}	2025-09-03 16:45:36.214+00
4791b2b1-1709-4832-93ff-5410e43236c6	disk_usage	gauge	45.200000	{}	2025-09-03 16:45:36.214+00
c6cb4161-8ad5-4d12-8906-ec5a15bcccbe	uptime	gauge	849.460687	{}	2025-09-03 16:45:36.214+00
ba1fc3b6-1977-4b52-b9a4-d128fbf82f24	cpu_usage	gauge	6.000000	{}	2025-09-03 16:45:58.348+00
246b0eba-4de4-4288-bbf2-2362cf4f0755	memory_usage	gauge	76.770000	{}	2025-09-03 16:45:58.348+00
5806108c-f82d-4c73-bcf7-f7e124dbc6bb	disk_usage	gauge	45.200000	{}	2025-09-03 16:45:58.348+00
2a12fb66-40f5-4906-8101-8ab0c709a108	uptime	gauge	788.107618	{}	2025-09-03 16:45:58.348+00
461c6d90-136b-4671-a6f5-b51f36d960a3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:46:36.213+00
6de51c31-0838-44fd-bfdb-28fd6da88786	memory_usage	gauge	76.910000	{}	2025-09-03 16:46:36.214+00
fa9bd97d-8f76-4f6e-8114-53b782254989	disk_usage	gauge	45.200000	{}	2025-09-03 16:46:36.214+00
4d0b1ece-6414-4ec9-9cae-afe51b4a6c98	uptime	gauge	909.460662	{}	2025-09-03 16:46:36.214+00
9567752d-07f4-4187-8d28-693de7089523	cpu_usage	gauge	6.000000	{}	2025-09-03 16:46:58.349+00
e7cbfe09-784e-4722-8cad-98359f589fd3	memory_usage	gauge	76.460000	{}	2025-09-03 16:46:58.349+00
978e6634-96d8-4b8e-b945-c613587ab0b4	disk_usage	gauge	45.200000	{}	2025-09-03 16:46:58.349+00
41f4f5ce-6cb4-4b4d-99d2-69e17078e6d0	uptime	gauge	848.109197	{}	2025-09-03 16:46:58.349+00
f53cfbfb-fef5-428f-b50e-cb4d623c5a28	cpu_usage	gauge	6.000000	{}	2025-09-03 16:47:36.214+00
d815f760-115e-4ee4-a8a8-af9da4689875	memory_usage	gauge	76.440000	{}	2025-09-03 16:47:36.214+00
98ebeb56-883d-4e3d-ac52-6d892d2c500a	disk_usage	gauge	45.200000	{}	2025-09-03 16:47:36.214+00
df8c3123-2107-40bf-a47c-22c0464cea5d	uptime	gauge	969.461411	{}	2025-09-03 16:47:36.214+00
35ba4a98-3e2d-4859-9c92-e9a8a38efa94	cpu_usage	gauge	6.000000	{}	2025-09-03 16:47:58.35+00
0924aa26-7132-4ed5-ad06-5f9f40d321f5	memory_usage	gauge	76.460000	{}	2025-09-03 16:47:58.35+00
07069f3e-b973-4ab7-adb6-5519a0a5cbd3	disk_usage	gauge	45.200000	{}	2025-09-03 16:47:58.35+00
d5caac0f-f079-4b79-8ed4-54264ec1cc93	uptime	gauge	908.109400	{}	2025-09-03 16:47:58.35+00
90ef54f5-0826-4a8f-88f9-4258454b64ec	cpu_usage	gauge	6.000000	{}	2025-09-03 16:48:36.215+00
d97f9450-a425-4e38-b7d3-fcc68a953625	disk_usage	gauge	45.200000	{}	2025-09-03 16:48:36.215+00
44678f0b-2356-4d5b-bcbc-556f09e5bca4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:49:36.215+00
daed18f5-efea-42d8-9949-a026fd287c88	memory_usage	gauge	74.970000	{}	2025-09-03 23:03:48.711+00
5cedf9ee-07b2-443e-aeea-717ff0402bc1	uptime	gauge	309.188739	{}	2025-09-03 23:04:48.711+00
cc98f6f8-3ffd-45b7-b644-470048ec9bbf	memory_usage	gauge	75.020000	{}	2025-09-03 23:05:48.712+00
c8842aa8-1ebb-4aba-a54c-459413b024ab	cpu_usage	gauge	6.000000	{}	2025-09-03 23:06:48.712+00
9252e11d-a4b4-4e9c-a4c9-c20c48573bf4	uptime	gauge	489.189811	{}	2025-09-03 23:07:48.712+00
06ffe52b-39fe-4c9e-a878-2933f33f2486	disk_usage	gauge	45.200000	{}	2025-09-03 23:08:48.713+00
4a314d7a-792e-4c98-ac3d-59319a79a4f9	disk_usage	gauge	45.200000	{}	2025-09-03 23:09:48.713+00
04ed57aa-1151-4d41-9516-8842678a153a	cpu_usage	gauge	6.000000	{}	2025-09-03 23:10:48.714+00
9e1871fe-fa14-428c-b325-31fdb6f49ed8	uptime	gauge	729.190960	{}	2025-09-03 23:11:48.713+00
9b16fd8c-70f4-409b-82a4-3b584502b995	disk_usage	gauge	45.200000	{}	2025-09-03 23:12:48.713+00
38a93a2f-fa4f-4e4e-95f7-4be20e3c3227	cpu_usage	gauge	6.000000	{}	2025-09-03 23:13:48.714+00
4c70a23a-6a2d-4f93-a0fa-7e836339ccb4	uptime	gauge	909.191489	{}	2025-09-03 23:14:48.714+00
b15578a9-8163-445d-b130-0a0c47ac902d	uptime	gauge	1029.461810	{}	2025-09-03 16:48:36.215+00
cb56c4d0-2cf1-4324-8130-5902f5b7c7ca	disk_usage	gauge	45.200000	{}	2025-09-03 16:49:36.215+00
46855250-c913-41fc-b26a-1c20977aa6e2	cpu_usage	gauge	6.000000	{}	2025-09-03 23:03:48.71+00
e819dbc4-8f0e-42a6-9523-2e86f1e9dddc	memory_usage	gauge	74.910000	{}	2025-09-03 23:04:48.711+00
dc57e072-35ce-4c51-89cd-80b471d85306	cpu_usage	gauge	6.000000	{}	2025-09-03 23:05:48.711+00
2ba542d4-78fc-49de-b109-741f78bcece0	uptime	gauge	429.189305	{}	2025-09-03 23:06:48.712+00
f19160e8-b8c1-4b3a-bb5a-3cc94c58ad86	disk_usage	gauge	45.200000	{}	2025-09-03 23:07:48.712+00
6d2faef2-ba46-42e0-8232-39b3f10d58c4	memory_usage	gauge	74.750000	{}	2025-09-03 23:08:48.713+00
0cb92faa-cd97-4c54-a5a9-41d1068932e0	memory_usage	gauge	74.720000	{}	2025-09-03 23:09:48.713+00
4d30dc7c-ea34-42a8-90c7-52dacfd4dfd8	memory_usage	gauge	75.050000	{}	2025-09-03 23:10:48.714+00
53c0ffb3-e06e-4e69-b9cb-94c79eb0a31a	disk_usage	gauge	45.200000	{}	2025-09-03 23:11:48.713+00
faab754d-7071-4cfc-b922-ac09b67df2a0	cpu_usage	gauge	6.000000	{}	2025-09-03 23:12:48.713+00
b0978204-6226-4e21-8b6c-87a2fb778c13	uptime	gauge	849.191227	{}	2025-09-03 23:13:48.714+00
68f09c4b-c411-4a8d-807c-c3f89ea19db2	cpu_usage	gauge	6.000000	{}	2025-09-03 23:14:48.714+00
df1d8c40-4523-4497-ae6c-063e714d1e1e	memory_usage	gauge	76.390000	{}	2025-09-03 16:48:58.35+00
5fba1d39-3646-4dc2-a6bc-c3965b1e422f	uptime	gauge	1028.112035	{}	2025-09-03 16:49:58.352+00
c884d167-6397-4228-a6d2-7706a7541bc1	disk_usage	gauge	45.200000	{}	2025-09-03 23:03:48.711+00
853d3d82-9d34-477e-996f-b4896bf0eed4	cpu_usage	gauge	6.000000	{}	2025-09-03 23:04:48.711+00
1eb73caa-1eb2-47e7-9ff4-3d47227e4bec	uptime	gauge	369.189198	{}	2025-09-03 23:05:48.712+00
04f63a6e-6185-4ad3-8974-0b930356f80b	memory_usage	gauge	75.040000	{}	2025-09-03 23:06:48.712+00
5e8e6d6b-f5e1-4ff1-898a-a32a220b3f88	memory_usage	gauge	75.000000	{}	2025-09-03 23:07:48.712+00
d717d13a-386a-4e66-bedc-d8d9112cc22e	cpu_usage	gauge	6.000000	{}	2025-09-03 23:08:48.713+00
d231c848-5703-4b46-ae7e-b3c1f43be220	uptime	gauge	609.190704	{}	2025-09-03 23:09:48.713+00
17c9cb76-bdfb-40e6-8c15-f7868793b656	disk_usage	gauge	45.200000	{}	2025-09-03 23:10:48.714+00
7e11d64b-645f-44de-9177-d17839d57036	memory_usage	gauge	74.920000	{}	2025-09-03 23:11:48.713+00
ea883bb9-ad71-4a08-a3dc-cb19aca81aa9	memory_usage	gauge	74.890000	{}	2025-09-03 23:12:48.713+00
466ea930-4de0-4ba2-b15e-fe404ee8cb33	memory_usage	gauge	74.840000	{}	2025-09-03 23:13:48.714+00
ecb87168-c0d6-4f39-959b-625ba1b76386	memory_usage	gauge	74.980000	{}	2025-09-03 23:14:48.714+00
93452c38-6d2e-4eb1-96c6-c16f02ffaf97	cpu_usage	gauge	6.000000	{}	2025-09-03 16:48:58.35+00
d0f3533d-a10c-4251-aa94-371a5f43313c	cpu_usage	gauge	6.000000	{}	2025-09-03 16:49:58.352+00
7ff2cb70-5ddd-4bd4-8dc2-def7a056cf1d	uptime	gauge	249.188210	{}	2025-09-03 23:03:48.711+00
1d24a215-4023-48e3-9d62-4cbe80cea605	disk_usage	gauge	45.200000	{}	2025-09-03 23:04:48.711+00
38e977c7-1335-47ec-a8d6-6b2e4db522ab	disk_usage	gauge	45.200000	{}	2025-09-03 23:05:48.712+00
5f80cf1a-f033-4eb7-a470-5bbb2401174f	disk_usage	gauge	45.200000	{}	2025-09-03 23:06:48.712+00
7d1ee554-0b16-4abc-98d3-eccfc5c6f1af	cpu_usage	gauge	6.000000	{}	2025-09-03 23:07:48.712+00
b6e59172-06da-4e4e-8c06-1d0e7bf24791	uptime	gauge	549.190502	{}	2025-09-03 23:08:48.713+00
e8238cac-1076-44a3-b4f0-bfba01cdf8bf	cpu_usage	gauge	6.000000	{}	2025-09-03 23:09:48.713+00
47cf9a46-ff27-45cf-8d24-07c29a47fdc6	uptime	gauge	669.191367	{}	2025-09-03 23:10:48.714+00
f97d56b1-6710-4ded-9165-a89a8ce2877d	cpu_usage	gauge	6.000000	{}	2025-09-03 23:11:48.713+00
fb5267ae-4413-42c4-822a-2da93c7a8a0c	uptime	gauge	789.191027	{}	2025-09-03 23:12:48.713+00
39b0c0f0-7de1-492d-8dff-6751919fc43d	disk_usage	gauge	45.200000	{}	2025-09-03 23:13:48.714+00
d87ff4fc-0897-4cdc-b9b1-1e4866368d1f	disk_usage	gauge	45.200000	{}	2025-09-03 23:14:48.714+00
ae03ce59-9cfd-4156-b98f-f8eab42fb501	disk_usage	gauge	45.200000	{}	2025-09-03 16:48:58.35+00
38dde6f2-ce08-4e2e-aecf-d168642a33fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:49:58.352+00
d5f0709f-88c8-4a64-80a2-f75ce43078ad	cpu_usage	gauge	6.000000	{}	2025-09-03 23:15:48.714+00
35e7cff5-f7fc-4b4c-813f-06a9db0abc01	cpu_usage	gauge	5.000000	{}	2025-09-04 12:56:55.2+00
50965abd-1edc-423c-a56d-173080ef02bd	memory_usage	gauge	78.640000	{}	2025-09-04 12:56:55.2+00
24d67052-e13f-4c11-93e1-01b2a804f5c6	disk_usage	gauge	45.200000	{}	2025-09-04 12:56:55.2+00
d4c73620-7dca-4b87-a39d-5830ce9af8f9	uptime	gauge	69.431993	{}	2025-09-04 12:56:55.2+00
74e5537b-8f12-4bf4-9eb6-031f508fa759	uptime	gauge	129.431692	{}	2025-09-04 12:57:55.2+00
1603b315-5620-41e6-b7b0-6c7701bde8df	uptime	gauge	189.431670	{}	2025-09-04 12:58:55.2+00
d38527db-6a2f-4154-9309-ccbb5598ef7d	uptime	gauge	309.438653	{}	2025-09-04 13:00:55.207+00
34d51552-441e-43ff-aa94-fa7ee5236b9c	disk_usage	gauge	45.200000	{}	2025-09-04 13:01:55.208+00
9df4f9e7-1829-4ef4-a568-7797ae5996b9	cpu_usage	gauge	5.000000	{}	2025-09-04 13:02:55.208+00
40eb9296-98f5-4f76-a228-c5b476f468ff	cpu_usage	gauge	5.000000	{}	2025-09-04 13:43:46.336+00
616c1a2c-566a-478b-b90c-2580a4941e1b	disk_usage	gauge	45.200000	{}	2025-09-04 13:44:46.336+00
e028891d-74eb-4554-ae81-4662db8201d7	disk_usage	gauge	45.200000	{}	2025-09-04 13:45:46.336+00
4b508cc2-0750-45ba-a7ee-04d108983820	disk_usage	gauge	45.200000	{}	2025-09-04 13:46:46.338+00
f53f3cdd-2fde-47a4-a2e6-f1443241d72c	cpu_usage	gauge	5.000000	{}	2025-09-04 13:47:46.342+00
645fe81a-9c99-47ad-9ce3-4256930508ac	uptime	gauge	369.389024	{}	2025-09-04 13:48:46.342+00
0c3fbd7f-bb72-40c2-a5f4-38a140f519d0	uptime	gauge	429.389502	{}	2025-09-04 13:49:46.342+00
2867f06a-cb88-4bc5-80d2-4de681668bc7	memory_usage	gauge	81.690000	{}	2025-09-04 13:50:46.342+00
a4b4f150-3d5f-479f-8252-3c393ac87e20	memory_usage	gauge	79.110000	{}	2025-09-04 13:51:46.341+00
99bf49be-f1bd-4227-9cc4-f22a65038011	cpu_usage	gauge	5.000000	{}	2025-09-04 13:52:46.342+00
dd8f35c8-14ae-40f4-916e-05b0992e653e	uptime	gauge	669.388731	{}	2025-09-04 13:53:46.342+00
6838a59c-49cb-438d-802e-f0cde0577b7a	cpu_usage	gauge	5.000000	{}	2025-09-04 13:54:46.342+00
23ad69aa-809e-4f0b-a7cd-5c3049be4437	uptime	gauge	789.389899	{}	2025-09-04 13:55:46.343+00
81741246-fc80-4262-91ad-f2227a443edf	disk_usage	gauge	45.200000	{}	2025-09-04 13:56:46.344+00
22e8d707-4b2b-4ae2-a0d6-210bece1213e	disk_usage	gauge	45.200000	{}	2025-09-04 13:57:46.344+00
30b2cf83-6c39-4221-8ef8-f64701261957	memory_usage	gauge	78.690000	{}	2025-09-04 13:58:46.345+00
d36ea0fc-dea8-4b84-8d0b-2eac3c75f17c	cpu_usage	gauge	5.000000	{}	2025-09-04 13:59:46.345+00
62a11a50-a3aa-477e-9b5d-1729732372ee	uptime	gauge	1089.391817	{}	2025-09-04 14:00:46.345+00
bb76dcd0-d45b-4c83-b84c-ecd3eefaddbe	memory_usage	gauge	80.220000	{}	2025-09-04 14:01:46.345+00
ccbbcc29-f601-4474-9835-e5c8950fa0c0	memory_usage	gauge	79.510000	{}	2025-09-04 14:02:46.345+00
11c366eb-d4e5-4383-a9a3-c588fb6b321f	cpu_usage	gauge	5.000000	{}	2025-09-04 14:03:46.345+00
9f15b988-64d4-409d-8ce4-fffb11ec5c19	uptime	gauge	1329.392279	{}	2025-09-04 14:04:46.345+00
1c16046f-37ff-4903-b5e6-52d4d0d64161	disk_usage	gauge	45.200000	{}	2025-09-04 14:05:46.346+00
94736f56-1edf-4317-8e99-0b181eb3b8ce	disk_usage	gauge	45.200000	{}	2025-09-04 14:06:46.346+00
b2d8561d-79fa-419c-acb0-45a5dfbebb91	memory_usage	gauge	79.670000	{}	2025-09-04 14:07:46.346+00
a30518e9-4822-492b-adf0-319e532fb363	uptime	gauge	1569.394587	{}	2025-09-04 14:08:46.348+00
8ba3df54-1d53-4ea0-b715-ccf99f502b43	memory_usage	gauge	79.770000	{}	2025-09-04 14:09:46.348+00
852cef6f-8bef-46f1-bee0-125c45da02aa	cpu_usage	gauge	5.000000	{}	2025-09-04 14:10:46.349+00
8ce662e1-2fcf-41ec-ac73-ad01bcfe88ea	uptime	gauge	1749.396496	{}	2025-09-04 14:11:46.349+00
ca6c52c8-c2cd-419c-923f-6f178b167137	disk_usage	gauge	45.200000	{}	2025-09-04 14:12:46.351+00
ca61196e-de6d-4f1f-a6d6-423c0a234ffc	memory_usage	gauge	79.420000	{}	2025-09-04 14:13:46.35+00
f56890bc-a14e-44f8-91de-434745c33278	uptime	gauge	1929.397214	{}	2025-09-04 14:14:46.35+00
f95bb8b1-5bcf-4a4b-acdb-f4f798902aa2	memory_usage	gauge	79.130000	{}	2025-09-04 14:15:46.351+00
987ec0bd-30ea-4c67-9ced-f2b05e25f84e	disk_usage	gauge	45.200000	{}	2025-09-04 14:16:46.351+00
d4dd3fd4-608b-40ae-ba81-cb416ec6976b	cpu_usage	gauge	5.000000	{}	2025-09-04 14:17:46.351+00
0bd6a8e6-7e16-400a-a4b6-cfc04b2563f3	uptime	gauge	2169.398786	{}	2025-09-04 14:18:46.352+00
2a8dfe28-ca98-4d36-ba27-ed7e8fc37cc8	disk_usage	gauge	45.200000	{}	2025-09-04 14:19:46.352+00
67c6ca14-ae51-45f1-a6ce-f590b43c177c	disk_usage	gauge	45.200000	{}	2025-09-04 14:20:46.352+00
1019dd1e-ec10-469d-8e0b-89b9e0902473	cpu_usage	gauge	5.000000	{}	2025-09-04 14:21:46.351+00
216789cf-00de-4fb5-a1d6-2b2fd1706232	uptime	gauge	2409.399002	{}	2025-09-04 14:22:46.352+00
853b8d23-5a4e-4170-bfd6-f3f51700792f	disk_usage	gauge	45.200000	{}	2025-09-04 14:23:46.352+00
9dfa1b81-61e7-441e-9e0f-476547f64ebb	cpu_usage	gauge	5.000000	{}	2025-09-04 18:59:23.22+00
ebaeda01-6796-4f74-96bb-2b295aa66f31	memory_usage	gauge	76.080000	{}	2025-09-04 18:59:23.22+00
1a3c0eb0-9c04-4689-9df6-fa006571f930	disk_usage	gauge	45.200000	{}	2025-09-04 18:59:23.221+00
918d6e88-cfe7-49d6-829e-3787c68744b6	uptime	gauge	69.302387	{}	2025-09-04 18:59:23.221+00
7636af42-9b87-4ba6-bd1b-2b370cbeb310	uptime	gauge	968.110089	{}	2025-09-03 16:48:58.35+00
1a66b0ac-854e-401b-8d46-7d4d0f116d38	memory_usage	gauge	76.500000	{}	2025-09-03 16:49:58.352+00
4c05dc6e-454a-4f1d-a8ac-fe9e67bccfee	memory_usage	gauge	75.860000	{}	2025-09-03 23:15:48.715+00
12df33a8-563d-4be3-bbec-4d96ff0a17a8	cpu_usage	gauge	5.000000	{}	2025-09-04 12:57:55.2+00
c7e898b5-dbbf-47c3-b600-32c803ccae5a	disk_usage	gauge	45.200000	{}	2025-09-04 12:58:55.2+00
ccb3f9bd-ffdf-4e0e-8dcf-076187733a8b	cpu_usage	gauge	5.000000	{}	2025-09-04 12:59:55.201+00
111abfb9-b4d3-4a1d-9b34-55e39df7b0c9	cpu_usage	gauge	5.000000	{}	2025-09-04 13:00:55.207+00
6cc64147-e0ab-4a60-9da5-82e29aeb7d99	uptime	gauge	369.439243	{}	2025-09-04 13:01:55.208+00
8f720962-e3d0-4ed1-bbc8-714203357ef2	disk_usage	gauge	45.200000	{}	2025-09-04 13:02:55.208+00
981d48a8-2214-452d-a719-80180115dd5d	disk_usage	gauge	45.200000	{}	2025-09-04 13:43:46.336+00
5e95ddf0-ed05-41fe-b3f0-d4ad8f7c5bda	memory_usage	gauge	81.060000	{}	2025-09-04 13:43:46.336+00
f3242c83-227d-4365-9bde-320d682bbe78	cpu_usage	gauge	5.000000	{}	2025-09-04 13:44:46.336+00
5f3b0077-12bf-4c3c-b5b5-a514e495cd4b	memory_usage	gauge	81.030000	{}	2025-09-04 13:44:46.336+00
d1475a18-e84b-4201-8713-d00e3f8aa5e9	cpu_usage	gauge	5.000000	{}	2025-09-04 13:45:46.336+00
6929c250-8d5c-4058-8af6-3d85c325f6f5	uptime	gauge	189.383461	{}	2025-09-04 13:45:46.336+00
c16f27a5-293e-40e9-bae7-ccdcdb3f578a	cpu_usage	gauge	5.000000	{}	2025-09-04 13:46:46.337+00
908bebd1-6b3f-42be-9f3e-ef98b611f505	memory_usage	gauge	81.730000	{}	2025-09-04 13:46:46.337+00
af08b7d4-162b-42a1-a0cc-0f6a8be6d023	disk_usage	gauge	45.200000	{}	2025-09-04 13:47:46.342+00
47f3258a-a6fc-4a90-915b-b495e9b1e1b2	uptime	gauge	309.389205	{}	2025-09-04 13:47:46.342+00
19ae3179-9444-4bac-9c44-3b586b24bf71	memory_usage	gauge	81.320000	{}	2025-09-04 13:48:46.342+00
2ca8cdf9-7fc0-4a28-9e44-1c5a30ac1985	disk_usage	gauge	45.200000	{}	2025-09-04 13:48:46.342+00
dbc5036f-aa52-40fa-8bb1-c5f2c71fd1c4	disk_usage	gauge	45.200000	{}	2025-09-04 13:49:46.342+00
5bcbacad-4d7f-4806-8cba-db4f52c29831	disk_usage	gauge	45.200000	{}	2025-09-04 13:50:46.342+00
d80900e7-fd39-441d-91be-3ad09dfa4d19	cpu_usage	gauge	5.000000	{}	2025-09-04 13:51:46.341+00
47c34ce2-85a8-46fe-9829-136b628c2496	uptime	gauge	609.388709	{}	2025-09-04 13:52:46.342+00
2622daeb-603a-4ed4-85b9-d70edcc423ee	disk_usage	gauge	45.200000	{}	2025-09-04 13:53:46.342+00
97b290d5-f3d2-4d81-951e-b3b6ef2b4d1b	disk_usage	gauge	45.200000	{}	2025-09-04 13:54:46.342+00
e4e6b2d5-6da6-4595-92f4-f2c70d4c79ab	disk_usage	gauge	45.200000	{}	2025-09-04 13:55:46.343+00
e62bba61-89f0-4c98-b294-4b0395cea179	memory_usage	gauge	78.750000	{}	2025-09-04 13:56:46.343+00
c437e013-af8b-40cc-ba7b-6ec2dff03c6a	cpu_usage	gauge	5.000000	{}	2025-09-04 13:57:46.344+00
4205c36a-6fb3-4182-b27b-ee4e51d3b1a5	cpu_usage	gauge	5.000000	{}	2025-09-04 13:58:46.345+00
529fc635-c250-4767-8f14-22d9960812ea	uptime	gauge	1029.392033	{}	2025-09-04 13:59:46.345+00
7ff4fa09-7baa-47e4-b2c8-95d2c413985c	disk_usage	gauge	45.200000	{}	2025-09-04 14:00:46.345+00
6734bea0-a20d-4469-a253-a4cceb337c47	cpu_usage	gauge	5.000000	{}	2025-09-04 14:01:46.345+00
02240e78-2238-4042-9edf-a211a8004f7d	uptime	gauge	1209.392360	{}	2025-09-04 14:02:46.345+00
0c2f06ec-257b-4156-a372-47167f00f75f	disk_usage	gauge	45.200000	{}	2025-09-04 14:03:46.345+00
44cfb7a3-d116-46e6-9ae0-7049a6f55769	memory_usage	gauge	79.530000	{}	2025-09-04 14:04:46.345+00
5e216a3a-494d-4b63-ac5d-c1f278737df5	uptime	gauge	1389.393411	{}	2025-09-04 14:05:46.346+00
d8acdc99-91e8-49e8-a7d5-3ad138c4c95b	memory_usage	gauge	79.480000	{}	2025-09-04 14:06:46.346+00
40771303-1880-436c-9578-9a4ff3567a1f	uptime	gauge	1509.393432	{}	2025-09-04 14:07:46.346+00
ac633615-3d1d-409f-83fa-9b56b8775ffa	cpu_usage	gauge	5.000000	{}	2025-09-04 14:08:46.347+00
8756fe58-f21d-409c-a205-c689c77ef01c	uptime	gauge	1629.395321	{}	2025-09-04 14:09:46.348+00
d35c2e86-eed2-42d5-ab7e-3b2ce19db78b	memory_usage	gauge	79.440000	{}	2025-09-04 14:10:46.349+00
63193c50-0cd0-4fce-9e1d-4d77bd6d10b8	memory_usage	gauge	79.600000	{}	2025-09-04 14:11:46.349+00
6677a37f-0234-4d27-a913-ee519d26138a	cpu_usage	gauge	5.000000	{}	2025-09-04 14:12:46.351+00
85df3c00-60fc-4154-82d8-42581052b7e8	uptime	gauge	1869.397066	{}	2025-09-04 14:13:46.35+00
13022de1-3e70-43c5-9720-032d9fe81fb4	disk_usage	gauge	45.200000	{}	2025-09-04 14:14:46.35+00
47be03a7-dac3-49ea-b3a5-6a6d9c437415	cpu_usage	gauge	5.000000	{}	2025-09-04 14:15:46.351+00
1d6bfe8b-4a78-48ab-bdbf-ba0eb9634541	uptime	gauge	2049.398211	{}	2025-09-04 14:16:46.351+00
8dc96840-fce7-483d-b3ae-9782121f7736	memory_usage	gauge	79.160000	{}	2025-09-04 14:17:46.351+00
47c4f0ec-1066-4a3d-9759-3ff313ce5177	memory_usage	gauge	79.130000	{}	2025-09-04 14:18:46.352+00
aef6b32e-6b89-4300-9bc4-49c03dd98c71	uptime	gauge	2229.399165	{}	2025-09-04 14:19:46.352+00
9c7aebf0-0d55-4f05-a111-6f58ca9bd5c7	cpu_usage	gauge	5.000000	{}	2025-09-04 14:20:46.352+00
2f38ff36-4b88-42cf-a55a-e4ce9c55dfc2	uptime	gauge	2349.398597	{}	2025-09-04 14:21:46.352+00
3ccfc5ad-fefd-49c2-9429-c1d8177ffec5	cpu_usage	gauge	5.000000	{}	2025-09-04 14:22:46.352+00
f67e9e07-535e-4e86-9d56-ba72587e285f	uptime	gauge	2469.398630	{}	2025-09-04 14:23:46.352+00
00ee542c-25da-4357-b1c6-f1f45af8d694	cpu_usage	gauge	5.000000	{}	2025-09-04 19:00:23.22+00
6d2c9cb5-a21a-4907-b13b-1db74703b336	uptime	gauge	189.301826	{}	2025-09-04 19:01:23.221+00
59c4677f-6644-4200-89a3-b324485ca579	disk_usage	gauge	45.200000	{}	2025-09-04 19:02:23.221+00
fc53b25d-4ece-4f30-9c29-abe646c8db60	uptime	gauge	1089.462308	{}	2025-09-03 16:49:36.215+00
be7495b3-726c-4cb6-9281-4f0ba7112e46	uptime	gauge	969.192216	{}	2025-09-03 23:15:48.715+00
f77b56b4-ad08-495c-b88b-dbf66c8be0b9	memory_usage	gauge	78.470000	{}	2025-09-04 12:57:55.2+00
c1df05cc-283b-48e0-acd4-bd32036ef4e7	memory_usage	gauge	78.490000	{}	2025-09-04 12:58:55.2+00
8334add2-65a9-4a17-9fb3-3feb6bb8642b	disk_usage	gauge	45.200000	{}	2025-09-04 12:59:55.201+00
a0976405-158d-445c-a37b-c0982b0f61dd	memory_usage	gauge	79.300000	{}	2025-09-04 13:00:55.207+00
f96b3a49-63f4-41d3-bf60-f8e96131ec25	memory_usage	gauge	81.840000	{}	2025-09-04 13:01:55.208+00
d27d4dc2-d61b-409d-acbd-18e403937e80	memory_usage	gauge	82.030000	{}	2025-09-04 13:02:55.208+00
2a6b1409-c7f6-4d89-8a45-9277db44c8a7	uptime	gauge	69.383405	{}	2025-09-04 13:43:46.336+00
8f1d958f-c46d-426a-8bee-988142534d7f	uptime	gauge	129.382779	{}	2025-09-04 13:44:46.336+00
faa1bd0b-4440-4435-b700-9d8d38b0d5fd	memory_usage	gauge	81.650000	{}	2025-09-04 13:45:46.336+00
ce18d437-b575-4396-913e-5b1da2198b24	uptime	gauge	249.384581	{}	2025-09-04 13:46:46.338+00
a3b11d8a-1dd9-451c-a43d-bf6e1a64475a	memory_usage	gauge	81.820000	{}	2025-09-04 13:47:46.342+00
031ad178-8c8e-4de5-9997-bc1980bff4fc	cpu_usage	gauge	5.000000	{}	2025-09-04 13:48:46.342+00
f42078c6-47c1-450f-871d-97e379752a34	memory_usage	gauge	81.540000	{}	2025-09-04 13:49:46.342+00
fea13b14-eaaf-48a1-9786-2fe90bc142ef	uptime	gauge	489.388969	{}	2025-09-04 13:50:46.342+00
684823ee-566e-4f66-b823-75a422784f9c	disk_usage	gauge	45.200000	{}	2025-09-04 13:51:46.341+00
9a5a261b-2287-4639-835d-8fcdebef72f0	disk_usage	gauge	45.200000	{}	2025-09-04 13:52:46.342+00
a32d8595-a471-44a1-8cb8-d7676fc4d0bb	memory_usage	gauge	78.540000	{}	2025-09-04 13:53:46.342+00
cf71ce2b-b810-49a7-a913-4927fbb43a80	memory_usage	gauge	78.530000	{}	2025-09-04 13:54:46.342+00
093f7dc8-b733-4e76-87cf-292db1607325	memory_usage	gauge	79.110000	{}	2025-09-04 13:55:46.343+00
490de5a0-5817-4dff-a94d-751408031de5	cpu_usage	gauge	5.000000	{}	2025-09-04 13:56:46.343+00
3895b8fa-8514-4276-828e-1954691d0950	uptime	gauge	909.390748	{}	2025-09-04 13:57:46.344+00
13c67c66-04fd-4ed0-8d18-fe575a4a0543	disk_usage	gauge	45.200000	{}	2025-09-04 13:58:46.345+00
0c78ae87-2eef-4cb2-8a11-408458305262	disk_usage	gauge	45.200000	{}	2025-09-04 13:59:46.345+00
d3025fbe-4b16-4711-bb9e-b41883a102da	cpu_usage	gauge	5.000000	{}	2025-09-04 14:00:46.345+00
93b19681-57ee-4411-8c15-6d4728f64c4c	uptime	gauge	1149.392017	{}	2025-09-04 14:01:46.345+00
d46600c5-6237-408d-abd5-867d9f1cee6b	cpu_usage	gauge	5.000000	{}	2025-09-04 14:02:46.345+00
922206ed-9339-49e9-8174-941f1998c10e	uptime	gauge	1269.392009	{}	2025-09-04 14:03:46.345+00
16726257-b8a1-4adb-ae8b-ab2d06365cd5	disk_usage	gauge	45.200000	{}	2025-09-04 14:04:46.345+00
e306d1bc-2a11-49ba-9fbf-f383f64e1e9a	memory_usage	gauge	79.470000	{}	2025-09-04 14:05:46.346+00
c7e9dcc0-bb75-47af-8a73-dc177d086399	uptime	gauge	1449.392733	{}	2025-09-04 14:06:46.346+00
65ffcd30-9542-4095-a10b-dd0c098c1d70	disk_usage	gauge	45.200000	{}	2025-09-04 14:07:46.346+00
a98b0954-56b1-463c-8c12-1a660911afb9	memory_usage	gauge	79.720000	{}	2025-09-04 14:08:46.347+00
9e00da7f-992d-44cc-a06f-a93d8ff08ca2	cpu_usage	gauge	5.000000	{}	2025-09-04 14:09:46.348+00
10b68793-70ce-4082-abb4-ced5692aede8	uptime	gauge	1689.395758	{}	2025-09-04 14:10:46.349+00
36e4dc52-37f7-48d0-9332-759df4b424d6	cpu_usage	gauge	5.000000	{}	2025-09-04 14:11:46.349+00
d727ab82-fb2a-48d8-98a7-87c7a7662398	uptime	gauge	1809.397691	{}	2025-09-04 14:12:46.351+00
6d6a4a5d-bc12-4fd1-99d3-75f44777bd9c	disk_usage	gauge	45.200000	{}	2025-09-04 14:13:46.35+00
64b50016-aaf7-48aa-88f1-3e424bd74085	memory_usage	gauge	79.400000	{}	2025-09-04 14:14:46.35+00
91986491-daa6-4e7d-ac77-cd5fafdfeab8	disk_usage	gauge	45.200000	{}	2025-09-04 14:15:46.352+00
b967d983-1455-4812-8f0e-66bf1f3de50a	memory_usage	gauge	79.210000	{}	2025-09-04 14:16:46.351+00
b6f714e1-7ae9-48c0-b782-722d566089d3	uptime	gauge	2109.398490	{}	2025-09-04 14:17:46.351+00
a3cdf0fe-c22c-41bd-a874-45d28624e6de	disk_usage	gauge	45.200000	{}	2025-09-04 14:18:46.352+00
20793a6f-ee64-436d-b871-dd4c3a8634ea	cpu_usage	gauge	5.000000	{}	2025-09-04 14:19:46.352+00
7856ac3c-db03-4f2c-bcee-a40a1a8dfce3	uptime	gauge	2289.398958	{}	2025-09-04 14:20:46.352+00
20f2fa14-0306-474e-afee-4dbda30b9485	disk_usage	gauge	45.200000	{}	2025-09-04 14:21:46.352+00
0d9b4f01-be1e-4ab5-b17b-5a6b1d72b19f	disk_usage	gauge	45.200000	{}	2025-09-04 14:22:46.352+00
ed58a5d8-e47c-4f6f-98ce-71561316bdff	cpu_usage	gauge	5.000000	{}	2025-09-04 14:23:46.351+00
3842abbf-8701-4cee-8694-9a2083379b2c	memory_usage	gauge	76.090000	{}	2025-09-04 19:00:23.22+00
78c996d3-67e1-4576-b7f2-44710a533ab8	cpu_usage	gauge	5.000000	{}	2025-09-04 19:01:23.22+00
847ae056-ead1-4c88-8666-04066743d8c5	uptime	gauge	249.301886	{}	2025-09-04 19:02:23.221+00
85254410-25a7-4fd6-ab62-f79ed59ddf34	memory_usage	gauge	76.890000	{}	2025-09-03 16:50:36.215+00
88939c22-aaa8-4a6a-8ea3-3e25c5b1722f	uptime	gauge	1209.461963	{}	2025-09-03 16:51:36.215+00
a5b2626f-92ae-4086-8a73-1c1d051c350d	memory_usage	gauge	76.490000	{}	2025-09-03 16:52:36.215+00
f5732cd5-1ae0-49c7-9d21-71e7c67a7705	memory_usage	gauge	76.390000	{}	2025-09-03 16:53:36.216+00
8e92afaa-5774-461a-b0f9-b0cfa3ba738a	memory_usage	gauge	76.400000	{}	2025-09-03 16:54:36.216+00
1ef2969e-b51f-4677-9f7a-f09479accb9f	memory_usage	gauge	77.340000	{}	2025-09-03 16:55:36.217+00
9ea5703c-811b-4687-861c-7d852eb2310f	memory_usage	gauge	77.550000	{}	2025-09-03 16:56:36.217+00
aaf04adb-ea06-4a89-b227-187bb57bb3f2	cpu_usage	gauge	6.000000	{}	2025-09-03 16:57:36.217+00
df9fc8bd-ff34-4b80-8aca-0c60814203a9	disk_usage	gauge	45.200000	{}	2025-09-03 23:15:48.715+00
18d8b8ee-52a5-42d8-98df-d22813395495	disk_usage	gauge	45.200000	{}	2025-09-04 12:57:55.2+00
1afbb68f-4e6d-4a5c-87df-aa2930c05c30	cpu_usage	gauge	5.000000	{}	2025-09-04 12:58:55.2+00
a082bf89-0d39-4c50-9b38-1f98e5721746	uptime	gauge	249.432684	{}	2025-09-04 12:59:55.201+00
23158d25-8daa-4c92-9ff6-e94a7e6fd86c	disk_usage	gauge	45.200000	{}	2025-09-04 13:00:55.207+00
f60f1711-effd-4e53-a2bb-4dd417b6ae1b	cpu_usage	gauge	5.000000	{}	2025-09-04 13:01:55.208+00
ed655e41-9345-49c6-b9ce-c41ce393a67e	uptime	gauge	429.439864	{}	2025-09-04 13:02:55.208+00
6212409e-9aaf-4db3-a23f-046e0a93af7d	cpu_usage	gauge	5.000000	{}	2025-09-04 13:49:46.342+00
300a119e-54fa-4bba-a2a4-488c080a8859	cpu_usage	gauge	5.000000	{}	2025-09-04 13:50:46.342+00
a07839f7-db0a-42fa-b4be-04608ff965bd	uptime	gauge	549.388137	{}	2025-09-04 13:51:46.341+00
2ba46c0d-b3ee-4823-976a-a68031ec4bb8	memory_usage	gauge	79.190000	{}	2025-09-04 13:52:46.342+00
d6bd530f-8f07-44c1-8369-b16dc6ce0e6d	cpu_usage	gauge	5.000000	{}	2025-09-04 13:53:46.342+00
f65c63e2-5d50-4dd3-94dc-23cc48f08529	uptime	gauge	729.388781	{}	2025-09-04 13:54:46.342+00
408e6dfa-70b3-4b50-969b-645fff5e1f55	cpu_usage	gauge	5.000000	{}	2025-09-04 13:55:46.343+00
71a092ca-bcfa-454f-8a2e-c2040cfde9d9	uptime	gauge	849.390575	{}	2025-09-04 13:56:46.344+00
c95c7fb5-8292-41be-8a5b-eae5d934116c	memory_usage	gauge	78.860000	{}	2025-09-04 13:57:46.344+00
f21a5cc6-7a6b-46ed-9500-34254af07ca7	uptime	gauge	969.392062	{}	2025-09-04 13:58:46.345+00
72ef87d4-6bed-4634-9384-3801427935ad	memory_usage	gauge	78.660000	{}	2025-09-04 13:59:46.345+00
81e6015b-749d-4e6f-bb8f-58f53780b484	disk_usage	gauge	45.200000	{}	2025-09-04 19:00:23.22+00
82151b80-fad9-455d-9e5a-0868136e79ec	memory_usage	gauge	76.270000	{}	2025-09-04 19:01:23.221+00
ea43f7f0-bbeb-42cd-b3ca-2a7eb0d445ec	cpu_usage	gauge	5.000000	{}	2025-09-04 19:02:23.221+00
c583016d-c1c3-42eb-bfeb-6a806b1b00d0	disk_usage	gauge	45.200000	{}	2025-09-03 16:50:36.215+00
25f41f13-2bea-40e9-827f-d05b2bb7d752	memory_usage	gauge	76.830000	{}	2025-09-03 16:51:36.215+00
c0c54375-df58-4fdc-94f0-04f88e23f92a	uptime	gauge	1269.462529	{}	2025-09-03 16:52:36.215+00
6958620c-4a77-4fd8-97b4-6482400dfb89	disk_usage	gauge	45.200000	{}	2025-09-03 16:53:36.216+00
47fbbd27-43fa-4f04-a934-884e230e892a	cpu_usage	gauge	6.000000	{}	2025-09-03 16:54:36.216+00
bab548c8-3025-4574-8659-1bbff5e377d7	uptime	gauge	1449.463962	{}	2025-09-03 16:55:36.217+00
9dce3151-544f-4020-ac28-a279a607a486	cpu_usage	gauge	6.000000	{}	2025-09-03 16:56:36.217+00
5a969cb1-206e-4251-b82d-6a6a9f0dffcf	uptime	gauge	1569.463926	{}	2025-09-03 16:57:36.217+00
8e004b24-1bad-41a5-9339-9fc33c31cbd5	memory_usage	gauge	78.860000	{}	2025-09-04 12:59:55.201+00
6ff1883d-21c3-4173-abdb-50ffbdf6921d	memory_usage	gauge	79.270000	{}	2025-09-04 14:00:46.345+00
a3054ae1-fb76-4440-8a88-b6068504ba01	disk_usage	gauge	45.200000	{}	2025-09-04 14:01:46.345+00
e72e3ffd-a6d6-4fe2-9a92-e18a748d5910	disk_usage	gauge	45.200000	{}	2025-09-04 14:02:46.345+00
3602d160-c6d3-4545-8b4b-732326dd7cb0	memory_usage	gauge	79.530000	{}	2025-09-04 14:03:46.345+00
8e672d7f-45c0-40f7-a5df-a0a5453c6d07	cpu_usage	gauge	5.000000	{}	2025-09-04 14:04:46.345+00
2e978922-f23f-4962-9429-1664e5377c43	cpu_usage	gauge	5.000000	{}	2025-09-04 14:05:46.346+00
027c1ace-7b8e-46fd-aefd-5f795daa5427	cpu_usage	gauge	5.000000	{}	2025-09-04 14:06:46.346+00
a27f2b57-dacd-4365-8831-f0e4913debc0	cpu_usage	gauge	5.000000	{}	2025-09-04 14:07:46.346+00
98dc662f-b57f-4b4b-8e47-bc640761b482	disk_usage	gauge	45.200000	{}	2025-09-04 14:08:46.348+00
b9f55322-eeea-4bf5-9e7c-32b638a29def	disk_usage	gauge	45.200000	{}	2025-09-04 14:09:46.348+00
24158b38-9c59-4908-bc84-b1bdb6eb2964	disk_usage	gauge	45.200000	{}	2025-09-04 14:10:46.349+00
ffb5a62b-b750-40be-a8f9-a7a162ad9645	disk_usage	gauge	45.200000	{}	2025-09-04 14:11:46.349+00
2617904d-3ce5-4714-974c-5b7c42fbb1d3	memory_usage	gauge	79.490000	{}	2025-09-04 14:12:46.351+00
8b346e0e-f761-454a-ba6b-9c03a4110978	cpu_usage	gauge	5.000000	{}	2025-09-04 14:13:46.35+00
ed9d2143-726d-47bd-9085-cc3a2b4a12b2	cpu_usage	gauge	5.000000	{}	2025-09-04 14:14:46.35+00
de76ca0a-c024-4d57-ab18-c7e3b1b056d8	uptime	gauge	1989.398609	{}	2025-09-04 14:15:46.352+00
f29c49b0-22a7-4bdc-b43b-29019a3190c2	cpu_usage	gauge	5.000000	{}	2025-09-04 14:16:46.351+00
f0126b27-d05e-4549-a7ab-9dc1b6d1fc1e	disk_usage	gauge	45.200000	{}	2025-09-04 14:17:46.351+00
2d791114-a67a-4a16-9d10-4633302e61ac	cpu_usage	gauge	5.000000	{}	2025-09-04 14:18:46.352+00
a028296f-c8d9-474f-920e-e906d9a57952	memory_usage	gauge	79.230000	{}	2025-09-04 14:19:46.352+00
ce82875d-baf7-4bc5-8103-98afb74542e7	memory_usage	gauge	79.640000	{}	2025-09-04 14:20:46.352+00
c4d7e51c-756b-42f8-842e-076d8c9a73d8	memory_usage	gauge	79.530000	{}	2025-09-04 14:21:46.351+00
95feedcd-6057-47f7-b3e3-95ee7c0f4891	memory_usage	gauge	79.540000	{}	2025-09-04 14:22:46.352+00
270dd830-ef56-45d8-a3a5-2cca00ba5d82	memory_usage	gauge	79.450000	{}	2025-09-04 14:23:46.352+00
afbeb278-8191-4a14-867b-a8f808d25caa	uptime	gauge	129.301111	{}	2025-09-04 19:00:23.22+00
87c7bb7d-3554-4fa9-8b08-43344c055c34	disk_usage	gauge	45.200000	{}	2025-09-04 19:01:23.221+00
fc3236e7-c9f4-49b8-9d3a-4c5275c91837	memory_usage	gauge	76.370000	{}	2025-09-04 19:02:23.221+00
1618c1d2-2938-4e08-81a5-75f0ae3bbdaa	cpu_usage	gauge	6.000000	{}	2025-09-03 16:50:36.215+00
c768e98c-9aaa-4052-b77c-6483ef4fc628	cpu_usage	gauge	6.000000	{}	2025-09-03 16:51:36.215+00
c0d9e31f-366a-453a-bee2-ea27ece5c16c	disk_usage	gauge	45.200000	{}	2025-09-03 16:52:36.215+00
87b60b73-fcd7-4807-9a3a-9a20688c0876	cpu_usage	gauge	6.000000	{}	2025-09-03 16:53:36.216+00
4e0b7007-57a7-4c14-ae4f-b26e34bfd25a	uptime	gauge	1389.463555	{}	2025-09-03 16:54:36.216+00
9524cd9f-0a77-49d1-a18f-df6cae49511f	disk_usage	gauge	45.200000	{}	2025-09-03 16:55:36.217+00
94679b9b-c52c-416f-9ad2-877a6b55d995	disk_usage	gauge	45.200000	{}	2025-09-03 16:56:36.217+00
9af066df-8321-46bf-9a12-08e38df63fd6	memory_usage	gauge	77.620000	{}	2025-09-03 16:57:36.217+00
556d5fa6-7e39-4059-9b04-48c8c4d177d3	memory_usage	gauge	81.750000	{}	2025-09-04 13:03:55.208+00
885f7503-a41b-49d3-b545-53a98e8c2db0	uptime	gauge	549.440303	{}	2025-09-04 13:04:55.209+00
6159d1a3-9915-43dc-b702-9997e5c80381	cpu_usage	gauge	5.000000	{}	2025-09-04 13:05:55.208+00
141baeee-a450-4ad7-a2c6-d2b03ab516d5	cpu_usage	gauge	5.000000	{}	2025-09-04 13:06:55.208+00
2d507890-db94-4517-9c8c-1500edf64082	uptime	gauge	729.439288	{}	2025-09-04 13:07:55.208+00
ad1cb774-af1b-4a1f-9b41-347740113c39	cpu_usage	gauge	5.000000	{}	2025-09-04 14:24:46.352+00
8f825e3e-d732-4b50-bd33-c4a5e743e8c7	uptime	gauge	2589.399530	{}	2025-09-04 14:25:46.352+00
4594ce54-583f-4475-b2dc-b24e6d5d847a	cpu_usage	gauge	5.000000	{}	2025-09-04 14:26:46.353+00
5b9fa15e-d8ce-4a7e-a1ae-bb9b999a0639	uptime	gauge	2709.400958	{}	2025-09-04 14:27:46.354+00
a86ce0e6-287a-4fc9-9a9d-202d26206d15	disk_usage	gauge	45.200000	{}	2025-09-04 14:28:46.354+00
9d416940-19fc-488b-939f-fb94a67869db	cpu_usage	gauge	5.000000	{}	2025-09-04 14:29:46.354+00
4355248a-4569-4fe0-bdcf-85b21a4465d3	cpu_usage	gauge	5.000000	{}	2025-09-04 14:30:46.354+00
615093d9-695c-4c79-9b6d-1aa626065be3	uptime	gauge	2949.402492	{}	2025-09-04 14:31:46.355+00
7cc4dd3e-93a6-4e63-855b-4613c7d95679	cpu_usage	gauge	5.000000	{}	2025-09-04 14:32:46.354+00
761156ef-43dc-4e8f-bb80-ebe3dc5a46b0	uptime	gauge	3069.402555	{}	2025-09-04 14:33:46.355+00
6b903b6c-e543-4c56-8fe1-8b108cf868c4	cpu_usage	gauge	5.000000	{}	2025-09-04 14:34:46.354+00
2889bc66-d6bf-49f6-9ff4-6fda34fe278e	cpu_usage	gauge	5.000000	{}	2025-09-04 14:35:46.355+00
5d78b44c-923b-48f5-834e-da25e28f3096	uptime	gauge	3249.402046	{}	2025-09-04 14:36:46.355+00
63d46695-d0aa-4f84-b64d-3ca4b2071c10	disk_usage	gauge	45.200000	{}	2025-09-04 14:37:46.355+00
68f92515-1c1e-444f-b7e5-e97279281022	disk_usage	gauge	45.200000	{}	2025-09-04 14:38:46.355+00
8e86de59-4d8d-4e95-996f-32bca124ba9c	cpu_usage	gauge	5.000000	{}	2025-09-04 14:39:46.356+00
2e13f48a-ae47-4096-8f7a-34c8ff861045	disk_usage	gauge	45.200000	{}	2025-09-04 14:40:46.356+00
ff2df40e-dc7d-4d7d-9410-b662a8ac3eb6	memory_usage	gauge	79.570000	{}	2025-09-04 14:41:46.357+00
6ccefaf0-2593-4773-bd2f-f7e53bccd736	cpu_usage	gauge	5.000000	{}	2025-09-04 14:42:46.358+00
0fbc7690-ded8-4eee-b595-9beaaee094d6	cpu_usage	gauge	5.000000	{}	2025-09-04 14:43:46.36+00
ebd53562-c41c-468a-a6ed-8c5f4c3ee3de	memory_usage	gauge	79.650000	{}	2025-09-04 14:44:46.359+00
cd3d6bdb-e192-43f6-84bb-224055f70c79	cpu_usage	gauge	5.000000	{}	2025-09-04 14:45:46.358+00
5743898d-c1c0-4661-9811-270e4f062a97	cpu_usage	gauge	5.000000	{}	2025-09-04 14:46:46.359+00
5201ffc1-875a-4d50-a90b-433d6af71ce5	uptime	gauge	3909.405587	{}	2025-09-04 14:47:46.359+00
1f5207d8-153b-46a3-bbc8-8c437d6a1040	disk_usage	gauge	45.200000	{}	2025-09-04 14:48:46.358+00
f8a17fc2-a141-44bb-a3d6-b246f96433f9	memory_usage	gauge	79.200000	{}	2025-09-04 14:49:46.359+00
0a898e38-8932-4c0c-b4d7-7d5a527df253	cpu_usage	gauge	5.000000	{}	2025-09-04 14:50:46.359+00
bd89a03c-5218-4d5c-9668-d64eae83a01e	uptime	gauge	4149.406588	{}	2025-09-04 14:51:46.36+00
20b4a395-83e7-421f-99a9-896e1714f089	cpu_usage	gauge	5.000000	{}	2025-09-04 14:52:46.36+00
1d6c40a8-2f15-4431-96e9-3d51440f9075	uptime	gauge	4269.407557	{}	2025-09-04 14:53:46.36+00
83797a4c-fb94-4e96-9535-9699f95ecd34	disk_usage	gauge	45.200000	{}	2025-09-04 14:54:46.361+00
14cd0336-b871-418a-bd7e-4b5464e25633	disk_usage	gauge	45.200000	{}	2025-09-04 14:55:46.363+00
368b2f46-c8de-4dcb-95c7-2e07af3f8aae	cpu_usage	gauge	5.000000	{}	2025-09-04 14:56:46.363+00
d06928ea-3f5a-4d3a-960d-31767a94bf57	uptime	gauge	4509.411666	{}	2025-09-04 14:57:46.365+00
2de4eb60-a30f-40eb-8a1d-6a1b670c1520	memory_usage	gauge	79.280000	{}	2025-09-04 14:58:46.365+00
9418e23f-2c9d-4d58-84bc-d637f76646a0	cpu_usage	gauge	5.000000	{}	2025-09-04 14:59:46.367+00
77bb8136-012c-4c94-ad7c-71782bc6a7c4	cpu_usage	gauge	5.000000	{}	2025-09-04 19:03:54.049+00
efd15ae6-581d-4e31-becb-8ffa8ec36743	disk_usage	gauge	45.200000	{}	2025-09-04 19:03:54.049+00
c8fc923f-c3b3-406d-9cff-0b164b3b8081	uptime	gauge	129.135165	{}	2025-09-04 19:04:54.049+00
d69d559b-f5ed-4186-9c96-f47c9a30ff3b	memory_usage	gauge	76.480000	{}	2025-09-04 19:05:54.051+00
78eda3ab-b0bc-4c3d-ab8c-5b874e206df5	memory_usage	gauge	76.450000	{}	2025-09-04 19:06:54.05+00
852d31e6-6803-496d-9f89-258a8b3202b6	cpu_usage	gauge	5.000000	{}	2025-09-04 19:07:54.056+00
cdea31ce-92c2-46fd-a7f0-c5965c462acb	uptime	gauge	369.142868	{}	2025-09-04 19:08:54.057+00
c3c1753e-5990-48f6-a217-7b8828266d43	disk_usage	gauge	45.200000	{}	2025-09-04 19:09:54.057+00
f6e014d5-7fd5-4806-aa3d-792eea380086	uptime	gauge	1149.462075	{}	2025-09-03 16:50:36.215+00
a84c2895-11c7-472d-ba73-b4c532d2aeda	disk_usage	gauge	45.200000	{}	2025-09-03 16:51:36.215+00
7ccb0354-b4c3-4427-9a26-0a85e70753b7	cpu_usage	gauge	6.000000	{}	2025-09-03 16:52:36.215+00
99fd1d87-b7af-4604-802d-23c61189a6cf	uptime	gauge	1329.463145	{}	2025-09-03 16:53:36.216+00
0d4fe496-8d6d-481d-9cb5-77af0b227b88	disk_usage	gauge	45.200000	{}	2025-09-03 16:54:36.216+00
af14e1d7-d5e4-4a09-8ffc-b9d26d88a61d	cpu_usage	gauge	6.000000	{}	2025-09-03 16:55:36.217+00
d55b816e-541a-46c7-af33-2c9f7176481c	uptime	gauge	1509.463941	{}	2025-09-03 16:56:36.217+00
66f772f5-4ae4-43a7-aa1f-226538e40f59	disk_usage	gauge	45.200000	{}	2025-09-03 16:57:36.217+00
400cd57d-adbe-4571-8c28-20b00e95f274	disk_usage	gauge	45.200000	{}	2025-09-04 13:03:55.208+00
9019a323-0cf5-4ff5-bfbf-9c22d6bfa63b	disk_usage	gauge	45.200000	{}	2025-09-04 13:04:55.209+00
df7e13f5-ac62-4583-9bd5-5cf25f0d3477	memory_usage	gauge	80.440000	{}	2025-09-04 13:05:55.208+00
f593b6de-29d2-4692-890d-40b5a4ed8801	uptime	gauge	669.439329	{}	2025-09-04 13:06:55.208+00
2da7b95e-1057-4f78-9e1f-cbe1bafde7fd	disk_usage	gauge	45.200000	{}	2025-09-04 13:07:55.208+00
e6c9fb46-4fe4-45d4-a154-946f0955ede6	memory_usage	gauge	79.430000	{}	2025-09-04 14:24:46.352+00
376dd21a-7a66-46f4-8eff-0add45999087	cpu_usage	gauge	5.000000	{}	2025-09-04 14:25:46.352+00
88ddde97-a83c-4fce-a012-50b7fd2b49a3	uptime	gauge	2649.400462	{}	2025-09-04 14:26:46.353+00
52aa2dc4-d750-4618-b1fb-9ba7a89dc438	memory_usage	gauge	79.540000	{}	2025-09-04 14:27:46.354+00
e417308c-7924-41c2-af66-e101f1f8534d	memory_usage	gauge	79.410000	{}	2025-09-04 14:28:46.354+00
3dfd4503-09e6-4903-bd71-dc068cb6e8de	disk_usage	gauge	45.200000	{}	2025-09-04 14:29:46.354+00
b9adee00-2764-425b-be9b-682eafe02982	memory_usage	gauge	79.190000	{}	2025-09-04 14:30:46.354+00
715baf18-0cb2-406d-8dba-585d6233e72f	disk_usage	gauge	45.200000	{}	2025-09-04 14:31:46.355+00
5ef9e46a-6f1d-4760-b0ba-23569a7e363c	memory_usage	gauge	79.640000	{}	2025-09-04 14:32:46.354+00
7911c57a-320a-4090-a792-bb00c9070528	cpu_usage	gauge	5.000000	{}	2025-09-04 14:33:46.355+00
e83e4940-7c17-4778-bdf9-7d88591fc4b8	uptime	gauge	3129.401562	{}	2025-09-04 14:34:46.355+00
bff88285-7ba2-4919-ae02-f8295a8c2567	disk_usage	gauge	45.200000	{}	2025-09-04 14:35:46.355+00
476334b0-bad3-424b-a789-b4dce759fb4d	memory_usage	gauge	79.540000	{}	2025-09-04 14:36:46.355+00
bd69cb6b-9f55-4762-8545-f26f1be1f656	cpu_usage	gauge	5.000000	{}	2025-09-04 14:37:46.355+00
aa2b687b-b965-496e-8aa0-bd92298242bc	memory_usage	gauge	79.480000	{}	2025-09-04 14:38:46.355+00
a18d4a5f-ccda-4ad4-9f75-c3a1146bc94d	memory_usage	gauge	79.550000	{}	2025-09-04 14:39:46.356+00
25d8beba-4ac6-428f-a4a8-c704013ea9dc	uptime	gauge	3489.403549	{}	2025-09-04 14:40:46.356+00
7470d3be-33ed-488b-9ac6-6db78ece8029	disk_usage	gauge	45.200000	{}	2025-09-04 14:41:46.357+00
1011b306-46c4-49c8-8146-3989ae775f56	memory_usage	gauge	79.500000	{}	2025-09-04 14:42:46.358+00
228e4874-ee85-426d-8543-cf6768336439	uptime	gauge	3669.406715	{}	2025-09-04 14:43:46.36+00
fce8dee4-4565-4169-a657-823aca2ae5eb	disk_usage	gauge	45.200000	{}	2025-09-04 14:44:46.359+00
cf9ad81e-6498-4a7c-9e70-62a6309fe904	memory_usage	gauge	84.270000	{}	2025-09-04 14:45:46.358+00
cfe5c1d7-0dbb-40aa-a2ee-01a039ed3194	uptime	gauge	3849.406127	{}	2025-09-04 14:46:46.359+00
92a6f5c9-0e0c-4b1f-a1bf-524d98fded30	disk_usage	gauge	45.200000	{}	2025-09-04 14:47:46.359+00
54fd69b9-b884-4be2-a3e1-2beba76a5e0b	memory_usage	gauge	79.170000	{}	2025-09-04 14:48:46.358+00
f8822b44-e96c-4e30-8d05-3d45259cf7db	disk_usage	gauge	45.200000	{}	2025-09-04 14:49:46.359+00
2692110e-8761-45ba-8714-081e092c7dd5	disk_usage	gauge	45.200000	{}	2025-09-04 14:50:46.359+00
b45532fb-2e78-4143-8c6c-dbc3b3165234	memory_usage	gauge	79.380000	{}	2025-09-04 14:51:46.359+00
bb69ab63-d91d-4de0-82c7-29f077cae297	disk_usage	gauge	45.200000	{}	2025-09-04 14:52:46.36+00
78579be2-a8b6-4cde-bab5-9e1f516b59c9	disk_usage	gauge	45.200000	{}	2025-09-04 14:53:46.36+00
727c1041-04d1-46c0-b8a5-67eba46673f3	cpu_usage	gauge	5.000000	{}	2025-09-04 14:54:46.361+00
541d5081-4d86-4d60-99d5-d8807d2a92d3	uptime	gauge	4389.409750	{}	2025-09-04 14:55:46.363+00
ce20daeb-d62d-4015-a667-0b575929db28	memory_usage	gauge	79.450000	{}	2025-09-04 14:56:46.363+00
d1f2e62f-948e-4732-9263-e611dc075291	memory_usage	gauge	79.250000	{}	2025-09-04 14:57:46.365+00
fb3d95f0-64ce-4f84-8a89-42dbc30829b8	uptime	gauge	4569.412446	{}	2025-09-04 14:58:46.365+00
392aeb93-4a50-43c9-a100-55c0631408f8	disk_usage	gauge	45.200000	{}	2025-09-04 14:59:46.367+00
2777c4d5-3070-475f-b0b4-dea06187f4a5	uptime	gauge	4689.414022	{}	2025-09-04 15:00:46.367+00
706af942-b305-41a4-aa3b-da166592d755	disk_usage	gauge	45.200000	{}	2025-09-04 15:01:46.37+00
1f265e98-c1a3-475a-8a3d-f75b8c99f6e1	memory_usage	gauge	79.690000	{}	2025-09-04 15:02:46.369+00
0ec3dc59-1cc7-4865-8fef-4574bb870569	cpu_usage	gauge	5.000000	{}	2025-09-04 15:03:46.37+00
0c452959-cc62-452b-aadc-542cc008838b	uptime	gauge	4929.417641	{}	2025-09-04 15:04:46.371+00
34967fa0-c36c-400c-b155-80a54ad1211d	disk_usage	gauge	45.200000	{}	2025-09-04 15:05:46.372+00
3d6cf226-16f1-4b5c-aa1f-45fa0fc3bcb1	cpu_usage	gauge	5.000000	{}	2025-09-04 15:06:46.372+00
6d37df6f-43b9-4b67-809a-7fc705309334	uptime	gauge	5109.418558	{}	2025-09-04 15:07:46.371+00
f30efbed-2983-4f5f-8703-097580931a2b	cpu_usage	gauge	5.000000	{}	2025-09-04 15:08:46.373+00
75083e31-ff93-4852-8522-d0b621c2ef64	uptime	gauge	5229.420233	{}	2025-09-04 15:09:46.373+00
58d08c03-78bf-43b3-8d11-25759dd0f081	memory_usage	gauge	79.280000	{}	2025-09-04 15:10:46.374+00
d7f170f0-f94a-4244-9aca-43cff4d439b3	uptime	gauge	5349.421145	{}	2025-09-04 15:11:46.374+00
260b4d13-5afe-4249-a8b2-4e54ef1e07e3	disk_usage	gauge	45.200000	{}	2025-09-04 15:12:46.375+00
b357a1f9-d0b4-4761-83f3-61096f1c542b	memory_usage	gauge	77.700000	{}	2025-09-04 15:13:46.377+00
c3e01d84-a50b-440e-a1ac-4321bf37ca8d	memory_usage	gauge	76.140000	{}	2025-09-04 19:03:54.049+00
7c4aa843-9493-47f5-b0a1-9fdfc831ef91	uptime	gauge	69.135301	{}	2025-09-04 19:03:54.049+00
67bab197-af25-4790-84f3-908eec9650c4	disk_usage	gauge	45.200000	{}	2025-09-04 19:04:54.049+00
322d150e-58dc-41cc-980e-b9b5062b4c37	uptime	gauge	189.137055	{}	2025-09-04 19:05:54.051+00
38a41070-83cb-427f-9fad-42bbc59e2e66	disk_usage	gauge	45.200000	{}	2025-09-04 19:06:54.05+00
fdaf1acd-aa55-4f9f-b305-5e762201a356	disk_usage	gauge	45.200000	{}	2025-09-04 19:07:54.056+00
5662a4ee-337c-45f4-b96f-19612c433d21	memory_usage	gauge	76.370000	{}	2025-09-04 19:08:54.056+00
4ee38f2f-6716-4a52-b223-b5b3d4f19ece	cpu_usage	gauge	5.000000	{}	2025-09-04 19:09:54.057+00
dc2cd04a-852c-4984-956b-39993ed2e6a9	memory_usage	gauge	76.910000	{}	2025-09-03 16:50:58.352+00
7c9e0c03-9af5-4754-bfc5-732216a618b1	uptime	gauge	1148.113165	{}	2025-09-03 16:51:58.353+00
e14bbee6-5894-49c7-b77c-10e862f5dc30	memory_usage	gauge	76.510000	{}	2025-09-03 16:52:58.354+00
e99bbe07-bb25-4f7e-a96d-96a886510c43	uptime	gauge	1268.113535	{}	2025-09-03 16:53:58.354+00
34024502-6841-4696-be4a-d9152356073d	memory_usage	gauge	76.370000	{}	2025-09-03 16:54:58.354+00
35ddd4af-b6b5-4c24-bc70-07b145fb9525	uptime	gauge	1388.114307	{}	2025-09-03 16:55:58.355+00
738ff6ac-17b4-423f-b18a-c1ab93396dbd	disk_usage	gauge	45.200000	{}	2025-09-03 16:56:58.355+00
6b8e51b9-c72a-42d6-aa3c-fdfe2a093eac	uptime	gauge	1508.115367	{}	2025-09-03 16:57:58.356+00
b4f7af89-851d-4e74-875a-762e0762cfb4	cpu_usage	gauge	5.000000	{}	2025-09-04 13:03:55.208+00
87996ec8-e6e9-4c5c-ab60-9e162a8abeb6	cpu_usage	gauge	5.000000	{}	2025-09-04 13:04:55.209+00
8fedd182-1422-4d92-b040-c93e600a0852	uptime	gauge	609.439789	{}	2025-09-04 13:05:55.208+00
66b9361f-d339-45a9-bba1-5175fd0d0183	disk_usage	gauge	45.200000	{}	2025-09-04 13:06:55.208+00
25c2b356-5977-4353-a7cd-8db1808b29c4	cpu_usage	gauge	5.000000	{}	2025-09-04 13:07:55.208+00
b5c95837-6732-41dd-ae32-1d1ae03a72b0	disk_usage	gauge	45.200000	{}	2025-09-04 14:24:46.352+00
16dda23d-d6a2-4ea4-9e41-05df5f01c648	memory_usage	gauge	79.480000	{}	2025-09-04 14:25:46.352+00
fd6a221e-ca11-46cf-8323-5c57382f29d8	disk_usage	gauge	45.200000	{}	2025-09-04 14:26:46.353+00
5ac4eb7d-a374-42b9-956f-1cd937bd40ff	disk_usage	gauge	45.200000	{}	2025-09-04 14:27:46.354+00
95a17f27-2568-42bb-8cb8-00dc775822f3	cpu_usage	gauge	5.000000	{}	2025-09-04 14:28:46.354+00
5fcb71a3-a5b0-4793-9ec7-b076e33cf2be	uptime	gauge	2829.401320	{}	2025-09-04 14:29:46.354+00
15ef5848-72ab-4449-83c4-635b53515514	disk_usage	gauge	45.200000	{}	2025-09-04 14:30:46.354+00
cb51cc72-656b-4794-8696-c4177c343867	cpu_usage	gauge	5.000000	{}	2025-09-04 14:31:46.355+00
290316d0-ee09-486e-82fa-0e66adefa328	uptime	gauge	3009.401618	{}	2025-09-04 14:32:46.355+00
8185fb12-6a10-4eea-ac8e-f703e287667c	memory_usage	gauge	79.430000	{}	2025-09-04 14:33:46.355+00
7250a42d-9c89-407b-8463-891bef2fc862	memory_usage	gauge	79.420000	{}	2025-09-04 14:34:46.354+00
dce618b0-f21f-4b33-b563-a752e67d0180	uptime	gauge	3189.402516	{}	2025-09-04 14:35:46.355+00
840a3b8e-b417-476c-a3bf-c45dce1269f7	disk_usage	gauge	45.200000	{}	2025-09-04 14:36:46.355+00
4a8d07d7-a09e-4a6c-b494-55e641d873f2	memory_usage	gauge	79.610000	{}	2025-09-04 14:37:46.355+00
11f4a429-6226-4db4-8542-a15979d4ef37	uptime	gauge	3369.402447	{}	2025-09-04 14:38:46.355+00
7cd90271-84ab-4b78-83c2-33e501265823	disk_usage	gauge	45.200000	{}	2025-09-04 14:39:46.356+00
4a5cfa13-398d-4261-a4c6-ab89788aa779	cpu_usage	gauge	5.000000	{}	2025-09-04 14:40:46.356+00
243e3ba5-4154-4e1e-9421-da76228ac73a	uptime	gauge	3549.404183	{}	2025-09-04 14:41:46.357+00
54d2c3a3-ebcc-43e2-a34b-88f8cdd1712f	disk_usage	gauge	45.200000	{}	2025-09-04 14:42:46.358+00
7b311851-3478-476c-80c4-398d34cde85a	memory_usage	gauge	79.680000	{}	2025-09-04 14:43:46.36+00
34ffb074-d35d-4156-95e2-b21eee4bd165	uptime	gauge	3729.406239	{}	2025-09-04 14:44:46.359+00
6d1ce429-b082-4ed2-9811-e5752d453c4d	disk_usage	gauge	45.200000	{}	2025-09-04 14:45:46.358+00
1eb2bc1b-9a36-4162-b074-32cba33c67e0	memory_usage	gauge	79.620000	{}	2025-09-04 14:46:46.359+00
78fb147f-e50e-4a0c-80cf-d29cdccdfb73	memory_usage	gauge	79.710000	{}	2025-09-04 14:47:46.358+00
fae743e3-85f7-4a08-994f-b0f2d6aa99d2	cpu_usage	gauge	5.000000	{}	2025-09-04 14:48:46.358+00
966eb7e9-a4c5-40d7-8c1f-3bf2ed454427	uptime	gauge	4029.405757	{}	2025-09-04 14:49:46.359+00
cae01d04-d6af-46bf-ada9-436d79ce657c	memory_usage	gauge	80.000000	{}	2025-09-04 14:50:46.359+00
39b5a583-83f1-48ce-871b-9f8be7abbbb4	cpu_usage	gauge	5.000000	{}	2025-09-04 14:51:46.359+00
41a4c54a-9681-4af4-adf8-6a0acfe6c6f7	uptime	gauge	4209.407550	{}	2025-09-04 14:52:46.36+00
318901ec-afc2-4549-8058-e5e85a4f4895	cpu_usage	gauge	5.000000	{}	2025-09-04 14:53:46.36+00
a4b543d6-3dc2-4509-8e76-0df7589bf471	uptime	gauge	4329.408542	{}	2025-09-04 14:54:46.361+00
790d05f2-a58a-4938-91c9-b980a1c200c8	memory_usage	gauge	79.280000	{}	2025-09-04 14:55:46.363+00
8e2ed241-3ef0-4510-aa5a-0557835c2a9c	disk_usage	gauge	45.200000	{}	2025-09-04 14:56:46.364+00
ba219ad9-dae3-4516-933a-e0941d442647	disk_usage	gauge	45.200000	{}	2025-09-04 14:57:46.365+00
d9d0a226-8c1b-4edc-9bcd-b1933a56cc2b	cpu_usage	gauge	5.000000	{}	2025-09-04 14:58:46.365+00
43fec2d1-4676-4bbe-b797-2d4ca98e562e	uptime	gauge	4629.413698	{}	2025-09-04 14:59:46.367+00
51947da0-f361-4733-9127-856ca3a7e2d6	cpu_usage	gauge	5.000000	{}	2025-09-04 19:04:54.049+00
1bba700e-cdb8-4610-a632-66c3e5275386	disk_usage	gauge	45.200000	{}	2025-09-04 19:05:54.051+00
fdcceff6-d0e0-4a49-9f06-71a99c548edc	cpu_usage	gauge	5.000000	{}	2025-09-04 19:06:54.05+00
8e402a76-e6f5-49d7-a7cb-ff0c52f1c320	uptime	gauge	309.142400	{}	2025-09-04 19:07:54.056+00
1ed5dbcd-f2c3-43d6-8e7b-40b63deb791e	disk_usage	gauge	45.200000	{}	2025-09-04 19:08:54.057+00
da260d1a-c001-42c9-82f5-7962c026e765	memory_usage	gauge	76.390000	{}	2025-09-04 19:09:54.057+00
91cc7563-40bc-4ed3-a0ad-72cfcd324084	uptime	gauge	1088.112187	{}	2025-09-03 16:50:58.352+00
ad4ca451-4298-471d-82e7-be176b75d0a4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:51:58.353+00
e9379543-6c19-4e2b-bf8f-10e806de848b	disk_usage	gauge	45.200000	{}	2025-09-03 16:52:58.354+00
cd61ce44-004a-4be7-aa6e-7a697f77bf47	disk_usage	gauge	45.200000	{}	2025-09-03 16:53:58.354+00
10617a79-e2a3-48b7-b798-02c3aa343483	cpu_usage	gauge	6.000000	{}	2025-09-03 16:54:58.354+00
5c4dbafc-9872-4fb2-a9b8-9222baf77c71	disk_usage	gauge	45.200000	{}	2025-09-03 16:55:58.355+00
5cc5b36f-b160-4d57-9538-1aacb0d63207	cpu_usage	gauge	6.000000	{}	2025-09-03 16:56:58.355+00
1fd04c1f-6c63-4b7e-84ba-53fd3c1a424d	disk_usage	gauge	45.200000	{}	2025-09-03 16:57:58.356+00
7cfef134-55ef-40d2-aeba-6b4f835d99cb	uptime	gauge	489.439604	{}	2025-09-04 13:03:55.208+00
e024591c-a412-4b5d-8b93-64a44bed142c	memory_usage	gauge	81.860000	{}	2025-09-04 13:04:55.209+00
36065376-18aa-49d8-9527-a2e679d8ed3c	disk_usage	gauge	45.200000	{}	2025-09-04 13:05:55.208+00
f328b668-739d-4aff-b351-f62cbf6c381e	memory_usage	gauge	82.140000	{}	2025-09-04 13:06:55.208+00
cac58d38-f4c9-4f73-ba48-6e6241574344	memory_usage	gauge	81.240000	{}	2025-09-04 13:07:55.208+00
7c8b4bc9-d128-4c7b-89aa-7f3bc182c7e3	uptime	gauge	2529.399467	{}	2025-09-04 14:24:46.352+00
a0aef0c0-8507-405f-a0f8-b54943a72ee9	disk_usage	gauge	45.200000	{}	2025-09-04 14:25:46.352+00
483415ba-890c-4647-bcfe-2e289f81fa4b	memory_usage	gauge	79.400000	{}	2025-09-04 14:26:46.353+00
7ed76f53-2442-42ef-832d-db5ee4ba49ad	cpu_usage	gauge	5.000000	{}	2025-09-04 14:27:46.354+00
463b78e1-ee93-43ad-b3f8-7ebdc443e7f9	uptime	gauge	2769.400873	{}	2025-09-04 14:28:46.354+00
eaf91ae6-ffd8-44e2-b986-8015b0540002	memory_usage	gauge	79.370000	{}	2025-09-04 14:29:46.354+00
8e5e19d2-55cb-44b3-92af-0d5cdb7655ca	uptime	gauge	2889.401442	{}	2025-09-04 14:30:46.354+00
cb51591d-3a28-493a-8a22-9bcb34322bae	memory_usage	gauge	79.290000	{}	2025-09-04 14:31:46.355+00
6d31aeb6-eada-433b-ba07-18813dd280e3	disk_usage	gauge	45.200000	{}	2025-09-04 14:32:46.355+00
76fb4ce9-1e0b-4e94-ada6-3a98c502a3d3	disk_usage	gauge	45.200000	{}	2025-09-04 14:33:46.355+00
b7359cf5-aa68-4935-bb97-a23ef04d81f1	disk_usage	gauge	45.200000	{}	2025-09-04 14:34:46.354+00
c77e77b0-98a2-486c-9715-d8d3393c3e8f	memory_usage	gauge	79.510000	{}	2025-09-04 14:35:46.355+00
8ba14580-d402-440e-85d3-ad4c3f821379	cpu_usage	gauge	5.000000	{}	2025-09-04 14:36:46.355+00
6b964c48-43c8-4df2-85dc-6bda0d94b0f5	uptime	gauge	3309.402137	{}	2025-09-04 14:37:46.355+00
edb2299a-55d8-42d3-b373-35c8a77dfa07	cpu_usage	gauge	5.000000	{}	2025-09-04 14:38:46.355+00
87523247-5df1-4bee-a95c-f9d6c82d36d7	uptime	gauge	3429.402675	{}	2025-09-04 14:39:46.356+00
64151acd-25e5-416d-80fd-f06cfeefe7ea	memory_usage	gauge	79.850000	{}	2025-09-04 14:40:46.356+00
7e62b15e-3eef-4d24-9e60-4d18e0938a5b	cpu_usage	gauge	5.000000	{}	2025-09-04 14:41:46.357+00
c7a6dca6-bc68-4c7d-a9e6-16117f723a93	uptime	gauge	3609.404908	{}	2025-09-04 14:42:46.358+00
cf610b11-a7b9-4255-b2bb-906a32e52cf1	disk_usage	gauge	45.200000	{}	2025-09-04 14:43:46.36+00
75ad6b21-8279-49de-a8b9-66a2db25b6bb	cpu_usage	gauge	5.000000	{}	2025-09-04 14:44:46.359+00
8a441bff-c852-46fe-b4a0-525b22179888	uptime	gauge	3789.405463	{}	2025-09-04 14:45:46.358+00
c79d1dc8-6ad4-4cb9-87dc-b79e7dd98a7c	disk_usage	gauge	45.200000	{}	2025-09-04 14:46:46.359+00
f6562e1d-51a2-4b3a-9ad0-6d94d2ac4b0e	cpu_usage	gauge	5.000000	{}	2025-09-04 14:47:46.358+00
5abccff9-ea12-48f7-81bf-116d7a4d9254	uptime	gauge	3969.405477	{}	2025-09-04 14:48:46.358+00
16c108ac-c11c-42df-a099-4fb6825c0daf	cpu_usage	gauge	5.000000	{}	2025-09-04 14:49:46.359+00
7900b035-4b78-4661-a544-89010f2f8d12	uptime	gauge	4089.406367	{}	2025-09-04 14:50:46.359+00
6724518c-168b-45c4-abea-a41f4470a37b	disk_usage	gauge	45.200000	{}	2025-09-04 14:51:46.36+00
084fe2bb-1f39-45d5-ae59-a02797b8fac8	memory_usage	gauge	79.280000	{}	2025-09-04 14:52:46.36+00
4df32ade-c9a0-4554-9a7b-93cf50683eb5	memory_usage	gauge	79.310000	{}	2025-09-04 14:53:46.36+00
6c920e75-0ea8-41ec-b921-95b791f6041d	memory_usage	gauge	79.360000	{}	2025-09-04 14:54:46.361+00
910cfa10-8476-4e1e-8b8f-bc111dcea028	cpu_usage	gauge	5.000000	{}	2025-09-04 14:55:46.363+00
e2f46a24-85e2-4b32-811b-60b1cd856842	uptime	gauge	4449.410646	{}	2025-09-04 14:56:46.364+00
e6734050-7e31-492f-99ba-ecfe5ad0af22	cpu_usage	gauge	5.000000	{}	2025-09-04 14:57:46.364+00
4c6e552e-01bb-4a61-ba73-7421cddcf225	disk_usage	gauge	45.200000	{}	2025-09-04 14:58:46.365+00
ddfad9c6-7a2c-475b-bf2e-e80753d78ba5	memory_usage	gauge	77.860000	{}	2025-09-04 14:59:46.367+00
9d2d69c0-fd7d-42d0-9423-a880924e2731	cpu_usage	gauge	5.000000	{}	2025-09-04 15:00:46.367+00
ab873e26-15df-4e48-92ef-b14fe03d1825	uptime	gauge	4749.417430	{}	2025-09-04 15:01:46.37+00
ed7829d9-a2de-415d-a589-e4d2ac00a873	disk_usage	gauge	45.200000	{}	2025-09-04 15:02:46.369+00
5fc8e56b-f0ae-4396-8d67-5ce6797e1a75	memory_usage	gauge	79.150000	{}	2025-09-04 15:03:46.37+00
e0a12470-e9bd-4986-ba1e-3070c261839a	cpu_usage	gauge	5.000000	{}	2025-09-04 15:04:46.37+00
6c4d8ee6-5ac7-4d2d-972c-eb8281496d5b	uptime	gauge	4989.419089	{}	2025-09-04 15:05:46.372+00
98b42e85-26d6-448b-ac85-f3c722ccc2f0	disk_usage	gauge	45.200000	{}	2025-09-04 15:06:46.372+00
b0db1178-2953-40ea-b012-c557394e89bb	disk_usage	gauge	45.200000	{}	2025-09-04 15:07:46.371+00
616beea5-94df-4d40-9ccb-315c4aa7a7d3	memory_usage	gauge	79.550000	{}	2025-09-04 15:08:46.373+00
20fa6531-0075-403d-a993-a2b185cbd848	disk_usage	gauge	45.200000	{}	2025-09-04 15:09:46.373+00
056f99ee-4eed-4c01-a837-274200d87c13	disk_usage	gauge	45.200000	{}	2025-09-04 15:10:46.374+00
862e54f5-a924-45d9-9857-3d14a487b61d	memory_usage	gauge	79.420000	{}	2025-09-04 15:11:46.374+00
f1a0100f-a5ea-4aa0-baeb-421b8c8dfca2	cpu_usage	gauge	5.000000	{}	2025-09-04 15:12:46.375+00
e3b11c14-bf64-4e9f-8f42-308f596445ae	uptime	gauge	5469.424019	{}	2025-09-04 15:13:46.377+00
8fca2c76-cf68-473e-9aae-8b6f2218e2a4	memory_usage	gauge	76.260000	{}	2025-09-04 19:04:54.049+00
aa3e3488-712c-4c21-9ba9-d2a7de6de4bc	cpu_usage	gauge	5.000000	{}	2025-09-04 19:05:54.051+00
be2c0d46-7bb4-49ed-a986-e26c60266c6e	uptime	gauge	249.136723	{}	2025-09-04 19:06:54.05+00
daa3a1d8-b253-4f2b-8158-df6ef09affa0	memory_usage	gauge	76.640000	{}	2025-09-04 19:07:54.056+00
46b070b9-d2b0-48a1-8ff9-4757b60cb7fd	cpu_usage	gauge	5.000000	{}	2025-09-04 19:08:54.056+00
81f039c0-fc46-4683-84f3-bedf1472a827	uptime	gauge	429.143415	{}	2025-09-04 19:09:54.057+00
7a94d813-5996-4d91-a62e-aa5573b74951	cpu_usage	gauge	6.000000	{}	2025-09-03 16:50:58.352+00
5623e58e-0559-4a44-9fca-ff2138d060a0	disk_usage	gauge	45.200000	{}	2025-09-03 16:51:58.353+00
c30fe19d-4b51-44a1-aa73-85ec8b8851c8	cpu_usage	gauge	6.000000	{}	2025-09-03 16:52:58.354+00
b345020d-42d0-4043-b17b-7e19ce9019d5	memory_usage	gauge	76.840000	{}	2025-09-03 16:53:58.354+00
d8b9c807-9254-4806-b8ff-8e2da1f9433c	disk_usage	gauge	45.200000	{}	2025-09-03 16:54:58.354+00
a8d91430-c233-470d-a60f-94fd99383671	memory_usage	gauge	77.750000	{}	2025-09-03 16:55:58.355+00
ed71f53b-e8db-4594-a221-97862189597c	memory_usage	gauge	77.660000	{}	2025-09-03 16:56:58.355+00
4e03288c-cfd4-49b9-a175-b39393efefec	memory_usage	gauge	77.410000	{}	2025-09-03 16:57:58.356+00
1f16219f-149d-438a-958f-d7dda5f0afbf	disk_usage	gauge	45.200000	{}	2025-09-04 15:00:46.367+00
0325eefc-d998-4e68-94d3-3cf01133c404	cpu_usage	gauge	5.000000	{}	2025-09-04 15:01:46.37+00
f1d59171-a052-4469-991f-69aa66d5b2c3	cpu_usage	gauge	5.000000	{}	2025-09-04 15:02:46.369+00
5d4f6b12-8dc8-4108-b246-0776b5fe7448	uptime	gauge	4869.417580	{}	2025-09-04 15:03:46.371+00
a82984b5-6605-4fbd-836e-673a6bc833e9	memory_usage	gauge	79.150000	{}	2025-09-04 15:04:46.371+00
bcf1a3cd-4cca-4d88-bf5c-2124913c673c	memory_usage	gauge	79.420000	{}	2025-09-04 15:05:46.372+00
3dd1b904-927b-4519-a3e7-7632847af40c	memory_usage	gauge	79.270000	{}	2025-09-04 15:06:46.372+00
49bddeea-0dc5-4717-b497-82c666eb4dc5	cpu_usage	gauge	5.000000	{}	2025-09-04 15:07:46.371+00
79cc641f-0413-4849-a5d1-f2b8c331e519	uptime	gauge	5169.419682	{}	2025-09-04 15:08:46.373+00
4ec7fbd7-a648-467f-895b-c9919bdf6a93	cpu_usage	gauge	5.000000	{}	2025-09-04 15:09:46.373+00
0c1a1d06-9f74-4d6b-96bc-f9288685d1a3	uptime	gauge	5289.420777	{}	2025-09-04 15:10:46.374+00
3a2dcb30-311f-42fb-b146-be18c4a23524	disk_usage	gauge	45.200000	{}	2025-09-04 15:11:46.374+00
bd62fd7a-9e23-4882-a255-6a795972c010	memory_usage	gauge	77.530000	{}	2025-09-04 15:12:46.375+00
03f11bde-d5f7-4ef8-94bb-af1815627187	disk_usage	gauge	45.200000	{}	2025-09-04 15:13:46.377+00
f3279c5f-00fd-4840-9f44-6fc55b3e063c	cpu_usage	gauge	5.000000	{}	2025-09-04 19:12:34.747+00
befc88cc-ec23-49f5-98fe-2b2859b0d0a8	disk_usage	gauge	45.200000	{}	2025-09-04 19:12:34.748+00
57a94809-32c6-42d3-a322-ae81e16973a6	disk_usage	gauge	45.200000	{}	2025-09-03 16:50:58.352+00
2bf194e7-76cd-46fc-a691-498931d6d6d3	memory_usage	gauge	76.510000	{}	2025-09-03 16:51:58.353+00
50a4c9e5-7af4-4249-b1c4-0e10bc4ba707	uptime	gauge	1208.113528	{}	2025-09-03 16:52:58.354+00
9b09020c-c369-4ecd-aa69-60f9f67a7f77	cpu_usage	gauge	6.000000	{}	2025-09-03 16:53:58.354+00
77f2a215-bcdc-46d0-b4c9-a115788e72f0	uptime	gauge	1328.114132	{}	2025-09-03 16:54:58.354+00
8a5b5b54-db6b-4a81-b3e8-2eec3f18c9c3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:55:58.354+00
ae4c1a07-7b87-43ac-aed0-2e8e9c01af12	uptime	gauge	1448.114582	{}	2025-09-03 16:56:58.355+00
90e1245b-8dda-4c99-87b6-46f3fc0b46c2	cpu_usage	gauge	6.000000	{}	2025-09-03 16:57:58.356+00
e80181a8-bbdc-41f6-999f-f347cedce900	memory_usage	gauge	79.470000	{}	2025-09-04 15:00:46.367+00
b449550f-2eb0-4318-9559-f1434668e8f6	memory_usage	gauge	79.590000	{}	2025-09-04 15:01:46.37+00
798008cb-6883-4e0d-8ae9-a8e54a255bdc	uptime	gauge	4809.416221	{}	2025-09-04 15:02:46.369+00
91aa5c5e-ee5a-47be-a8aa-c5373e844ec1	disk_usage	gauge	45.200000	{}	2025-09-04 15:03:46.371+00
d53086af-360d-44b1-9a80-73e90bf4c30c	disk_usage	gauge	45.200000	{}	2025-09-04 15:04:46.371+00
6d1dc8ac-b7e9-495a-bdcc-d47200ef8747	cpu_usage	gauge	5.000000	{}	2025-09-04 15:05:46.372+00
daa06708-2d7e-4b95-96fd-f0e7dcb568ae	uptime	gauge	5049.419298	{}	2025-09-04 15:06:46.372+00
06d33ca3-c746-4caa-bcd4-03fd28c721ef	memory_usage	gauge	79.460000	{}	2025-09-04 15:07:46.371+00
2c9a3ff3-c58f-466d-b866-f86098412f1f	disk_usage	gauge	45.200000	{}	2025-09-04 15:08:46.373+00
300957e5-7e4b-43b0-bb57-41875885b138	memory_usage	gauge	79.470000	{}	2025-09-04 15:09:46.373+00
383f036c-a905-467e-b9e5-030c15a9a7dd	cpu_usage	gauge	5.000000	{}	2025-09-04 15:10:46.374+00
e69ff56d-f353-4f0c-b159-ac290e040351	cpu_usage	gauge	5.000000	{}	2025-09-04 15:11:46.374+00
f335a77b-7675-4efa-893a-0774f8c14632	uptime	gauge	5409.421764	{}	2025-09-04 15:12:46.375+00
913771f3-609f-4542-8714-ecf72cd6e81b	cpu_usage	gauge	5.000000	{}	2025-09-04 15:13:46.377+00
d541373a-5d90-4390-bf66-ebb2ee186bd9	memory_usage	gauge	76.030000	{}	2025-09-04 19:12:34.747+00
36a36ebb-aae9-4390-9a4e-c8111217ac06	uptime	gauge	69.419017	{}	2025-09-04 19:12:34.748+00
ed01d5ab-a889-41b6-94f1-41970b068823	cpu_usage	gauge	6.000000	{}	2025-09-03 16:58:36.218+00
2875c1da-aa02-49fc-81b0-e041cb12b878	uptime	gauge	1689.466714	{}	2025-09-03 16:59:36.22+00
1d230758-7692-4039-ae50-b1ea5a269269	cpu_usage	gauge	6.000000	{}	2025-09-03 17:00:36.219+00
8109c091-71a4-457e-8559-4819c73bdb14	uptime	gauge	1809.465741	{}	2025-09-03 17:01:36.219+00
f53f34be-6bc6-4ecb-b862-7bce2f975874	disk_usage	gauge	45.200000	{}	2025-09-03 17:02:36.219+00
91d1845a-5fe5-4b5d-bfee-87d9267b3cdc	memory_usage	gauge	77.130000	{}	2025-09-03 17:03:36.22+00
e613a6a4-7482-4074-833c-7020d7dc067c	memory_usage	gauge	76.730000	{}	2025-09-03 17:04:36.22+00
71cd9b27-3d96-4018-a5f5-a156ae03fb86	cpu_usage	gauge	6.000000	{}	2025-09-03 17:05:36.221+00
d25d4831-5e09-4169-b488-746399a097f7	uptime	gauge	2109.467788	{}	2025-09-03 17:06:36.221+00
3371205f-c7b5-4d6c-b1e3-d79c1695d750	cpu_usage	gauge	6.000000	{}	2025-09-03 17:49:13.549+00
45f56c25-749c-4c3d-91ec-5c0822f51f62	memory_usage	gauge	74.380000	{}	2025-09-03 17:49:13.549+00
eefea8a0-a3e6-4725-8eb0-164000123a83	disk_usage	gauge	45.200000	{}	2025-09-03 17:49:13.549+00
1700a00c-3d54-42ce-b8ce-9ff3bcb1e395	uptime	gauge	69.351909	{}	2025-09-03 17:49:13.549+00
05bed622-ca87-486a-8ce3-d8920ba57c8c	uptime	gauge	129.352361	{}	2025-09-03 17:50:13.55+00
2ed66c06-c2d1-40f0-a757-a976ef764c06	uptime	gauge	189.353844	{}	2025-09-03 17:51:13.551+00
d8af877f-dd9b-4a60-9654-16495a995c44	disk_usage	gauge	45.200000	{}	2025-09-03 17:52:13.55+00
37648ab8-e0cb-4f9d-8928-649b70e9806f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:53:13.555+00
adc6e688-a32b-45a7-ae8b-cbb7687d037b	cpu_usage	gauge	6.000000	{}	2025-09-03 18:25:38.088+00
91704d68-4297-45b3-be58-e6d6646f1027	memory_usage	gauge	69.490000	{}	2025-09-03 18:25:38.089+00
9c63ec59-9bed-4261-a54d-c3253eb117b7	disk_usage	gauge	45.200000	{}	2025-09-03 18:25:38.089+00
8e1dc14b-d12f-4f03-a4bc-dc1c51fd730e	uptime	gauge	69.232184	{}	2025-09-03 18:25:38.089+00
b0a363d2-b265-46df-868b-a4ed489d7358	uptime	gauge	129.231973	{}	2025-09-03 18:26:38.088+00
50e31809-7d08-4931-aa19-18745ca09d2d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:27:38.089+00
63f0832c-730a-4c0b-80f6-d125dda49223	uptime	gauge	249.234122	{}	2025-09-03 18:28:38.091+00
52621e95-2cfc-4d17-85fc-43a843773565	cpu_usage	gauge	6.000000	{}	2025-09-03 18:29:38.096+00
e3f55673-1768-4898-adc5-38717a4c8bd7	uptime	gauge	369.239983	{}	2025-09-03 18:30:38.096+00
9c0cad8c-5136-49e6-872c-9847e5c4a24f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:34:38.098+00
0b7b76b9-23ca-461d-9d2d-22e786f5e95a	memory_usage	gauge	64.770000	{}	2025-09-03 18:34:38.098+00
44a79de9-55e6-4b1d-9cd0-521a44a5ef44	disk_usage	gauge	45.200000	{}	2025-09-03 18:34:38.098+00
4f5a04bc-6db1-4bf0-a62d-3fd62ec86fa4	uptime	gauge	609.241256	{}	2025-09-03 18:34:38.098+00
228492a9-36c6-4b3e-8019-c5215cebcf93	uptime	gauge	669.243544	{}	2025-09-03 18:35:38.1+00
4abca9a5-b301-41f8-8cdb-a4b99554ddc6	cpu_usage	gauge	6.000000	{}	2025-09-03 18:46:36.591+00
dbf8a728-a41b-475e-a9c2-8fe296f98fab	memory_usage	gauge	69.510000	{}	2025-09-03 18:46:36.591+00
fed8bfdd-4d42-4b15-b5b4-49043d47966b	disk_usage	gauge	45.200000	{}	2025-09-03 18:46:36.591+00
32cd1a40-1a36-4b5d-aac0-a14a0f12d001	uptime	gauge	68.948844	{}	2025-09-03 18:46:36.591+00
19624da4-9cb5-40ef-ba5a-5e0446786399	cpu_usage	gauge	6.000000	{}	2025-09-03 18:49:04.666+00
c097a3bd-3c6f-4c87-a5dd-f3e613772222	memory_usage	gauge	64.330000	{}	2025-09-03 18:49:04.666+00
a8913fe1-69c0-41eb-8802-b19dacd67c29	disk_usage	gauge	45.200000	{}	2025-09-03 18:49:04.666+00
4e567f05-9134-463b-879b-2c3f3c160e43	uptime	gauge	69.196963	{}	2025-09-03 18:49:04.667+00
39c5c6fa-6011-4157-8068-dffc260e092a	uptime	gauge	129.196145	{}	2025-09-03 18:50:04.666+00
8616dd93-0945-4ee0-8296-18a7d1b8b123	uptime	gauge	189.195945	{}	2025-09-03 18:51:04.665+00
b37fdd36-e97a-41f5-a63a-527a61980b11	disk_usage	gauge	45.200000	{}	2025-09-03 18:52:04.667+00
a0673e67-9c5a-4b61-a53d-9efbf1af7c23	cpu_usage	gauge	6.000000	{}	2025-09-03 18:53:04.667+00
0e5bd295-a99c-43bf-a05a-4fb700d5fbe4	uptime	gauge	369.197139	{}	2025-09-03 18:54:04.667+00
c173b9f8-a69c-4b7d-8ba7-d1f0929af960	cpu_usage	gauge	6.000000	{}	2025-09-03 18:59:30.075+00
e2205e8c-4b02-42c9-8ee0-f236a6fe59d9	memory_usage	gauge	67.880000	{}	2025-09-03 18:59:30.075+00
4bb0d98e-8afe-440c-923a-74f9afcb1651	disk_usage	gauge	45.200000	{}	2025-09-03 18:59:30.075+00
534c6be9-6510-44fd-8ae8-fdcce78f4339	uptime	gauge	69.074141	{}	2025-09-03 18:59:30.075+00
df79894b-a5c9-421a-94e8-5ccf3f144af0	cpu_usage	gauge	6.000000	{}	2025-09-03 19:18:37.465+00
32047568-e95e-4026-858a-089ae2755d05	memory_usage	gauge	67.530000	{}	2025-09-03 19:18:37.466+00
93a2c134-9795-45a2-a5e3-b6394f632781	disk_usage	gauge	45.200000	{}	2025-09-03 19:18:37.466+00
ad126027-4c63-4d8a-82bb-0080f1bfad45	uptime	gauge	69.040327	{}	2025-09-03 19:18:37.466+00
f187d352-744e-4d28-b7e6-513dcd2acd8c	uptime	gauge	129.040185	{}	2025-09-03 19:19:37.466+00
2e8c7663-5211-4199-8467-5d0b52750e04	disk_usage	gauge	45.200000	{}	2025-09-03 19:20:37.467+00
f4760940-a5c1-44b3-8817-2ce5b81bd0d2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:21:37.468+00
4db25c5d-eebd-4044-a185-9e89dce702ec	uptime	gauge	309.047343	{}	2025-09-03 19:22:37.473+00
cbb29218-1ef4-4e9d-9869-67c6b1850c0f	memory_usage	gauge	68.140000	{}	2025-09-03 19:23:37.473+00
9c21b4f3-0e46-419b-aaf8-d1c21391d1f4	uptime	gauge	429.048043	{}	2025-09-03 19:24:37.474+00
6882f55b-9cb9-43a3-8977-56dd4fbffd08	disk_usage	gauge	45.200000	{}	2025-09-03 19:25:37.474+00
3c6f737a-639f-4225-8a6e-5d5906193cc6	memory_usage	gauge	68.290000	{}	2025-09-03 19:26:37.473+00
211efd3e-8cda-45d7-b9a5-84f4672c0cdf	memory_usage	gauge	68.170000	{}	2025-09-03 19:27:37.475+00
b63dd5e9-22e1-461f-a88d-427f9ba0a2cf	memory_usage	gauge	68.160000	{}	2025-09-03 19:28:37.476+00
227d44b2-4c78-4d38-a07f-5eb4bb494cc0	uptime	gauge	68.968708	{}	2025-09-03 19:32:52.834+00
731f12d2-58f2-48dd-81bf-7a28b6e990d3	disk_usage	gauge	45.200000	{}	2025-09-03 19:33:52.834+00
ac31a206-6746-4893-9f24-49faa0658446	memory_usage	gauge	67.860000	{}	2025-09-03 19:34:52.834+00
21827b26-24ce-43b7-a31b-57e287bfbf5e	disk_usage	gauge	45.200000	{}	2025-09-03 19:35:52.834+00
1c50cb2f-b6ea-422b-9b30-058793ab8417	cpu_usage	gauge	6.000000	{}	2025-09-03 19:36:52.84+00
764ca5a8-3e87-4691-9940-a3c93ae031cb	uptime	gauge	368.975498	{}	2025-09-03 19:37:52.841+00
5b127ef0-9711-4ee9-8d90-72ad53702d78	cpu_usage	gauge	6.000000	{}	2025-09-03 19:38:52.841+00
3ee3fff0-3098-4001-b34d-ad4c4a7d9073	uptime	gauge	488.976124	{}	2025-09-03 19:39:52.841+00
9118064a-8705-4f48-aaa1-5c6799a7fd63	disk_usage	gauge	45.200000	{}	2025-09-03 19:40:52.841+00
f61bf6b5-6ce1-4d04-83dd-3e72efa0ca7f	disk_usage	gauge	45.200000	{}	2025-09-03 19:41:52.841+00
2ea82cac-b5d4-405f-b5bc-74e2ce475ee9	disk_usage	gauge	45.200000	{}	2025-09-03 19:42:52.84+00
2b14a6ab-ba85-4885-9ef8-7126a87d2b93	uptime	gauge	728.975737	{}	2025-09-03 19:43:52.841+00
6d5c7e2c-2c2b-4225-8a55-6c375aa81c48	memory_usage	gauge	68.320000	{}	2025-09-03 19:44:52.84+00
71f4b035-cb25-4ea9-9c17-30480036f3fb	uptime	gauge	848.975548	{}	2025-09-03 19:45:52.841+00
73c76503-5324-435e-ada2-10640ddf67b2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:46:52.84+00
6e9bef52-9be3-4661-b583-e9283f3c2ce4	uptime	gauge	968.976505	{}	2025-09-03 19:47:52.842+00
bdca1e69-4c70-4b47-8a1b-717cd99feeaf	cpu_usage	gauge	6.000000	{}	2025-09-03 19:48:52.841+00
cf7a49e4-e90e-4db9-af70-c72ed7c77eec	disk_usage	gauge	45.200000	{}	2025-09-03 19:49:52.842+00
e95ba39b-1e16-4668-a3cd-f0f4bf22013e	memory_usage	gauge	68.440000	{}	2025-09-03 19:50:52.842+00
be861ea9-d8cc-4fbb-bacf-247a65323a9a	cpu_usage	gauge	6.000000	{}	2025-09-03 19:51:52.842+00
3b4761b3-8297-4ff1-9b29-96a698f5a715	uptime	gauge	1268.977048	{}	2025-09-03 19:52:52.842+00
dbb4d9cf-6533-4fea-bba9-db7604d55090	disk_usage	gauge	45.200000	{}	2025-09-03 19:53:52.842+00
c6ff69fe-9cd9-455f-8c8a-af4cf3b00516	cpu_usage	gauge	6.000000	{}	2025-09-03 22:10:05.396+00
15dfcd0b-17d1-4c41-b381-3c3ad19b19bc	uptime	gauge	69.328221	{}	2025-09-03 22:10:05.396+00
f1b8be26-b8d6-4f26-be7e-d4687a8ea3f2	disk_usage	gauge	45.200000	{}	2025-09-03 22:11:05.397+00
89a1a9d4-a412-4253-97e3-dbd75cabe69e	uptime	gauge	189.329793	{}	2025-09-03 22:12:05.398+00
0411d0eb-bbb1-40f3-a282-9feb05f38bec	disk_usage	gauge	45.200000	{}	2025-09-03 22:13:05.398+00
56e1c25a-c15e-409f-b393-ad6b08b1b95c	memory_usage	gauge	72.340000	{}	2025-09-03 22:14:05.403+00
bf65f882-42aa-4a6f-b9af-73e68aa4d26e	cpu_usage	gauge	6.000000	{}	2025-09-03 22:16:12.169+00
e4744be0-8026-42a2-a59c-9106a2aaa1a4	memory_usage	gauge	74.650000	{}	2025-09-03 22:16:12.169+00
e5f647b6-1170-4775-8334-cde7e6c20b85	disk_usage	gauge	45.200000	{}	2025-09-03 22:16:12.169+00
500042a8-f970-493c-a7e7-8050a3bd5485	uptime	gauge	69.165921	{}	2025-09-03 22:16:12.169+00
a1880f20-0073-4120-a650-9bc9da3474d2	uptime	gauge	129.165722	{}	2025-09-03 22:17:12.169+00
f1c77bf6-bd16-403d-9a5b-36db4db1b08a	uptime	gauge	189.166052	{}	2025-09-03 22:18:12.169+00
a3b1a000-1d22-490b-83f2-a164b2f8fde0	disk_usage	gauge	45.200000	{}	2025-09-03 22:19:12.171+00
162a8336-ba7e-4b6c-998a-f8a9ba17bf6b	disk_usage	gauge	45.200000	{}	2025-09-03 16:58:36.218+00
12a4a02e-da43-46f9-aa27-fa7872c6ab19	disk_usage	gauge	45.200000	{}	2025-09-03 16:59:36.22+00
baea5735-735e-43e1-8e6f-8468b8a710d9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:49:27.515+00
f399410a-2ee3-4477-80db-66e59c228057	memory_usage	gauge	74.350000	{}	2025-09-03 17:49:27.515+00
40985f3f-1879-4a96-8216-355e9fce3e39	disk_usage	gauge	45.200000	{}	2025-09-03 17:49:27.515+00
b409d95f-4967-45ff-8758-402d95ca6ac4	memory_usage	gauge	74.980000	{}	2025-09-03 17:50:27.515+00
551762e7-85a6-4a67-898b-2892c3013b99	cpu_usage	gauge	6.000000	{}	2025-09-03 17:51:27.516+00
a6a84e9e-af5b-4ca4-9bee-87416df919c5	uptime	gauge	248.008572	{}	2025-09-03 17:52:27.517+00
ac7d293f-d2ed-442f-b602-e2edd9b02090	cpu_usage	gauge	6.000000	{}	2025-09-03 17:53:27.524+00
805d2158-6f59-4674-ad28-8cb6be55f15f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:26:38.088+00
0cd936e6-f756-4f7a-b48a-63f386ef78d4	uptime	gauge	189.232937	{}	2025-09-03 18:27:38.089+00
89c0b5a3-e12d-4f92-beb1-10415134671e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:28:38.091+00
760449ca-1102-488c-8ae5-1c1ce8e80453	uptime	gauge	309.239843	{}	2025-09-03 18:29:38.096+00
dcb80716-27da-4b25-8119-f48778a4b929	disk_usage	gauge	45.200000	{}	2025-09-03 18:30:38.096+00
f58ead89-ea45-47ae-ada1-2e33960fb97f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:35:38.1+00
88988fbf-a1c3-434c-bb06-5514905e744a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:50:04.666+00
8cfe7c57-cfa5-4981-b8e5-1c5c5e246755	cpu_usage	gauge	6.000000	{}	2025-09-03 18:51:04.665+00
19070a34-3048-47f7-bf17-ec0691a68417	uptime	gauge	249.197199	{}	2025-09-03 18:52:04.667+00
91283943-1552-4d08-afe3-9f077c69a0fd	disk_usage	gauge	45.200000	{}	2025-09-03 18:53:04.667+00
9e683998-9f2f-48b0-b7d7-d015da48d27d	memory_usage	gauge	64.730000	{}	2025-09-03 18:54:04.667+00
0a7564c0-24be-4f73-930e-be42316d2767	cpu_usage	gauge	6.000000	{}	2025-09-03 19:00:30.074+00
14959e0c-2574-4ac3-a2a0-016453c587c5	uptime	gauge	189.074307	{}	2025-09-03 19:01:30.075+00
e7e95855-d772-4024-9415-db0b1278b0b6	cpu_usage	gauge	6.000000	{}	2025-09-03 19:02:30.076+00
d8e8cf5c-1b86-46a9-9983-2c9071aa31a0	uptime	gauge	309.074804	{}	2025-09-03 19:03:30.076+00
e9e5ba61-9ee2-468a-a724-8615601971af	disk_usage	gauge	45.200000	{}	2025-09-03 19:04:30.075+00
dd9e6d01-1317-4492-8032-28eb3c16b1f4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:05:30.076+00
1654998b-77ba-46bc-b3d3-4e814b415325	uptime	gauge	489.075076	{}	2025-09-03 19:06:30.076+00
cc095702-81f3-4390-a463-25bd008c07c1	cpu_usage	gauge	6.000000	{}	2025-09-03 19:19:37.465+00
40d6a792-76fd-4fe2-a51c-748bbe08fbf2	uptime	gauge	189.041228	{}	2025-09-03 19:20:37.467+00
77c0208c-7cf0-47b5-a532-41bee9601c23	disk_usage	gauge	45.200000	{}	2025-09-03 19:21:37.468+00
18a79157-ef39-4207-9a21-1bcca66f0568	disk_usage	gauge	45.200000	{}	2025-09-03 19:22:37.473+00
bbcd9a98-e319-4dfc-b47f-1302adc2d0c0	disk_usage	gauge	45.200000	{}	2025-09-03 19:32:52.834+00
45facab1-f731-43f5-bcf7-11a82098973b	uptime	gauge	128.968605	{}	2025-09-03 19:33:52.834+00
a7f2c7ca-eba0-4cc3-9c93-4762debd128e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:34:52.834+00
13177cc4-cae7-4f22-9be2-d9807f4b4ede	uptime	gauge	248.968926	{}	2025-09-03 19:35:52.834+00
8032a1b7-7b1f-4390-8c9e-1eb5da5ec122	memory_usage	gauge	68.270000	{}	2025-09-03 19:36:52.84+00
edce9231-35b0-4496-84c2-576124bd4cd3	memory_usage	gauge	68.190000	{}	2025-09-03 19:37:52.841+00
0f6ff111-041f-4990-b0a2-bf6f1cbd57b5	disk_usage	gauge	45.200000	{}	2025-09-03 19:38:52.841+00
38e2b864-89c8-495c-ac99-578a63507be2	disk_usage	gauge	45.200000	{}	2025-09-03 19:39:52.841+00
2b8db020-a9c5-4bb7-86d9-04e34b06410b	cpu_usage	gauge	6.000000	{}	2025-09-03 19:40:52.841+00
5792c382-01f0-48f5-91b1-3db84ee6e134	uptime	gauge	608.976130	{}	2025-09-03 19:41:52.841+00
da4bbd0d-b3d9-4805-928b-4945874ebe63	uptime	gauge	668.975303	{}	2025-09-03 19:42:52.84+00
2198561d-a596-478b-9ce0-57f7a809508a	disk_usage	gauge	45.200000	{}	2025-09-03 19:43:52.841+00
ececb330-e955-413a-aa57-a69695718bf5	cpu_usage	gauge	6.000000	{}	2025-09-03 19:44:52.84+00
18271016-3faa-4219-915f-0d2cbba5cdd5	disk_usage	gauge	45.200000	{}	2025-09-03 19:45:52.841+00
7684670d-3713-4642-bc12-b1aaefcfbb32	disk_usage	gauge	45.200000	{}	2025-09-03 19:46:52.84+00
29bf35d3-e770-4cbe-982b-9a83cccf2586	cpu_usage	gauge	6.000000	{}	2025-09-03 19:47:52.841+00
5b2fa2a3-dda7-4b9c-bb1c-2201ad88a620	uptime	gauge	1028.975739	{}	2025-09-03 19:48:52.841+00
4ff8caa0-0330-4c39-9f97-ca7726a5f572	memory_usage	gauge	68.260000	{}	2025-09-03 19:49:52.842+00
db3a169e-2e55-497c-83db-b65768bf39ee	cpu_usage	gauge	6.000000	{}	2025-09-03 19:50:52.842+00
b09744c9-f438-4cc1-a62e-23f60542540d	uptime	gauge	1208.977123	{}	2025-09-03 19:51:52.842+00
202d8c59-b317-4d26-a9d1-fe508d158507	disk_usage	gauge	45.200000	{}	2025-09-03 19:52:52.842+00
bb3ff4be-2e0c-477e-b08a-06d2eea46755	cpu_usage	gauge	6.000000	{}	2025-09-03 19:53:52.842+00
90a21f87-858b-4ae7-ab82-43f2958ae4e4	memory_usage	gauge	72.030000	{}	2025-09-03 22:10:05.396+00
e6e264c2-7975-4cf4-90bc-91f5c8208aa5	disk_usage	gauge	45.200000	{}	2025-09-03 22:10:05.396+00
eefb33fe-f144-4190-abdb-2cfc4fe21f74	uptime	gauge	129.328964	{}	2025-09-03 22:11:05.397+00
f06d0938-9391-4226-a8fb-7778100f3754	memory_usage	gauge	72.380000	{}	2025-09-03 22:12:05.398+00
ed500ca6-7a39-4dbe-99f7-ba7c979a44e8	memory_usage	gauge	72.420000	{}	2025-09-03 22:13:05.398+00
895c8737-5df7-42a9-9832-934084a689b6	uptime	gauge	309.335464	{}	2025-09-03 22:14:05.403+00
2cbbc202-7c5e-4189-b6c2-3ee29857e1c8	cpu_usage	gauge	6.000000	{}	2025-09-03 22:17:12.169+00
cce72b6c-5504-4d07-934f-b5443919ea18	cpu_usage	gauge	6.000000	{}	2025-09-03 22:18:12.169+00
bf8ee21e-4ff5-4a11-aa54-c922c0f81417	uptime	gauge	249.167799	{}	2025-09-03 22:19:12.171+00
18a4372a-3439-4232-a207-c7f848642277	disk_usage	gauge	45.200000	{}	2025-09-03 22:20:12.176+00
86c0b898-d0d7-4ee0-a53a-8d8c36a79e67	cpu_usage	gauge	6.000000	{}	2025-09-03 22:21:12.176+00
558f4f58-c990-4215-88c9-face3862f098	uptime	gauge	429.172796	{}	2025-09-03 22:22:12.176+00
4736fa40-5b9f-4e5d-99d2-b6244192a2c1	memory_usage	gauge	73.360000	{}	2025-09-03 22:23:12.177+00
b9f998ce-2e84-48f7-9c89-b7b873fcacb5	disk_usage	gauge	45.200000	{}	2025-09-03 22:24:12.177+00
9700b91d-3c4a-4504-9459-04e5e2c4953b	cpu_usage	gauge	6.000000	{}	2025-09-03 22:25:12.177+00
115d6df7-3d51-455a-85fc-7c14cfc0eefb	uptime	gauge	669.174081	{}	2025-09-03 22:26:12.177+00
23bcbb5f-6697-4f1b-b8b6-576ac0ece6ed	memory_usage	gauge	73.590000	{}	2025-09-03 22:27:12.178+00
4c544127-0771-43c8-9bf1-d4d7bca2d179	cpu_usage	gauge	6.000000	{}	2025-09-03 22:28:12.179+00
4dd46083-8fb3-4202-91cf-819015fafedd	cpu_usage	gauge	5.000000	{}	2025-09-04 15:14:46.378+00
a65f50ed-cc2d-48d1-80a7-d384223a68d8	uptime	gauge	5589.425466	{}	2025-09-04 15:15:46.378+00
3a88ade7-60f7-4a4a-80e6-a7b6da0b0cb3	disk_usage	gauge	45.200000	{}	2025-09-04 15:16:46.378+00
7114b5ea-bdde-40e2-91bb-66a6fb0cffd6	cpu_usage	gauge	5.000000	{}	2025-09-04 15:17:46.378+00
8d8ce1bb-172d-4b66-be1b-481e6869f221	uptime	gauge	5769.426361	{}	2025-09-04 15:18:46.379+00
7c3ae950-ee1e-4574-8e04-eaf9713ee719	disk_usage	gauge	45.200000	{}	2025-09-04 15:19:46.379+00
a7600efc-ed9b-4b81-bcfd-e60d5c06afbb	cpu_usage	gauge	5.000000	{}	2025-09-04 15:20:46.379+00
e91b4ff9-8a45-4523-aa4e-7afe3d889d9d	uptime	gauge	5949.427224	{}	2025-09-04 15:21:46.38+00
75ecadc7-ee8e-4e47-80e2-270e229c0f02	disk_usage	gauge	45.200000	{}	2025-09-04 15:22:46.382+00
46aa5da3-5084-4768-9710-3d62d54cc434	cpu_usage	gauge	5.000000	{}	2025-09-04 15:23:46.382+00
13fb5f47-24c0-4404-9ff0-2a0f2bb1b8e0	disk_usage	gauge	45.200000	{}	2025-09-04 15:24:46.382+00
27604f90-6639-49ee-8b74-f0e084ea9576	cpu_usage	gauge	5.000000	{}	2025-09-04 19:13:59.376+00
d1793d45-4264-4d27-bb0a-a0a16b427b20	disk_usage	gauge	45.200000	{}	2025-09-04 19:13:59.376+00
739e7618-42f3-453e-a187-35e18acf95fe	uptime	gauge	129.330374	{}	2025-09-04 19:14:59.377+00
f59a7276-f30c-4642-b58a-3d7938f6d98c	memory_usage	gauge	76.110000	{}	2025-09-04 19:15:59.377+00
b6af4982-305e-4576-93a7-ab03a8757ff1	cpu_usage	gauge	5.000000	{}	2025-09-04 19:16:59.378+00
439f3083-b641-4e87-a0a0-b5065f9c5bf2	memory_usage	gauge	77.580000	{}	2025-09-03 16:58:36.218+00
8ecb4883-a8fe-442c-a0d8-b2a07ea834ff	memory_usage	gauge	77.730000	{}	2025-09-03 16:59:36.22+00
a3f17fe1-dbb4-4f13-978d-e4114c3ce481	disk_usage	gauge	45.200000	{}	2025-09-03 17:00:36.219+00
45ac46ad-29be-4c75-8a4d-74ba339b005f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:01:36.219+00
6a1d6916-0bb5-4b07-baac-a599679fb84c	uptime	gauge	1869.466244	{}	2025-09-03 17:02:36.219+00
bbe61130-6afb-47d6-b10e-02c64df7313e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:03:36.22+00
2675a6a9-232b-4c26-81c6-f8361ba6f41c	uptime	gauge	1989.467490	{}	2025-09-03 17:04:36.22+00
cdcbdc96-208c-4ffa-b9ba-80e20085a2c1	disk_usage	gauge	45.200000	{}	2025-09-03 17:05:36.221+00
ac414b67-ed77-4266-9f24-6519e86b7853	disk_usage	gauge	45.200000	{}	2025-09-03 17:06:36.221+00
f3824755-58a4-4161-b6ca-c608acb75275	uptime	gauge	68.007429	{}	2025-09-03 17:49:27.515+00
77d96717-83af-442d-83f2-4b262bb313b0	cpu_usage	gauge	6.000000	{}	2025-09-03 17:50:27.515+00
3ff221c7-8d31-49ea-a606-ab0d242d123d	uptime	gauge	188.008019	{}	2025-09-03 17:51:27.516+00
b7b9d5b5-eff4-4d78-a8b8-cd00f8a9a27e	disk_usage	gauge	45.200000	{}	2025-09-03 17:52:27.517+00
98849cb2-b66b-48c9-9784-e7dad72363af	memory_usage	gauge	75.230000	{}	2025-09-03 17:53:27.524+00
3178b127-82b7-4f67-9cfa-eb679b46680d	memory_usage	gauge	74.920000	{}	2025-09-03 18:26:38.088+00
293ee845-fb5e-48c6-9d32-95609eec0781	disk_usage	gauge	45.200000	{}	2025-09-03 18:27:38.089+00
e448ba2c-4cb2-4003-9d05-a2e34436db10	disk_usage	gauge	45.200000	{}	2025-09-03 18:28:38.091+00
2d74987b-0c33-4720-b19a-269d9678875c	disk_usage	gauge	45.200000	{}	2025-09-03 18:29:38.096+00
61825128-71ad-4e91-912a-3041b3d3de0e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:30:38.096+00
c2af9ddc-3516-49b7-99fe-48c155238e9a	memory_usage	gauge	70.470000	{}	2025-09-03 18:35:38.1+00
63bba86d-6df4-4807-ba75-ed23cd574cab	memory_usage	gauge	64.540000	{}	2025-09-03 18:50:04.666+00
a8f7e67e-5af1-4db8-96b2-e56ff61d49b8	memory_usage	gauge	64.810000	{}	2025-09-03 18:51:04.665+00
49aa1b8a-35c1-4aab-bbb0-caf0de611ada	memory_usage	gauge	65.030000	{}	2025-09-03 18:52:04.667+00
9f41496f-9f98-4cf1-85eb-b92984582bc2	memory_usage	gauge	65.010000	{}	2025-09-03 18:53:04.667+00
48d9391d-1936-42e6-b451-0337c4558df2	cpu_usage	gauge	6.000000	{}	2025-09-03 18:54:04.667+00
bceab078-eeb9-418e-ae26-d94e4072a710	memory_usage	gauge	68.740000	{}	2025-09-03 19:00:30.074+00
97c55e44-7f8c-438c-aedb-d57589e81dfc	memory_usage	gauge	68.690000	{}	2025-09-03 19:01:30.075+00
8a68a564-e1e4-4b65-a679-94580af4e7d7	disk_usage	gauge	45.200000	{}	2025-09-03 19:02:30.076+00
747cc2e6-5449-4835-926a-f0b3a8cb86f7	disk_usage	gauge	45.200000	{}	2025-09-03 19:03:30.076+00
59db97e2-bec7-4ae9-bbf2-fc641dd2cab2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:04:30.075+00
90c109c7-bc7b-44e8-af16-09516d9d88b8	uptime	gauge	429.074738	{}	2025-09-03 19:05:30.076+00
420b4357-ae7c-4532-8467-f6067eabc132	cpu_usage	gauge	6.000000	{}	2025-09-03 19:06:30.076+00
0ddf8d9f-d9e7-4fb9-b3b3-37ac6540ca88	memory_usage	gauge	67.520000	{}	2025-09-03 19:19:37.465+00
149e21d2-da52-4da0-831b-38980ef72d8c	memory_usage	gauge	67.830000	{}	2025-09-03 19:20:37.467+00
122b56b1-d3af-4ffa-acc3-f14bccc9dadd	memory_usage	gauge	67.890000	{}	2025-09-03 19:21:37.468+00
eea2c15d-056b-4e88-8e53-0e9526319fe2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:22:37.473+00
510162e3-10c2-4bcb-8267-6d08a13c3a7c	memory_usage	gauge	67.910000	{}	2025-09-03 19:32:52.834+00
c363b213-b103-4095-bb01-3315944802a5	cpu_usage	gauge	6.000000	{}	2025-09-03 19:33:52.834+00
d6cbd1c8-145f-4557-9914-1d18e2e226ba	uptime	gauge	188.968887	{}	2025-09-03 19:34:52.834+00
3569844f-ab7d-4795-9baa-64b39c16fe1f	memory_usage	gauge	68.350000	{}	2025-09-03 19:35:52.834+00
772aff23-16fd-49f3-9f82-3ae4a8b5665d	disk_usage	gauge	45.200000	{}	2025-09-03 19:36:52.84+00
9bc66451-b6ec-43db-951b-8bc11ba5d211	cpu_usage	gauge	6.000000	{}	2025-09-03 19:37:52.84+00
422673b5-8c14-44e6-b764-76cf6572dbe6	uptime	gauge	428.976146	{}	2025-09-03 19:38:52.841+00
ae953613-6018-41bb-8021-064710a405c7	cpu_usage	gauge	6.000000	{}	2025-09-03 19:39:52.841+00
be02cf81-fef6-4f50-905d-e70b590f6100	uptime	gauge	548.976003	{}	2025-09-03 19:40:52.841+00
1e3760d7-73a5-4514-a3f4-a2c3f77617c4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:41:52.841+00
858e41e2-3dad-4734-be6a-e176bbadf199	cpu_usage	gauge	6.000000	{}	2025-09-03 22:11:05.397+00
2a0eb627-81c2-4da2-b868-180e50a1d144	cpu_usage	gauge	6.000000	{}	2025-09-03 22:12:05.398+00
48df7bf5-fd59-438e-9323-da78cf8327aa	uptime	gauge	249.330092	{}	2025-09-03 22:13:05.398+00
a5093a68-b3cd-4539-bc93-4636d7836173	disk_usage	gauge	45.200000	{}	2025-09-03 22:14:05.403+00
c8c4110d-cb61-40fc-8d8d-0336fd81ac3d	memory_usage	gauge	74.740000	{}	2025-09-03 22:17:12.169+00
21f04e19-bf57-46aa-bb69-5c9de4647676	memory_usage	gauge	74.670000	{}	2025-09-03 22:18:12.169+00
e4e85c3f-8ece-4a46-97fd-bbe949e05a72	cpu_usage	gauge	6.000000	{}	2025-09-03 22:19:12.171+00
9c91b0fd-dcba-46df-8881-3fa421a87274	uptime	gauge	309.172874	{}	2025-09-03 22:20:12.176+00
66d2428d-13a7-4707-8502-dc05d1a407a3	memory_usage	gauge	73.890000	{}	2025-09-03 22:21:12.176+00
0e865609-a79e-4c9a-83ee-1c0cbe3eef63	disk_usage	gauge	45.200000	{}	2025-09-03 22:22:12.176+00
c565ac81-0272-4760-97ce-aacb9f7bd213	disk_usage	gauge	45.200000	{}	2025-09-03 22:23:12.177+00
fa7bbce1-66c2-4704-ae50-476696e2a6dd	memory_usage	gauge	73.290000	{}	2025-09-03 22:24:12.177+00
6f1f1e01-da33-4b9e-877e-b5e08e47ef4f	memory_usage	gauge	73.680000	{}	2025-09-03 22:25:12.177+00
94035db9-9a0a-4e00-8ce4-e20126ae3fd7	cpu_usage	gauge	6.000000	{}	2025-09-03 22:26:12.177+00
4a7e1b75-4ab6-40c0-89ea-6d2b515141be	uptime	gauge	729.175029	{}	2025-09-03 22:27:12.178+00
80196bd6-c682-49e6-889b-14c6ae0ca816	disk_usage	gauge	45.200000	{}	2025-09-03 22:28:12.179+00
2d802b11-5622-4c26-904e-d7aeb926e660	memory_usage	gauge	77.660000	{}	2025-09-04 15:14:46.378+00
e8be2411-0f5c-4e42-b57b-759ed6c32d62	cpu_usage	gauge	5.000000	{}	2025-09-04 15:15:46.378+00
595a456f-3b61-4ce3-a016-3b29e877a478	uptime	gauge	5649.425099	{}	2025-09-04 15:16:46.378+00
789d9722-e650-4d09-b65a-a1573cbf90c0	memory_usage	gauge	77.440000	{}	2025-09-04 15:17:46.378+00
1f8289db-1e52-438f-aae5-17074b4f1f96	disk_usage	gauge	45.200000	{}	2025-09-04 15:18:46.379+00
25c2e446-49e1-4a6b-a42f-0f344d3d20d5	cpu_usage	gauge	5.000000	{}	2025-09-04 15:19:46.379+00
1528ebad-a383-4429-9727-e4e6919c8e9a	uptime	gauge	5889.425790	{}	2025-09-04 15:20:46.379+00
28835adb-e08d-4d66-9812-45591af1679c	memory_usage	gauge	80.290000	{}	2025-09-04 15:21:46.38+00
2ddbe69d-b0f5-4638-9a77-c33cd7ea787c	memory_usage	gauge	80.280000	{}	2025-09-04 15:22:46.382+00
b907d263-76bd-4105-a52f-ea5f2836d817	memory_usage	gauge	80.320000	{}	2025-09-04 15:23:46.382+00
0dc023e3-6d45-4e52-9296-16eeca49e9d2	uptime	gauge	6129.428989	{}	2025-09-04 15:24:46.382+00
894eab17-9b1d-4362-8098-7b8d5af3d915	memory_usage	gauge	75.910000	{}	2025-09-04 19:13:59.376+00
edf72f7e-19d0-4b17-b828-ae0383248a14	uptime	gauge	69.329730	{}	2025-09-04 19:13:59.376+00
bb242a34-648f-4305-80a9-660342c90c8c	disk_usage	gauge	45.200000	{}	2025-09-04 19:14:59.376+00
0f7e9ac7-4e4f-4cac-bc78-875567222bc5	uptime	gauge	189.330627	{}	2025-09-04 19:15:59.377+00
506d0776-4ae5-41a6-8af4-6d8b8a9bcd72	memory_usage	gauge	76.170000	{}	2025-09-04 19:16:59.378+00
7b1fbe62-88f2-4d78-842f-0b243c7bdf52	uptime	gauge	1629.465376	{}	2025-09-03 16:58:36.218+00
5bd3af0e-b2d3-435f-844f-65cec0138f70	cpu_usage	gauge	6.000000	{}	2025-09-03 16:59:36.22+00
207ac82f-c59c-479b-ac5d-aa6ae59b5b35	uptime	gauge	1749.466056	{}	2025-09-03 17:00:36.219+00
bc1e715f-20bc-48ce-873b-c9095097b76f	disk_usage	gauge	45.200000	{}	2025-09-03 17:01:36.219+00
fb61be77-8dbd-452c-b9ee-2c782c585fd7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:02:36.219+00
a0f2de85-a417-43d4-84e6-3dfe257fc901	uptime	gauge	1929.466925	{}	2025-09-03 17:03:36.22+00
af67a2cb-e226-4883-a73d-3d11943b839f	disk_usage	gauge	45.200000	{}	2025-09-03 17:04:36.22+00
23a101f4-fe28-4379-b700-4b61acd95d3c	memory_usage	gauge	77.160000	{}	2025-09-03 17:05:36.221+00
15e906d6-275b-4c5b-a3d0-6321e068ded4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:06:36.221+00
b215b67b-3e39-4ccf-826b-04f7fbfafa2c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:50:13.55+00
2536f46a-cc35-484c-aa69-0607fe438371	cpu_usage	gauge	6.000000	{}	2025-09-03 17:51:13.55+00
61f60293-2c24-459d-a1c0-2ca2eb605639	uptime	gauge	249.352346	{}	2025-09-03 17:52:13.55+00
99032f33-6b8a-4516-bb70-b7b71d71c1be	disk_usage	gauge	45.200000	{}	2025-09-03 17:53:13.555+00
bb06498d-accd-4fc4-9276-8e1b39439826	disk_usage	gauge	45.200000	{}	2025-09-03 18:26:38.088+00
22e71650-2fc8-4b76-9457-234d9cd4f89f	memory_usage	gauge	74.930000	{}	2025-09-03 18:27:38.089+00
afcfc18a-bd27-446d-8f95-8844f910180a	memory_usage	gauge	74.870000	{}	2025-09-03 18:28:38.091+00
5e53d09c-1600-4a12-80e2-0bdd8e38d5a1	memory_usage	gauge	74.720000	{}	2025-09-03 18:29:38.096+00
40c224c1-df94-4dd4-adf2-7e452f82f83d	memory_usage	gauge	75.300000	{}	2025-09-03 18:30:38.096+00
84e7722c-e02c-4f35-a91d-8e7dd363c599	disk_usage	gauge	45.200000	{}	2025-09-03 18:35:38.1+00
08f750a2-5b68-4b28-8bca-1d71409b3398	disk_usage	gauge	45.200000	{}	2025-09-03 18:50:04.666+00
096adcb1-a3c5-4786-899a-bdeb9e41af1b	disk_usage	gauge	45.200000	{}	2025-09-03 18:51:04.665+00
05823d57-4cab-41a9-8cc4-fed1921ad000	cpu_usage	gauge	6.000000	{}	2025-09-03 18:52:04.667+00
c95d10f1-9eed-4ae6-9702-d5591b53d012	uptime	gauge	309.197155	{}	2025-09-03 18:53:04.667+00
858bc9b8-725f-46d9-8b64-091c13e11424	disk_usage	gauge	45.200000	{}	2025-09-03 18:54:04.667+00
2c7763da-5bc8-480c-9063-9b8fec7fe6e3	disk_usage	gauge	45.200000	{}	2025-09-03 19:00:30.075+00
f92773be-0881-4300-b37b-2e965b8a5c8d	disk_usage	gauge	45.200000	{}	2025-09-03 19:01:30.075+00
030b2b98-38dc-4289-9bdc-9cde5473b7d1	memory_usage	gauge	68.720000	{}	2025-09-03 19:02:30.076+00
e39ae644-68b7-4805-94f0-f1b124d96ea0	memory_usage	gauge	68.720000	{}	2025-09-03 19:03:30.076+00
3ac9fb19-d4e9-4fa3-9246-1f670745d8ea	memory_usage	gauge	68.460000	{}	2025-09-03 19:04:30.075+00
77e136a7-04ee-42ff-8276-b260b6e76f75	disk_usage	gauge	45.200000	{}	2025-09-03 19:05:30.076+00
c5ac5b53-2775-4e9e-83a8-38012f1ca36b	memory_usage	gauge	68.480000	{}	2025-09-03 19:06:30.076+00
08d6b272-38c4-42a0-8341-1acc3f6259bf	disk_usage	gauge	45.200000	{}	2025-09-03 19:19:37.466+00
ac5bed5c-2f43-4d95-8580-7a1d4483c3cd	cpu_usage	gauge	6.000000	{}	2025-09-03 19:20:37.467+00
f79d526b-8ff2-4102-83dc-7904e004a405	uptime	gauge	249.042096	{}	2025-09-03 19:21:37.468+00
3f38e322-1524-4892-819a-c74c69279cee	memory_usage	gauge	68.150000	{}	2025-09-03 19:22:37.473+00
96510857-6fa0-4c20-a595-9fd14d29c064	cpu_usage	gauge	6.000000	{}	2025-09-03 19:32:52.834+00
db7b975a-f1d3-4da3-9337-266f1b8335f0	memory_usage	gauge	67.890000	{}	2025-09-03 19:33:52.834+00
2827d9da-6a2d-4426-afe6-fd24d9703e7f	disk_usage	gauge	45.200000	{}	2025-09-03 19:34:52.834+00
57655b12-f680-469b-b6ba-b5224a1bcc7e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:35:52.834+00
cf45b048-5cb4-4a42-8b0b-4e6425cf1d56	uptime	gauge	308.974913	{}	2025-09-03 19:36:52.84+00
8bf61177-345d-4c58-9a8b-0963ff03dc8b	disk_usage	gauge	45.200000	{}	2025-09-03 19:37:52.841+00
afefc198-1758-40c4-b31f-de4c9d2da4ef	memory_usage	gauge	68.210000	{}	2025-09-03 19:38:52.841+00
4fa55c3c-5af9-4290-8f12-2812888455f2	memory_usage	gauge	68.130000	{}	2025-09-03 19:39:52.841+00
f0a68461-ae94-4e7f-bf6d-6bce5fb3b379	memory_usage	gauge	68.430000	{}	2025-09-03 19:40:52.841+00
56b14eed-570f-4d99-add7-47bb89482f9f	memory_usage	gauge	68.300000	{}	2025-09-03 19:41:52.841+00
5fbeb48d-d1a7-4cee-81c6-ce12ffbef76d	memory_usage	gauge	72.410000	{}	2025-09-03 22:11:05.397+00
98008b04-3eee-4164-91ab-a287422d91a3	disk_usage	gauge	45.200000	{}	2025-09-03 22:12:05.398+00
48a636d2-7da9-4451-8df3-4729b81f7bb6	cpu_usage	gauge	6.000000	{}	2025-09-03 22:13:05.398+00
d2d3580f-46e5-4d52-937d-e841aeb6a4ac	cpu_usage	gauge	6.000000	{}	2025-09-03 22:14:05.403+00
ed359a43-46db-4b19-a823-e83f4c33c714	disk_usage	gauge	45.200000	{}	2025-09-03 22:17:12.169+00
c361f0bc-2df2-42ab-921c-b34375e0db90	disk_usage	gauge	45.200000	{}	2025-09-03 22:18:12.169+00
2b51235b-463d-48f1-9b35-ed1f490faf3b	memory_usage	gauge	74.760000	{}	2025-09-03 22:19:12.171+00
4a4d54c9-508f-4faa-b2b2-596a6a1fcc56	memory_usage	gauge	73.160000	{}	2025-09-03 22:20:12.176+00
b971f5fd-5466-47e2-b4f6-246d224a764f	disk_usage	gauge	45.200000	{}	2025-09-03 22:21:12.176+00
62825e3d-35d4-4dd2-986f-8fd21494ff36	memory_usage	gauge	73.520000	{}	2025-09-03 22:22:12.176+00
72f13f52-d5bc-4893-bf7e-1c1b1b345e3b	cpu_usage	gauge	6.000000	{}	2025-09-03 22:23:12.177+00
c7bd0c91-c29f-41c8-ac24-4629ad19db96	uptime	gauge	549.174089	{}	2025-09-03 22:24:12.177+00
bcb43373-e743-4de9-acd8-7a6287640714	disk_usage	gauge	45.200000	{}	2025-09-03 22:25:12.177+00
cbd43f76-45e2-4eec-800c-76579e8463d0	disk_usage	gauge	45.200000	{}	2025-09-03 22:26:12.177+00
9a8f078d-56f0-4252-8290-2fbbde2e4711	cpu_usage	gauge	6.000000	{}	2025-09-03 22:27:12.178+00
6cf7593a-491b-4821-abdf-f732799ca4d3	uptime	gauge	789.175931	{}	2025-09-03 22:28:12.179+00
a12ab7d2-5076-4036-872c-120da8f10716	disk_usage	gauge	45.200000	{}	2025-09-04 15:14:46.378+00
17c562ca-6a30-46d7-8095-47e3b947969c	memory_usage	gauge	77.550000	{}	2025-09-04 15:15:46.378+00
c29b4509-e206-4f9e-b196-eebcb141530e	memory_usage	gauge	77.560000	{}	2025-09-04 15:16:46.378+00
2b2dfb9e-e320-43ce-ab65-81ea12a2d2e8	disk_usage	gauge	45.200000	{}	2025-09-04 15:17:46.378+00
f75db2b0-8360-44c7-9a70-0a8012af60d5	cpu_usage	gauge	5.000000	{}	2025-09-04 15:18:46.379+00
680396aa-bbe2-44d8-8bea-3698f3a536f0	memory_usage	gauge	81.110000	{}	2025-09-04 15:19:46.379+00
431032f4-054c-48ed-9e7c-ad75b38cecf2	memory_usage	gauge	80.920000	{}	2025-09-04 15:20:46.379+00
aae2444b-3c89-479b-8327-c5a9ce464996	cpu_usage	gauge	5.000000	{}	2025-09-04 15:21:46.38+00
9145a37c-7545-4730-a92b-972a8108c04c	uptime	gauge	6009.429276	{}	2025-09-04 15:22:46.382+00
c06d47e0-8b85-4297-8d82-427025b4dac1	disk_usage	gauge	45.200000	{}	2025-09-04 15:23:46.382+00
1b348b60-8750-4d2c-9c8b-45304dbf70b8	cpu_usage	gauge	5.000000	{}	2025-09-04 15:24:46.382+00
fd436ba5-ffc7-4189-a44f-c6d80645eff8	cpu_usage	gauge	5.000000	{}	2025-09-04 19:14:59.376+00
c9c2cd61-12a3-41e1-8317-bca118f22f0d	cpu_usage	gauge	5.000000	{}	2025-09-04 19:15:59.377+00
48b0c4d7-4e8b-4afe-aca1-dd0e19c76f9b	uptime	gauge	249.332221	{}	2025-09-04 19:16:59.378+00
152115f4-80f8-4cd9-911d-375138467e7b	memory_usage	gauge	77.560000	{}	2025-09-03 16:58:58.356+00
a62d7691-d332-49d1-9006-1cc557e11e3b	disk_usage	gauge	45.200000	{}	2025-09-03 16:59:58.358+00
bc2d2e45-7c84-45d2-ac21-7910b2e0d98c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:00:58.359+00
63faf7cb-e4ab-4097-86ef-db8a5f5121f2	uptime	gauge	1748.119501	{}	2025-09-03 17:01:58.36+00
bccec84f-896b-4847-8306-497405880f03	disk_usage	gauge	45.200000	{}	2025-09-03 17:02:58.36+00
47916e18-56d2-40bb-b974-a863b8781cb7	memory_usage	gauge	77.120000	{}	2025-09-03 17:03:58.36+00
895118b3-51c8-4f5b-a81f-ef7c0784c537	uptime	gauge	1928.121136	{}	2025-09-03 17:04:58.361+00
0ec7f319-e0d6-4965-8c9d-7d667df21849	cpu_usage	gauge	6.000000	{}	2025-09-03 17:05:58.362+00
ba20a386-0580-4c97-9186-63aa7ba46e1c	memory_usage	gauge	75.120000	{}	2025-09-03 17:50:13.55+00
addd5a0c-ae31-43bf-8d89-209cf5fbc993	memory_usage	gauge	75.460000	{}	2025-09-03 17:51:13.55+00
d41f882e-3ff4-4b4a-ab61-3b4d92884bf7	memory_usage	gauge	75.400000	{}	2025-09-03 17:52:13.55+00
e160e128-2b2c-4112-9ee1-1c0631734fac	memory_usage	gauge	75.510000	{}	2025-09-03 17:53:13.555+00
dad9eca1-d07f-418b-a60d-c5077b1e2741	cpu_usage	gauge	6.000000	{}	2025-09-03 18:26:50.187+00
efb4d334-1d0b-404d-b478-86a8aa654469	memory_usage	gauge	74.850000	{}	2025-09-03 18:26:50.187+00
45bf2e44-07df-4272-9440-6d8a01e70d04	uptime	gauge	68.198442	{}	2025-09-03 18:26:50.187+00
9399d6b0-e5c0-4c24-b144-75bc1776037d	memory_usage	gauge	74.890000	{}	2025-09-03 18:27:50.188+00
6c0aa62c-4b63-4fa8-9ec3-6be1bdbeb121	memory_usage	gauge	74.840000	{}	2025-09-03 18:28:50.188+00
f3d1c175-c18e-4bea-a9db-b09f1d535cea	memory_usage	gauge	75.120000	{}	2025-09-03 18:29:50.188+00
a724e335-3db6-46ae-aa92-98e1c052b7d6	memory_usage	gauge	75.360000	{}	2025-09-03 18:30:50.195+00
fe7291c8-6e35-470c-ac20-46e7526774e7	cpu_usage	gauge	6.000000	{}	2025-09-03 18:36:05.743+00
9bdfde73-d891-4f5a-9d10-a8fddbcfafe3	memory_usage	gauge	70.100000	{}	2025-09-03 18:36:05.743+00
6c31d348-42b7-47f8-b0dc-72cb1e788ff1	cpu_usage	gauge	6.000000	{}	2025-09-03 18:55:56.048+00
ec1b030f-60db-47ac-bc01-86dee0a36ce6	memory_usage	gauge	64.720000	{}	2025-09-03 18:55:56.048+00
b78f907c-9c5d-45ae-b3af-c7fe79bb1405	disk_usage	gauge	45.200000	{}	2025-09-03 18:55:56.048+00
15f0e0b0-4344-4344-b07d-e515c8ba0787	uptime	gauge	68.980998	{}	2025-09-03 18:55:56.048+00
cd138524-98dc-4a07-aae5-d8b8263ad696	uptime	gauge	128.980816	{}	2025-09-03 18:56:56.048+00
83e5f2b2-052d-4546-bed2-68817ab250c2	uptime	gauge	129.073520	{}	2025-09-03 19:00:30.075+00
f393ab40-cdb8-488b-8ee2-c8bfb1d64b6e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:01:30.075+00
e79aecc5-87b1-4a3c-8a4f-48252f52c6eb	uptime	gauge	249.074701	{}	2025-09-03 19:02:30.076+00
c80b4cc1-4891-40ee-92e0-4caaab321216	cpu_usage	gauge	6.000000	{}	2025-09-03 19:03:30.076+00
65839a63-ed92-478c-b84c-3aad17b7fee9	uptime	gauge	369.074395	{}	2025-09-03 19:04:30.075+00
d2cbf79f-a9da-4874-82ac-d2d814cfebec	memory_usage	gauge	68.670000	{}	2025-09-03 19:05:30.076+00
33ee87f7-0540-4a4b-92a6-1111c1eab5b3	disk_usage	gauge	45.200000	{}	2025-09-03 19:06:30.076+00
6d0405b8-e135-46d4-bdb2-0bdb9a8ab4d4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:23:37.473+00
4f63d864-1d4d-4b41-8145-7a3623949fdc	memory_usage	gauge	68.030000	{}	2025-09-03 19:24:37.474+00
95d13c0b-c337-4780-9730-06f689b14900	memory_usage	gauge	68.260000	{}	2025-09-03 19:25:37.474+00
dbfd2fdd-ca2d-494e-a419-290fee6ae0ec	cpu_usage	gauge	6.000000	{}	2025-09-03 19:26:37.473+00
b9b1a66b-16f3-4c9e-8841-fd957a408739	uptime	gauge	609.049130	{}	2025-09-03 19:27:37.475+00
b7b18886-c0ae-4a2d-ba7e-99c5a0146cb2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:28:37.476+00
fa6d57f9-079c-4696-aed3-c33d45722a48	cpu_usage	gauge	6.000000	{}	2025-09-03 19:42:52.84+00
a3a3eb2a-cfae-418b-82a8-70eb3ed4abd5	memory_usage	gauge	68.380000	{}	2025-09-03 19:43:52.841+00
bde24dce-c7cb-452e-8764-77b112fd0183	disk_usage	gauge	45.200000	{}	2025-09-03 19:44:52.84+00
abdbf64c-c947-4ce0-8eee-907b6ef4eb10	memory_usage	gauge	68.460000	{}	2025-09-03 19:45:52.841+00
0ac815f8-26f8-48c2-8d21-b828f1a221a0	uptime	gauge	908.975090	{}	2025-09-03 19:46:52.84+00
82f71241-63bb-464c-86c0-a0c9e91f3905	disk_usage	gauge	45.200000	{}	2025-09-03 19:47:52.842+00
28b96502-74aa-48d4-89b3-049bf7ea945f	memory_usage	gauge	68.330000	{}	2025-09-03 19:48:52.841+00
6ba3b6d7-021b-4578-8ffc-70fe2ebcecac	uptime	gauge	1088.977238	{}	2025-09-03 19:49:52.842+00
2ecdf4d1-100e-4294-a1ea-51c3e722635a	disk_usage	gauge	45.200000	{}	2025-09-03 19:50:52.842+00
da0260e8-974d-46e0-9e11-a1ba1a27cfce	memory_usage	gauge	68.550000	{}	2025-09-03 19:51:52.842+00
3a53a89c-7757-4d62-b9ed-48eea60ad4f6	cpu_usage	gauge	6.000000	{}	2025-09-03 19:52:52.842+00
f2576999-40fa-4132-82ed-31f5deb15665	uptime	gauge	1328.976807	{}	2025-09-03 19:53:52.842+00
db4a173a-39d2-4948-90ea-ab432aac5792	cpu_usage	gauge	6.000000	{}	2025-09-03 22:20:12.176+00
248f87c0-1301-49d0-8b04-ca9e38e70524	uptime	gauge	369.173091	{}	2025-09-03 22:21:12.176+00
c52ae48b-8f61-4b43-b03d-2c3fe57331f5	cpu_usage	gauge	6.000000	{}	2025-09-03 22:22:12.176+00
c3e581bd-b1cb-4eea-8e2e-c6110dfd69a3	uptime	gauge	489.173934	{}	2025-09-03 22:23:12.177+00
a5c62828-bc3f-4355-b1c9-4483f2118c61	cpu_usage	gauge	6.000000	{}	2025-09-03 22:24:12.177+00
9d75fe26-8260-41cb-aaeb-53265dde71df	uptime	gauge	609.174284	{}	2025-09-03 22:25:12.178+00
f183f3fc-3102-424b-a460-667a85a96d2f	memory_usage	gauge	73.610000	{}	2025-09-03 22:26:12.177+00
c4212166-95ab-4ed8-a063-0243c414c205	disk_usage	gauge	45.200000	{}	2025-09-03 22:27:12.178+00
0052da8f-bbaf-48c3-840b-0eead3842d12	memory_usage	gauge	73.430000	{}	2025-09-03 22:28:12.179+00
46a26eb0-ee96-43e3-bf2e-f8426f866dec	uptime	gauge	5529.425040	{}	2025-09-04 15:14:46.378+00
1b19d19a-dcac-4642-8c29-f6c9add69121	disk_usage	gauge	45.200000	{}	2025-09-04 15:15:46.378+00
0bafb388-d475-43ea-8c97-118b827df73c	cpu_usage	gauge	5.000000	{}	2025-09-04 15:16:46.378+00
b908c108-d72a-4f00-ab49-e11f5fe8f81d	uptime	gauge	5709.425194	{}	2025-09-04 15:17:46.378+00
2d5b479b-4016-4695-bbe2-820a16f28b42	memory_usage	gauge	77.530000	{}	2025-09-04 15:18:46.379+00
f7335bd5-6e51-4375-9aeb-4615dbf9ef8e	uptime	gauge	5829.426259	{}	2025-09-04 15:19:46.379+00
685f3737-e934-4f88-b33a-7229b439d380	disk_usage	gauge	45.200000	{}	2025-09-04 15:20:46.379+00
3900fe95-12d8-4f10-9d91-2c77a5106269	disk_usage	gauge	45.200000	{}	2025-09-04 15:21:46.38+00
a3b40178-a21b-46b1-9105-b409ec0af2a4	cpu_usage	gauge	5.000000	{}	2025-09-04 15:22:46.382+00
6c3ccfe6-c472-47ff-b5bb-76cffd1540ec	uptime	gauge	6069.428823	{}	2025-09-04 15:23:46.382+00
30a12d66-ad90-41bd-a1c1-cd3d27f4fb0c	memory_usage	gauge	80.230000	{}	2025-09-04 15:24:46.382+00
ff6d8e63-6f90-4860-ab3c-83124ca44fad	memory_usage	gauge	75.920000	{}	2025-09-04 19:14:59.376+00
23b997f3-ef16-424e-8482-c41ecc417153	disk_usage	gauge	45.200000	{}	2025-09-04 19:15:59.377+00
5b12aa02-be3d-4035-89e0-bd40fdeb9e5f	disk_usage	gauge	45.200000	{}	2025-09-04 19:16:59.378+00
fe2136f1-3dc4-4220-9b7d-ea04ceeb6380	cpu_usage	gauge	6.000000	{}	2025-09-03 16:58:58.356+00
a67ea2c4-9d46-44e7-bd8f-831a2c5cbebe	uptime	gauge	1628.117564	{}	2025-09-03 16:59:58.358+00
1abc87ba-1ca9-407e-b3dc-6e06782864e8	memory_usage	gauge	77.010000	{}	2025-09-03 17:00:58.359+00
8856a57c-67fa-4394-bc81-827fa8eef3bc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:01:58.36+00
928e94c1-9a63-4a45-8ceb-1fa1a0ba10d8	uptime	gauge	1808.119512	{}	2025-09-03 17:02:58.36+00
d6b864d1-8849-4f3f-b9cd-4776e7e16d4e	disk_usage	gauge	45.200000	{}	2025-09-03 17:03:58.36+00
b6b275f6-e553-468e-9ab1-7c1402d16336	disk_usage	gauge	45.200000	{}	2025-09-03 17:04:58.361+00
e7a09ccb-040f-4381-b746-a6083b62f5fa	disk_usage	gauge	45.200000	{}	2025-09-03 17:05:58.362+00
d39967be-0cf0-4e4d-ac72-e01a0b1cd39d	disk_usage	gauge	45.200000	{}	2025-09-03 17:50:13.55+00
c122c76f-4189-4faf-b315-ea9b4cd11dd5	disk_usage	gauge	45.200000	{}	2025-09-03 17:51:13.55+00
9aab627e-5e90-41a3-aee8-b5a09fbdb8d1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:52:13.55+00
aaeff1ba-7593-4afc-85f8-a9e3459c1392	uptime	gauge	309.357754	{}	2025-09-03 17:53:13.555+00
0fc7ccd5-bcb9-482b-955c-5bc1d14e055d	disk_usage	gauge	45.200000	{}	2025-09-03 18:26:50.187+00
0e6e720b-c06c-4e35-8959-e803f0928b83	cpu_usage	gauge	6.000000	{}	2025-09-03 18:27:50.187+00
cbb8de96-ce5e-4e5f-918e-10bc8e89bdc7	uptime	gauge	188.198657	{}	2025-09-03 18:28:50.188+00
707669dd-4b30-4100-9b8b-a1420c9d8c34	disk_usage	gauge	45.200000	{}	2025-09-03 18:29:50.189+00
82b0aec0-ef2b-40c6-8e64-a1d871afd8d6	disk_usage	gauge	45.200000	{}	2025-09-03 18:30:50.195+00
d7969dff-9d85-4e14-994e-82194ff9d068	disk_usage	gauge	45.200000	{}	2025-09-03 18:36:05.743+00
dcafa2e2-a38f-44a5-82b2-df6944625835	cpu_usage	gauge	6.000000	{}	2025-09-03 18:56:56.048+00
a3a3736e-5194-40ef-9c26-7ec047ff9a39	memory_usage	gauge	68.660000	{}	2025-09-03 19:07:30.076+00
6b23c719-ca08-4f51-b512-7abe3c9cdbe2	disk_usage	gauge	45.200000	{}	2025-09-03 19:23:37.473+00
2552ff3a-eeed-4bf5-9477-a471e8818a85	cpu_usage	gauge	6.000000	{}	2025-09-03 19:24:37.473+00
0a20ac66-13ce-4f0d-a766-dbb64f6cc812	uptime	gauge	489.048141	{}	2025-09-03 19:25:37.474+00
e14067dd-1307-4e68-86f2-a0c4e488dc1c	disk_usage	gauge	45.200000	{}	2025-09-03 19:26:37.474+00
741a4712-2788-46f8-b187-3a1abbaa43b4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:27:37.475+00
c9b207bd-355d-421c-903c-d3b5465386ec	uptime	gauge	669.050150	{}	2025-09-03 19:28:37.476+00
6a83de07-857d-4700-9060-82ff0a2408b8	memory_usage	gauge	68.270000	{}	2025-09-03 19:42:52.84+00
27cb6c4d-cf0d-4606-bced-0b508248e1af	cpu_usage	gauge	6.000000	{}	2025-09-03 19:43:52.841+00
f3f7c20b-754f-46e0-9af3-a44d27356128	uptime	gauge	788.975383	{}	2025-09-03 19:44:52.84+00
af6bf345-11da-4c6d-92ed-588dd7658b0b	cpu_usage	gauge	6.000000	{}	2025-09-03 19:45:52.841+00
7228f2de-f3d0-4e4c-ae4c-8310df6e4274	memory_usage	gauge	68.370000	{}	2025-09-03 19:46:52.84+00
86c8dda5-efd0-437e-84bb-ddff408aeed3	memory_usage	gauge	68.300000	{}	2025-09-03 19:47:52.842+00
4625ee99-2f57-4121-b334-0fd01845ff7b	disk_usage	gauge	45.200000	{}	2025-09-03 19:48:52.841+00
8f3be31b-4701-48c4-905d-5d839443e93e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:49:52.842+00
df75a087-e66d-4e25-92e9-b0a8de9153ba	uptime	gauge	1148.976887	{}	2025-09-03 19:50:52.842+00
cf6bf71e-361c-4152-955f-e48b15d99b89	disk_usage	gauge	45.200000	{}	2025-09-03 19:51:52.842+00
4d43c392-4a73-4c00-a7a2-2dce797f34c1	memory_usage	gauge	68.290000	{}	2025-09-03 19:52:52.842+00
3019ab3c-9306-4f64-8d5c-e98042ebc194	memory_usage	gauge	70.040000	{}	2025-09-03 19:53:52.842+00
5dbfec42-e039-4c3f-9c10-14b75dd1cc8e	cpu_usage	gauge	6.000000	{}	2025-09-03 22:29:47.692+00
4d5e8cfa-022e-4b89-91b1-98bcc3a4834d	memory_usage	gauge	75.730000	{}	2025-09-03 22:29:47.692+00
d6595621-a198-4cb5-a37f-1835e59efeb8	disk_usage	gauge	45.200000	{}	2025-09-03 22:29:47.692+00
7224dafa-51ce-43e5-867d-a8e5456fb683	uptime	gauge	68.875030	{}	2025-09-03 22:29:47.692+00
4ae14db9-b22c-42e1-886e-bd3389a52ad6	uptime	gauge	128.875205	{}	2025-09-03 22:30:47.693+00
cfbea671-5b5b-4503-ba37-89dc5cf06e99	uptime	gauge	188.875766	{}	2025-09-03 22:31:47.693+00
551002e9-b4fd-4b76-818a-dcf4ff9985b6	disk_usage	gauge	45.200000	{}	2025-09-03 22:32:47.694+00
af6371ce-4bcb-4504-8caf-7741bfb5faed	disk_usage	gauge	45.200000	{}	2025-09-03 22:33:47.699+00
9d8d7a29-0ebc-4ecd-bdac-423703c3ea89	cpu_usage	gauge	6.000000	{}	2025-09-03 22:34:47.7+00
c6b5fd52-3ef8-4474-a840-cd0d285c709e	uptime	gauge	428.883257	{}	2025-09-03 22:35:47.701+00
92e6f053-36bb-4389-9692-ed43cc6189e8	disk_usage	gauge	45.200000	{}	2025-09-03 22:36:47.7+00
055ff525-3757-401b-a14a-ad541bb8a3bc	cpu_usage	gauge	6.000000	{}	2025-09-03 22:37:47.7+00
de515351-f990-4169-ac19-628050fafd8e	cpu_usage	gauge	6.000000	{}	2025-09-03 22:40:22.425+00
69811e06-db2b-4a34-981a-96b1a0d90511	uptime	gauge	69.198126	{}	2025-09-03 22:40:22.426+00
ca74b8e2-9c66-43f1-9a4b-8e0993a388d2	disk_usage	gauge	45.200000	{}	2025-09-03 22:41:22.426+00
7fb6c4c4-4c4c-4f25-a03e-248b93749e11	uptime	gauge	189.198794	{}	2025-09-03 22:42:22.426+00
c6cbfe95-b1b1-4af2-9131-ef868b885beb	memory_usage	gauge	76.210000	{}	2025-09-03 22:50:22.432+00
6aeff977-10af-483d-9970-d4b4da0e0d19	cpu_usage	gauge	5.000000	{}	2025-09-04 15:29:40.991+00
1e8e3e91-7999-4539-b28e-8f41e25ce5ca	memory_usage	gauge	80.700000	{}	2025-09-04 15:29:40.991+00
f7a63266-c2fe-4ca4-a1f6-a93d11f376b3	disk_usage	gauge	45.200000	{}	2025-09-04 15:29:40.992+00
c2e334d0-139b-43fd-99b0-fdd73a4ceda4	uptime	gauge	69.106525	{}	2025-09-04 15:29:40.992+00
014ee6fc-4af6-4978-a1a0-34d22ffc73f3	uptime	gauge	129.107673	{}	2025-09-04 15:30:40.993+00
e2c2a12d-868c-4388-a04b-e0c19ec13e5c	memory_usage	gauge	80.890000	{}	2025-09-04 15:31:40.992+00
8130b571-df23-4828-97c5-8eea3026f168	cpu_usage	gauge	5.000000	{}	2025-09-04 15:32:40.993+00
10ee85c9-4bf9-4d2b-a51b-fd4e891ef2ab	uptime	gauge	309.113712	{}	2025-09-04 15:33:40.999+00
049283ed-0655-4d0e-92f2-79d6e23834a4	cpu_usage	gauge	5.000000	{}	2025-09-04 19:20:30.549+00
4ea9ca91-f481-46e8-b79f-b25c9ffa4737	uptime	gauge	129.397756	{}	2025-09-04 19:21:30.549+00
a24dff7d-8e4f-4b40-8e9d-3975481852a3	disk_usage	gauge	45.200000	{}	2025-09-04 19:22:30.549+00
31c8575c-c899-4a79-bda2-9f0b7d248227	uptime	gauge	1568.116239	{}	2025-09-03 16:58:58.357+00
90901a37-320a-4a07-8db4-7414275ab946	memory_usage	gauge	77.400000	{}	2025-09-03 16:59:58.358+00
13184740-621d-4183-93b6-07b0c09a6c94	disk_usage	gauge	45.200000	{}	2025-09-03 17:50:27.515+00
b1193f65-cfda-4bfc-a02d-9ad986e4d7c0	disk_usage	gauge	45.200000	{}	2025-09-03 17:51:27.516+00
7aace998-5ccc-4e3d-9acd-8d38649cbaea	cpu_usage	gauge	6.000000	{}	2025-09-03 17:52:27.517+00
8ac794b9-87ed-49e0-aa2d-fb00a272fe49	uptime	gauge	308.016112	{}	2025-09-03 17:53:27.524+00
ecffc8aa-87fa-4b74-88ac-e004d2455ff2	disk_usage	gauge	45.200000	{}	2025-09-03 18:27:50.188+00
3454be98-668b-4652-ad6f-bbc5bd191c33	cpu_usage	gauge	6.000000	{}	2025-09-03 18:28:50.187+00
a291221b-8240-4167-9624-15f4cd1c3eda	uptime	gauge	248.199536	{}	2025-09-03 18:29:50.189+00
37a0572d-8d1f-4e98-bb65-8f3dfeb4ec80	cpu_usage	gauge	6.000000	{}	2025-09-03 18:30:50.195+00
881c31cb-627e-44e5-b35b-8b0d04778335	uptime	gauge	68.374480	{}	2025-09-03 18:36:05.743+00
2969c330-2b71-4984-93a9-a1f676085348	memory_usage	gauge	64.610000	{}	2025-09-03 18:56:56.048+00
1988b199-eeff-437b-bffc-a4d2e8a33708	cpu_usage	gauge	6.000000	{}	2025-09-03 19:07:30.076+00
72a08ea5-cec4-413a-9247-483485d538cf	uptime	gauge	369.047262	{}	2025-09-03 19:23:37.473+00
80592a7d-5eb8-4828-bf56-16a36dc59786	disk_usage	gauge	45.200000	{}	2025-09-03 19:24:37.474+00
6130d85e-17cb-47d5-8a52-9de63a16513d	cpu_usage	gauge	6.000000	{}	2025-09-03 19:25:37.474+00
9fd5a878-6c24-42b7-9220-94aea4283e94	uptime	gauge	549.047955	{}	2025-09-03 19:26:37.474+00
993c4c7e-6151-4b35-8c7d-223820122783	disk_usage	gauge	45.200000	{}	2025-09-03 19:27:37.475+00
9e05312f-c9ef-4ac9-b099-0dbbeb66c47a	disk_usage	gauge	45.200000	{}	2025-09-03 19:28:37.476+00
0a927c09-d4b7-44e1-96b4-eec756a2b63a	cpu_usage	gauge	6.000000	{}	2025-09-03 19:54:52.841+00
62f0431c-9156-458f-9415-45f58be57768	uptime	gauge	1448.977900	{}	2025-09-03 19:55:52.843+00
a143cd70-47fd-4939-801a-192ae0f5fe0c	disk_usage	gauge	45.200000	{}	2025-09-03 19:56:52.843+00
a9f3d2d8-2ad9-4633-a457-987b982cc286	cpu_usage	gauge	6.000000	{}	2025-09-03 19:57:52.844+00
c525e3f7-5b5f-4779-99ba-dea018d86baa	uptime	gauge	1628.979000	{}	2025-09-03 19:58:52.844+00
a9be3d89-4b51-4a4f-a3f9-8851c97d2bd8	memory_usage	gauge	71.440000	{}	2025-09-03 19:59:52.845+00
a1e69dc8-1a85-4974-a18c-c0f4470bec93	cpu_usage	gauge	6.000000	{}	2025-09-03 20:00:52.846+00
6de25d3f-1c75-486c-a134-e772fd628f19	uptime	gauge	1808.982347	{}	2025-09-03 20:01:52.847+00
92c52fca-0dab-42dc-9dac-4bf0619918e7	disk_usage	gauge	45.200000	{}	2025-09-03 20:02:52.847+00
dcb1e9db-059f-48ad-9f20-9a01e7993586	cpu_usage	gauge	6.000000	{}	2025-09-03 20:03:52.849+00
3ce9f76c-3fee-4ad6-96ad-11ee36b8485f	disk_usage	gauge	45.200000	{}	2025-09-03 20:04:52.85+00
4d9c89c9-53df-4bf1-b47b-c383811b655f	cpu_usage	gauge	6.000000	{}	2025-09-03 22:30:47.692+00
3c1ed2a7-bb7e-459c-a9f0-442525b8e119	cpu_usage	gauge	6.000000	{}	2025-09-03 22:31:47.693+00
75c2189e-8156-4e07-b94d-329d8a92553f	uptime	gauge	248.876465	{}	2025-09-03 22:32:47.694+00
f0a0ce78-f4f6-4741-8ae8-0d9dbcb9cffb	memory_usage	gauge	75.770000	{}	2025-09-03 22:33:47.699+00
a3b1e213-0a1e-41c3-bb91-5717103eeee5	memory_usage	gauge	76.210000	{}	2025-09-03 22:34:47.7+00
640cc0cd-05e2-449a-aa3b-7b2aaea65637	disk_usage	gauge	45.200000	{}	2025-09-03 22:35:47.701+00
4bc1dab5-f3bb-4f7b-9fb5-0cd09d753151	cpu_usage	gauge	6.000000	{}	2025-09-03 22:36:47.7+00
94e99c6c-66ca-499f-9074-638f66f1d561	uptime	gauge	548.882939	{}	2025-09-03 22:37:47.7+00
dd491a4e-7fbf-4f62-9472-4dcfdb197331	memory_usage	gauge	76.100000	{}	2025-09-03 22:40:22.426+00
2a8f2789-66d3-42aa-8319-2f684541e33d	disk_usage	gauge	45.200000	{}	2025-09-03 22:40:22.426+00
1af7b6bc-eea7-4ccd-b3bf-5e72dc0106e6	uptime	gauge	129.198237	{}	2025-09-03 22:41:22.426+00
8d0b5dc5-5309-44b4-bd08-ab1b3ff4ba2b	disk_usage	gauge	45.200000	{}	2025-09-03 22:42:22.426+00
f0845b00-8b7c-4b1d-ad6f-09222a00ec27	uptime	gauge	489.203567	{}	2025-09-03 22:47:22.431+00
21d2cd0f-a1d9-4e75-8a05-c1ae3489f72a	uptime	gauge	669.204705	{}	2025-09-03 22:50:22.432+00
c628588d-e9f4-4d72-8ab4-946b4f7e27fa	disk_usage	gauge	45.200000	{}	2025-09-03 22:51:22.433+00
1350ba73-7186-4ba0-9f45-7d6c355f9663	cpu_usage	gauge	5.000000	{}	2025-09-04 15:30:40.993+00
1cca1928-039e-4e9e-b158-5def90fa4ad8	uptime	gauge	189.107315	{}	2025-09-04 15:31:40.992+00
62cb0e74-7282-4ecf-8b64-ca99f6bb4bcb	disk_usage	gauge	45.200000	{}	2025-09-04 15:32:40.993+00
7c3b611e-731e-480b-a650-1cde76811f25	memory_usage	gauge	80.830000	{}	2025-09-04 15:33:40.999+00
2b2b055a-d55c-48bf-a805-951ef3b439aa	memory_usage	gauge	77.100000	{}	2025-09-04 19:20:30.549+00
b9cba28e-7cd7-4d80-b665-d2ef3b71bec6	disk_usage	gauge	45.200000	{}	2025-09-04 19:21:30.549+00
51f7b0fb-163c-4fc4-b0ff-2807f2828138	memory_usage	gauge	76.550000	{}	2025-09-04 19:22:30.549+00
30d0f38d-4f29-4361-bdd1-4f052d927d28	disk_usage	gauge	45.200000	{}	2025-09-03 16:58:58.357+00
0f731d25-3b61-4dbc-add0-791689711995	cpu_usage	gauge	6.000000	{}	2025-09-03 16:59:58.358+00
e46a2a11-9276-449b-83b2-57ce3280aa12	uptime	gauge	1688.118572	{}	2025-09-03 17:00:58.359+00
ff5a4ed8-0a45-4452-b3cc-d51dd694a45f	disk_usage	gauge	45.200000	{}	2025-09-03 17:01:58.36+00
3ad5eb8a-7df3-45bb-ad03-279f8c3e5903	cpu_usage	gauge	6.000000	{}	2025-09-03 17:02:58.36+00
97a65b23-1de0-45a5-98ab-b95ccec215f4	uptime	gauge	1868.120054	{}	2025-09-03 17:03:58.36+00
544aa8ff-8fb9-4245-91ac-8d0ab06a91a7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:04:58.361+00
85b74caf-cb01-4e1d-91b8-9e854842db8b	uptime	gauge	1988.121847	{}	2025-09-03 17:05:58.362+00
b59a4e71-9f0e-4e5e-a74e-399751a73add	memory_usage	gauge	80.520000	{}	2025-09-03 17:06:58.363+00
5f08c24c-398e-41b7-9aba-1dddf4d185c4	uptime	gauge	128.006954	{}	2025-09-03 17:50:27.515+00
7207918c-efe0-4404-8ae8-7ad150ac7b5f	memory_usage	gauge	75.390000	{}	2025-09-03 17:51:27.516+00
8c715a76-93bf-4660-9f32-dc1544f495a2	memory_usage	gauge	75.400000	{}	2025-09-03 17:52:27.517+00
9cc1ab8c-fbcd-45f6-a632-361eaca89b83	disk_usage	gauge	45.200000	{}	2025-09-03 17:53:27.524+00
2d0ccc6a-d4dc-4d47-8658-987b9b49686e	uptime	gauge	128.198785	{}	2025-09-03 18:27:50.188+00
f3f36932-75bf-4076-adf7-13ab1895d462	disk_usage	gauge	45.200000	{}	2025-09-03 18:28:50.188+00
9d7c852b-b9ad-488c-9e75-1157f4f8f573	cpu_usage	gauge	6.000000	{}	2025-09-03 18:29:50.188+00
ce2fc85e-2331-4049-a7b1-67cfaa738b70	uptime	gauge	308.206194	{}	2025-09-03 18:30:50.195+00
02cfdbd7-ad8e-4752-8133-ee62d75f09c8	memory_usage	gauge	70.040000	{}	2025-09-03 18:36:38.101+00
483488c5-5132-4634-8a09-9844787f34ec	disk_usage	gauge	45.200000	{}	2025-09-03 18:36:38.101+00
4ad4cf3a-3b58-4512-b027-484bc8d02755	disk_usage	gauge	45.200000	{}	2025-09-03 18:37:38.102+00
4f364891-41e5-4fdb-a1b0-d31548feeda0	uptime	gauge	789.245064	{}	2025-09-03 18:37:38.102+00
da3c0a8d-eeaa-4292-9592-f845dc5673e0	cpu_usage	gauge	6.000000	{}	2025-09-03 18:38:38.102+00
18a80aaa-30cf-498d-a85e-6e82b0f6032e	memory_usage	gauge	70.050000	{}	2025-09-03 18:38:38.102+00
f9b6aad6-2583-4e60-992c-f8fb2f505c6d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:39:38.102+00
58c5a80b-3762-4104-9d77-dbeef12cd12b	uptime	gauge	909.245526	{}	2025-09-03 18:39:38.102+00
9427ba04-02cf-48e1-bff2-507294eaa325	cpu_usage	gauge	6.000000	{}	2025-09-03 18:40:38.102+00
a93ffe8e-e198-4e92-b0a6-bd0c58545021	uptime	gauge	969.245579	{}	2025-09-03 18:40:38.102+00
9398429d-b675-42c9-88a9-d58657b82f30	disk_usage	gauge	45.200000	{}	2025-09-03 18:41:38.103+00
17b2d0d4-9549-4fc7-9ca1-7808e4bb23d7	uptime	gauge	1029.246470	{}	2025-09-03 18:41:38.103+00
9f5225dd-9348-4df0-bab6-9da067c8090a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:42:38.104+00
bc88fca3-1511-4a01-8721-d7c30f405aa6	memory_usage	gauge	65.450000	{}	2025-09-03 18:42:38.104+00
dd91f8ce-a967-49b3-804f-22e02e17726c	disk_usage	gauge	45.200000	{}	2025-09-03 18:43:38.105+00
0ef23ac7-40a2-4232-852b-f44bcf4f2dcb	uptime	gauge	1149.248413	{}	2025-09-03 18:43:38.105+00
900acc49-254b-468a-83b8-fcd20c259607	cpu_usage	gauge	6.000000	{}	2025-09-03 18:44:38.105+00
a2d3f4af-8838-44b5-8a1d-a647c200a32e	disk_usage	gauge	45.200000	{}	2025-09-03 18:44:38.105+00
8658eba8-0b1d-4614-8176-eb469d8fa6c7	disk_usage	gauge	45.200000	{}	2025-09-03 18:56:56.048+00
02ab761d-8ac5-4f2b-bf81-aa3416c23764	uptime	gauge	549.075517	{}	2025-09-03 19:07:30.077+00
b904ae5a-c0f2-438d-9191-357631b88e07	disk_usage	gauge	45.200000	{}	2025-09-03 19:54:52.842+00
fe2a8c48-c94b-4e01-83f9-3ec300126544	memory_usage	gauge	72.790000	{}	2025-09-03 19:55:52.843+00
0b88b93e-1a06-491f-90eb-e09947433410	memory_usage	gauge	71.550000	{}	2025-09-03 19:56:52.843+00
d5003013-2ade-4d0a-9e90-b8fe500ca3e3	memory_usage	gauge	71.400000	{}	2025-09-03 19:57:52.844+00
ddcac467-bb65-4d22-8d3a-53ca65d53ab6	disk_usage	gauge	45.200000	{}	2025-09-03 19:58:52.844+00
218c16b3-6820-44f4-954f-44a194de46b3	cpu_usage	gauge	6.000000	{}	2025-09-03 19:59:52.845+00
9d09da62-ff36-407d-a5f8-ecb5c106c4b7	uptime	gauge	1748.981099	{}	2025-09-03 20:00:52.846+00
822b89ea-6a98-449f-9c79-6f3b10d06020	memory_usage	gauge	74.130000	{}	2025-09-03 20:01:52.847+00
659b6cb3-164c-4418-9f22-c4cba7808300	uptime	gauge	1868.982393	{}	2025-09-03 20:02:52.847+00
517dc441-a8a1-4a3f-a4eb-d949cbc790d3	memory_usage	gauge	73.410000	{}	2025-09-03 20:03:52.849+00
04d0f347-4dcf-45f2-ae75-6c65d491da62	uptime	gauge	1988.985174	{}	2025-09-03 20:04:52.85+00
bd8a48aa-976e-43f9-a1fd-c371a9e85d86	memory_usage	gauge	73.540000	{}	2025-09-03 22:30:47.693+00
e7ab15cf-6b11-494d-889f-ef7bd2d1482b	disk_usage	gauge	45.200000	{}	2025-09-03 22:31:47.693+00
f8cdb5db-fced-4ca6-a4f5-d3fc3dd79a06	cpu_usage	gauge	6.000000	{}	2025-09-03 22:32:47.694+00
c57779d5-acc8-41b8-b8dc-34c4c8d89653	uptime	gauge	308.881639	{}	2025-09-03 22:33:47.699+00
c0ca57be-0a0d-47a9-a96d-760b059d3652	disk_usage	gauge	45.200000	{}	2025-09-03 22:34:47.7+00
045152a9-eec3-48e0-bd46-9428ebab8567	cpu_usage	gauge	6.000000	{}	2025-09-03 22:35:47.701+00
e0936650-e19b-4cb2-bead-21751da88b46	uptime	gauge	488.882725	{}	2025-09-03 22:36:47.7+00
17eff526-1677-41e5-9bd4-5f8f9982b05b	disk_usage	gauge	45.200000	{}	2025-09-03 22:37:47.7+00
aa0ca644-3448-4bd5-ba99-32b8a571f9a9	cpu_usage	gauge	6.000000	{}	2025-09-03 22:41:22.426+00
4689ddd5-0e07-49e9-b149-53d8085bf0f8	cpu_usage	gauge	6.000000	{}	2025-09-03 22:42:22.426+00
b0e49b0a-6703-4bb0-abe0-724dd6efc41a	cpu_usage	gauge	6.000000	{}	2025-09-03 22:43:22.426+00
23ac25f4-cfa6-4cc7-802d-94c998953f2d	uptime	gauge	309.204237	{}	2025-09-03 22:44:22.432+00
e5323f05-156c-4b25-80e7-963938a03599	uptime	gauge	369.204884	{}	2025-09-03 22:45:22.432+00
226bc185-53f3-428c-aaf4-99b43f9669ec	memory_usage	gauge	75.250000	{}	2025-09-03 22:46:22.431+00
c9b4bec5-7d4c-413f-947a-3db65a86bfcc	memory_usage	gauge	78.080000	{}	2025-09-03 22:51:22.433+00
fb435cb9-551f-45a0-97ce-5e963ccf6628	memory_usage	gauge	80.810000	{}	2025-09-04 15:30:40.993+00
4ed3c0dc-1fa3-4015-8a87-d2cb8459c383	disk_usage	gauge	45.200000	{}	2025-09-04 15:31:40.992+00
068b415e-d5b8-4e30-9089-fc7ea00631b3	memory_usage	gauge	80.850000	{}	2025-09-04 15:32:40.993+00
b86d491d-d637-476b-90ca-3aa8255d9db3	disk_usage	gauge	45.200000	{}	2025-09-04 15:33:40.999+00
8c200ad7-bdd7-4e3b-ac86-a040bb5fd830	disk_usage	gauge	45.200000	{}	2025-09-04 19:20:30.549+00
17710c03-3cb6-4c5e-8852-ddfac361e04e	memory_usage	gauge	76.910000	{}	2025-09-04 19:21:30.549+00
a7aaf215-5ca3-491c-92d7-ec4618aef0be	cpu_usage	gauge	5.000000	{}	2025-09-04 19:22:30.549+00
52a782fd-2941-4082-b835-60e282fd0e3c	memory_usage	gauge	76.800000	{}	2025-09-03 17:00:36.219+00
178ea446-acec-4fc8-a9a2-9140478c700e	memory_usage	gauge	77.040000	{}	2025-09-03 17:01:36.219+00
df99fccb-5466-4c2d-ab78-16ccbc7398fa	memory_usage	gauge	77.140000	{}	2025-09-03 17:02:36.219+00
5d667bb4-bc58-4bea-bacf-81f6ba1cd584	disk_usage	gauge	45.200000	{}	2025-09-03 17:03:36.22+00
7b45de76-7205-471a-95d9-a10cb12fe6d8	cpu_usage	gauge	6.000000	{}	2025-09-03 17:04:36.22+00
8c684642-e481-451a-9eeb-4c7053104c0e	uptime	gauge	2049.468047	{}	2025-09-03 17:05:36.221+00
2bcb2492-124e-46e4-b30c-e36cea4a9f62	memory_usage	gauge	77.130000	{}	2025-09-03 17:06:36.221+00
b0831fff-964b-4493-b564-4e29fd384219	memory_usage	gauge	75.280000	{}	2025-09-03 17:54:13.555+00
950b8b99-bd74-4930-9943-6a88b54090e8	uptime	gauge	429.358211	{}	2025-09-03 17:55:13.556+00
1b2b0779-5c17-4929-bc5b-3608908b8581	disk_usage	gauge	45.200000	{}	2025-09-03 17:56:13.556+00
9c6b56cf-595d-431f-bc5b-a5b180607d60	cpu_usage	gauge	6.000000	{}	2025-09-03 17:57:13.556+00
ef6cc8f9-0a8c-4686-9f78-3760e6e2c0ef	uptime	gauge	609.358561	{}	2025-09-03 17:58:13.556+00
ccc98f65-da37-49c7-9775-8aa62fa85d41	memory_usage	gauge	75.100000	{}	2025-09-03 17:59:13.556+00
c413f8ba-450c-420a-8830-37980b92ab14	cpu_usage	gauge	6.000000	{}	2025-09-03 18:00:13.557+00
b6546104-ac49-4c0b-a3a6-2633af0d30d3	uptime	gauge	789.359829	{}	2025-09-03 18:01:13.557+00
75f78142-de3b-4a3e-8177-1b2d4d91ff31	disk_usage	gauge	45.200000	{}	2025-09-03 18:02:13.557+00
76796ee3-8964-45b4-9fa3-3c894edfe888	memory_usage	gauge	74.790000	{}	2025-09-03 18:03:13.558+00
fd1959c8-5f5b-4125-a379-3e84dee6f978	cpu_usage	gauge	6.000000	{}	2025-09-03 18:04:13.558+00
5818e9b5-8620-4e7b-8d64-08bcea6c70b5	uptime	gauge	1029.360547	{}	2025-09-03 18:05:13.558+00
cf9834d3-c878-44c6-b93e-664a67fd0872	memory_usage	gauge	75.260000	{}	2025-09-03 18:06:13.559+00
8a12a203-1630-48cb-8950-c68b128643eb	cpu_usage	gauge	6.000000	{}	2025-09-03 18:36:38.101+00
3c548717-767e-4b83-83ef-a5d8e044b65c	cpu_usage	gauge	6.000000	{}	2025-09-03 18:37:38.101+00
7513f06c-d0a5-4817-98f4-bf76361b2d03	uptime	gauge	849.245132	{}	2025-09-03 18:38:38.102+00
1330e200-eac0-45ed-aede-9a44e6e5a8d6	disk_usage	gauge	45.200000	{}	2025-09-03 18:39:38.102+00
7059cc98-190c-49d7-80e3-d4c5e332338a	disk_usage	gauge	45.200000	{}	2025-09-03 18:40:38.102+00
e89da9cb-55e5-4f10-a18b-27b2fed42740	cpu_usage	gauge	6.000000	{}	2025-09-03 18:41:38.103+00
89f0b838-43e0-46be-a9bc-c1527845501d	uptime	gauge	1089.247237	{}	2025-09-03 18:42:38.104+00
228da3d5-0ce2-4d79-8cdf-37cb12cb2646	memory_usage	gauge	65.350000	{}	2025-09-03 18:43:38.105+00
b06c0f85-8534-402a-84e0-3a20e0bcae1f	memory_usage	gauge	65.270000	{}	2025-09-03 18:44:38.105+00
4999bb45-6f9f-429d-9705-2bf7fc6a064a	disk_usage	gauge	45.200000	{}	2025-09-03 19:07:30.077+00
e047d578-0f77-474c-ae9c-b6946c4c1b48	memory_usage	gauge	69.880000	{}	2025-09-03 19:54:52.841+00
eeb2353c-c833-469b-a53a-c3cc0f629b43	cpu_usage	gauge	6.000000	{}	2025-09-03 19:55:52.843+00
aacc6db8-c9f5-460d-adf5-934a477bc203	uptime	gauge	1508.977564	{}	2025-09-03 19:56:52.843+00
ae69ebb4-5f96-49d7-8301-714623441fe6	disk_usage	gauge	45.200000	{}	2025-09-03 19:57:52.844+00
79c54ed3-87e3-4b1b-a59b-cbff3a514678	memory_usage	gauge	71.400000	{}	2025-09-03 19:58:52.844+00
c4e18e72-bd04-4cd5-96ae-f6148085683d	disk_usage	gauge	45.200000	{}	2025-09-03 19:59:52.845+00
35fb84ae-85f8-4633-878b-a5a1ee4eed0e	disk_usage	gauge	45.200000	{}	2025-09-03 22:30:47.693+00
dc56f412-cd39-4e7a-8d70-3a34d8639c1c	memory_usage	gauge	73.310000	{}	2025-09-03 22:31:47.693+00
e3621100-37dc-4625-87b0-4a81fe51435a	memory_usage	gauge	73.450000	{}	2025-09-03 22:32:47.694+00
b6c91f88-0f9c-4eb6-ba8f-9a072da16bd6	cpu_usage	gauge	6.000000	{}	2025-09-03 22:33:47.699+00
33c5b940-0444-40d7-bdad-ee9a5a0abf78	uptime	gauge	368.882306	{}	2025-09-03 22:34:47.7+00
410d86b1-e4ee-4130-8a65-e4d464287a0d	memory_usage	gauge	76.180000	{}	2025-09-03 22:35:47.701+00
526c9b27-225e-43d8-b2d6-52eb905fe2aa	memory_usage	gauge	75.930000	{}	2025-09-03 22:36:47.7+00
5d720c04-ca05-4b84-95b6-5fb3e44e7ad5	memory_usage	gauge	75.660000	{}	2025-09-03 22:37:47.7+00
01d17649-e40f-471b-a72b-140120708a70	memory_usage	gauge	75.720000	{}	2025-09-03 22:41:22.426+00
e5099552-cc92-4581-86b5-d2c0661d473a	memory_usage	gauge	75.230000	{}	2025-09-03 22:42:22.426+00
f02599dc-a819-4f03-a2f9-62e35e8cd394	cpu_usage	gauge	6.000000	{}	2025-09-03 22:50:22.432+00
dc2e0320-a556-4529-b35a-e1f6a965e620	uptime	gauge	789.205185	{}	2025-09-03 22:52:22.433+00
932b0ac4-2e7b-4b7f-a15f-ff749ccd4883	disk_usage	gauge	45.200000	{}	2025-09-03 22:53:22.433+00
37b1544d-3985-473e-bbd0-53b16e315ed3	memory_usage	gauge	76.060000	{}	2025-09-03 22:54:22.433+00
024310d9-33df-4111-b885-c7d8d1dd9285	memory_usage	gauge	76.220000	{}	2025-09-03 22:55:22.432+00
708aff54-0676-49aa-849e-d145cc7e4c9b	cpu_usage	gauge	6.000000	{}	2025-09-03 22:56:22.433+00
92068753-b281-41ad-989f-d512a51144e2	uptime	gauge	1089.207216	{}	2025-09-03 22:57:22.435+00
822b7d84-d633-47ee-bce4-35ae21b0f432	memory_usage	gauge	75.560000	{}	2025-09-03 22:58:22.435+00
08d5a2a2-7264-4321-bb07-e0bbddf229f5	cpu_usage	gauge	6.000000	{}	2025-09-03 22:59:22.435+00
69e54769-ad04-407b-9e5c-01707a883800	disk_usage	gauge	45.200000	{}	2025-09-04 15:30:40.993+00
817c58ce-1daa-4e4b-84ad-6bde8aad5fc9	cpu_usage	gauge	5.000000	{}	2025-09-04 15:31:40.992+00
80ca9416-36ed-4968-822b-6dfeacc9ce40	uptime	gauge	249.108151	{}	2025-09-04 15:32:40.993+00
2c15844e-c5ab-40ba-b8f0-fbad842f1e5e	cpu_usage	gauge	5.000000	{}	2025-09-04 15:33:40.999+00
07707281-5780-4953-ab05-88d0440a9684	uptime	gauge	69.397749	{}	2025-09-04 19:20:30.549+00
e991e2e9-b196-43d6-8d04-e0fd635b8e5f	cpu_usage	gauge	5.000000	{}	2025-09-04 19:21:30.549+00
562ce051-9583-4cdb-8e98-70d1561e7cb6	uptime	gauge	189.397396	{}	2025-09-04 19:22:30.549+00
06e9bca4-edf1-410f-9199-30e57e30a590	disk_usage	gauge	45.200000	{}	2025-09-03 17:00:58.359+00
db39f074-72a3-48bb-b91e-640b1551e416	memory_usage	gauge	77.150000	{}	2025-09-03 17:01:58.36+00
7bbd9e4c-3bb4-439b-b3da-265143332c72	memory_usage	gauge	76.840000	{}	2025-09-03 17:02:58.36+00
93a8abbf-b19b-4d1c-8a09-fb7213b2b751	cpu_usage	gauge	6.000000	{}	2025-09-03 17:03:58.36+00
7a561ff9-8447-41bb-b4c7-3b3b38c9b745	memory_usage	gauge	76.740000	{}	2025-09-03 17:04:58.361+00
c3dfecc4-92a5-4e0d-80e7-4b55241547b0	memory_usage	gauge	77.790000	{}	2025-09-03 17:05:58.362+00
a968738e-0c3a-4927-815e-df16aa4e8564	cpu_usage	gauge	6.000000	{}	2025-09-03 17:54:13.555+00
32ff6cf6-65ed-41fc-a8cb-2a19eeec6e15	cpu_usage	gauge	6.000000	{}	2025-09-03 17:55:13.555+00
f8b746f0-d5d9-4bec-ac97-419e7691b316	uptime	gauge	489.358895	{}	2025-09-03 17:56:13.556+00
d4146555-29b5-4848-90fe-7daa8eba3280	disk_usage	gauge	45.200000	{}	2025-09-03 17:57:13.557+00
b0dbefb4-3655-4ca4-9167-7e79de54780e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:58:13.556+00
04e2f48e-4f63-40e9-88d7-305d073752fb	uptime	gauge	669.359033	{}	2025-09-03 17:59:13.556+00
4da21533-d76d-4fae-a4fa-a338905f60da	disk_usage	gauge	45.200000	{}	2025-09-03 18:00:13.557+00
25043142-358b-4fd7-9d87-a3ae94ed9ed6	memory_usage	gauge	74.820000	{}	2025-09-03 18:01:13.557+00
ae8dd4ca-282c-439b-9aa5-c0e6d3b531de	cpu_usage	gauge	6.000000	{}	2025-09-03 18:02:13.557+00
29b963ea-78f1-460d-a990-0cd9875897a9	uptime	gauge	909.360392	{}	2025-09-03 18:03:13.558+00
d1310a79-8e02-43a3-a67c-f088e951feed	memory_usage	gauge	74.810000	{}	2025-09-03 18:04:13.558+00
958a6791-2c96-45bc-819d-a601067a9368	memory_usage	gauge	75.710000	{}	2025-09-03 18:05:13.558+00
8df9e310-d96c-4a2a-af34-8186ee5951d5	disk_usage	gauge	45.200000	{}	2025-09-03 18:06:13.559+00
8678cb01-ddd8-4f11-b7ae-e3924a8f0345	uptime	gauge	729.244554	{}	2025-09-03 18:36:38.101+00
d73306ea-b709-42f4-94a1-29457d4b5818	memory_usage	gauge	70.120000	{}	2025-09-03 18:37:38.102+00
bf388ede-bfe2-451a-ab1d-d85058f0f26c	disk_usage	gauge	45.200000	{}	2025-09-03 18:38:38.102+00
da6c7dee-62f6-41d7-8860-8ac77b916cb6	memory_usage	gauge	69.960000	{}	2025-09-03 18:39:38.102+00
39e4a285-63f7-498e-b2a7-175395c03648	memory_usage	gauge	70.420000	{}	2025-09-03 18:40:38.102+00
d521346a-0d45-4554-8d65-28e4e59aeba4	memory_usage	gauge	65.510000	{}	2025-09-03 18:41:38.103+00
e0f56d77-322b-4e74-9332-4fc116ebb431	disk_usage	gauge	45.200000	{}	2025-09-03 18:42:38.104+00
573c1167-864a-4f8f-bd09-aea905a8145d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:43:38.105+00
295d6581-bbea-47aa-9fca-5cc4474cd589	uptime	gauge	1209.248664	{}	2025-09-03 18:44:38.105+00
2ca86fc9-d181-4a2b-9c2e-0f1961fcea3a	uptime	gauge	1388.976426	{}	2025-09-03 19:54:52.842+00
3aa10f6b-f34b-4393-a92d-6adbaf62a341	disk_usage	gauge	45.200000	{}	2025-09-03 19:55:52.843+00
48f82743-0b05-442c-ab5e-a60a3431735c	cpu_usage	gauge	6.000000	{}	2025-09-03 19:56:52.843+00
cc930b05-9fb9-4d10-9506-cc91cc1ce5bc	uptime	gauge	1568.978934	{}	2025-09-03 19:57:52.844+00
385fb79a-bd55-4d30-b96a-8fc3e0de2e98	cpu_usage	gauge	6.000000	{}	2025-09-03 19:58:52.844+00
5c3514cd-8af4-4fd2-a486-6b98e99f0c25	uptime	gauge	1688.979852	{}	2025-09-03 19:59:52.845+00
5e717742-4951-430b-9a53-aeecde1ca642	disk_usage	gauge	45.200000	{}	2025-09-03 20:00:52.846+00
f1b54236-975d-4deb-9eec-e20f51177742	disk_usage	gauge	45.200000	{}	2025-09-03 20:01:52.847+00
eab6c182-0af4-42e1-86e8-cb67965b6ac0	memory_usage	gauge	71.520000	{}	2025-09-03 20:02:52.847+00
916fd47a-1073-4a0a-963e-5c92904b6e03	uptime	gauge	1928.983856	{}	2025-09-03 20:03:52.849+00
dd4cabe9-f214-4323-ab0d-72de0b2a8c81	memory_usage	gauge	73.470000	{}	2025-09-03 20:04:52.85+00
1e4162db-96f2-4673-93d3-1f315f00231e	cpu_usage	gauge	6.000000	{}	2025-09-03 22:38:47.7+00
13abe68e-42c9-49e5-a68f-7fa0afb364b8	memory_usage	gauge	76.450000	{}	2025-09-03 22:43:22.426+00
da99d20a-3e0b-4015-af81-cfc3b7c93046	disk_usage	gauge	45.200000	{}	2025-09-03 22:44:22.432+00
fd62e1bf-88e9-42c8-a3ff-997cf9565b0a	cpu_usage	gauge	6.000000	{}	2025-09-03 22:45:22.432+00
dcb04f7f-3de5-4024-82b7-3d166eae171d	disk_usage	gauge	45.200000	{}	2025-09-03 22:46:22.431+00
cfcdfe7a-fbb8-40aa-ad41-f67f3fa61e46	memory_usage	gauge	76.640000	{}	2025-09-03 22:52:22.433+00
f87072bf-de0d-42dd-b488-8a8783b2d588	cpu_usage	gauge	6.000000	{}	2025-09-03 22:53:22.433+00
ca0d4955-7831-42c8-ac96-dab586c87245	uptime	gauge	909.205624	{}	2025-09-03 22:54:22.433+00
91f83dea-3ac3-4086-ae49-3d647666cc92	disk_usage	gauge	45.200000	{}	2025-09-03 22:55:22.433+00
9b94188d-45e4-4e2c-b2d3-1eb424bf0715	disk_usage	gauge	45.200000	{}	2025-09-03 22:56:22.433+00
2846dafa-9f4f-48bd-8665-3a76b607dba2	memory_usage	gauge	75.450000	{}	2025-09-03 22:57:22.435+00
48fa8098-5896-4186-bbe9-a6e53c0dfa0b	disk_usage	gauge	45.200000	{}	2025-09-03 22:58:22.436+00
0a384884-8762-46c6-b641-f5dc5147a505	memory_usage	gauge	75.720000	{}	2025-09-03 22:59:22.435+00
89f959e5-45c9-476c-ad44-b5140ea67318	cpu_usage	gauge	5.000000	{}	2025-09-04 15:37:51.813+00
e933dd78-b521-46bf-9175-b3764f09c1f8	memory_usage	gauge	79.650000	{}	2025-09-04 15:37:51.813+00
0a3e9f24-5ba4-4915-aaa4-7add5e3c1e72	disk_usage	gauge	45.200000	{}	2025-09-04 15:37:51.813+00
79bcd37f-d19c-4d8a-be23-9760d0edc48f	uptime	gauge	69.423221	{}	2025-09-04 15:37:51.813+00
1777bf1d-44b6-4f3c-99a6-aee5441badc8	uptime	gauge	129.423990	{}	2025-09-04 15:38:51.814+00
a4a46dd8-34c8-404b-ad0e-abec31b7b30e	cpu_usage	gauge	5.000000	{}	2025-09-04 15:39:51.814+00
af2fe4ba-f857-46ec-ae73-cad6f0982473	uptime	gauge	249.425761	{}	2025-09-04 15:40:51.816+00
c4721779-7d80-4f55-a64d-f832fc95059a	disk_usage	gauge	45.200000	{}	2025-09-04 15:41:51.818+00
6c7c6c8a-628b-4cdc-bc39-0827559b277a	memory_usage	gauge	79.200000	{}	2025-09-04 15:42:51.818+00
8799431c-707a-49f8-a046-233c2db904c2	cpu_usage	gauge	5.000000	{}	2025-09-04 15:43:51.818+00
a0292152-e1ed-4a7f-b737-ff628897f4da	uptime	gauge	489.428900	{}	2025-09-04 15:44:51.819+00
62dd9c33-732c-42d9-92f0-c80138e814f6	memory_usage	gauge	79.720000	{}	2025-09-04 15:45:51.818+00
0cdb3667-7636-445b-9b32-93a2f9b4f023	memory_usage	gauge	79.550000	{}	2025-09-04 15:46:51.819+00
e106b772-aa68-4da1-add6-54eb1cda6a46	memory_usage	gauge	79.650000	{}	2025-09-04 15:47:51.819+00
5ee2783a-f41e-43f9-8453-6d2a824f9872	uptime	gauge	729.429106	{}	2025-09-04 15:48:51.819+00
b0e74264-d674-443c-956b-0b7ef7d26541	cpu_usage	gauge	5.000000	{}	2025-09-04 15:49:51.82+00
d95d85a9-f2bd-46f2-b7f6-a3d90dfbedda	uptime	gauge	849.430116	{}	2025-09-04 15:50:51.82+00
a4144f76-d6bc-4586-8848-626d368d47d6	disk_usage	gauge	45.200000	{}	2025-09-04 15:51:51.82+00
83b6b690-b100-49cc-9ccd-300b6955ff22	disk_usage	gauge	45.200000	{}	2025-09-04 15:52:51.82+00
4d0ad497-f430-4cc0-8ec3-c85f9cad087d	disk_usage	gauge	45.200000	{}	2025-09-04 15:53:51.82+00
c0d10670-8eb6-4d4f-9d95-2cd15426efa5	memory_usage	gauge	81.490000	{}	2025-09-04 15:54:51.82+00
29993e96-b00f-4420-be4a-02b13ea283ab	cpu_usage	gauge	5.000000	{}	2025-09-04 15:55:51.821+00
082befd1-8682-49e3-b27f-7581524e6c97	uptime	gauge	1209.431755	{}	2025-09-04 15:56:51.822+00
3aacf8c1-73f6-43ff-875d-2f962426bae2	memory_usage	gauge	81.650000	{}	2025-09-04 15:57:51.823+00
6f2d92bf-ab2e-4117-bc0d-da2f8b83077b	memory_usage	gauge	82.020000	{}	2025-09-04 15:58:51.823+00
bc6d52b4-90ed-488c-a1db-6a98a7f4f0d7	memory_usage	gauge	81.490000	{}	2025-09-04 15:59:51.823+00
847fc152-8486-4918-b162-f0e5a0da0f88	disk_usage	gauge	45.200000	{}	2025-09-04 16:00:51.824+00
47a873aa-4400-494f-b602-40f56a0d5c10	disk_usage	gauge	45.200000	{}	2025-09-04 16:01:51.824+00
96f2d218-8beb-4d3f-9400-d261a09081ea	memory_usage	gauge	81.750000	{}	2025-09-04 16:02:51.824+00
411f4782-957d-4aae-8a89-f9917b21c6af	cpu_usage	gauge	5.000000	{}	2025-09-04 16:03:51.824+00
b34f64f4-274b-4620-9547-c871170f792a	uptime	gauge	1689.434714	{}	2025-09-04 16:04:51.825+00
18c96dc5-6d6e-4353-b8f9-05f960ccbec2	disk_usage	gauge	45.200000	{}	2025-09-04 16:05:51.826+00
88192813-a453-4547-ba09-46d3a78a4b58	disk_usage	gauge	45.200000	{}	2025-09-04 16:06:51.826+00
3853e3be-342d-4478-b489-f8a6fa2fca6b	cpu_usage	gauge	5.000000	{}	2025-09-04 16:07:51.827+00
b2a90117-a07a-49a8-b7e1-a09eaee964b5	uptime	gauge	1929.437999	{}	2025-09-04 16:08:51.828+00
5a0ba12a-1317-46a1-a4f6-ee6a50faf7eb	memory_usage	gauge	72.840000	{}	2025-09-04 16:09:51.828+00
191455e9-5259-400c-b541-0b558998fb97	cpu_usage	gauge	5.000000	{}	2025-09-04 19:24:07.86+00
ce25cca6-489c-4023-9c38-148a47e6c2e9	disk_usage	gauge	45.200000	{}	2025-09-04 19:24:07.861+00
57d22ae5-588c-4de1-a56d-aac415979aef	memory_usage	gauge	76.270000	{}	2025-09-04 19:25:07.861+00
20385a93-1d88-49f6-8f46-cc646f088355	cpu_usage	gauge	5.000000	{}	2025-09-04 19:26:07.861+00
28af6b18-1e3c-48f3-b616-baeafb0373ac	uptime	gauge	249.322188	{}	2025-09-04 19:27:07.862+00
9a8fd849-a7d5-4295-96e4-b1fd66e7c208	disk_usage	gauge	45.200000	{}	2025-09-04 19:28:07.867+00
589260f9-4e40-4a10-87aa-7f03bbc68146	memory_usage	gauge	76.170000	{}	2025-09-04 19:29:07.867+00
79f11cc0-7c11-4537-9523-9eab3430f002	disk_usage	gauge	45.200000	{}	2025-09-04 19:30:07.867+00
e93e2158-1772-4b85-a844-13cf6708ccfb	cpu_usage	gauge	5.000000	{}	2025-09-04 19:31:07.867+00
593d72dd-c3c3-4bcf-8c96-7b0aedac84cd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:06:58.363+00
0893102a-0363-4391-a7d1-34eeb64d6325	disk_usage	gauge	45.200000	{}	2025-09-03 17:54:13.555+00
fa43c723-4aba-42f7-a486-8b4bfd41d3fa	disk_usage	gauge	45.200000	{}	2025-09-03 17:55:13.556+00
50e1b3c4-a8ad-41b8-8955-2fdad02d73c6	memory_usage	gauge	75.230000	{}	2025-09-03 17:56:13.556+00
a55d2163-2da1-4907-b52a-dea522662699	memory_usage	gauge	75.210000	{}	2025-09-03 17:57:13.556+00
38fd8e2b-5a24-43c7-b847-4859659c685f	memory_usage	gauge	75.190000	{}	2025-09-03 17:58:13.556+00
115af0da-7dc1-4667-9ba8-aa8a54e7fc42	cpu_usage	gauge	6.000000	{}	2025-09-03 17:59:13.556+00
13a45bac-62d8-4fca-9c90-56718fc2c79a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:37:05.744+00
0677e501-c2f6-4b2d-9db9-2b1352f1b645	uptime	gauge	188.376412	{}	2025-09-03 18:38:05.745+00
6abfbccb-b0cf-4405-90e9-68d7e469bc11	cpu_usage	gauge	6.000000	{}	2025-09-03 18:39:05.746+00
dbc428a1-b101-4682-9624-a28c53baafc5	memory_usage	gauge	70.700000	{}	2025-09-03 18:40:05.751+00
a81177eb-85db-48f5-a78d-4e2623142d18	memory_usage	gauge	71.970000	{}	2025-09-03 20:00:52.846+00
43c08327-4da4-44f9-8f1e-003743e15c7d	cpu_usage	gauge	6.000000	{}	2025-09-03 20:01:52.847+00
2e51a069-5c28-4f80-b2ef-0ef03e4a25c6	cpu_usage	gauge	6.000000	{}	2025-09-03 20:02:52.847+00
37ef5706-fe19-4551-bd92-16a5fea57364	disk_usage	gauge	45.200000	{}	2025-09-03 20:03:52.849+00
d907a157-a14a-4f6a-aa5d-fd0551530dea	cpu_usage	gauge	6.000000	{}	2025-09-03 20:04:52.85+00
3b40a473-0260-4c16-a786-a772cf864671	memory_usage	gauge	75.900000	{}	2025-09-03 22:38:47.7+00
b25bc745-19b4-40ef-bab2-1da16c3d1f36	uptime	gauge	249.198592	{}	2025-09-03 22:43:22.426+00
acba1d14-e4fb-40fd-95e7-f0afc892d2e3	memory_usage	gauge	75.820000	{}	2025-09-03 22:44:22.432+00
4e253faa-a5aa-4400-8ec4-945a1aad58ca	disk_usage	gauge	45.200000	{}	2025-09-03 22:45:22.432+00
8d605bcf-75d7-4808-b7a8-b98c2493fb5d	uptime	gauge	429.203828	{}	2025-09-03 22:46:22.431+00
dd15b989-a8bb-46c4-8e4c-f3e81813a4d2	memory_usage	gauge	75.450000	{}	2025-09-03 22:47:22.431+00
9eda040b-2762-4f6c-9340-4fbda809cc0e	memory_usage	gauge	75.350000	{}	2025-09-03 22:48:22.432+00
5808b170-c4c7-46da-a624-0f0da09f7745	disk_usage	gauge	45.200000	{}	2025-09-03 22:49:22.432+00
24efbc80-e83d-4ea2-a4ee-36ebc19e3e13	cpu_usage	gauge	5.000000	{}	2025-09-04 15:38:51.814+00
bf1baf0a-bdda-4235-8b7f-b043eefc3664	uptime	gauge	189.424675	{}	2025-09-04 15:39:51.814+00
c5f00303-ceb7-40a0-895f-310c4e003bbc	memory_usage	gauge	79.150000	{}	2025-09-04 15:40:51.815+00
0c8755e6-9848-44bf-9315-89a3936273d5	memory_usage	gauge	79.100000	{}	2025-09-04 15:41:51.818+00
b1b4b72a-9f47-4c9c-8d5d-a0d9cadbc9ca	disk_usage	gauge	45.200000	{}	2025-09-04 15:42:51.818+00
2d390e56-6315-4deb-a6e5-bbb6303797e2	memory_usage	gauge	79.170000	{}	2025-09-04 15:43:51.818+00
2412bdde-3af3-43f7-98b3-48020bd0eadb	cpu_usage	gauge	5.000000	{}	2025-09-04 15:44:51.819+00
9c0b9a46-680d-49f9-a45f-62dac8e291c3	uptime	gauge	549.428219	{}	2025-09-04 15:45:51.818+00
f482a944-e2e4-4792-882c-45566fd591d9	cpu_usage	gauge	5.000000	{}	2025-09-04 15:46:51.819+00
e385f257-bde5-4364-99b2-c4cc31330b79	uptime	gauge	669.429092	{}	2025-09-04 15:47:51.819+00
c636be47-1d31-4633-a5d1-9b6b198e2192	cpu_usage	gauge	5.000000	{}	2025-09-04 15:48:51.819+00
d71e3508-9ec0-49e5-90cd-1ce798ef845f	uptime	gauge	789.429826	{}	2025-09-04 15:49:51.82+00
4e866139-1255-492d-a690-46b6db8ad47f	disk_usage	gauge	45.200000	{}	2025-09-04 15:50:51.82+00
c2ff5ed8-2b9a-4168-8db2-fd31567cea03	memory_usage	gauge	80.470000	{}	2025-09-04 15:51:51.82+00
d6d887cc-f63e-42e4-9174-edd9e2540b5c	memory_usage	gauge	83.860000	{}	2025-09-04 15:52:51.82+00
5ce57159-5c70-4acc-b2e4-992a7dbc5ecd	cpu_usage	gauge	5.000000	{}	2025-09-04 15:53:51.82+00
3c5bb9f6-2a54-4bf5-b1fd-d50e050990aa	uptime	gauge	1089.430481	{}	2025-09-04 15:54:51.82+00
fac790b3-4df5-406a-9362-8f8a5d36f6ad	memory_usage	gauge	81.850000	{}	2025-09-04 15:55:51.821+00
4e4fa8dc-da5d-4adb-a74b-6464646d5389	memory_usage	gauge	81.850000	{}	2025-09-04 15:56:51.822+00
d5b7000a-a8e6-4ae2-8e33-1c8f43a00e8f	cpu_usage	gauge	5.000000	{}	2025-09-04 15:57:51.822+00
40413919-3a0f-412d-a223-b0db96c3ba34	uptime	gauge	1329.433323	{}	2025-09-04 15:58:51.823+00
6e1c7ee3-3d72-4d7b-a151-9bbaee7f3b12	cpu_usage	gauge	5.000000	{}	2025-09-04 15:59:51.823+00
e3db9e09-c26a-40ee-bbc0-bee309bd2378	memory_usage	gauge	76.060000	{}	2025-09-04 19:24:07.86+00
b4f79de1-97d9-4ea2-be5f-d00f8467118f	uptime	gauge	69.320613	{}	2025-09-04 19:24:07.861+00
20d41fcc-0a6e-4369-982c-e2d81766c5ce	cpu_usage	gauge	5.000000	{}	2025-09-04 19:25:07.86+00
d3620071-f10f-454e-a2b7-784e32b1e996	uptime	gauge	189.321257	{}	2025-09-04 19:26:07.861+00
bf65717e-d8d3-4320-962e-a912c937ca4c	memory_usage	gauge	76.370000	{}	2025-09-04 19:27:07.862+00
869d2679-d6e5-4059-894c-b9970c5cbbe1	uptime	gauge	309.326712	{}	2025-09-04 19:28:07.867+00
9229e40a-5b68-4403-99d5-81d270b86b25	disk_usage	gauge	45.200000	{}	2025-09-04 19:29:07.867+00
07d5fdee-c30f-4c48-ab49-c04eb4a5f3ed	cpu_usage	gauge	5.000000	{}	2025-09-04 19:30:07.867+00
3d11b740-2100-4e78-8c58-524fb54ce842	uptime	gauge	489.327396	{}	2025-09-04 19:31:07.867+00
93e6425a-cd96-43df-9f05-cbd0b479d7ae	cpu_usage	gauge	5.000000	{}	2025-09-04 19:32:07.868+00
de611ecc-566c-4319-8009-a12769d43d00	cpu_usage	gauge	5.000000	{}	2025-09-04 19:33:07.868+00
fee8bc45-4dbc-4760-b989-ca78f801bf32	cpu_usage	gauge	5.000000	{}	2025-09-04 19:34:07.868+00
8acbb507-299b-4a6b-a712-78472fd2971a	uptime	gauge	729.327755	{}	2025-09-04 19:35:07.868+00
8395cd7e-0d77-4547-8fb7-6b17ee21124a	disk_usage	gauge	45.200000	{}	2025-09-04 19:36:07.869+00
6b5b27bc-dcec-4ee3-b179-66542167461d	cpu_usage	gauge	5.000000	{}	2025-09-04 19:37:07.869+00
83e97789-d2b2-45f0-996e-69b99acb1664	uptime	gauge	909.329565	{}	2025-09-04 19:38:07.87+00
3501c26c-677e-45a1-85e2-f598bba476ae	cpu_usage	gauge	5.000000	{}	2025-09-04 19:39:07.87+00
328de195-8d51-4d51-8b26-4a4751aa9f55	cpu_usage	gauge	5.000000	{}	2025-09-04 19:40:07.871+00
6d983a23-4d05-42d6-9756-ccb663d9bfda	uptime	gauge	1089.331298	{}	2025-09-04 19:41:07.871+00
a7477aba-3d80-4a42-b633-b7f5c6162a3e	disk_usage	gauge	45.200000	{}	2025-09-04 19:42:07.872+00
571517fc-ccc8-4e13-8461-0f172a0f95ba	disk_usage	gauge	45.200000	{}	2025-09-04 19:43:07.872+00
3270b2f8-ae62-43b3-984d-7510153e341e	cpu_usage	gauge	5.000000	{}	2025-09-04 19:44:07.873+00
f264be77-01b9-4b93-97b9-e53b28176b3d	memory_usage	gauge	77.680000	{}	2025-09-04 19:45:07.873+00
0b833db6-eb96-4f68-aac5-070552871639	disk_usage	gauge	45.200000	{}	2025-09-04 19:46:07.873+00
6ad77af4-1d0f-475b-aae4-068dc9f1be8f	disk_usage	gauge	45.200000	{}	2025-09-04 19:47:07.873+00
5e1ae0dc-e544-4f2d-b304-0f620e290f31	cpu_usage	gauge	5.000000	{}	2025-09-04 19:48:07.875+00
d0a8593b-2c98-4a1f-a983-87875d121e6b	uptime	gauge	1569.335522	{}	2025-09-04 19:49:07.875+00
569c357b-0a6d-4b08-9925-e1cf0c2037ba	cpu_usage	gauge	5.000000	{}	2025-09-04 19:50:07.877+00
7a416cc0-395a-42e0-bbdd-a160b7fff21a	disk_usage	gauge	45.200000	{}	2025-09-03 17:06:58.363+00
a6ec7fef-6afe-452c-b9ea-f37824eadda1	uptime	gauge	369.357701	{}	2025-09-03 17:54:13.555+00
a3a83037-b16d-4c7e-80dc-6922a2c2b917	memory_usage	gauge	75.740000	{}	2025-09-03 17:55:13.555+00
33626b8c-4a44-435a-a570-ce9c80bbd2d9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:56:13.556+00
bdc3104b-55c6-4c75-9106-67250c87f3ba	uptime	gauge	549.359220	{}	2025-09-03 17:57:13.557+00
3eed3566-5372-4b88-9ab1-39d83a411812	disk_usage	gauge	45.200000	{}	2025-09-03 17:58:13.556+00
96a50edf-4a1d-469b-aec7-25cdfd261f7b	disk_usage	gauge	45.200000	{}	2025-09-03 17:59:13.556+00
125b0a8a-f8d0-41c7-a25c-908c6f4b61f2	memory_usage	gauge	70.110000	{}	2025-09-03 18:37:05.744+00
398c8e92-55ff-4546-85eb-1b7f57084993	disk_usage	gauge	45.200000	{}	2025-09-03 18:38:05.745+00
e85d4367-266e-4d27-8688-14cb3831e21a	disk_usage	gauge	45.200000	{}	2025-09-03 18:39:05.746+00
57d02880-7bfc-4b0c-9aa3-253fd06b9ba4	disk_usage	gauge	45.200000	{}	2025-09-03 18:40:05.751+00
7cbec849-9e88-49e5-96a4-0c15c7328b6c	disk_usage	gauge	45.200000	{}	2025-09-03 22:38:47.7+00
6de7b247-f8f2-4c75-872c-61baa3c1154e	disk_usage	gauge	45.200000	{}	2025-09-03 22:43:22.426+00
317d2c6b-4106-4896-9119-e4d7cc22164a	cpu_usage	gauge	6.000000	{}	2025-09-03 22:44:22.432+00
beec7608-4586-4c9b-a543-9422b5e4dbb8	uptime	gauge	729.205462	{}	2025-09-03 22:51:22.433+00
a9488c7e-4cd8-4e7a-b875-cfb605e20a19	memory_usage	gauge	79.680000	{}	2025-09-04 15:38:51.814+00
16b39603-e621-4059-95af-ec1f07a71cc6	memory_usage	gauge	79.010000	{}	2025-09-04 15:39:51.814+00
d4f29e77-cfbf-4af5-b5b8-5576f9aa7fb6	disk_usage	gauge	45.200000	{}	2025-09-04 15:40:51.816+00
3c7faee3-91fb-4521-89fd-f71a6f7cc990	cpu_usage	gauge	5.000000	{}	2025-09-04 15:41:51.818+00
cf474128-44ab-4c9e-ab02-6e6f216f36c5	uptime	gauge	369.428368	{}	2025-09-04 15:42:51.818+00
92f71623-db7d-4055-a3c6-1aaee3b59660	disk_usage	gauge	45.200000	{}	2025-09-04 15:43:51.818+00
8f988321-ab8e-4d5d-9a23-9365e00f308a	memory_usage	gauge	79.230000	{}	2025-09-04 15:44:51.819+00
3edc8d3a-583c-4b88-ad4e-ba7cf0ee8f41	disk_usage	gauge	45.200000	{}	2025-09-04 15:45:51.818+00
8bc86d53-bec5-4dd8-b6ca-c0102baedbd2	disk_usage	gauge	45.200000	{}	2025-09-04 15:46:51.819+00
8e3563d8-f02a-41c4-b6d1-5aaf1a9b284d	disk_usage	gauge	45.200000	{}	2025-09-04 15:47:51.819+00
58fba4e5-107e-466d-a6e6-eef0a7558417	disk_usage	gauge	45.200000	{}	2025-09-04 15:48:51.819+00
c4210970-5fcc-4c2e-83ef-3f8ecfb9a214	disk_usage	gauge	45.200000	{}	2025-09-04 15:49:51.82+00
c094fa92-c308-4446-96c7-6c5e5977d5d6	memory_usage	gauge	81.780000	{}	2025-09-04 15:50:51.82+00
69f47b63-9983-430d-bb33-80669650ed33	cpu_usage	gauge	5.000000	{}	2025-09-04 15:51:51.82+00
3168f11e-cece-4d85-82ee-29eb101058ff	uptime	gauge	969.430085	{}	2025-09-04 15:52:51.82+00
04e8d17a-37ec-4a65-bfd5-f520960c1df5	memory_usage	gauge	81.120000	{}	2025-09-04 15:53:51.82+00
d947af29-5dc4-4ad1-8ff0-92f644512476	disk_usage	gauge	45.200000	{}	2025-09-04 15:54:51.82+00
b4245930-5c31-4eaa-b9d7-366ce13184cb	disk_usage	gauge	45.200000	{}	2025-09-04 15:55:51.821+00
4d429824-5315-424f-8695-bb78b37244db	cpu_usage	gauge	5.000000	{}	2025-09-04 15:56:51.821+00
53126bce-a241-48c9-ab95-412b6585a407	uptime	gauge	1269.432807	{}	2025-09-04 15:57:51.823+00
658e0dc8-c3a1-40aa-8e67-b641c91fe6f9	disk_usage	gauge	45.200000	{}	2025-09-04 15:58:51.823+00
8fa12fe0-a09d-421a-88cb-f3513473eeda	disk_usage	gauge	45.200000	{}	2025-09-04 15:59:51.823+00
6d22f868-6e55-45f0-9af5-d3db448360be	cpu_usage	gauge	5.000000	{}	2025-09-04 16:00:51.823+00
fd174b69-6466-4dfa-a565-c8c7cf3da66b	uptime	gauge	1509.434048	{}	2025-09-04 16:01:51.824+00
58db9d6f-cc6f-410a-9ab2-a7a52c3522e7	disk_usage	gauge	45.200000	{}	2025-09-04 16:02:51.824+00
fc1c9acb-cfc9-4e4c-a560-45961cfa348c	disk_usage	gauge	45.200000	{}	2025-09-04 16:03:51.824+00
1a9ee630-601b-4e24-abf6-9464f89ee5da	disk_usage	gauge	45.200000	{}	2025-09-04 16:04:51.825+00
6720346f-f27c-4ca0-ba11-0adbc0b244e7	cpu_usage	gauge	5.000000	{}	2025-09-04 16:05:51.825+00
324754c7-b376-4d55-adc6-08527e62e764	uptime	gauge	1809.436198	{}	2025-09-04 16:06:51.826+00
ed72a007-35fe-4adc-bea1-39382ee55e2f	disk_usage	gauge	45.200000	{}	2025-09-04 16:07:51.827+00
40d81c67-9ec2-41f3-8d9a-9b98fcdbdabb	disk_usage	gauge	45.200000	{}	2025-09-04 16:08:51.828+00
fef4502f-ad44-4e81-8347-93ae6d0f79e6	cpu_usage	gauge	5.000000	{}	2025-09-04 16:09:51.828+00
a0014c43-7a22-47ad-9c73-3d249a57cdfc	disk_usage	gauge	45.200000	{}	2025-09-04 19:25:07.861+00
580b5ae3-78df-4c88-a91c-8753bb6895f5	memory_usage	gauge	76.200000	{}	2025-09-04 19:26:07.861+00
e46e679d-fb09-4043-a0e2-66799ee8f6dc	disk_usage	gauge	45.200000	{}	2025-09-04 19:27:07.862+00
57a252b8-d049-47ed-833c-2ac0dad1fc8b	cpu_usage	gauge	5.000000	{}	2025-09-04 19:28:07.867+00
3df69789-6f5d-4b5b-b1ad-387c0fa036fa	uptime	gauge	369.327392	{}	2025-09-04 19:29:07.867+00
4a59d0ec-fc7d-49fe-86ca-209bb57972df	uptime	gauge	429.327234	{}	2025-09-04 19:30:07.867+00
9a4146ca-2bfd-40df-b2b6-0798ad61d1ec	memory_usage	gauge	76.560000	{}	2025-09-04 19:31:07.867+00
6bd69375-6931-4eff-b645-b1d212b281bd	uptime	gauge	549.327669	{}	2025-09-04 19:32:07.868+00
407b0546-22d1-4465-857c-a6ebd97e875c	memory_usage	gauge	76.390000	{}	2025-09-04 19:33:07.868+00
3db9507c-bcde-4ec7-b0ee-4ad724206ddb	uptime	gauge	669.328409	{}	2025-09-04 19:34:07.868+00
6aa4194d-3a5b-4a58-9d79-f57e0b41743f	disk_usage	gauge	45.200000	{}	2025-09-04 19:35:07.868+00
f76b6292-aabb-48d7-b056-f66630f5f02e	memory_usage	gauge	75.660000	{}	2025-09-04 19:36:07.869+00
1b1bcfc8-0485-4d4b-8e94-ac2da8fe39ad	memory_usage	gauge	75.940000	{}	2025-09-04 19:37:07.869+00
7a2c6b7a-b596-4f57-a077-abe55927bce6	cpu_usage	gauge	5.000000	{}	2025-09-04 19:38:07.869+00
57d1a13b-ebed-43d5-93aa-bacb5a746410	uptime	gauge	969.330192	{}	2025-09-04 19:39:07.87+00
d6ba55d1-01fb-4121-b2e2-9dd17ed709e5	disk_usage	gauge	45.200000	{}	2025-09-04 19:40:07.871+00
d038c877-6aa3-4aca-8726-84b30f40cb31	disk_usage	gauge	45.200000	{}	2025-09-04 19:41:07.871+00
06c4c34f-38d0-466e-a8dc-f2c9860c557c	cpu_usage	gauge	5.000000	{}	2025-09-04 19:42:07.872+00
2e658129-0e1d-4753-959a-a12cc7e31e90	uptime	gauge	1209.332387	{}	2025-09-04 19:43:07.872+00
8e39f876-9744-4fe2-9c9e-3ed1331eb135	disk_usage	gauge	45.200000	{}	2025-09-04 19:44:07.873+00
83d1ecca-3696-4524-8ca5-72ee9d5a0ee4	uptime	gauge	1329.333215	{}	2025-09-04 19:45:07.873+00
11cc0e75-32ff-4d4d-a83b-8bd0b096a68b	cpu_usage	gauge	5.000000	{}	2025-09-04 19:46:07.873+00
9f974cd1-3b4b-4f55-b4ef-ecad9c8fcfe6	uptime	gauge	1449.333379	{}	2025-09-04 19:47:07.873+00
fe0d6611-cb14-4ded-8b6c-c6a0da8e4cdf	disk_usage	gauge	45.200000	{}	2025-09-04 19:48:07.875+00
76c419b7-945e-45c5-8688-3914c019206c	cpu_usage	gauge	5.000000	{}	2025-09-04 19:49:07.875+00
7e9579f7-dd22-4b6a-9f2a-17236ba3c31e	memory_usage	gauge	77.050000	{}	2025-09-04 19:50:07.877+00
d3999f84-bc63-4d6a-becd-106f2b9d3eb0	uptime	gauge	2048.122778	{}	2025-09-03 17:06:58.363+00
4896ae26-f6ff-4088-9c84-cddda7ec4eaa	cpu_usage	gauge	6.000000	{}	2025-09-03 17:54:27.524+00
ac87095f-210a-428d-bac4-16ace962d72b	disk_usage	gauge	45.200000	{}	2025-09-03 17:55:27.525+00
85019642-0b78-4a91-a122-8b80b1d7261d	memory_usage	gauge	75.210000	{}	2025-09-03 17:56:27.526+00
e2e46ab7-d5b6-4e8e-b8ad-def8d83b8914	uptime	gauge	548.019306	{}	2025-09-03 17:57:27.527+00
8576239a-8cfc-490f-b0b6-455df384d31b	disk_usage	gauge	45.200000	{}	2025-09-03 17:58:27.529+00
885d2ac0-b8f3-4ad5-899f-3aff2a091a81	memory_usage	gauge	75.050000	{}	2025-09-03 17:59:27.53+00
abd0bc4c-9dc6-470f-8bf6-1ea7d9af2ad0	uptime	gauge	128.375530	{}	2025-09-03 18:37:05.744+00
c2e27a77-cfcd-43c2-9095-1614ed4f6eb2	cpu_usage	gauge	6.000000	{}	2025-09-03 18:38:05.745+00
1397ff4a-987d-4f15-95b1-5a8819cf5feb	uptime	gauge	248.377534	{}	2025-09-03 18:39:05.746+00
701cbdd9-7c31-42d7-918b-77139c98ab18	cpu_usage	gauge	6.000000	{}	2025-09-03 18:40:05.751+00
59d7996c-0bff-4e57-926e-9ad594c9bfee	uptime	gauge	608.882887	{}	2025-09-03 22:38:47.7+00
a8edace0-e3ed-4205-9185-d1c54b36a0f9	memory_usage	gauge	76.680000	{}	2025-09-03 22:45:22.432+00
b161db70-a616-4b7f-b309-0e8041baa7b8	cpu_usage	gauge	6.000000	{}	2025-09-03 22:46:22.431+00
130216b3-f24a-4daf-9f34-8efdcdc0ada3	cpu_usage	gauge	6.000000	{}	2025-09-03 22:47:22.431+00
745f8a3c-b0e9-494e-83c6-5bbb8b1865a4	uptime	gauge	549.204492	{}	2025-09-03 22:48:22.432+00
8bb7a64b-7eb2-4934-a069-780fd310a564	memory_usage	gauge	75.210000	{}	2025-09-03 22:49:22.432+00
d4bef841-eeb1-4b47-ae0a-67f65ea2d321	disk_usage	gauge	45.200000	{}	2025-09-03 22:52:22.433+00
7e80fdc5-58df-4ee5-923b-4b1657743c33	memory_usage	gauge	76.410000	{}	2025-09-03 22:53:22.433+00
39120bef-9157-4856-b66e-2f2d148fd2e9	disk_usage	gauge	45.200000	{}	2025-09-03 22:54:22.433+00
4feb1a9f-fd7e-4c8c-8af8-812f0aa317ba	cpu_usage	gauge	6.000000	{}	2025-09-03 22:55:22.432+00
38bdb497-3242-4163-86e8-128bf18a769c	uptime	gauge	1029.205940	{}	2025-09-03 22:56:22.433+00
1497a634-d409-460c-aa1e-b14ade1c1ec1	disk_usage	gauge	45.200000	{}	2025-09-03 22:57:22.435+00
48695400-b77c-41b8-906e-a75432bfd5f8	cpu_usage	gauge	6.000000	{}	2025-09-03 22:58:22.435+00
e2bb5057-702b-46cc-8f11-460a2c03abb5	uptime	gauge	1209.207837	{}	2025-09-03 22:59:22.435+00
5a32b78c-bad2-4de4-9826-d8bb73cdaf20	disk_usage	gauge	45.200000	{}	2025-09-04 15:38:51.814+00
2fee5a3f-a0cc-4c54-96bd-c1569e99a36a	disk_usage	gauge	45.200000	{}	2025-09-04 15:39:51.814+00
b7712ec0-e0c9-4626-b902-0c4f912e4cc5	cpu_usage	gauge	5.000000	{}	2025-09-04 15:40:51.815+00
b2d01d94-ed52-438c-8076-00bfef56d004	uptime	gauge	309.428146	{}	2025-09-04 15:41:51.818+00
9caffa7e-81e8-4137-861d-0ac13dab95c4	cpu_usage	gauge	5.000000	{}	2025-09-04 15:42:51.818+00
7a833274-e55b-45ab-8c64-220b8cff329b	uptime	gauge	429.427878	{}	2025-09-04 15:43:51.818+00
dbf28ff5-62b7-4cc0-94a8-9d3321e51940	disk_usage	gauge	45.200000	{}	2025-09-04 15:44:51.819+00
85085bf9-4846-4788-85af-b934a0f9394e	cpu_usage	gauge	5.000000	{}	2025-09-04 15:45:51.818+00
1847ec9e-6145-482d-98ae-ba8bbef0ad22	uptime	gauge	609.429065	{}	2025-09-04 15:46:51.819+00
f22aec48-0e4a-4710-9133-0712b67e4909	cpu_usage	gauge	5.000000	{}	2025-09-04 15:47:51.819+00
896e3576-397e-45d8-9d3a-2724d921535e	memory_usage	gauge	79.800000	{}	2025-09-04 15:48:51.819+00
49871e08-a8c0-4340-8b58-a36408205a80	memory_usage	gauge	79.900000	{}	2025-09-04 15:49:51.82+00
1b7b4c90-3dd2-4c34-81d1-472a6c40fcd5	cpu_usage	gauge	5.000000	{}	2025-09-04 15:50:51.82+00
97f6e568-a7cb-4c78-8ccd-ea6bc0f79bc1	uptime	gauge	909.429964	{}	2025-09-04 15:51:51.82+00
b238bf62-913c-4ccf-86e0-448ea6e21988	cpu_usage	gauge	5.000000	{}	2025-09-04 15:52:51.82+00
344d01fc-884c-4c12-9bcc-2c8be0a1cc25	uptime	gauge	1029.430589	{}	2025-09-04 15:53:51.82+00
9814cf18-ee94-4383-be52-f10e8af2a87b	cpu_usage	gauge	5.000000	{}	2025-09-04 15:54:51.82+00
dbdae56b-a4e1-4582-8879-092cb65ca94d	uptime	gauge	1149.430989	{}	2025-09-04 15:55:51.821+00
190ff45d-ebca-4889-b415-ad5eb97ed175	disk_usage	gauge	45.200000	{}	2025-09-04 15:56:51.822+00
4ec7ed6c-8f84-4f07-ab3d-891bc55ef6a9	disk_usage	gauge	45.200000	{}	2025-09-04 15:57:51.823+00
8048f83c-4a0c-4671-876e-09512a6cae1b	cpu_usage	gauge	5.000000	{}	2025-09-04 15:58:51.823+00
d9c2575d-9cff-42ff-a7ba-15e827196637	uptime	gauge	1389.432882	{}	2025-09-04 15:59:51.823+00
e399932f-6962-4387-8427-e8cf86c514e5	uptime	gauge	129.320625	{}	2025-09-04 19:25:07.861+00
f7d94b2e-5191-4f90-b662-2fbc4e54bea1	disk_usage	gauge	45.200000	{}	2025-09-04 19:26:07.861+00
40ae1d2a-f0f3-4d19-8e18-6c3b6def1f3e	cpu_usage	gauge	5.000000	{}	2025-09-04 19:27:07.862+00
e84b587a-cc7b-45e9-9ad4-49d65f881f2e	memory_usage	gauge	76.530000	{}	2025-09-04 19:28:07.867+00
7ea7401e-1db8-4401-850f-86f8221dcb54	cpu_usage	gauge	5.000000	{}	2025-09-04 19:29:07.867+00
74fef9b4-1be9-4e69-a355-b76fdfeb4bb3	memory_usage	gauge	80.120000	{}	2025-09-03 17:07:36.221+00
8be7605b-b5c1-4198-a78c-5f058ea11eae	uptime	gauge	2229.467882	{}	2025-09-03 17:08:36.221+00
bdd8e51d-eae5-4007-8db1-09774b775f44	cpu_usage	gauge	6.000000	{}	2025-09-03 17:09:36.221+00
ead6c676-13b4-47fa-b818-1e3256c7cf4b	uptime	gauge	2349.468163	{}	2025-09-03 17:10:36.221+00
36297ecd-83c5-466c-b470-db98989be65d	disk_usage	gauge	45.200000	{}	2025-09-03 17:11:36.221+00
8ea22fe9-785c-44a5-b04a-4a6ae7c0003f	memory_usage	gauge	73.530000	{}	2025-09-03 17:12:36.22+00
e740de99-d085-4022-9a0c-cc0bbcdbed85	cpu_usage	gauge	6.000000	{}	2025-09-03 17:13:36.221+00
0a31e880-087e-4274-9cca-d3c360c26d59	uptime	gauge	2589.468058	{}	2025-09-03 17:14:36.221+00
86ff9aeb-b5d1-4b0b-b805-847567172cf2	memory_usage	gauge	75.220000	{}	2025-09-03 17:54:27.524+00
6a17db26-03fa-4475-9c54-a80ad217e97a	uptime	gauge	428.016571	{}	2025-09-03 17:55:27.525+00
7e65e53f-f303-4c72-a1b2-254f62df01fc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:56:27.526+00
60f1de7c-bac0-4478-bd0e-328448e4958b	disk_usage	gauge	45.200000	{}	2025-09-03 17:57:27.527+00
54635bcd-af81-42fd-bb1c-3bfda26eca10	memory_usage	gauge	75.050000	{}	2025-09-03 17:58:27.529+00
6f8a6cd2-445d-49ea-85c1-85ec63e9bdf0	uptime	gauge	668.021710	{}	2025-09-03 17:59:27.53+00
169970be-9766-41a7-8bc7-62811826f851	cpu_usage	gauge	6.000000	{}	2025-09-03 18:00:27.53+00
3ad2eeb5-4454-497a-860b-935a1452b03b	disk_usage	gauge	45.200000	{}	2025-09-03 18:01:27.53+00
2ece1b96-db65-40c6-81cb-3fc62b8e9b94	cpu_usage	gauge	6.000000	{}	2025-09-03 18:02:27.531+00
212618b7-d799-42fe-b841-2af6f0f66282	cpu_usage	gauge	6.000000	{}	2025-09-03 18:03:27.532+00
f1dbb1de-ada8-49f6-bdf6-ebeb520bce7f	uptime	gauge	968.023437	{}	2025-09-03 18:04:27.531+00
8c86c25d-b27f-48cd-9282-074de256f897	disk_usage	gauge	45.200000	{}	2025-09-03 18:05:27.532+00
81c16fd1-0399-41db-9d83-aaef8118b9dd	cpu_usage	gauge	6.000000	{}	2025-09-03 18:06:27.532+00
9fd4feb2-a7dc-4a58-b653-aa569c80dca2	disk_usage	gauge	45.200000	{}	2025-09-03 18:37:05.744+00
ef331e35-59ab-4a4d-9623-d7e5974f82ba	memory_usage	gauge	70.110000	{}	2025-09-03 18:38:05.745+00
20395fed-ee74-478d-95ee-36930dcacc80	memory_usage	gauge	70.040000	{}	2025-09-03 18:39:05.746+00
25f47245-208e-460b-818d-08ce3fe9b30c	uptime	gauge	308.382555	{}	2025-09-03 18:40:05.751+00
2f24c0c1-8ddf-4347-b588-1c728f9234d8	disk_usage	gauge	45.200000	{}	2025-09-03 22:47:22.431+00
df6755a4-bbc8-4742-b883-481bba856dd7	disk_usage	gauge	45.200000	{}	2025-09-03 22:48:22.432+00
980f47d9-8ec7-4830-ba60-5cedacdfa223	uptime	gauge	609.204809	{}	2025-09-03 22:49:22.432+00
4d5771fc-4350-4937-b38e-4b1145aa04c8	disk_usage	gauge	45.200000	{}	2025-09-03 22:50:22.432+00
c484ba85-6fba-4193-9fc9-b92eb4496219	cpu_usage	gauge	6.000000	{}	2025-09-03 22:51:22.433+00
d3bf3303-f1e1-40d2-aca9-727c5559473b	cpu_usage	gauge	6.000000	{}	2025-09-03 22:52:22.433+00
f66ad9bc-e0b9-4a91-bc59-f38a226599ee	uptime	gauge	849.205342	{}	2025-09-03 22:53:22.433+00
4037fd69-ef60-49ca-ad30-0d2c2a382204	cpu_usage	gauge	6.000000	{}	2025-09-03 22:54:22.433+00
c78972df-fb37-4f21-965c-cd25d60a3e13	uptime	gauge	969.204961	{}	2025-09-03 22:55:22.433+00
178dab0e-14b5-4fa1-8ad9-03e1c606786a	memory_usage	gauge	75.590000	{}	2025-09-03 22:56:22.433+00
87e72eb2-f395-4996-884f-4dbdcd23d758	cpu_usage	gauge	6.000000	{}	2025-09-03 22:57:22.435+00
73d42e16-de97-4626-b106-1dc78a0d8ffa	uptime	gauge	1149.207957	{}	2025-09-03 22:58:22.436+00
ab3d7081-613d-4ad9-b9cf-188186aeeec7	disk_usage	gauge	45.200000	{}	2025-09-03 22:59:22.435+00
2e7a8843-11cb-46e4-b9c8-287f271d3183	memory_usage	gauge	85.290000	{}	2025-09-04 16:00:51.823+00
932174bb-2daf-4e50-87f8-db0c723806a1	memory_usage	gauge	81.260000	{}	2025-09-04 16:01:51.824+00
c972fc22-32bc-4478-a831-c772f04913cf	cpu_usage	gauge	5.000000	{}	2025-09-04 16:02:51.824+00
404ca4a4-262a-4bc7-90ba-88ffed8f1533	uptime	gauge	1629.433996	{}	2025-09-04 16:03:51.824+00
cecceac6-1c37-494f-acf0-9b53e2c617e2	cpu_usage	gauge	5.000000	{}	2025-09-04 16:04:51.824+00
16e0e3e5-aba5-4501-9b71-c6aa37e03209	uptime	gauge	1749.435712	{}	2025-09-04 16:05:51.826+00
84cfe8da-d4ee-44cb-910c-69832d22fb5e	memory_usage	gauge	78.620000	{}	2025-09-04 16:06:51.826+00
8a962fad-c3cb-4ec4-b9ce-014e995f9d2c	memory_usage	gauge	78.960000	{}	2025-09-04 16:07:51.827+00
cb239907-b82a-4cff-a8cc-521327fb1a1b	memory_usage	gauge	73.320000	{}	2025-09-04 16:08:51.828+00
ea12e781-8a6b-4d2c-8e17-165098e7b235	uptime	gauge	1989.438231	{}	2025-09-04 16:09:51.828+00
162d6bd1-b182-476b-8cf0-32c8700b75d6	memory_usage	gauge	76.490000	{}	2025-09-04 19:30:07.867+00
5b48cbde-d28b-4280-94a9-b5d8f614c182	disk_usage	gauge	45.200000	{}	2025-09-04 19:31:07.867+00
ea7c10bd-ba8f-46f3-a6e6-37b15a16526b	memory_usage	gauge	76.290000	{}	2025-09-04 19:32:07.868+00
6d0802c6-c854-421c-9fe5-36cc8a845399	uptime	gauge	609.328423	{}	2025-09-04 19:33:07.868+00
ed0a36dc-3382-4b89-8c92-aa9f06e08c29	disk_usage	gauge	45.200000	{}	2025-09-04 19:34:07.868+00
472fa289-42f7-4612-9b1c-f968b3b4894b	memory_usage	gauge	78.910000	{}	2025-09-04 19:35:07.868+00
47029836-0830-4fc6-a725-069b9fd21d61	cpu_usage	gauge	5.000000	{}	2025-09-04 19:36:07.869+00
deb1c92b-fff2-4eed-b77c-7a5b08bc0793	uptime	gauge	849.329501	{}	2025-09-04 19:37:07.869+00
02304c5e-55a7-4a8e-80b9-f02294454f01	disk_usage	gauge	45.200000	{}	2025-09-04 19:38:07.87+00
7a2dca8b-ec2e-4595-8706-1b6d4eed7a8d	disk_usage	gauge	45.200000	{}	2025-09-04 19:39:07.87+00
5065c05e-ffaf-44ce-8df1-e46db17bda1c	uptime	gauge	1029.330800	{}	2025-09-04 19:40:07.871+00
205c2ed6-d553-42ab-bc7c-198d1b2b1269	cpu_usage	gauge	5.000000	{}	2025-09-04 19:41:07.871+00
d0317f6f-c7f8-449b-8972-10303ee95874	uptime	gauge	1149.331779	{}	2025-09-04 19:42:07.872+00
b204bbf7-5bce-4a70-ab66-663534b4864c	cpu_usage	gauge	5.000000	{}	2025-09-04 19:43:07.872+00
ff83e9fb-23fb-4bc6-8675-e1b8153635ee	memory_usage	gauge	75.810000	{}	2025-09-04 19:44:07.873+00
38cc1d9f-5df7-4493-890d-2b7110dfc53e	cpu_usage	gauge	5.000000	{}	2025-09-04 19:45:07.873+00
e23ade93-2a57-4e28-8337-9095c9e9fc9d	uptime	gauge	1389.333091	{}	2025-09-04 19:46:07.873+00
f1547705-99fc-454c-988c-5b6b4b109bd2	cpu_usage	gauge	5.000000	{}	2025-09-04 19:47:07.873+00
dcc37953-c209-4458-beb8-a69f639b769b	uptime	gauge	1509.334672	{}	2025-09-04 19:48:07.875+00
b3f9e400-7874-48b5-be0e-1c3119511162	memory_usage	gauge	76.490000	{}	2025-09-04 19:49:07.875+00
bb3e8f4a-0fe0-4da2-a0de-bacb4e9ed6ef	uptime	gauge	1629.337474	{}	2025-09-04 19:50:07.877+00
236d6964-7a71-41df-84f4-04d97e2d7ec1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:07:36.221+00
d114cdd1-0aeb-4d4a-8dfe-f99df59c2820	disk_usage	gauge	45.200000	{}	2025-09-03 17:08:36.221+00
292611b6-3a52-41f3-93e5-ae4a8545ef9a	memory_usage	gauge	79.950000	{}	2025-09-03 17:09:36.221+00
813b7d5c-fc08-49bd-890b-9343774339a6	disk_usage	gauge	45.200000	{}	2025-09-03 17:10:36.221+00
3d97f592-5fe2-4964-9aea-0f79f71f4b2d	memory_usage	gauge	73.880000	{}	2025-09-03 17:11:36.22+00
69497139-d446-4fd7-aeab-af3ff8afcf78	disk_usage	gauge	45.200000	{}	2025-09-03 17:12:36.22+00
98e35d0f-ac4d-40b7-abc2-e32e7efaed0d	memory_usage	gauge	73.490000	{}	2025-09-03 17:13:36.221+00
e6d3ccf4-3408-4e3c-853a-330d6c8ea879	memory_usage	gauge	73.510000	{}	2025-09-03 17:14:36.221+00
0d8f4e92-c80e-459a-a4d1-b86de4072424	disk_usage	gauge	45.200000	{}	2025-09-03 17:54:27.524+00
6ce9b273-3a82-4d04-87dc-c327a69b28b1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:55:27.525+00
526b7d07-448a-4336-84d2-c79b15a5e949	disk_usage	gauge	45.200000	{}	2025-09-03 17:56:27.526+00
851ce068-7cf3-423a-9d41-2e5146c489e0	memory_usage	gauge	75.230000	{}	2025-09-03 17:57:27.527+00
b8d910d9-671c-4b10-bd92-9853637e37f1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:58:27.529+00
b08304d6-07f6-4a6f-9ac1-03c39742dcde	cpu_usage	gauge	6.000000	{}	2025-09-03 17:59:27.53+00
5a198919-d6fb-47e4-9706-66f6780519c7	disk_usage	gauge	45.200000	{}	2025-09-03 18:00:27.53+00
d2cb15c8-30f8-4667-bf9d-d1b3edf9bea6	cpu_usage	gauge	6.000000	{}	2025-09-03 18:01:27.53+00
f13bcd40-4af8-482f-a5df-33b7165630f3	uptime	gauge	848.022909	{}	2025-09-03 18:02:27.531+00
1529c2ee-1f90-42d0-b515-a9cf056960fb	memory_usage	gauge	74.840000	{}	2025-09-03 18:03:27.532+00
edb9b1b8-0673-4b62-b85c-779b362f3235	memory_usage	gauge	74.800000	{}	2025-09-03 18:04:27.531+00
60c19e2b-1dca-45d2-9894-322ee288abf6	memory_usage	gauge	75.230000	{}	2025-09-03 18:05:27.532+00
9c220060-78ad-42cc-a9d6-f97c03b9de6e	uptime	gauge	1088.024047	{}	2025-09-03 18:06:27.532+00
c84cbaa8-2e57-42c7-8244-a985f3bdec92	cpu_usage	gauge	6.000000	{}	2025-09-03 22:48:22.432+00
e39a6655-2a6b-41bd-a946-5179ba7b3d41	cpu_usage	gauge	6.000000	{}	2025-09-03 22:49:22.432+00
b6dac9d4-dcdd-4591-bf4b-74de44011b68	uptime	gauge	1449.433748	{}	2025-09-04 16:00:51.824+00
f13af2dc-41ab-4e21-a8ab-f3f5a804c046	cpu_usage	gauge	5.000000	{}	2025-09-04 16:01:51.824+00
5fa0ff4d-3e04-4ee0-9ccd-58b1fbd49f42	uptime	gauge	1569.434272	{}	2025-09-04 16:02:51.824+00
aadf4324-7283-4a32-8eb9-7fd80b0cf9c6	memory_usage	gauge	81.440000	{}	2025-09-04 16:03:51.824+00
349b651d-8afa-42c6-91c9-4f545af0b629	memory_usage	gauge	81.520000	{}	2025-09-04 16:04:51.824+00
99ab40e8-c63c-4bd1-aff1-cb12c80b3e0a	memory_usage	gauge	83.160000	{}	2025-09-04 16:05:51.825+00
a3ed0aec-aa8f-4c62-919f-47f7ee68877b	cpu_usage	gauge	5.000000	{}	2025-09-04 16:06:51.826+00
8602112d-8be9-4833-8966-9e6f9b109082	uptime	gauge	1869.437302	{}	2025-09-04 16:07:51.827+00
023320b2-2ca0-4aad-8c55-4971ecee4609	cpu_usage	gauge	5.000000	{}	2025-09-04 16:08:51.828+00
d9bf36a5-3383-4306-889c-6dba93756978	disk_usage	gauge	45.200000	{}	2025-09-04 16:09:51.828+00
929473af-64c0-4efa-b104-2cb62a1467eb	disk_usage	gauge	45.200000	{}	2025-09-04 19:32:07.868+00
36af52a8-1850-4bab-91b2-3f102dfa32a7	disk_usage	gauge	45.200000	{}	2025-09-04 19:33:07.868+00
6f671451-e680-482e-aa3f-c297f8c93d17	memory_usage	gauge	76.600000	{}	2025-09-04 19:34:07.868+00
a9554921-a432-4ea5-ac63-fc71c9595990	cpu_usage	gauge	5.000000	{}	2025-09-04 19:35:07.868+00
8f59d54e-dc75-417f-b152-82539ceeaafd	uptime	gauge	789.329053	{}	2025-09-04 19:36:07.869+00
3344ad23-d21c-4698-a72d-f3dbc785467f	disk_usage	gauge	45.200000	{}	2025-09-04 19:37:07.869+00
741d2a07-3916-4689-b4b8-cbaf0508e5af	memory_usage	gauge	75.950000	{}	2025-09-04 19:38:07.869+00
d7925172-5596-447d-b9a7-03a9f90f650d	memory_usage	gauge	75.670000	{}	2025-09-04 19:39:07.87+00
58146070-cfbe-4d46-93be-e1507432b06e	memory_usage	gauge	76.380000	{}	2025-09-04 19:40:07.871+00
a0cc3788-0d58-437a-bec7-3960d836dda4	memory_usage	gauge	76.020000	{}	2025-09-04 19:41:07.871+00
d0bbc9a5-2c0a-4061-ae1b-590b8e4dd327	memory_usage	gauge	75.810000	{}	2025-09-04 19:42:07.872+00
21c71947-67bd-4065-95e5-da8648a5f18b	memory_usage	gauge	76.180000	{}	2025-09-04 19:43:07.872+00
899810a1-1b49-4539-b0ac-45121a6adf70	uptime	gauge	1269.332659	{}	2025-09-04 19:44:07.873+00
48ed2aea-c1f3-4ad8-af23-5085f35222f0	disk_usage	gauge	45.200000	{}	2025-09-04 19:45:07.873+00
cba61d81-5f08-4adf-88dd-98943fe74ce3	memory_usage	gauge	76.670000	{}	2025-09-04 19:46:07.873+00
a4dae7a6-1f61-4c94-87e5-0e75ba87829e	memory_usage	gauge	76.350000	{}	2025-09-04 19:47:07.873+00
81024017-fa9a-4c44-ab27-bdb554ca0a38	memory_usage	gauge	76.220000	{}	2025-09-04 19:48:07.875+00
cfd9e098-b873-4544-b6d2-da8edf809731	disk_usage	gauge	45.200000	{}	2025-09-04 19:49:07.875+00
f0fad8fd-8914-4f4b-942e-b4b5ca4f5c26	disk_usage	gauge	45.200000	{}	2025-09-04 19:50:07.877+00
0572fab4-6e27-4e80-bf20-c22f0c62f588	uptime	gauge	2169.468543	{}	2025-09-03 17:07:36.221+00
892718eb-007f-467b-88c5-84694281ccfc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:08:36.221+00
5ae5424b-e5d1-4772-b993-350f5474d5e7	uptime	gauge	2289.467913	{}	2025-09-03 17:09:36.221+00
e3bc98e5-7418-45d1-af6b-75134fe34cd7	memory_usage	gauge	73.680000	{}	2025-09-03 17:10:36.221+00
4b74e76b-ff21-4f16-aea2-4170c19cd4e2	cpu_usage	gauge	6.000000	{}	2025-09-03 17:11:36.22+00
2f4ca8af-026f-46cb-9a33-276c2f3af12a	uptime	gauge	2469.467082	{}	2025-09-03 17:12:36.22+00
3cfcabcd-fb43-45b9-932c-d4c18a25b750	disk_usage	gauge	45.200000	{}	2025-09-03 17:13:36.221+00
1db7fbcb-7b7d-4949-bfb9-231314cac727	cpu_usage	gauge	6.000000	{}	2025-09-03 17:14:36.221+00
d0b96b46-fcfa-49ab-8a87-063861a82ce8	uptime	gauge	368.016447	{}	2025-09-03 17:54:27.525+00
68359b1d-23a6-4341-b633-c4de9f4186e6	memory_usage	gauge	75.670000	{}	2025-09-03 17:55:27.525+00
50ec496b-9d12-4292-ab2f-c23a392181d5	uptime	gauge	488.018111	{}	2025-09-03 17:56:27.526+00
c14682bb-fed2-4419-a995-71d87faa0766	cpu_usage	gauge	6.000000	{}	2025-09-03 17:57:27.527+00
2c82278f-526f-40d8-858e-70db204dc8c2	uptime	gauge	608.020676	{}	2025-09-03 17:58:27.529+00
70133665-f38a-4c47-a9b3-80910be059e3	disk_usage	gauge	45.200000	{}	2025-09-03 17:59:27.53+00
e9ef07f0-d62b-4c28-97e0-cddb07d4ba2d	memory_usage	gauge	75.200000	{}	2025-09-03 18:00:27.53+00
62ec8bff-59f3-40fe-b06d-5d5485cbc3d7	uptime	gauge	788.022343	{}	2025-09-03 18:01:27.53+00
3d73aba9-d330-4482-aa57-a6e97a80ed52	disk_usage	gauge	45.200000	{}	2025-09-03 18:02:27.531+00
cb7012f1-0c7b-47c0-aaf2-1c7ebd5cc162	disk_usage	gauge	45.200000	{}	2025-09-03 18:03:27.532+00
3a2d122d-8f25-4bf5-b2dd-31098714b5ae	cpu_usage	gauge	6.000000	{}	2025-09-03 18:04:27.531+00
71dbc44c-ed20-46ca-8a74-8813dceea871	uptime	gauge	1028.023922	{}	2025-09-03 18:05:27.532+00
8ce09bc1-7386-41cc-97f3-bf0a8c7140bc	disk_usage	gauge	45.200000	{}	2025-09-03 18:06:27.532+00
d350a091-c014-4924-9e6b-a6b5b7077458	cpu_usage	gauge	6.000000	{}	2025-09-03 23:00:48.71+00
7f5087e5-17ab-4560-9b74-a1bf24b12522	disk_usage	gauge	45.200000	{}	2025-09-03 23:01:48.71+00
44bd279d-144b-4986-8e9a-37696d136ff9	disk_usage	gauge	45.200000	{}	2025-09-03 23:02:48.71+00
d9341aab-fc92-4e2d-9635-19fc7427bd27	cpu_usage	gauge	5.000000	{}	2025-09-04 16:11:34.298+00
1830f859-0b11-47b2-87fa-d7b41ebf3814	disk_usage	gauge	45.200000	{}	2025-09-04 16:11:34.299+00
8a155e71-01cc-4609-a4f9-7e506c3e03e6	uptime	gauge	129.257711	{}	2025-09-04 16:12:34.299+00
4b750a35-1d80-4183-b229-a6e521b8720d	disk_usage	gauge	45.200000	{}	2025-09-04 16:13:34.299+00
a63e9846-ec6a-4680-a3d1-b8eed309eac8	cpu_usage	gauge	5.000000	{}	2025-09-04 16:14:34.298+00
b99ce00a-2239-4b48-a1ad-8940b681ed90	cpu_usage	gauge	5.000000	{}	2025-09-04 19:51:07.878+00
77681e56-d379-4ac7-ace4-d55b0c7fc062	uptime	gauge	1749.339271	{}	2025-09-04 19:52:07.879+00
63630806-3d94-4183-a98b-0fbefd3b5aac	disk_usage	gauge	45.200000	{}	2025-09-04 19:53:07.88+00
4c28e6ec-95ca-417e-aee3-288741bb8aa3	memory_usage	gauge	76.580000	{}	2025-09-04 19:54:07.882+00
307d6a19-d565-4203-8d1d-286f3f531305	cpu_usage	gauge	5.000000	{}	2025-09-04 19:55:07.882+00
a30253e1-a394-416c-830e-d64e080736ff	memory_usage	gauge	78.710000	{}	2025-09-04 19:56:07.883+00
57ae799b-2aac-49c6-a0ba-5424594b09b1	memory_usage	gauge	78.390000	{}	2025-09-04 19:57:07.882+00
1744efcd-1354-41af-9960-8def656686be	disk_usage	gauge	45.200000	{}	2025-09-04 19:58:07.883+00
c032bc45-91ab-4086-92d0-7c0859583163	memory_usage	gauge	77.760000	{}	2025-09-04 19:59:07.884+00
9c4d6af7-62c3-4a69-98ee-979dd6758817	disk_usage	gauge	45.200000	{}	2025-09-04 20:00:07.884+00
bbe88557-7963-4f74-96e5-e2fa270d921a	cpu_usage	gauge	5.000000	{}	2025-09-04 20:01:07.885+00
1cde7d8c-173a-4208-8790-fd0b2d93f3fd	uptime	gauge	2349.345474	{}	2025-09-04 20:02:07.885+00
38d7a1e2-bac8-422f-b474-e055d5a0c487	cpu_usage	gauge	5.000000	{}	2025-09-04 20:03:07.885+00
b7792125-ad4e-4eb8-99f0-fca0953de2cb	uptime	gauge	2469.345630	{}	2025-09-04 20:04:07.886+00
cc9a0ba0-4b6f-44e0-ab4a-d3802d678b0b	uptime	gauge	2530.528663	{}	2025-09-04 20:05:09.069+00
9c73bb5b-3333-47e2-bd48-5f3a64b498b2	cpu_usage	gauge	5.000000	{}	2025-09-04 22:10:56.032+00
63a925f3-60a3-4b66-b1a8-06dae4d964c9	disk_usage	gauge	45.200000	{}	2025-09-04 22:11:56.033+00
75669daf-7536-400e-be25-c4afef955146	cpu_usage	gauge	5.000000	{}	2025-09-04 22:12:56.034+00
23510154-af20-4042-9f8d-7c4849e1a0bf	uptime	gauge	249.479717	{}	2025-09-04 22:13:56.035+00
a353fc5e-ad96-4f7a-b9e0-7930d387ab31	disk_usage	gauge	45.200000	{}	2025-09-03 17:07:36.221+00
20878942-e971-4f6a-9e0c-25bfc121064c	memory_usage	gauge	79.960000	{}	2025-09-03 17:08:36.221+00
9fb905e0-2c97-4a3d-9835-ec786020e6a4	disk_usage	gauge	45.200000	{}	2025-09-03 17:09:36.221+00
8068179f-2ea6-4804-a6f1-72a128807ecd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:10:36.221+00
ad4e9379-1e1f-458e-b32d-e0124a2af3c3	uptime	gauge	2409.467594	{}	2025-09-03 17:11:36.221+00
ce1347b7-0c85-45fc-9bb5-f9c6c02ac00c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:12:36.22+00
dd1ad1c9-89e4-4b81-823c-71a4f2f54920	uptime	gauge	2529.467712	{}	2025-09-03 17:13:36.221+00
d9a22324-15f5-4c71-bfeb-3aad0adae1d8	disk_usage	gauge	45.200000	{}	2025-09-03 17:14:36.221+00
fc93079c-382a-4c59-9f72-64bbe08ca364	memory_usage	gauge	76.080000	{}	2025-09-03 18:00:13.557+00
e3596281-30f4-4886-af1a-1760834382ed	cpu_usage	gauge	6.000000	{}	2025-09-03 18:01:13.557+00
f202489c-42df-4761-8eaa-2f4634322372	uptime	gauge	849.360087	{}	2025-09-03 18:02:13.557+00
42aed1aa-d076-4d8d-8d15-218d67339e2a	disk_usage	gauge	45.200000	{}	2025-09-03 18:03:13.558+00
e7a6074a-9845-4bad-8e32-fe4f2404d45b	disk_usage	gauge	45.200000	{}	2025-09-03 18:04:13.558+00
3b90f3b6-37a2-4edf-b275-d0120b877000	cpu_usage	gauge	6.000000	{}	2025-09-03 18:05:13.558+00
23ee16e0-ffbe-4b5f-abaf-2cdaf43a4379	uptime	gauge	1089.361612	{}	2025-09-03 18:06:13.559+00
7e9ea41f-dc12-4244-9c88-b377e4abae70	memory_usage	gauge	75.230000	{}	2025-09-03 23:00:48.711+00
2570f826-18c8-4c71-8c23-19c43dead8e9	uptime	gauge	129.187891	{}	2025-09-03 23:01:48.71+00
2ac9da2e-2555-45c0-8cc0-4deb24e0df95	memory_usage	gauge	74.970000	{}	2025-09-03 23:02:48.71+00
6e468650-f633-43f8-a7f4-7f9176c7a37f	memory_usage	gauge	73.140000	{}	2025-09-04 16:11:34.298+00
d0878d25-7d25-44c2-bcf5-efd077bcfa1a	uptime	gauge	69.257861	{}	2025-09-04 16:11:34.299+00
9cdea2c8-7344-4726-b5f3-024e7a4e42e9	disk_usage	gauge	45.200000	{}	2025-09-04 16:12:34.299+00
5be4f9f3-e5d8-4ba9-965e-b52936d32cdf	uptime	gauge	189.258408	{}	2025-09-04 16:13:34.299+00
02c651a9-6a92-4d15-9f41-fd16f64190dd	disk_usage	gauge	45.200000	{}	2025-09-04 16:14:34.299+00
7277ec0a-6035-4490-83a7-99d3ab51061f	disk_usage	gauge	45.200000	{}	2025-09-04 19:51:07.878+00
7acc46d4-8b84-4985-b4e2-3165d2a74cbe	memory_usage	gauge	76.270000	{}	2025-09-04 19:52:07.879+00
6abe4c9e-5eaf-46e0-a613-4184a0266703	cpu_usage	gauge	5.000000	{}	2025-09-04 19:53:07.88+00
89c18c03-0c36-40a7-b2d8-c01ef504b3fb	cpu_usage	gauge	5.000000	{}	2025-09-04 19:54:07.882+00
77bea24c-d264-4568-98ac-a8da88ba05e0	uptime	gauge	1929.342119	{}	2025-09-04 19:55:07.882+00
3a512aa1-6b18-4ea0-ab17-a99333757263	disk_usage	gauge	45.200000	{}	2025-09-04 19:56:07.883+00
29bcff6d-ffde-4536-9326-ff633d030c36	disk_usage	gauge	45.200000	{}	2025-09-04 19:57:07.882+00
b58f2dd3-11ba-4853-a3f3-05efa8ae3fd6	memory_usage	gauge	77.090000	{}	2025-09-04 19:58:07.883+00
490dfc09-98d4-48bb-b3ef-677d457a9ce3	cpu_usage	gauge	5.000000	{}	2025-09-04 19:59:07.884+00
13ecc88a-0480-4c81-b98f-35d0d6d0b6f1	memory_usage	gauge	71.280000	{}	2025-09-04 22:10:56.032+00
027bcd7a-92ba-4208-b934-eed2f7ccfe41	cpu_usage	gauge	5.000000	{}	2025-09-04 22:11:56.033+00
21466e09-031d-4c0a-bebb-962e169f7a9f	uptime	gauge	189.478951	{}	2025-09-04 22:12:56.034+00
848d0894-ac91-4e96-afc8-e66b0038b7cc	disk_usage	gauge	45.200000	{}	2025-09-04 22:13:56.035+00
faabcc97-3093-44fd-a9f0-551bc9db0faa	memory_usage	gauge	79.840000	{}	2025-09-03 17:07:58.362+00
100b15e2-7979-48ab-a55c-6d834cad30e0	uptime	gauge	2168.122447	{}	2025-09-03 17:08:58.363+00
06645b6d-55c6-4c45-a13f-8fa524da5cb5	disk_usage	gauge	45.200000	{}	2025-09-03 17:09:58.363+00
8953881f-413d-427e-a474-6dc9e4c9bf4b	uptime	gauge	729.359537	{}	2025-09-03 18:00:13.557+00
01aa07e1-c2db-484a-8fde-e31ca4469ac5	disk_usage	gauge	45.200000	{}	2025-09-03 18:01:13.557+00
93063b9f-8e4a-4acb-bbea-8928c2805bd1	memory_usage	gauge	74.820000	{}	2025-09-03 18:02:13.557+00
42c7211c-4aeb-4ec4-90a0-f0f01e983c39	cpu_usage	gauge	6.000000	{}	2025-09-03 18:03:13.558+00
1125b234-e8b1-421e-bbb6-925d306a4214	uptime	gauge	969.360463	{}	2025-09-03 18:04:13.558+00
09ac95d2-d741-4412-bdbc-97820384c5b1	disk_usage	gauge	45.200000	{}	2025-09-03 18:05:13.558+00
627bcda1-0afa-4d8a-8fc5-512ba932cec5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:06:13.559+00
dcc0778f-8c41-441d-95d0-0cfb17ea32e0	disk_usage	gauge	45.200000	{}	2025-09-03 23:00:48.711+00
50da5a45-7032-4a26-aa6c-6e3f828270c7	memory_usage	gauge	75.180000	{}	2025-09-03 23:01:48.71+00
8a845ea6-774c-4785-ba71-91eea26b6a4f	cpu_usage	gauge	6.000000	{}	2025-09-03 23:02:48.71+00
5a46201a-3efb-4589-a931-4b26325f761f	cpu_usage	gauge	5.000000	{}	2025-09-04 16:12:34.298+00
c0500ad6-8f72-4a5e-b9af-ee27bf1eb4ab	memory_usage	gauge	72.500000	{}	2025-09-04 16:13:34.299+00
3b94e0ac-a88e-4ab8-a9cf-8492457ad066	memory_usage	gauge	72.650000	{}	2025-09-04 16:14:34.299+00
100b2de3-abb4-41f0-ba23-c549429f6e2a	uptime	gauge	1689.338481	{}	2025-09-04 19:51:07.878+00
e854d6bd-28ee-4168-a484-b57c07940780	cpu_usage	gauge	5.000000	{}	2025-09-04 19:52:07.879+00
a392aace-660d-45ab-8f14-7a1902bd3313	uptime	gauge	1809.340149	{}	2025-09-04 19:53:07.88+00
12e176aa-08c4-4499-935a-6fc62aa234e9	disk_usage	gauge	45.200000	{}	2025-09-04 19:54:07.882+00
f172f7b1-0051-4cb7-af87-4f8cf8963fc9	disk_usage	gauge	45.200000	{}	2025-09-04 19:55:07.882+00
604e9831-8641-4240-b30e-121c1f5b6843	uptime	gauge	1989.342867	{}	2025-09-04 19:56:07.883+00
0d8bc315-db94-4b66-80db-f2868b660dd1	cpu_usage	gauge	5.000000	{}	2025-09-04 19:57:07.882+00
122229a5-02ec-4d4e-894d-7ad5891f8b76	uptime	gauge	2109.342993	{}	2025-09-04 19:58:07.883+00
557c20b4-ac1a-4660-a5da-c51039bd710b	disk_usage	gauge	45.200000	{}	2025-09-04 19:59:07.884+00
fc82eb4b-da93-4630-8584-69a9305b2d38	memory_usage	gauge	78.640000	{}	2025-09-04 20:00:07.884+00
0c449ee9-0393-4f41-9782-7d5c11265b75	uptime	gauge	2289.344848	{}	2025-09-04 20:01:07.885+00
26e27842-3d9a-4b9c-aaa1-823ffbead0f6	disk_usage	gauge	45.200000	{}	2025-09-04 20:02:07.885+00
3dc526f6-c6f6-4a31-9925-f597c4df18fa	memory_usage	gauge	79.630000	{}	2025-09-04 20:03:07.885+00
9e945632-ed23-41fd-a7cd-9b613f0826e3	cpu_usage	gauge	5.000000	{}	2025-09-04 20:04:07.885+00
468d9535-0108-4532-bad4-0e3ee6295832	disk_usage	gauge	45.200000	{}	2025-09-04 20:05:09.069+00
5c45af31-ba52-4b6e-8bee-a483a47c943f	disk_usage	gauge	45.200000	{}	2025-09-04 20:06:09.069+00
91275da2-60ad-4c05-a3e3-c91e71f62cf4	memory_usage	gauge	75.530000	{}	2025-09-04 20:07:09.069+00
8f0b3722-4fbf-47b4-9324-968a8eae09f8	uptime	gauge	2710.529036	{}	2025-09-04 20:08:09.069+00
1fb4c1ad-a7aa-4e58-ae2f-44b15d8db3c3	disk_usage	gauge	45.200000	{}	2025-09-04 20:09:09.069+00
c30487ed-c1d3-4905-805f-b9dd17b763a1	cpu_usage	gauge	5.000000	{}	2025-09-04 20:10:09.421+00
81a0eaf0-78f7-421d-bd75-a937d26f722b	uptime	gauge	2890.882023	{}	2025-09-04 20:11:09.422+00
40e1be49-5903-416f-ab18-50790b7d786c	memory_usage	gauge	74.830000	{}	2025-09-04 20:12:09.422+00
b5bea16d-2786-43a0-9523-877ad08ded32	uptime	gauge	3070.883855	{}	2025-09-04 20:14:09.424+00
dd610451-c3b0-4ba9-9243-4c360cd3d330	disk_usage	gauge	45.200000	{}	2025-09-04 20:15:09.424+00
cfb0513f-cba6-428c-9650-a88edcdcae3e	uptime	gauge	3250.884600	{}	2025-09-04 20:17:09.425+00
cb014eb0-e811-4980-83a0-fc4244f86038	disk_usage	gauge	45.200000	{}	2025-09-04 20:18:09.425+00
b907448d-413f-4d9b-b6b8-d50876a05317	cpu_usage	gauge	5.000000	{}	2025-09-04 20:19:09.426+00
4044e8f0-c19e-40c6-84b7-8770f38f1499	uptime	gauge	3490.886682	{}	2025-09-04 20:21:09.427+00
bb6a182e-21c9-4b7d-ba82-a1d2667280be	memory_usage	gauge	74.500000	{}	2025-09-04 20:22:09.427+00
c0a34c4a-7fcb-4776-a886-8e9bd8f74800	disk_usage	gauge	45.200000	{}	2025-09-04 20:23:09.427+00
5370cba1-f304-48b5-9176-9216e8b016d2	memory_usage	gauge	75.570000	{}	2025-09-04 20:24:09.428+00
68a3e84a-b6c0-4088-8848-8c44662a53d9	memory_usage	gauge	81.870000	{}	2025-09-04 20:25:09.428+00
fa3669e4-b042-4eed-9275-30397d888282	uptime	gauge	3850.888940	{}	2025-09-04 20:27:09.429+00
5e3dd9f2-7723-464f-bff5-5844a1d5ef85	memory_usage	gauge	78.620000	{}	2025-09-04 20:29:09.429+00
1f35a8b3-4971-48a6-94cd-ff8fa95f2081	cpu_usage	gauge	5.000000	{}	2025-09-04 20:30:19.874+00
c43c7269-95a8-4b4c-9129-ddb4818087ca	uptime	gauge	4101.334782	{}	2025-09-04 20:31:19.875+00
06187d25-5c57-478a-a7c1-a6d1234bc9d1	uptime	gauge	69.476967	{}	2025-09-04 22:10:56.032+00
c0450346-14ba-4c4e-b9cd-10fd8b74bb3f	uptime	gauge	129.477828	{}	2025-09-04 22:11:56.033+00
0f81ad73-c3de-484a-8619-a08baeeb548b	memory_usage	gauge	71.330000	{}	2025-09-04 22:12:56.034+00
0647fb0e-b217-434d-8e8f-f6332c59a092	memory_usage	gauge	71.260000	{}	2025-09-04 22:13:56.035+00
c32b9313-5f40-408f-a9f9-6117feb5096b	uptime	gauge	2108.121918	{}	2025-09-03 17:07:58.362+00
eb8f84c0-d3c2-4764-ad09-80c3d2cc2025	cpu_usage	gauge	6.000000	{}	2025-09-03 17:08:58.363+00
2f6d05e1-a0e0-4eee-90d8-7567dcff1880	memory_usage	gauge	79.980000	{}	2025-09-03 17:09:58.363+00
ee012111-4d0b-4ecc-b476-6c1e0f403da8	uptime	gauge	728.021665	{}	2025-09-03 18:00:27.53+00
44084259-0841-40bf-b10f-04defe4ab2c8	memory_usage	gauge	74.890000	{}	2025-09-03 18:01:27.53+00
989b8f45-487c-4818-a82e-a3e9d4ac5b66	memory_usage	gauge	74.780000	{}	2025-09-03 18:02:27.531+00
1fb291ec-32ad-4415-8c86-832adf081570	uptime	gauge	908.023937	{}	2025-09-03 18:03:27.532+00
6d497e94-d0ff-4592-b1a7-06407e2a9fea	disk_usage	gauge	45.200000	{}	2025-09-03 18:04:27.531+00
6e211289-0593-4e6b-b9b6-6428d8869743	cpu_usage	gauge	6.000000	{}	2025-09-03 18:05:27.532+00
0d660b70-dd23-4bcb-8d08-d721ae844da3	memory_usage	gauge	75.290000	{}	2025-09-03 18:06:27.532+00
336f07b6-23b8-46f5-a76f-54fb3c2fc286	uptime	gauge	69.188302	{}	2025-09-03 23:00:48.711+00
f68bb694-75ad-4d96-acc5-227a46ef9ac9	cpu_usage	gauge	6.000000	{}	2025-09-03 23:01:48.71+00
690c75d0-275c-41f4-9d03-a0645b9bbb9b	uptime	gauge	189.187510	{}	2025-09-03 23:02:48.71+00
933f1039-fccf-4d9f-bbaf-f2fd2c6857c0	memory_usage	gauge	72.420000	{}	2025-09-04 16:12:34.298+00
d526e471-dfbb-434c-88bd-abb810e307a4	cpu_usage	gauge	5.000000	{}	2025-09-04 16:13:34.299+00
f98e6d40-d853-4595-b9d2-7e81714fe39c	uptime	gauge	249.257759	{}	2025-09-04 16:14:34.299+00
206c8a74-d2ad-491e-942c-95ef5d26575f	memory_usage	gauge	76.680000	{}	2025-09-04 19:51:07.878+00
0473549c-10e7-4607-9c48-25f354d57797	disk_usage	gauge	45.200000	{}	2025-09-04 19:52:07.879+00
eb0152a1-e8be-49d0-b4a6-bd91ba9d750a	memory_usage	gauge	76.710000	{}	2025-09-04 19:53:07.88+00
e6d4aa63-b0a4-441a-85fe-ffd4be30bde2	uptime	gauge	1869.341979	{}	2025-09-04 19:54:07.882+00
ba366448-a2b8-4aee-9489-757596b8bd7e	memory_usage	gauge	81.560000	{}	2025-09-04 19:55:07.882+00
c817b1c7-e6c6-4f2f-b584-c3b33fed1660	cpu_usage	gauge	5.000000	{}	2025-09-04 19:56:07.883+00
c42f1554-cc63-41f6-8cbb-286ab17a5b6e	uptime	gauge	2049.342431	{}	2025-09-04 19:57:07.882+00
5b9bb821-86cd-46d2-89be-90a73b6f60cd	cpu_usage	gauge	5.000000	{}	2025-09-04 19:58:07.883+00
89515c20-af27-44be-97f3-7d0cc978923d	uptime	gauge	2169.344415	{}	2025-09-04 19:59:07.884+00
84a4a6cc-eec9-4d4f-bcb4-223665c30cc8	cpu_usage	gauge	5.000000	{}	2025-09-04 20:00:07.884+00
65376915-8e66-432e-803c-ceec6d2400ec	memory_usage	gauge	82.010000	{}	2025-09-04 20:01:07.885+00
cae3cff3-3dd0-4572-8f1e-f757a24a5f35	cpu_usage	gauge	5.000000	{}	2025-09-04 20:02:07.885+00
07c60fdf-060a-4bbe-8d28-347d48bd38c0	uptime	gauge	2409.345174	{}	2025-09-04 20:03:07.885+00
751a331d-63c0-4ab4-8fb5-de312329909a	memory_usage	gauge	80.040000	{}	2025-09-04 20:04:07.886+00
624f9207-05e5-4864-806e-e748933a11bb	memory_usage	gauge	87.510000	{}	2025-09-04 20:05:09.069+00
302f30cd-d600-4694-bfc4-3273dbf024f1	cpu_usage	gauge	5.000000	{}	2025-09-04 20:06:09.069+00
97ac8354-bb1b-4f36-9edc-8a92a48395da	uptime	gauge	2650.529331	{}	2025-09-04 20:07:09.069+00
b74f0f13-0b3d-4aa8-9180-890f38c4dbd3	disk_usage	gauge	45.200000	{}	2025-09-04 20:08:09.069+00
9c6cb6bc-100d-4e99-82ab-8f11c92cd871	cpu_usage	gauge	5.000000	{}	2025-09-04 20:09:09.069+00
1dd0efb7-04a1-407a-9475-9a7997fb5de0	uptime	gauge	2830.881512	{}	2025-09-04 20:10:09.421+00
3291e629-fd58-4b9a-a9c6-f69281f67fe9	uptime	gauge	2950.881890	{}	2025-09-04 20:12:09.422+00
1f7af0cc-41c2-42b8-9d1c-25f71bb026b3	memory_usage	gauge	77.110000	{}	2025-09-04 20:13:09.423+00
7566ab20-d53b-40a7-ae3f-ed4cf2c59230	memory_usage	gauge	75.370000	{}	2025-09-04 20:14:09.424+00
cb27490b-13c9-465c-91dc-2049455a77cf	uptime	gauge	3190.883771	{}	2025-09-04 20:16:09.424+00
589f8f91-cc03-4e62-82ca-7df67fea5877	memory_usage	gauge	76.770000	{}	2025-09-04 20:17:09.425+00
8c997f74-0ad6-46ac-81b0-fd8665b18caa	cpu_usage	gauge	5.000000	{}	2025-09-04 20:18:09.425+00
185fb409-a69c-4f4f-9dd7-e1d1692ef983	disk_usage	gauge	45.200000	{}	2025-09-04 20:19:09.426+00
b0f618da-be78-4c80-8eaf-2bcd39cc4c5c	disk_usage	gauge	45.200000	{}	2025-09-04 20:20:09.426+00
a507184f-6e4c-41c6-b0cc-b41afe4a6472	cpu_usage	gauge	5.000000	{}	2025-09-04 20:21:09.427+00
9d7e04ac-81ce-4290-a1ee-27827b4840ac	disk_usage	gauge	45.200000	{}	2025-09-04 20:22:09.427+00
792825b1-40e0-4acb-80e4-65f6ed860772	uptime	gauge	3670.888517	{}	2025-09-04 20:24:09.428+00
9e89cca7-f5d3-4f76-ac63-c02fcc9b39c2	uptime	gauge	3790.888888	{}	2025-09-04 20:26:09.429+00
d442bf0f-057e-4117-86a4-83252e2f2199	memory_usage	gauge	76.810000	{}	2025-09-04 20:27:09.429+00
201e4d20-1b03-43cb-8811-ef44d2e94ef8	disk_usage	gauge	45.200000	{}	2025-09-04 20:29:09.429+00
e55f67e3-0886-45e6-ac85-0c886cfb9b6a	memory_usage	gauge	88.650000	{}	2025-09-04 20:30:19.874+00
eed9da58-fcf5-4462-bf1d-4fb49f1d81ca	disk_usage	gauge	45.200000	{}	2025-09-04 20:31:19.875+00
326833ea-cfcd-4ca4-95c4-b162890338f9	disk_usage	gauge	45.200000	{}	2025-09-04 22:10:56.032+00
1d0f1456-2fdc-4176-8ad3-67225cd6bfda	memory_usage	gauge	71.320000	{}	2025-09-04 22:11:56.033+00
e66dc775-3238-4270-8268-267b898873e2	disk_usage	gauge	45.200000	{}	2025-09-04 22:12:56.034+00
2def5461-3f0e-4293-88dd-0b7479c728ae	cpu_usage	gauge	5.000000	{}	2025-09-04 22:13:56.035+00
e796b422-8602-40d3-8994-98cfadf97156	disk_usage	gauge	45.200000	{}	2025-09-03 17:07:58.362+00
221edaa3-1fab-483c-a59b-6715a102f5bf	memory_usage	gauge	79.950000	{}	2025-09-03 17:08:58.363+00
4aa10899-41f9-428f-aed8-e1c4d22776d9	uptime	gauge	2228.122903	{}	2025-09-03 17:09:58.363+00
b579e2ce-342a-44f1-afce-1358d1e93d05	cpu_usage	gauge	6.000000	{}	2025-09-03 18:07:13.56+00
9069e2f9-8ce7-4e5e-89ba-bea4eda65476	uptime	gauge	1209.363598	{}	2025-09-03 18:08:13.561+00
dbeed448-46a0-445f-aca7-e0895608e47b	disk_usage	gauge	45.200000	{}	2025-09-03 18:09:13.562+00
e0f5f6eb-c30a-41c0-9cab-2962221d2275	memory_usage	gauge	69.650000	{}	2025-09-03 18:10:13.563+00
1db6f0b9-3c25-4474-b222-8fc3f225ded5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:11:13.564+00
25bbf5d2-1419-4996-9d20-74254d9f4a3c	uptime	gauge	1449.368303	{}	2025-09-03 18:12:13.566+00
7a1df8c0-e8c2-4fa4-bbb5-b9cf2b3be5ee	memory_usage	gauge	69.540000	{}	2025-09-03 18:13:13.567+00
86fd848e-0449-4f71-9650-73937cd831f5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:14:13.568+00
925d0922-01cb-4816-96b2-1cd1f87aaaf2	uptime	gauge	1629.371522	{}	2025-09-03 18:15:13.569+00
f610c3b6-2594-492a-9c8f-c5e95243d658	memory_usage	gauge	69.550000	{}	2025-09-03 18:16:13.57+00
a8746a0c-84f5-4799-8f06-2481f5f3f327	memory_usage	gauge	69.460000	{}	2025-09-03 18:17:13.571+00
c3966036-c66d-411e-afbc-6a66ea0acc63	cpu_usage	gauge	6.000000	{}	2025-09-03 18:18:13.571+00
fb165fa6-1450-430b-98e7-310c5cf24a68	disk_usage	gauge	45.200000	{}	2025-09-04 16:15:56.019+00
e702248b-aa3e-40bf-8523-a5ff7ca3b439	uptime	gauge	128.878800	{}	2025-09-04 16:16:56.018+00
462bef63-1d7b-4717-be0b-b70fae4d2e28	uptime	gauge	2229.344306	{}	2025-09-04 20:00:07.884+00
bea40570-7a3c-4d6d-9c78-04643d7a90fc	disk_usage	gauge	45.200000	{}	2025-09-04 20:01:07.885+00
7f0ad3fb-5b5c-4fb1-90c9-4cdb682d5d35	memory_usage	gauge	79.590000	{}	2025-09-04 20:02:07.885+00
bc91c101-13f4-4774-92ec-2e178e129d57	disk_usage	gauge	45.200000	{}	2025-09-04 20:03:07.885+00
28b08cf2-0236-4ad0-b142-7a4849006927	disk_usage	gauge	45.200000	{}	2025-09-04 20:04:07.886+00
06394a70-1344-468f-bdd9-389932c13490	cpu_usage	gauge	5.000000	{}	2025-09-04 20:05:09.069+00
6d6ae2a9-1f5d-46ba-be9e-64a3e927fb98	uptime	gauge	2590.529300	{}	2025-09-04 20:06:09.069+00
9f67bb71-2e20-4f9f-82e1-7caabba34d3b	cpu_usage	gauge	5.000000	{}	2025-09-04 20:07:09.069+00
b3a9ca69-9608-4891-83dd-70387e3fd0e5	memory_usage	gauge	75.680000	{}	2025-09-04 20:08:09.069+00
fd6241a7-9505-4932-a178-585b9ca0fd33	uptime	gauge	2770.529267	{}	2025-09-04 20:09:09.069+00
a5a5da9b-101f-4a9a-87bd-5bfe9bf46cf5	memory_usage	gauge	88.750000	{}	2025-09-04 20:10:09.421+00
9cad6184-ca8d-4550-ad63-cbfd844d38a8	memory_usage	gauge	78.750000	{}	2025-09-04 20:11:09.422+00
7b1eb3a3-a01c-46f3-a9b0-6b46ac70c3cb	disk_usage	gauge	45.200000	{}	2025-09-04 20:12:09.422+00
d0484f64-b084-4219-b035-aa34bded3f9c	cpu_usage	gauge	5.000000	{}	2025-09-04 20:13:09.423+00
d1a9d473-900c-46f6-98f9-9a621a00f863	disk_usage	gauge	45.200000	{}	2025-09-04 20:14:09.424+00
e5b82beb-22bf-4915-8d68-17d050d1ac21	memory_usage	gauge	82.260000	{}	2025-09-04 20:15:09.424+00
1bcc7254-5865-4fee-a884-2bfba1615b87	cpu_usage	gauge	5.000000	{}	2025-09-04 20:16:09.424+00
f77eb191-8713-4811-9974-bbf18dfb400d	disk_usage	gauge	45.200000	{}	2025-09-04 20:17:09.425+00
5de1fe2f-b21e-4aa6-ad9f-06c4dd290fb7	memory_usage	gauge	77.160000	{}	2025-09-04 20:18:09.425+00
2b6cfe52-5820-4c3d-88aa-9c04a2fddc74	uptime	gauge	3430.886475	{}	2025-09-04 20:20:09.426+00
49b7ee61-d04e-4aa0-bcb2-169118b67f40	uptime	gauge	3550.886839	{}	2025-09-04 20:22:09.427+00
009d0e56-6a7f-49a3-9df0-d52d18e15ffd	cpu_usage	gauge	5.000000	{}	2025-09-04 20:23:09.427+00
da8d8f35-4eae-43a7-8e35-fefb9510c427	cpu_usage	gauge	5.000000	{}	2025-09-04 20:24:09.428+00
ebbeebbc-f556-4182-98d5-533290160a02	disk_usage	gauge	45.200000	{}	2025-09-04 20:25:09.428+00
6d0db91a-28ee-433e-b762-b796246947c5	memory_usage	gauge	87.860000	{}	2025-09-04 20:26:09.429+00
d39766bf-9a8c-4889-bb7b-9043b78a0190	disk_usage	gauge	45.200000	{}	2025-09-04 20:28:09.428+00
c141f4a0-6aef-4fc3-af69-0f4d5f3d9595	cpu_usage	gauge	5.000000	{}	2025-09-04 22:17:28.141+00
4f489387-505c-465a-872e-92a91d6fed3a	memory_usage	gauge	70.980000	{}	2025-09-04 22:17:28.141+00
cb5b83d0-a533-4bdb-84c5-1a248ecadd30	disk_usage	gauge	45.200000	{}	2025-09-04 22:17:28.141+00
8f316c4f-f6db-46a9-a97d-c7eaac596547	uptime	gauge	69.349799	{}	2025-09-04 22:17:28.141+00
b821c642-99e1-4177-8ed3-bc0f2285a975	memory_usage	gauge	70.800000	{}	2025-09-04 22:18:28.141+00
19669bdc-6812-4f48-907e-a1990cc58fcb	uptime	gauge	189.350526	{}	2025-09-04 22:19:28.142+00
0e91e9b6-c716-4c3d-ad54-6c0d20780487	memory_usage	gauge	72.290000	{}	2025-09-04 22:20:28.142+00
427c56d9-20ad-48d3-b227-c355d27e28ce	cpu_usage	gauge	5.000000	{}	2025-09-04 22:21:28.148+00
fbe849bb-c3cb-40d1-af5c-0daaca723782	cpu_usage	gauge	6.000000	{}	2025-09-03 17:07:58.362+00
5746d62b-e513-42c6-9d2e-8f99393d5a0d	disk_usage	gauge	45.200000	{}	2025-09-03 17:08:58.363+00
2a5edd04-1659-4a0e-a511-f444de268fd5	cpu_usage	gauge	6.000000	{}	2025-09-03 17:09:58.363+00
5cc6504b-3c58-4df5-b176-456986305ea0	memory_usage	gauge	75.270000	{}	2025-09-03 18:07:13.56+00
57d7667b-7ae3-4be9-8c1f-8541e2db0897	memory_usage	gauge	69.430000	{}	2025-09-03 18:08:13.561+00
b3ac7986-6a5d-4a9a-9978-a2892580c9f6	memory_usage	gauge	69.380000	{}	2025-09-03 18:09:13.562+00
aeae42ec-000e-46d5-9cc5-8ca7617c465f	uptime	gauge	1329.365581	{}	2025-09-03 18:10:13.563+00
979dd128-6120-4e7e-818e-7ac7e0203241	disk_usage	gauge	45.200000	{}	2025-09-03 18:11:13.564+00
a7d68c6d-943a-4c3f-9f02-6a0105a5ae24	memory_usage	gauge	69.710000	{}	2025-09-03 18:12:13.566+00
3d7912a7-7d36-4657-b01c-7a31d83b8236	uptime	gauge	1509.369883	{}	2025-09-03 18:13:13.567+00
4ab32e1d-537a-40e8-a4f8-d58c05457756	disk_usage	gauge	45.200000	{}	2025-09-03 18:14:13.568+00
0c9dc365-8d0a-4f73-8665-4e68ce7dad80	memory_usage	gauge	69.690000	{}	2025-09-03 18:15:13.569+00
ab1aa279-b17a-43af-af7e-48ac6febcabb	cpu_usage	gauge	6.000000	{}	2025-09-03 18:16:13.57+00
96774761-f531-41b7-ac8c-bc652b25b637	uptime	gauge	1749.373588	{}	2025-09-03 18:17:13.571+00
b9980662-4a56-4205-b318-b241da9fbf07	disk_usage	gauge	45.200000	{}	2025-09-03 18:18:13.571+00
f1f93333-cb34-4cbd-a3da-a0d970b27a3d	cpu_usage	gauge	5.000000	{}	2025-09-04 16:15:56.019+00
e9bc12fd-43d8-458d-bc2e-d78d037d983c	disk_usage	gauge	45.200000	{}	2025-09-04 16:16:56.018+00
1b9ee61d-e8fe-437f-be71-e8a18bca9cb7	memory_usage	gauge	77.670000	{}	2025-09-04 20:06:09.069+00
ace99874-8dbb-47d8-98ce-b61118cfb62a	disk_usage	gauge	45.200000	{}	2025-09-04 20:07:09.069+00
269aeb23-ab08-4b5f-9998-f78b386123f5	cpu_usage	gauge	5.000000	{}	2025-09-04 20:08:09.069+00
b59bbd77-c653-4ca3-ab72-c2deefbd27e4	memory_usage	gauge	75.560000	{}	2025-09-04 20:09:09.069+00
82da6dfe-7d1d-4bd3-b9f6-1ad41913e8ec	disk_usage	gauge	45.200000	{}	2025-09-04 20:10:09.421+00
fa6b07d0-2746-41b8-a94b-5c9321715d7a	disk_usage	gauge	45.200000	{}	2025-09-04 20:11:09.422+00
2cb69bd9-9831-4edc-86f5-2ad6b2a4d8ee	cpu_usage	gauge	5.000000	{}	2025-09-04 20:12:09.422+00
6a4f2599-4343-4bf9-af02-4203e70337ac	disk_usage	gauge	45.200000	{}	2025-09-04 20:13:09.423+00
09f964f2-4977-41f9-a701-e3a946d1c786	uptime	gauge	3130.884278	{}	2025-09-04 20:15:09.424+00
1c3c7541-43a6-484c-9a27-e3a3aaacbc24	memory_usage	gauge	77.130000	{}	2025-09-04 20:16:09.424+00
30e378a5-6e77-4b4d-aa92-a3917f89171c	uptime	gauge	3310.885490	{}	2025-09-04 20:18:09.425+00
80674fda-0929-4582-9f44-58c6f43dca50	memory_usage	gauge	73.600000	{}	2025-09-04 20:19:09.426+00
134d4576-989c-4f08-a414-31db441d9a94	cpu_usage	gauge	5.000000	{}	2025-09-04 20:20:09.426+00
97719be4-b683-44c0-aee2-da3e28366c1b	disk_usage	gauge	45.200000	{}	2025-09-04 20:21:09.427+00
b1d31abb-34b0-4b91-8e1f-a17e3601bacb	cpu_usage	gauge	5.000000	{}	2025-09-04 20:22:09.427+00
d0526d73-cdcd-41e4-8188-3e86dbbc08fe	memory_usage	gauge	74.800000	{}	2025-09-04 20:23:09.427+00
7fd98c6b-3f96-49bf-9b40-2b8a15fe5a16	disk_usage	gauge	45.200000	{}	2025-09-04 20:24:09.428+00
d965c33a-4d57-4f36-baa5-32989fa4a7d2	cpu_usage	gauge	5.000000	{}	2025-09-04 20:25:09.428+00
cc439c68-831f-4b6a-acf5-a5314a1b7064	disk_usage	gauge	45.200000	{}	2025-09-04 20:26:09.429+00
07ddbb0f-23b8-4da3-ba0b-cd5652492025	cpu_usage	gauge	5.000000	{}	2025-09-04 20:27:09.429+00
3c6b36cb-2774-4676-bd9e-6b01e58ee32d	cpu_usage	gauge	5.000000	{}	2025-09-04 20:28:09.428+00
681e4975-428b-4198-936e-89a1cbb65ca5	cpu_usage	gauge	5.000000	{}	2025-09-04 20:29:09.428+00
2977de69-bf66-4cfd-b6f9-74030053d0aa	disk_usage	gauge	45.200000	{}	2025-09-04 20:30:19.874+00
3f541624-3873-4fe1-8133-1f9c1ecc90de	memory_usage	gauge	80.360000	{}	2025-09-04 20:31:19.875+00
cf926d5b-5bcf-4db1-b33e-863ec5c6f18a	cpu_usage	gauge	5.000000	{}	2025-09-04 22:18:28.141+00
3546aae6-7b21-4e21-bac3-fa9138ad1016	disk_usage	gauge	45.200000	{}	2025-09-04 22:19:28.142+00
ef148c26-4d57-4e64-9963-aaae212ac2de	uptime	gauge	249.351070	{}	2025-09-04 22:20:28.143+00
688b27fe-eef1-445e-b978-260005429402	disk_usage	gauge	45.200000	{}	2025-09-04 22:21:28.148+00
f2b042d8-9017-47e2-a715-667a44479e7f	uptime	gauge	369.358080	{}	2025-09-04 22:22:28.15+00
bf73036a-a0b9-428e-808f-1b2adb6ce74c	disk_usage	gauge	45.200000	{}	2025-09-04 22:23:28.149+00
cc6d240b-a188-4589-b90a-3012f781eeae	cpu_usage	gauge	6.000000	{}	2025-09-03 17:15:57.652+00
eb3a530a-1d2b-415f-89c2-c61d666102df	memory_usage	gauge	73.550000	{}	2025-09-03 17:15:57.652+00
aaa1b317-20a7-42c6-9ef5-3af8e4cb4c37	disk_usage	gauge	45.200000	{}	2025-09-03 17:15:57.652+00
2c048d53-fac5-4e5e-9906-0901f44557fb	uptime	gauge	69.177471	{}	2025-09-03 17:15:57.652+00
d567945e-f155-485f-8811-f2ef3dcb49e6	uptime	gauge	129.178474	{}	2025-09-03 17:16:57.653+00
abbb9092-bf91-43dc-8dc3-a77db7b1fd1c	memory_usage	gauge	73.390000	{}	2025-09-03 17:17:57.654+00
4f0f973c-2f4b-4eff-a256-8ad0b0589b89	memory_usage	gauge	73.430000	{}	2025-09-03 17:18:57.655+00
60177094-40fa-4e45-8b4c-3a4ab972d8bb	disk_usage	gauge	45.200000	{}	2025-09-03 17:19:57.659+00
ef850883-0710-4e8b-92e2-be42553211f7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:20:57.659+00
2373de2e-cdc7-42c5-bd67-6e68a244d78b	uptime	gauge	429.185337	{}	2025-09-03 17:21:57.66+00
bcbc7b93-e38c-43fc-8e06-535c3c30ccd0	disk_usage	gauge	45.200000	{}	2025-09-03 17:22:57.661+00
6510877d-0324-4ef4-b84f-0677456b9a63	disk_usage	gauge	45.200000	{}	2025-09-03 18:07:13.56+00
b833150c-09db-4e3e-8e57-6aad22b67afe	cpu_usage	gauge	6.000000	{}	2025-09-03 18:08:13.561+00
38b3192c-e1aa-40af-ae75-fa98af0c3483	uptime	gauge	1269.365035	{}	2025-09-03 18:09:13.562+00
53c7cfb3-ffe7-4dec-b2dd-e2e0824007ee	disk_usage	gauge	45.200000	{}	2025-09-03 18:10:13.563+00
a93b57ef-8071-4359-9490-3deab54afd05	memory_usage	gauge	69.730000	{}	2025-09-03 18:11:13.564+00
334bdbf0-98f3-4535-b662-b591e06ac283	cpu_usage	gauge	6.000000	{}	2025-09-03 18:12:13.566+00
4e1d3d51-f6b5-4697-be2e-b013e68a879e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:13:13.567+00
6a0c80b0-3831-48ad-9d75-0412ab2f673c	uptime	gauge	1569.371083	{}	2025-09-03 18:14:13.568+00
56c887b1-84ef-4044-bf8f-c50301dd974e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:15:13.569+00
63fd6f7e-e80d-4ca3-b5e8-aca5e2fc1a69	uptime	gauge	1689.373051	{}	2025-09-03 18:16:13.57+00
e872e324-4cff-48b9-9a38-b684a5b0572a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:17:13.571+00
a0f562ca-5450-4962-b777-654721a53be2	uptime	gauge	1809.373791	{}	2025-09-03 18:18:13.571+00
241ea965-907f-4c5a-87ed-f8393a1e4a63	memory_usage	gauge	73.370000	{}	2025-09-04 16:15:56.019+00
e76ab1b0-7a33-4866-a25b-8128cb260cc4	memory_usage	gauge	75.870000	{}	2025-09-04 16:16:56.018+00
86381ab6-8db5-409e-89ab-0bcce13ee759	cpu_usage	gauge	5.000000	{}	2025-09-04 20:11:09.422+00
dd9b2762-6e69-444d-8e4b-024fb9c8f5fe	uptime	gauge	3010.883304	{}	2025-09-04 20:13:09.423+00
b2bac87e-a20d-4bdd-a850-5125f0623921	cpu_usage	gauge	5.000000	{}	2025-09-04 20:14:09.424+00
5453d8dc-ec77-44e0-8918-e8184f042adc	cpu_usage	gauge	5.000000	{}	2025-09-04 20:15:09.424+00
70bf4f7b-05f3-4dfd-9e5e-debe18f027a9	disk_usage	gauge	45.200000	{}	2025-09-04 20:16:09.424+00
cfedaa33-75c5-457f-be86-ac0ccd0edccd	cpu_usage	gauge	5.000000	{}	2025-09-04 20:17:09.424+00
72f00906-603f-4fa7-920e-4da37f3ce0a4	uptime	gauge	3370.886094	{}	2025-09-04 20:19:09.426+00
1c1e2b63-d264-4ef5-a12b-3eb713c09104	memory_usage	gauge	81.420000	{}	2025-09-04 20:20:09.426+00
bdf988e5-6e32-4542-bc1c-943761c0fad6	memory_usage	gauge	81.200000	{}	2025-09-04 20:21:09.427+00
d3f181aa-7678-4693-ad2b-df992db410f4	uptime	gauge	3610.887357	{}	2025-09-04 20:23:09.427+00
1dbb7362-3712-4121-a40e-4ce2678c53cc	uptime	gauge	3730.888139	{}	2025-09-04 20:25:09.428+00
d48a9273-82d9-436d-8044-e574ac0946ed	cpu_usage	gauge	5.000000	{}	2025-09-04 20:26:09.429+00
b8266112-11b7-410f-9e2e-007dad587730	disk_usage	gauge	45.200000	{}	2025-09-04 20:27:09.429+00
e7f142d7-aabe-4319-a4a7-b5246676a1a3	disk_usage	gauge	45.200000	{}	2025-09-04 22:18:28.141+00
37dd0c7f-73c7-4982-be1e-5a17b5bb707e	cpu_usage	gauge	5.000000	{}	2025-09-04 22:19:28.142+00
c92ab6b7-f4a5-4c4b-a18c-77f4788920cf	disk_usage	gauge	45.200000	{}	2025-09-04 22:20:28.143+00
111287c1-329c-4369-86ba-539a4c892faf	memory_usage	gauge	69.200000	{}	2025-09-04 22:21:28.148+00
341f32fd-0367-490b-a9bc-4f76d49ec49b	cpu_usage	gauge	5.000000	{}	2025-09-04 22:22:28.149+00
453984af-f7bf-4488-b2a4-0fbd3be1a4dc	uptime	gauge	429.357874	{}	2025-09-04 22:23:28.149+00
be334deb-a194-4e03-ab51-ba8398200c94	cpu_usage	gauge	6.000000	{}	2025-09-03 17:16:57.653+00
8d7cfbec-fdd6-4b08-8dea-965d13cdbfb8	uptime	gauge	189.179006	{}	2025-09-03 17:17:57.654+00
f00f1e09-74ff-4b06-8797-59b66346324f	disk_usage	gauge	45.200000	{}	2025-09-03 17:18:57.655+00
6d36a95e-93e2-4ac5-99df-6a603ab2f11d	memory_usage	gauge	73.340000	{}	2025-09-03 17:19:57.659+00
96c5dfd1-f696-4a8c-86e2-7ee3c465599e	memory_usage	gauge	73.480000	{}	2025-09-03 17:20:57.66+00
080b7989-3817-4ba6-86f3-c035eb6feaf5	memory_usage	gauge	73.480000	{}	2025-09-03 17:21:57.66+00
07e93c27-27ea-43de-9db8-60ca815dd2f4	uptime	gauge	489.186048	{}	2025-09-03 17:22:57.661+00
dfa54aeb-b5e8-4204-92c1-332c8444374b	uptime	gauge	1149.362512	{}	2025-09-03 18:07:13.56+00
4ecdbff2-dc03-4ecb-a7c8-9b632f86c73f	disk_usage	gauge	45.200000	{}	2025-09-03 18:08:13.561+00
972d3d3a-b6e9-4f98-9672-6e42f49597c7	cpu_usage	gauge	6.000000	{}	2025-09-03 18:09:13.562+00
b3c16b68-f711-45b5-a94b-f5ab82285848	cpu_usage	gauge	6.000000	{}	2025-09-03 18:10:13.563+00
ac1cf103-1f0a-4558-873e-44622d7375a3	uptime	gauge	1389.366537	{}	2025-09-03 18:11:13.564+00
8a0d0905-ec9d-4538-b555-01bad9bb7ed8	disk_usage	gauge	45.200000	{}	2025-09-03 18:12:13.566+00
4ff1200d-6ce5-4f0c-9d34-eab3c972f03c	disk_usage	gauge	45.200000	{}	2025-09-03 18:13:13.567+00
9539ea33-6d2a-455a-b582-8b988b1589d7	memory_usage	gauge	69.450000	{}	2025-09-03 18:14:13.568+00
910ba5f6-b593-451a-9d23-f5750e45b5f0	disk_usage	gauge	45.200000	{}	2025-09-03 18:15:13.569+00
ea393711-2455-4652-bfb0-f67e1825b695	disk_usage	gauge	45.200000	{}	2025-09-03 18:16:13.57+00
9a5413e9-af5d-44e5-964c-0786a1a8c451	disk_usage	gauge	45.200000	{}	2025-09-03 18:17:13.571+00
288c21bc-bb4d-4fdb-ba19-c07dba87e187	memory_usage	gauge	69.450000	{}	2025-09-03 18:18:13.571+00
4fb5854e-17e7-443c-88a1-b84d728a2081	uptime	gauge	68.879992	{}	2025-09-04 16:15:56.019+00
4001f08d-9f17-4a3a-a2d3-f72d06fecc16	cpu_usage	gauge	5.000000	{}	2025-09-04 16:16:56.018+00
e8248a2b-dfd7-455c-a6bf-c8cad29f69a9	memory_usage	gauge	77.490000	{}	2025-09-04 20:28:09.428+00
3f7580e8-ec41-4b70-a3e9-9272093b6ab2	uptime	gauge	4041.334519	{}	2025-09-04 20:30:19.874+00
2f776eb6-bf91-4899-aaa1-4591cf759257	uptime	gauge	129.349596	{}	2025-09-04 22:18:28.141+00
7dccc486-c19d-4720-bf35-4721b651ff13	memory_usage	gauge	70.830000	{}	2025-09-04 22:19:28.142+00
18c47354-29c8-4019-8ab7-022c19b22499	cpu_usage	gauge	5.000000	{}	2025-09-04 22:20:28.142+00
ad29f9dc-38bd-449c-849c-095ebf6b329a	uptime	gauge	309.356183	{}	2025-09-04 22:21:28.148+00
eabdfb0a-1b4e-4568-ba12-e881a470cf38	memory_usage	gauge	73.550000	{}	2025-09-03 17:16:57.653+00
5ace40fe-84c6-42ae-86e5-39df46b4d595	cpu_usage	gauge	6.000000	{}	2025-09-03 17:17:57.654+00
81e133a1-7a1a-40c7-80f9-a728802a4afa	uptime	gauge	249.180038	{}	2025-09-03 17:18:57.655+00
eb687907-f990-4a2b-904b-10e92a4a58c4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:19:57.659+00
2a385943-0f33-4274-8c36-d0228dcc15c0	uptime	gauge	369.184574	{}	2025-09-03 17:20:57.66+00
a8dbddb4-a7f4-4e77-9cac-ae7f50953432	disk_usage	gauge	45.200000	{}	2025-09-03 17:21:57.66+00
25997b9d-8821-406b-b9cb-ab82f45997a1	memory_usage	gauge	73.510000	{}	2025-09-03 17:22:57.661+00
85cb48eb-bf53-41df-a5f2-cd2d67b808a0	cpu_usage	gauge	6.000000	{}	2025-09-03 18:19:55.008+00
2cf6d1c1-13c7-4e31-87e0-2fc6198a0a78	memory_usage	gauge	70.240000	{}	2025-09-03 18:19:55.008+00
27d15cea-8017-43ce-ae19-2bddf3353f48	uptime	gauge	67.944511	{}	2025-09-03 18:19:55.009+00
1337474c-b5be-4b60-88a9-588af317ba7a	memory_usage	gauge	75.600000	{}	2025-09-04 16:17:56.018+00
8d2faca0-1373-4e63-9952-51ee586b8a3f	uptime	gauge	248.879717	{}	2025-09-04 16:18:56.019+00
dd5933fb-3e09-4864-8993-cb82598b2593	disk_usage	gauge	45.200000	{}	2025-09-04 16:19:56.018+00
7fdb6964-8701-4963-9015-97f682b6c822	memory_usage	gauge	75.660000	{}	2025-09-04 16:20:56.018+00
03c22984-3901-4b60-b20d-58b5d2659225	cpu_usage	gauge	5.000000	{}	2025-09-04 16:21:56.018+00
ac47c690-f81d-4ecb-a68b-178ef515c56c	uptime	gauge	488.879113	{}	2025-09-04 16:22:56.018+00
0664a897-00a7-4655-80de-9e6ee764d502	disk_usage	gauge	45.200000	{}	2025-09-04 16:23:56.018+00
915230f7-7e5f-4f31-8f64-18e1689d2851	memory_usage	gauge	75.710000	{}	2025-09-04 16:24:56.019+00
5248b914-c4bc-4e4d-95ea-5c51750cd840	cpu_usage	gauge	5.000000	{}	2025-09-04 16:25:56.019+00
cd00d827-3abf-455c-8314-e2f0874e73b2	cpu_usage	gauge	5.000000	{}	2025-09-04 16:26:56.019+00
079cc8e9-2808-43fc-8b0c-73c5bb76c813	uptime	gauge	788.880090	{}	2025-09-04 16:27:56.019+00
b2322de9-e1f3-4063-8f4b-4a164ed97b3e	disk_usage	gauge	45.200000	{}	2025-09-04 16:28:56.02+00
ca20c044-b59b-4c3c-8a0a-c72bb861070e	disk_usage	gauge	45.200000	{}	2025-09-04 16:29:56.02+00
57abf1e0-c141-47ef-9072-afc649cbd028	cpu_usage	gauge	5.000000	{}	2025-09-04 16:30:56.022+00
66f11ccc-6892-40ea-bafe-8dfea2d7eca3	uptime	gauge	1028.883792	{}	2025-09-04 16:31:56.023+00
c5c353e9-698a-4e5c-8098-b0ea5341a35b	disk_usage	gauge	45.200000	{}	2025-09-04 16:32:56.024+00
4068e49d-ad72-4bf7-8b54-7217c0d7051e	cpu_usage	gauge	5.000000	{}	2025-09-04 16:33:56.024+00
030b24ea-f84c-42ad-bd56-b296443da4f8	uptime	gauge	1208.884759	{}	2025-09-04 16:34:56.024+00
4a9dbc00-fb9d-47b2-855b-8fb4ba72af13	cpu_usage	gauge	5.000000	{}	2025-09-04 16:35:56.025+00
7c9f6d3f-80e1-4ed2-bbd4-f9369d26953d	uptime	gauge	1328.886011	{}	2025-09-04 16:36:56.025+00
cb04c44b-7de6-4f2f-86e7-989c95e074f4	disk_usage	gauge	45.200000	{}	2025-09-04 16:37:56.025+00
4aa0c319-fd8e-4891-a6dd-5d01078e3de7	uptime	gauge	3910.888461	{}	2025-09-04 20:28:09.428+00
4e23abee-17aa-42fa-b119-0093830297c5	uptime	gauge	3970.888588	{}	2025-09-04 20:29:09.429+00
9bbcd275-4476-4584-b7fe-3c0dd8679f2c	disk_usage	gauge	45.200000	{}	2025-09-04 22:22:28.15+00
c9a84648-4cc4-4f54-9a0c-c4f09040163f	cpu_usage	gauge	5.000000	{}	2025-09-04 22:23:28.149+00
5001f8ec-c1bb-4c03-ad7f-e240fb893a8d	disk_usage	gauge	45.200000	{}	2025-09-03 17:16:57.653+00
2471561c-cbe9-474e-9646-4acf1ff126df	disk_usage	gauge	45.200000	{}	2025-09-03 17:17:57.654+00
ba021b83-7ab8-4d02-833f-2fb82658f2ee	cpu_usage	gauge	6.000000	{}	2025-09-03 17:18:57.655+00
10c265b0-4c9d-41d2-bed2-fbd69b8b0881	uptime	gauge	309.184296	{}	2025-09-03 17:19:57.659+00
8e84707d-e378-41d5-b39a-406acea47f78	disk_usage	gauge	45.200000	{}	2025-09-03 17:20:57.66+00
a20131f7-4c47-44ba-be21-d448dc9aff0f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:21:57.66+00
5851af99-3611-4bf5-a7a8-456c0dfc3c39	cpu_usage	gauge	6.000000	{}	2025-09-03 17:22:57.661+00
c994aac7-3388-4bb6-8ab7-2f5a42bd0c9d	disk_usage	gauge	45.200000	{}	2025-09-03 18:19:55.009+00
f3f0f575-8ea8-4930-bc21-2b296829a826	cpu_usage	gauge	5.000000	{}	2025-09-04 16:17:56.018+00
93385f03-6e2b-4442-9ab8-cdc641115ae0	memory_usage	gauge	75.130000	{}	2025-09-04 16:18:56.019+00
d69c4db2-e8db-4da7-898a-fa0e97445cee	memory_usage	gauge	74.990000	{}	2025-09-04 16:19:56.018+00
7503fbd0-1dfc-46c3-a413-1aca627d6f48	cpu_usage	gauge	5.000000	{}	2025-09-04 16:20:56.018+00
4ba9a4e5-5a3f-470d-aa03-dbf8a1d982b1	uptime	gauge	428.879437	{}	2025-09-04 16:21:56.018+00
ee0fd14a-83c9-44b5-903b-3aa34c7f6577	disk_usage	gauge	45.200000	{}	2025-09-04 16:22:56.018+00
02a1ffd3-15f6-435e-b8fb-8ee230e093cd	cpu_usage	gauge	5.000000	{}	2025-09-04 16:23:56.018+00
73437abc-445c-480d-ae26-51d969a17558	uptime	gauge	608.879860	{}	2025-09-04 16:24:56.019+00
4ae919f5-7117-4ce0-851a-a422f9687a75	disk_usage	gauge	45.200000	{}	2025-09-04 16:25:56.019+00
9ded0307-d6a1-4c02-812c-54805c5e09db	memory_usage	gauge	75.030000	{}	2025-09-04 16:26:56.019+00
187c8963-7f2c-483d-a151-d588a1de3e96	disk_usage	gauge	45.200000	{}	2025-09-04 16:27:56.019+00
275e27f7-8d53-4807-9ee4-491f7bdf4ca2	memory_usage	gauge	77.870000	{}	2025-09-04 16:28:56.02+00
54eaeabc-31f2-4b07-8127-9cdbc52d5c34	cpu_usage	gauge	5.000000	{}	2025-09-04 16:29:56.02+00
416e2922-7c0c-4818-a9b5-47adc6692b36	cpu_usage	gauge	5.000000	{}	2025-09-04 20:31:19.875+00
aa28c3ad-695c-40ca-9630-b9e223395024	memory_usage	gauge	69.270000	{}	2025-09-04 22:22:28.149+00
7379e135-e956-42a6-b3fb-7265cffc7630	memory_usage	gauge	69.270000	{}	2025-09-04 22:23:28.149+00
1bbf7112-8d46-48d7-8236-e8008ce89630	memory_usage	gauge	73.510000	{}	2025-09-03 17:23:57.661+00
2f6a5f2c-3b75-4bbd-88b0-66d1ed2c5e30	uptime	gauge	609.186876	{}	2025-09-03 17:24:57.662+00
2cd23b75-439d-474c-a15f-ea6988075648	disk_usage	gauge	45.200000	{}	2025-09-03 17:25:57.663+00
44e3c031-099d-491e-98ac-ae4f49d9cfe0	disk_usage	gauge	45.200000	{}	2025-09-03 17:26:57.663+00
fcbe8b10-4ad9-40d2-8d3e-db032ddefee9	disk_usage	gauge	45.200000	{}	2025-09-03 17:27:57.665+00
062a51cf-cd46-4c29-9bdf-9f3c9f015428	cpu_usage	gauge	6.000000	{}	2025-09-03 17:28:57.666+00
fcf14e4f-cd2a-494e-96ba-ae778bd37e55	uptime	gauge	909.190355	{}	2025-09-03 17:29:57.665+00
daa2ca23-89d4-4685-8344-833313fd17fd	disk_usage	gauge	45.200000	{}	2025-09-03 17:30:57.666+00
1744df53-1cd0-4a74-a459-f5a91dc99b8b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:31:57.667+00
24cd93d5-9348-4f8f-8f60-d80f8dce486c	uptime	gauge	1089.192565	{}	2025-09-03 17:32:57.668+00
72e0fd3f-aa1b-4762-98fb-b53086f40f7c	memory_usage	gauge	79.000000	{}	2025-09-03 17:33:57.668+00
3b9ec0a2-c04d-4b91-a3c3-73b1ff6e6a48	cpu_usage	gauge	6.000000	{}	2025-09-03 17:34:57.669+00
def2efb6-fb4a-456e-b82e-0040be90cb58	uptime	gauge	1269.194585	{}	2025-09-03 17:35:57.67+00
889c4765-2c3f-4a0d-adfa-56f789e8e0eb	memory_usage	gauge	79.230000	{}	2025-09-03 17:36:57.67+00
58f22014-c053-4966-939f-07b511774886	cpu_usage	gauge	6.000000	{}	2025-09-03 17:37:57.671+00
c91735ee-6ba6-48bb-9c46-3cf1b9512c7e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:21:49.691+00
483cbeed-1dd7-4d34-bf18-c44dd8d66553	memory_usage	gauge	70.280000	{}	2025-09-03 18:21:49.691+00
88af6154-594c-4d2f-a827-b2933fe388dc	uptime	gauge	68.127091	{}	2025-09-03 18:21:49.691+00
98108ab4-a217-4696-8a82-364c567a45f4	disk_usage	gauge	45.200000	{}	2025-09-04 16:17:56.018+00
35982590-6433-4f10-99cd-2d685e6c19e2	disk_usage	gauge	45.200000	{}	2025-09-04 16:18:56.019+00
712aba11-e074-4d9f-a989-42db36e303b5	cpu_usage	gauge	5.000000	{}	2025-09-04 16:19:56.018+00
4a35ee24-d29c-4704-87b6-5e89bf135a7c	uptime	gauge	368.879161	{}	2025-09-04 16:20:56.018+00
347aaf7c-b717-42a0-b317-9256f71c0f2a	disk_usage	gauge	45.200000	{}	2025-09-04 16:21:56.018+00
8a738c67-392a-4e7f-ac26-4ef5ef0e8253	memory_usage	gauge	75.420000	{}	2025-09-04 16:22:56.018+00
3a3293fa-c924-4b55-8774-69b25dccc922	memory_usage	gauge	75.520000	{}	2025-09-04 16:23:56.018+00
e127035f-8421-44ed-8498-dc8946e98368	cpu_usage	gauge	5.000000	{}	2025-09-04 16:24:56.019+00
7deca39a-8bf1-43b7-9f5e-657f500a667b	uptime	gauge	668.879939	{}	2025-09-04 16:25:56.019+00
47a712a6-159d-4747-9469-3d7f11479557	disk_usage	gauge	45.200000	{}	2025-09-04 16:26:56.019+00
cf9b6658-c86c-41c9-9ddb-24a74364f3c1	cpu_usage	gauge	5.000000	{}	2025-09-04 16:27:56.019+00
6a827310-50cc-4974-ba7c-ebc7b5a5179f	uptime	gauge	848.880775	{}	2025-09-04 16:28:56.02+00
ff871e7b-0a90-4d76-a8e8-511ed03905e9	memory_usage	gauge	80.590000	{}	2025-09-04 16:29:56.02+00
844904a2-28bb-424d-9f50-69cc178503b5	uptime	gauge	968.883224	{}	2025-09-04 16:30:56.022+00
78dce714-cb13-40e1-b0f7-b5396497ff1f	disk_usage	gauge	45.200000	{}	2025-09-04 16:31:56.023+00
9f45488c-6743-4355-a9ea-ff887d13eb48	memory_usage	gauge	80.180000	{}	2025-09-04 16:32:56.024+00
8e2e6803-be33-48b5-b706-707ef079fbd6	disk_usage	gauge	45.200000	{}	2025-09-04 16:33:56.025+00
21a07e45-fc99-4a78-8883-e4517200ad34	memory_usage	gauge	80.430000	{}	2025-09-04 16:34:56.024+00
1dd895e0-5c6f-476b-9b90-63916b38aafd	disk_usage	gauge	45.200000	{}	2025-09-04 16:35:56.025+00
e4220ee6-4105-4ec2-8201-23a9b4e0046e	cpu_usage	gauge	5.000000	{}	2025-09-04 16:36:56.025+00
274ea01d-cc24-4fdb-817a-4e47034866be	uptime	gauge	1388.885844	{}	2025-09-04 16:37:56.025+00
55051a65-bdd5-4e1c-9123-4b0744642142	cpu_usage	gauge	5.000000	{}	2025-09-04 20:33:26.385+00
b10cef89-03b1-4461-aeb5-4226f14f8c08	disk_usage	gauge	45.200000	{}	2025-09-04 20:33:26.385+00
013e4f4b-5c64-4a0b-9134-c230406b3238	cpu_usage	gauge	5.000000	{}	2025-09-04 22:25:18.299+00
ea5f3f25-3796-4931-9794-43b5cd39ba38	uptime	gauge	129.339273	{}	2025-09-04 22:26:18.298+00
6008a7f5-a939-4624-b1ba-1f450aedd6b2	disk_usage	gauge	45.200000	{}	2025-09-04 22:27:18.299+00
12f44b5d-2bb6-42df-91e3-8d4472c838e1	disk_usage	gauge	45.200000	{}	2025-09-04 22:28:18.299+00
e5b17fbd-635c-4b69-9f4c-56c8d8ca06d6	memory_usage	gauge	70.560000	{}	2025-09-04 22:29:18.3+00
f4d96af7-641a-49fb-ac5f-541c27d3f709	cpu_usage	gauge	6.000000	{}	2025-09-03 17:23:57.661+00
f68bf990-baf5-4780-8e28-fd818489f36d	disk_usage	gauge	45.200000	{}	2025-09-03 17:24:57.662+00
88cd1712-20cb-4f58-80ba-4936c6d5ec63	cpu_usage	gauge	6.000000	{}	2025-09-03 17:25:57.663+00
e4819dce-e111-4483-ae3f-db3008fa2239	cpu_usage	gauge	6.000000	{}	2025-09-03 17:26:57.663+00
03399bde-61ab-4162-8872-61e261812f8d	uptime	gauge	789.189898	{}	2025-09-03 17:27:57.665+00
31fbd92e-a5bc-4d7a-b616-c01dc82be3dc	disk_usage	gauge	45.200000	{}	2025-09-03 17:28:57.666+00
9e314934-1998-4ef9-b02e-2182b7da2b46	memory_usage	gauge	73.270000	{}	2025-09-03 17:29:57.665+00
1714a085-a281-46e8-98ea-007a39126866	memory_usage	gauge	79.090000	{}	2025-09-03 17:30:57.666+00
9b6165b7-9f79-4a2a-9581-1079720bbe05	disk_usage	gauge	45.200000	{}	2025-09-03 17:31:57.667+00
1b5c0aa3-8d80-4e2b-9ca1-d3fdde8ebb74	cpu_usage	gauge	6.000000	{}	2025-09-03 17:32:57.667+00
ba9a3291-6ed6-4d83-9200-b8a9f415370c	uptime	gauge	1149.193574	{}	2025-09-03 17:33:57.669+00
ff8a9ce7-11ed-4d6a-b745-0a9bc6d1c205	disk_usage	gauge	45.200000	{}	2025-09-03 17:34:57.669+00
795decb9-2601-4ea4-8832-969100ce836f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:35:57.669+00
26d986f9-1670-4c1f-9a42-10ff45b8b568	uptime	gauge	1329.195144	{}	2025-09-03 17:36:57.67+00
b6a526bb-f30b-4f2f-ad9c-89139af15e67	memory_usage	gauge	70.630000	{}	2025-09-03 17:37:57.671+00
ee709e3e-7593-460a-802b-deb833e35d09	disk_usage	gauge	45.200000	{}	2025-09-03 18:21:49.691+00
381d1c48-22d5-4a99-9527-4db0b647c9ff	uptime	gauge	188.879135	{}	2025-09-04 16:17:56.018+00
06b304b6-a37d-4506-845f-e5e06d3ec9aa	cpu_usage	gauge	5.000000	{}	2025-09-04 16:18:56.018+00
f8c637bc-4138-4ff3-9652-029210460951	uptime	gauge	308.879366	{}	2025-09-04 16:19:56.018+00
903244d0-8d38-4b7d-8691-19112dda8d46	disk_usage	gauge	45.200000	{}	2025-09-04 16:20:56.018+00
dbaa81ee-31ac-4e28-a8a2-420533b0a96a	memory_usage	gauge	75.660000	{}	2025-09-04 16:21:56.018+00
5f1bed43-f611-45a9-9d1f-35565a15f7d4	cpu_usage	gauge	5.000000	{}	2025-09-04 16:22:56.018+00
576fb089-b0a7-46a3-a693-e936c2b5949a	uptime	gauge	548.879463	{}	2025-09-04 16:23:56.018+00
6dbbecf9-cf07-4316-a446-f7b96e2fb122	disk_usage	gauge	45.200000	{}	2025-09-04 16:24:56.019+00
e067b56d-acef-42a9-8240-bec523ea7b37	memory_usage	gauge	75.660000	{}	2025-09-04 16:25:56.019+00
95978364-db7b-415a-971f-6665a4321d8a	uptime	gauge	728.880406	{}	2025-09-04 16:26:56.019+00
19bd6a0a-498a-45db-851b-0d19b0d8d1c5	memory_usage	gauge	78.940000	{}	2025-09-04 16:27:56.019+00
5ccca553-5c20-49c5-a2dd-ca42e7ec7aa9	cpu_usage	gauge	5.000000	{}	2025-09-04 16:28:56.02+00
4a3c66c3-6f57-49a2-818b-ba0f8e644d3e	uptime	gauge	908.881457	{}	2025-09-04 16:29:56.02+00
32a1342c-a917-4582-90c4-e9a5823089a3	disk_usage	gauge	45.200000	{}	2025-09-04 16:30:56.022+00
9162fe5e-1a0f-471b-8f9c-f47cc69acab4	cpu_usage	gauge	5.000000	{}	2025-09-04 16:31:56.023+00
d3552946-df25-407d-ab0e-d0629560e409	uptime	gauge	1088.885223	{}	2025-09-04 16:32:56.024+00
28cde81b-8617-496b-ac66-b736758247ce	memory_usage	gauge	80.410000	{}	2025-09-04 16:33:56.024+00
25165b13-4e39-43f0-8edb-537878f1450d	disk_usage	gauge	45.200000	{}	2025-09-04 16:34:56.024+00
6e13d747-735c-4176-960e-cedb914b9042	memory_usage	gauge	86.500000	{}	2025-09-04 16:35:56.025+00
4fe8098a-1218-4e12-bfbe-716935b67d2b	memory_usage	gauge	80.370000	{}	2025-09-04 16:36:56.025+00
e866ad29-0403-45e7-bde3-97f0f3c420e6	memory_usage	gauge	77.590000	{}	2025-09-04 16:37:56.025+00
07377c68-dad8-435f-a423-862fabcd031a	memory_usage	gauge	72.560000	{}	2025-09-04 20:33:26.385+00
9c069866-c2cf-4713-bad8-4eeec08e6423	uptime	gauge	69.664414	{}	2025-09-04 20:33:26.386+00
0b82677d-88a2-453d-86cb-f1040cf7e201	cpu_usage	gauge	5.000000	{}	2025-09-04 20:34:26.386+00
891b336c-3dab-4715-9bef-bced100790fb	memory_usage	gauge	70.040000	{}	2025-09-04 20:35:26.386+00
36b539b8-cdf1-4f08-a4f7-aea1c5ae138f	memory_usage	gauge	69.920000	{}	2025-09-04 20:36:26.388+00
2f1f3b9a-4348-4d51-92df-3262067a7f73	uptime	gauge	309.670445	{}	2025-09-04 20:37:26.392+00
1a46ae0b-192a-492f-a1b8-3b8d0569d2f5	disk_usage	gauge	45.200000	{}	2025-09-04 20:38:26.392+00
c7194c49-7f90-453f-bf52-bf78f4510620	memory_usage	gauge	69.920000	{}	2025-09-04 20:39:26.392+00
c4508f8f-3d9d-4303-8cd8-ae07aefe98b4	disk_usage	gauge	45.200000	{}	2025-09-04 22:25:18.299+00
243ee1e6-bd52-44a1-a9d7-6ef50390436f	disk_usage	gauge	45.200000	{}	2025-09-04 22:26:18.298+00
2775b536-5219-48b0-8e3f-de6927661c1a	memory_usage	gauge	69.310000	{}	2025-09-04 22:27:18.299+00
b6481fe0-8424-49a1-8c19-a67b6776c0d4	memory_usage	gauge	70.640000	{}	2025-09-04 22:28:18.299+00
5c77d910-cf9b-4480-b18b-b8064a49f5a0	disk_usage	gauge	45.200000	{}	2025-09-04 22:29:18.3+00
0a15b3b4-f379-46ce-8af9-d168c44aeab2	uptime	gauge	549.186378	{}	2025-09-03 17:23:57.661+00
6ad01ea6-a1b0-4861-ac7a-cf5b268b0d41	memory_usage	gauge	73.440000	{}	2025-09-03 17:24:57.662+00
080ba86e-9f31-4204-b38c-e90c8b2a77d9	memory_usage	gauge	73.290000	{}	2025-09-03 17:25:57.663+00
3ff50c4b-05fd-45a2-9ce4-5f812d801dcc	uptime	gauge	729.188507	{}	2025-09-03 17:26:57.664+00
17b57c47-d80e-499e-910c-9ad81f551601	cpu_usage	gauge	6.000000	{}	2025-09-03 17:27:57.665+00
d30d63f4-b05a-42ca-8251-dd0974c9f211	uptime	gauge	849.190754	{}	2025-09-03 17:28:57.666+00
0354ef2e-c075-4603-81ad-1041c473b55a	disk_usage	gauge	45.200000	{}	2025-09-03 17:29:57.665+00
d3cac468-ee13-4041-acec-b41034829f5b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:30:57.666+00
801992ad-7028-4db7-b364-0e35e490e596	uptime	gauge	1029.191988	{}	2025-09-03 17:31:57.667+00
59646754-93a8-412e-bc0f-e7784855684f	disk_usage	gauge	45.200000	{}	2025-09-03 17:32:57.668+00
6b064bf2-3dc2-44b4-a9be-0bbed2ab5179	cpu_usage	gauge	6.000000	{}	2025-09-03 17:33:57.668+00
708e52d0-2c6a-4fb5-b20b-c4cb82132c22	uptime	gauge	1209.193943	{}	2025-09-03 17:34:57.669+00
e074298f-ffd9-4507-8fec-a87be44ed43c	memory_usage	gauge	79.260000	{}	2025-09-03 17:35:57.669+00
c6706d36-d4b3-494b-ab8c-89a1f5734be5	disk_usage	gauge	45.200000	{}	2025-09-03 17:36:57.67+00
d8b3eabb-e71e-4ae2-837f-b7346af424f0	disk_usage	gauge	45.200000	{}	2025-09-03 17:37:57.671+00
d0532994-ee21-4ceb-8950-934296b1019d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:22:49.692+00
c4d1cfd1-c50e-46bf-a476-67afcaae43ea	memory_usage	gauge	80.240000	{}	2025-09-04 16:30:56.022+00
dc6869d1-c183-4fed-b858-b7feae79099e	memory_usage	gauge	80.260000	{}	2025-09-04 16:31:56.023+00
b231cb29-1c50-495a-8f60-78faaa3999e9	cpu_usage	gauge	5.000000	{}	2025-09-04 16:32:56.024+00
f0353a89-c9fe-414d-a480-721b13586143	uptime	gauge	1148.885675	{}	2025-09-04 16:33:56.025+00
9f6bfd5f-b15e-4bec-9a7d-acc219d09f21	cpu_usage	gauge	5.000000	{}	2025-09-04 16:34:56.024+00
93179de1-7b05-4bbf-b9b4-19830d6c6856	uptime	gauge	1268.886082	{}	2025-09-04 16:35:56.025+00
0d3b08b0-e3a2-45af-ae58-33f2fd25249a	disk_usage	gauge	45.200000	{}	2025-09-04 16:36:56.025+00
33d00391-cf9d-4e73-8bd1-d7c33fdd4f7d	cpu_usage	gauge	5.000000	{}	2025-09-04 16:37:56.025+00
1494b40c-76fb-4714-98ca-1e991bbe8d51	memory_usage	gauge	72.530000	{}	2025-09-04 20:34:26.386+00
23d4d3e5-0733-47f7-bedf-76ccefc76020	cpu_usage	gauge	5.000000	{}	2025-09-04 20:35:26.386+00
5c7785ad-c5e0-42f4-84cb-1c33a0cbbd51	uptime	gauge	249.666746	{}	2025-09-04 20:36:26.388+00
4dbfd1e7-1191-49f6-a010-3a9185a9d795	cpu_usage	gauge	5.000000	{}	2025-09-04 20:37:26.391+00
e906610f-d500-4834-8f4b-789bcb7ca024	uptime	gauge	369.670973	{}	2025-09-04 20:38:26.392+00
5dd36a7a-89d9-46ab-8a55-edb842c85bcb	cpu_usage	gauge	5.000000	{}	2025-09-04 20:39:26.392+00
99da751d-7a16-40e9-a1d9-b3b5dbc7ad17	memory_usage	gauge	69.340000	{}	2025-09-04 22:25:18.299+00
20a36bb3-abb3-4b9c-ab65-59f9d98934ae	cpu_usage	gauge	5.000000	{}	2025-09-04 22:26:18.298+00
08b0d3a0-4e0c-4027-b435-20130149d4de	uptime	gauge	189.339836	{}	2025-09-04 22:27:18.299+00
7954c49e-160a-48de-973e-d1f098fa1bc1	cpu_usage	gauge	5.000000	{}	2025-09-04 22:28:18.299+00
95a4e88b-486f-4ea9-be76-f3c00b23a4af	uptime	gauge	309.340730	{}	2025-09-04 22:29:18.3+00
13937912-20b8-4113-be57-e493a12cecca	disk_usage	gauge	45.200000	{}	2025-09-03 17:23:57.661+00
c3d1bd23-f8fe-4eae-916f-1f934f4b8cb4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:24:57.662+00
629a556a-601b-4458-9128-4e2dc1dc36a1	uptime	gauge	669.187821	{}	2025-09-03 17:25:57.663+00
fe1a93fc-9c50-4b43-95fc-0dfa6faa1c84	memory_usage	gauge	73.500000	{}	2025-09-03 17:26:57.663+00
9044d786-8e5b-434c-91bb-6da09a6e63c7	memory_usage	gauge	73.470000	{}	2025-09-03 17:27:57.665+00
bc2c7d0c-d302-4a4a-b821-e05a2137bab3	memory_usage	gauge	73.500000	{}	2025-09-03 17:28:57.666+00
59064047-9b82-45b7-b979-3bb383932649	cpu_usage	gauge	6.000000	{}	2025-09-03 17:29:57.665+00
f09aa6f5-024f-407e-b134-c91a1ed0d58a	uptime	gauge	969.191058	{}	2025-09-03 17:30:57.666+00
0066939d-34fc-406b-b5d3-b45f58a5d07a	memory_usage	gauge	79.090000	{}	2025-09-03 17:31:57.667+00
91090694-2e39-426f-92c3-2fda79d9f25e	memory_usage	gauge	79.030000	{}	2025-09-03 17:32:57.667+00
4b196780-ab90-448c-aa9a-0a19e2c8b3dc	disk_usage	gauge	45.200000	{}	2025-09-03 17:33:57.669+00
541b6742-58d4-48d8-a3d6-066aadbc1ea8	memory_usage	gauge	79.030000	{}	2025-09-03 17:34:57.669+00
88d3ce6e-0da9-4fbc-92f8-ba3c8fe03f9e	disk_usage	gauge	45.200000	{}	2025-09-03 17:35:57.67+00
c755aada-643f-44d8-bb4e-33d75d883543	cpu_usage	gauge	6.000000	{}	2025-09-03 17:36:57.67+00
a9020538-270b-4b5c-b26e-56433f08e4a9	uptime	gauge	1389.195707	{}	2025-09-03 17:37:57.671+00
1f36ad7d-9d78-4452-9f77-147951a9eecf	disk_usage	gauge	45.200000	{}	2025-09-03 18:22:49.692+00
86a0e1d7-f3b3-4a23-84b7-a53114a2f0be	memory_usage	gauge	77.370000	{}	2025-09-04 16:39:57.873+00
8318d254-b922-4721-b7a4-a4c41b40f980	disk_usage	gauge	45.200000	{}	2025-09-04 16:39:57.873+00
034c68de-5efa-4dd2-adf0-96319e98a64b	cpu_usage	gauge	5.000000	{}	2025-09-04 16:40:57.873+00
58cc8a08-1af8-4d30-8427-cc5c89123027	uptime	gauge	189.339865	{}	2025-09-04 16:41:57.874+00
fff22a8b-03a8-4bfa-b4de-c311105d6936	memory_usage	gauge	77.520000	{}	2025-09-04 16:42:57.875+00
5d40a40b-1f49-464f-ba83-484d01f34fe2	disk_usage	gauge	45.200000	{}	2025-09-04 16:43:57.88+00
2d55d0d7-2d65-4775-90ea-ab866a4a6c21	memory_usage	gauge	77.600000	{}	2025-09-04 16:44:57.88+00
d61471d4-1709-4661-b48d-470b5080532a	cpu_usage	gauge	5.000000	{}	2025-09-04 16:45:57.88+00
07af0635-fe9b-4858-ae0f-3674fd319978	uptime	gauge	489.347338	{}	2025-09-04 16:46:57.881+00
c34ebe3f-36ae-4c39-9c36-ab05fc970549	cpu_usage	gauge	5.000000	{}	2025-09-04 16:47:57.882+00
6ac82567-175d-4eba-bcd5-fcaf6814c9ab	uptime	gauge	609.348224	{}	2025-09-04 16:48:57.882+00
99f9765b-aced-4901-8544-b4bd2a716e6b	cpu_usage	gauge	5.000000	{}	2025-09-04 16:49:57.883+00
f2239308-e1cc-4eac-8ecb-f70af5acc413	cpu_usage	gauge	5.000000	{}	2025-09-04 16:50:57.884+00
2526435a-7092-40bf-83e7-4537e9ce1bc4	uptime	gauge	789.351165	{}	2025-09-04 16:51:57.885+00
e898df73-fb4c-491c-b7fb-70c6532e50f8	disk_usage	gauge	45.200000	{}	2025-09-04 16:52:57.885+00
f665a284-80e9-4775-9aab-4cf27063677e	memory_usage	gauge	78.800000	{}	2025-09-04 16:53:57.885+00
a65d9e3d-3323-4dae-8600-77d67e2a66ef	memory_usage	gauge	77.850000	{}	2025-09-04 16:54:57.885+00
1b3ee910-9c62-45fa-a8c3-a3459713261e	uptime	gauge	1029.351891	{}	2025-09-04 16:55:57.886+00
aa354840-a0a0-4761-af94-ad7248af3422	cpu_usage	gauge	5.000000	{}	2025-09-04 16:56:57.887+00
8006d48d-a8dc-4c33-a966-6d3744ca9ec9	uptime	gauge	1149.354220	{}	2025-09-04 16:57:57.888+00
d1683a2c-2d7e-4546-af50-b0fc59f7448e	memory_usage	gauge	77.740000	{}	2025-09-04 16:58:57.889+00
1f1bb0ea-efae-4a84-a05b-061efbf3367d	memory_usage	gauge	77.900000	{}	2025-09-04 16:59:57.89+00
3eef52f0-590f-4eaf-a967-17d15ba45cc6	disk_usage	gauge	45.200000	{}	2025-09-04 20:34:26.386+00
96e8abda-9fba-4b04-872e-ab969011a8af	uptime	gauge	189.665519	{}	2025-09-04 20:35:26.387+00
a801274d-e79a-4ae3-aa39-7aa0669d0c4d	cpu_usage	gauge	5.000000	{}	2025-09-04 20:36:26.388+00
7e2dc87e-8d20-4a95-9fa8-1e080267c8f2	disk_usage	gauge	45.200000	{}	2025-09-04 20:37:26.392+00
65f8fca0-3e69-411f-8ec6-79c7af973d07	cpu_usage	gauge	5.000000	{}	2025-09-04 20:38:26.392+00
41c12514-e95f-4689-b1e0-1df8003c6df1	uptime	gauge	429.671048	{}	2025-09-04 20:39:26.392+00
7b07821e-ac1d-47c7-8e09-a701b42792c1	uptime	gauge	69.340127	{}	2025-09-04 22:25:18.299+00
a7ff3c73-91f9-496e-bbb2-159bc21eca7e	memory_usage	gauge	69.270000	{}	2025-09-04 22:26:18.298+00
3b3a1897-cf1d-42c3-91d5-5665510a5b6a	cpu_usage	gauge	5.000000	{}	2025-09-04 22:27:18.299+00
48f39bfd-e906-4010-a741-abc55e557c0e	uptime	gauge	249.340492	{}	2025-09-04 22:28:18.299+00
c74a7ae1-db98-4bda-85c7-3fd29aa4cc80	cpu_usage	gauge	5.000000	{}	2025-09-04 22:29:18.3+00
36417aae-1a99-480f-9ad7-2ecbc8002489	memory_usage	gauge	79.130000	{}	2025-09-03 17:31:21.877+00
de4a318e-3ef9-498c-ae48-7c86aa7e4296	uptime	gauge	128.129944	{}	2025-09-03 17:32:21.878+00
ffb275b7-ba7c-4899-9d95-dbc249ceb8bc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:33:21.878+00
8987639c-9835-4f5a-af94-6e2d769983d3	uptime	gauge	248.130245	{}	2025-09-03 17:34:21.878+00
7e2b28cc-99bb-4acc-ba99-3434033aeb84	disk_usage	gauge	45.200000	{}	2025-09-03 17:35:21.896+00
b13f1be4-e9a2-41f2-b116-949c06980a9a	cpu_usage	gauge	6.000000	{}	2025-09-03 17:36:21.896+00
046fa173-5f02-4249-86d5-02970d53c8e2	memory_usage	gauge	70.760000	{}	2025-09-03 18:22:49.692+00
78fd43a0-91e1-40bd-861b-6978e766b90a	cpu_usage	gauge	5.000000	{}	2025-09-04 16:39:57.873+00
ecd59a55-89df-4013-9c50-9d87d3fc13ec	uptime	gauge	69.339355	{}	2025-09-04 16:39:57.873+00
c097182a-1ecb-4a72-ae9e-bb1f92cf843a	disk_usage	gauge	45.200000	{}	2025-09-04 16:40:57.873+00
9e74f3b7-e85a-4c4a-b36d-92fcf208b3b1	disk_usage	gauge	45.200000	{}	2025-09-04 16:41:57.874+00
e3e1efc1-708e-491d-b2f4-4227275d549b	cpu_usage	gauge	5.000000	{}	2025-09-04 16:42:57.875+00
eae66596-cfd4-40ec-952a-5e3ac9bca76f	uptime	gauge	309.346021	{}	2025-09-04 16:43:57.88+00
11e9a2da-7277-479d-bad9-5ffd1b8c97a9	disk_usage	gauge	45.200000	{}	2025-09-04 16:44:57.88+00
48a10c1f-5c24-4750-b433-f0d85972a730	disk_usage	gauge	45.200000	{}	2025-09-04 16:45:57.88+00
c6bb0458-7a86-4986-93b2-1de01b671569	cpu_usage	gauge	5.000000	{}	2025-09-04 16:46:57.881+00
8d8fc3b8-bcc2-4c90-b3ab-a60f264020e9	uptime	gauge	549.347895	{}	2025-09-04 16:47:57.882+00
a52d4544-d4a2-4f91-ac0b-5ff9244e27b9	cpu_usage	gauge	5.000000	{}	2025-09-04 16:48:57.882+00
a780de60-8a5d-46be-88f5-7d76de5f044d	uptime	gauge	669.349266	{}	2025-09-04 16:49:57.883+00
12a8c44b-e837-48a8-8391-a6787ecac582	disk_usage	gauge	45.200000	{}	2025-09-04 16:50:57.884+00
b57da6e6-ce18-4b3d-b4ce-77bcc49fef02	cpu_usage	gauge	5.000000	{}	2025-09-04 16:51:57.885+00
2be9c39c-7687-4f88-87fe-d802cd5962f1	uptime	gauge	849.351211	{}	2025-09-04 16:52:57.885+00
b6d1c203-110c-43b7-a853-9f630e59815b	disk_usage	gauge	45.200000	{}	2025-09-04 16:53:57.885+00
ca4ba734-5bf2-4050-999f-608d1b89d3e0	disk_usage	gauge	45.200000	{}	2025-09-04 16:54:57.885+00
b2850ae6-d289-4055-81e5-48ac782aeada	memory_usage	gauge	86.690000	{}	2025-09-04 16:55:57.886+00
ad7bd5de-8c0b-4bda-ae3e-1e6f71a6ce4b	memory_usage	gauge	77.620000	{}	2025-09-04 16:56:57.887+00
a38a0f22-ad3f-4dd8-b601-610fa5a8f0a3	memory_usage	gauge	77.760000	{}	2025-09-04 16:57:57.888+00
7531babf-58be-48f4-b73e-e39ae2b45918	cpu_usage	gauge	5.000000	{}	2025-09-04 16:58:57.889+00
00f3b689-b2f7-4fa4-96ac-daa73dc010ae	uptime	gauge	1269.356312	{}	2025-09-04 16:59:57.89+00
334307cc-d149-487e-bb61-9307ddbd4bc3	memory_usage	gauge	80.900000	{}	2025-09-04 17:00:57.89+00
980289fc-95ec-4f9f-ab1f-3d7e13ec940d	uptime	gauge	1389.356765	{}	2025-09-04 17:01:57.891+00
60bdc327-4fe9-4aee-90d1-df6969f18cbe	disk_usage	gauge	45.200000	{}	2025-09-04 17:02:57.89+00
9f900ebc-bf7b-4022-a9c3-d3d10e1a8a0f	memory_usage	gauge	77.740000	{}	2025-09-04 17:03:57.889+00
bdaf6375-660b-4f1d-bce6-71a1fd721d5f	disk_usage	gauge	45.200000	{}	2025-09-04 17:04:57.891+00
2bc226ae-69c7-41da-b2fa-4b7e91bdc506	disk_usage	gauge	45.200000	{}	2025-09-04 17:05:57.891+00
39ee7cb1-36be-40b1-abf9-a04da231450c	memory_usage	gauge	83.020000	{}	2025-09-04 17:06:57.892+00
dfb71b81-1a7e-423e-b5e4-8b71348a98df	disk_usage	gauge	45.200000	{}	2025-09-04 17:07:57.893+00
d77ac185-d56c-4ffd-963b-2e628ca4b89e	memory_usage	gauge	80.180000	{}	2025-09-04 17:08:57.892+00
b1ad5d70-a3d2-43e7-a84c-2eca38b9c967	disk_usage	gauge	45.200000	{}	2025-09-04 17:09:57.893+00
f13f6f81-4736-4fe5-bc42-013da659047a	uptime	gauge	1929.359304	{}	2025-09-04 17:10:57.893+00
ae04666c-0160-4f59-8b53-c14c2594eb6b	disk_usage	gauge	45.200000	{}	2025-09-04 17:11:57.893+00
428eb8d6-e430-4a9c-9177-d36bd44de6d6	memory_usage	gauge	85.120000	{}	2025-09-04 17:12:57.893+00
55c0b4de-cecc-4bcd-a15a-77c8446c4bbc	memory_usage	gauge	75.240000	{}	2025-09-04 17:13:57.894+00
67e2867d-ece3-4a7a-a9a8-914070d2abd8	cpu_usage	gauge	5.000000	{}	2025-09-04 17:14:57.895+00
88234e06-4dcd-4322-89fc-e4ef00318e54	disk_usage	gauge	45.200000	{}	2025-09-04 17:15:57.895+00
02bd188d-dbfe-4a85-84f1-20bd6e6923ff	disk_usage	gauge	45.200000	{}	2025-09-04 17:16:57.895+00
fe4f9c3a-e8dc-43fe-9dc0-1bff8935b4fb	disk_usage	gauge	45.200000	{}	2025-09-04 17:17:57.895+00
bf557685-6e4a-43a1-b099-6f2793e6b829	disk_usage	gauge	45.200000	{}	2025-09-04 17:18:57.896+00
a013ce63-437b-4efc-b369-acf9fae0cbcf	uptime	gauge	129.664870	{}	2025-09-04 20:34:26.386+00
b8503ab8-8f86-4b4c-924b-8fedc150e6fe	disk_usage	gauge	45.200000	{}	2025-09-04 20:35:26.387+00
a9b5f42c-dbe9-419c-af33-9c09764ad97b	disk_usage	gauge	45.200000	{}	2025-09-04 20:36:26.388+00
aae82e0b-7b44-4546-9b22-f7bfe288ce7f	memory_usage	gauge	69.880000	{}	2025-09-04 20:37:26.391+00
fcba07b9-8bb5-4fe4-83a3-0e320a039828	memory_usage	gauge	70.030000	{}	2025-09-04 20:38:26.392+00
268e7870-13cd-4b35-901b-429561eead50	disk_usage	gauge	45.200000	{}	2025-09-04 20:39:26.392+00
c0251be2-bbab-4abd-b534-d5369a7d0b29	cpu_usage	gauge	6.000000	{}	2025-09-03 17:31:21.877+00
f2666d49-e82b-49e6-8c8d-47c09ec09a14	memory_usage	gauge	79.130000	{}	2025-09-03 17:32:21.877+00
24264319-6b2a-46ad-98e1-5f8dcacdfca1	memory_usage	gauge	79.070000	{}	2025-09-03 17:33:21.878+00
bdcd56fe-a253-419e-a565-66221eb165be	cpu_usage	gauge	6.000000	{}	2025-09-03 17:34:21.878+00
58393ffe-d320-499f-8196-172d873b3909	uptime	gauge	308.148617	{}	2025-09-03 17:35:21.896+00
0b573faf-d572-4189-98ba-cb936d961496	disk_usage	gauge	45.200000	{}	2025-09-03 17:36:21.896+00
cd20be01-35ba-4a49-a75b-85520bfe00c0	uptime	gauge	128.127564	{}	2025-09-03 18:22:49.692+00
1e2ad3ea-25c6-4aff-b21a-221d8dfe0f38	memory_usage	gauge	77.540000	{}	2025-09-04 16:40:57.873+00
bd586ff8-36f2-4a97-8b44-fb4ecc3ae44c	memory_usage	gauge	77.610000	{}	2025-09-04 16:41:57.874+00
8e077abf-f146-4681-b21e-ed3c5ea4b764	disk_usage	gauge	45.200000	{}	2025-09-04 16:42:57.875+00
5eeabf2f-0fbd-478e-a994-752a7ecce27b	memory_usage	gauge	77.550000	{}	2025-09-04 16:43:57.88+00
c0b389c8-2061-4144-9ece-2804e789aae1	cpu_usage	gauge	5.000000	{}	2025-09-04 16:44:57.88+00
c28ad3f4-f804-4595-b1dd-ee5b7d246a41	memory_usage	gauge	77.690000	{}	2025-09-04 16:45:57.88+00
6419547e-2455-45dc-ae0b-656c888d5b87	memory_usage	gauge	77.730000	{}	2025-09-04 16:46:57.881+00
597d6c69-9047-4826-8b78-5cce092350d1	disk_usage	gauge	45.200000	{}	2025-09-04 16:47:57.882+00
f1d06ff3-406f-4426-91cf-2d835bf5f859	memory_usage	gauge	77.940000	{}	2025-09-04 16:48:57.882+00
ef5854e8-11a1-44ad-8ff3-2e3913cd0190	memory_usage	gauge	78.080000	{}	2025-09-04 16:49:57.883+00
1276d2c3-d199-4119-9aaa-48806114545c	memory_usage	gauge	77.990000	{}	2025-09-04 16:50:57.884+00
70e1f840-86ac-42a4-9237-0390a75b9896	memory_usage	gauge	77.920000	{}	2025-09-04 16:51:57.885+00
4ce2bc03-14aa-4494-8ca1-80aeb6abc88b	memory_usage	gauge	78.100000	{}	2025-09-04 16:52:57.885+00
ca37c283-acb8-4cce-991b-e4db4464b409	cpu_usage	gauge	5.000000	{}	2025-09-04 16:53:57.885+00
ef44bde4-90fe-4efc-8f5a-37c78dc8fca4	uptime	gauge	969.351313	{}	2025-09-04 16:54:57.885+00
b664dbc1-6b5d-4dd8-a908-cf280832a79f	disk_usage	gauge	45.200000	{}	2025-09-04 16:55:57.886+00
deeb50e0-9ebe-4f05-bf42-64165f36496d	disk_usage	gauge	45.200000	{}	2025-09-04 16:56:57.887+00
ea1bd877-f778-4874-9db2-df22ea996a0a	cpu_usage	gauge	5.000000	{}	2025-09-04 16:57:57.888+00
9aaea5f5-61e5-442a-ba3d-fb450f9dec0b	uptime	gauge	1209.355005	{}	2025-09-04 16:58:57.889+00
09985923-5d4b-47b8-a04b-b13f171b9307	disk_usage	gauge	45.200000	{}	2025-09-04 16:59:57.89+00
7d39d590-0e76-48d4-a2d7-59e2a466d36e	disk_usage	gauge	45.200000	{}	2025-09-04 17:00:57.89+00
7109685e-9562-4258-b7fe-9e51a982ace8	disk_usage	gauge	45.200000	{}	2025-09-04 17:01:57.891+00
cbbc14d6-ad57-41a2-a64e-e7fa18711480	cpu_usage	gauge	5.000000	{}	2025-09-04 17:02:57.89+00
ae81a6c5-97d1-4b0c-b307-9b769fa6bf90	uptime	gauge	1509.355709	{}	2025-09-04 17:03:57.89+00
e35d43ed-af85-4074-a8eb-399ef72e405c	memory_usage	gauge	78.260000	{}	2025-09-04 17:04:57.891+00
1158d519-1ce7-47bd-9512-2b025d13054b	memory_usage	gauge	77.990000	{}	2025-09-04 17:05:57.891+00
21218be3-2049-4bee-a79a-4d49243fca33	cpu_usage	gauge	5.000000	{}	2025-09-04 17:06:57.892+00
bc9817cc-da43-4be5-b4d0-3899d705da2a	uptime	gauge	1749.359096	{}	2025-09-04 17:07:57.893+00
9bd1ea5f-6f93-40c2-b89c-b2ebd598b8ba	disk_usage	gauge	45.200000	{}	2025-09-04 17:08:57.893+00
7f251e60-dd08-4d36-8a3e-9b1234570c76	cpu_usage	gauge	5.000000	{}	2025-09-04 17:09:57.893+00
fe313a5a-e490-4ef4-82a5-74f3b70e92a4	cpu_usage	gauge	5.000000	{}	2025-09-04 17:10:57.893+00
0302b660-1bc7-4ba3-b44a-ad4f82d12b1a	uptime	gauge	1989.359069	{}	2025-09-04 17:11:57.893+00
f09e10aa-04ab-4ef7-83d8-d0dad413ad6e	disk_usage	gauge	45.200000	{}	2025-09-04 17:12:57.893+00
a9581e03-81f7-4ef5-94e6-cd70c1b3d92f	cpu_usage	gauge	5.000000	{}	2025-09-04 17:13:57.894+00
06c80fbe-8693-4113-ade9-f750f0397ad8	uptime	gauge	2169.361115	{}	2025-09-04 17:14:57.895+00
70c858b0-eafc-42df-a568-f3b3d3f4ce91	uptime	gauge	2229.361250	{}	2025-09-04 17:15:57.895+00
13e9ed8a-67f1-42b1-a8f4-2f74460cbdba	cpu_usage	gauge	5.000000	{}	2025-09-04 17:16:57.895+00
616cecc1-cf35-4745-a74a-460191d1dab5	uptime	gauge	2349.360814	{}	2025-09-04 17:17:57.895+00
10321115-227b-4cc6-99b7-86151ad16ee4	cpu_usage	gauge	5.000000	{}	2025-09-04 17:18:57.896+00
2c70287d-e94d-4e8a-a96a-1f120bbb3263	disk_usage	gauge	45.200000	{}	2025-09-03 17:31:21.878+00
99dd1e0f-2d4e-4529-b4ff-5dc4e93ad707	disk_usage	gauge	45.200000	{}	2025-09-03 17:32:21.878+00
ff4ced47-4133-48ff-8330-f96c1be6111d	disk_usage	gauge	45.200000	{}	2025-09-03 17:33:21.878+00
e0e0d6a7-cca0-4945-9de2-ea45236f3dd1	memory_usage	gauge	79.030000	{}	2025-09-03 17:34:21.878+00
bd01913d-aaf5-44d5-82aa-2fbffee5df55	memory_usage	gauge	79.140000	{}	2025-09-03 17:35:21.896+00
f8d33af6-0a7b-4eb3-8f97-512c5bf73e1e	memory_usage	gauge	79.490000	{}	2025-09-03 17:36:21.896+00
fa636474-0779-4faf-a3a6-c418ba1f424b	uptime	gauge	129.339579	{}	2025-09-04 16:40:57.873+00
f8d8c451-65ba-491a-ab67-73cb41ffc750	cpu_usage	gauge	5.000000	{}	2025-09-04 16:41:57.874+00
05f19fbc-7bfa-4998-9834-fba6de62518d	uptime	gauge	249.341043	{}	2025-09-04 16:42:57.875+00
599e5d3e-b46e-42f9-8560-1a48041f64e7	cpu_usage	gauge	5.000000	{}	2025-09-04 16:43:57.88+00
ab50b48e-9d69-45e5-b3b1-6c266cd753e5	uptime	gauge	369.346492	{}	2025-09-04 16:44:57.88+00
a4e0e54a-f6c5-4ce3-a5bf-6205f8d228a4	uptime	gauge	429.346563	{}	2025-09-04 16:45:57.88+00
849d3a63-4e93-4d02-b5cc-b99e3bdafd02	disk_usage	gauge	45.200000	{}	2025-09-04 16:46:57.881+00
af794412-f3a2-4fc4-9b55-da86c75404bf	memory_usage	gauge	77.720000	{}	2025-09-04 16:47:57.882+00
3e71075d-7cbc-4f73-876c-6503518fdaba	disk_usage	gauge	45.200000	{}	2025-09-04 16:48:57.882+00
faef1202-dd83-4646-b04d-dfd52def6b02	disk_usage	gauge	45.200000	{}	2025-09-04 16:49:57.883+00
339124c0-973a-4029-91e9-869259917c06	uptime	gauge	729.350031	{}	2025-09-04 16:50:57.884+00
df4adf7a-3a83-48ca-be27-2067b540489b	disk_usage	gauge	45.200000	{}	2025-09-04 16:51:57.885+00
bab29ea6-6fb6-4df5-bff5-caef791b8db8	cpu_usage	gauge	5.000000	{}	2025-09-04 16:52:57.885+00
d1085dc9-0344-4756-9def-05c7701c2d44	uptime	gauge	909.350901	{}	2025-09-04 16:53:57.885+00
b15a7262-bba4-45f1-9790-21b266626f02	cpu_usage	gauge	5.000000	{}	2025-09-04 16:54:57.885+00
3611b995-5e29-4c86-b3d5-98ef2c6d0786	cpu_usage	gauge	5.000000	{}	2025-09-04 16:55:57.886+00
ce4fbf78-d41e-4e2d-b19b-a544d54b52c6	uptime	gauge	1089.353264	{}	2025-09-04 16:56:57.887+00
65bc5fca-dfdb-43ec-b443-6207809edb8c	disk_usage	gauge	45.200000	{}	2025-09-04 16:57:57.888+00
6b0eba33-37fa-46e6-ac90-c7c00ab28c9c	disk_usage	gauge	45.200000	{}	2025-09-04 16:58:57.889+00
48130f21-99c9-407d-900e-5c27d6ba4bcb	cpu_usage	gauge	5.000000	{}	2025-09-04 16:59:57.89+00
710e6b75-94bb-4953-b7c7-00455cb4c0af	uptime	gauge	68.129961	{}	2025-09-03 17:31:21.878+00
40817c41-def0-4764-a6df-d13c621c14a2	cpu_usage	gauge	6.000000	{}	2025-09-03 17:32:21.877+00
ea506bb9-da97-4a5b-916b-1bcad3c27027	uptime	gauge	188.130180	{}	2025-09-03 17:33:21.878+00
e677f4da-30aa-40a6-b74c-a2312f080ad7	disk_usage	gauge	45.200000	{}	2025-09-03 17:34:21.878+00
2f14a29f-be35-4d30-8ddf-e0381db7fb32	cpu_usage	gauge	6.000000	{}	2025-09-03 17:35:21.896+00
4b7c0c27-f188-4d11-93a9-4d6a3593f90e	uptime	gauge	368.148572	{}	2025-09-03 17:36:21.896+00
557e1e13-89a8-431e-9cd5-eb973d170e54	cpu_usage	gauge	5.000000	{}	2025-09-04 17:00:57.89+00
0af82bad-74c6-4b53-b5c4-0beed6788d29	cpu_usage	gauge	5.000000	{}	2025-09-04 17:01:57.89+00
7727954e-5adc-4675-8723-7a226bed2a16	uptime	gauge	1449.355875	{}	2025-09-04 17:02:57.89+00
5548ccc5-d1c9-42e5-8b35-b5f1522fbf50	cpu_usage	gauge	5.000000	{}	2025-09-04 17:03:57.889+00
57eb2ce7-9369-4a06-a906-22fa41b5a9bf	uptime	gauge	1569.357223	{}	2025-09-04 17:04:57.891+00
32f20f55-79b6-4db6-a9db-5d7bf78baa92	cpu_usage	gauge	5.000000	{}	2025-09-04 17:05:57.891+00
266a0663-b937-46a7-8ad1-fe769ae8f6a8	uptime	gauge	1689.358410	{}	2025-09-04 17:06:57.892+00
cdfb8e38-2037-4d9d-8f21-b25a6f2b2b5b	cpu_usage	gauge	5.000000	{}	2025-09-04 17:07:57.893+00
cd3f65be-ece4-4dbe-a52f-b736283e54a5	uptime	gauge	1809.358753	{}	2025-09-04 17:08:57.893+00
086c8da7-f6c6-4212-8897-5265769f0f0f	memory_usage	gauge	79.290000	{}	2025-09-04 17:09:57.893+00
7873522a-a2b9-41b1-80b3-2a3e7082a2b1	memory_usage	gauge	86.170000	{}	2025-09-04 17:10:57.893+00
beebd88e-c2fb-4d89-9130-18d5d74be486	cpu_usage	gauge	5.000000	{}	2025-09-04 17:11:57.893+00
dfe82467-7f4e-44e8-b355-54aa0248b4bb	uptime	gauge	2049.359541	{}	2025-09-04 17:12:57.893+00
e089f719-d2ca-4b6d-bec2-ba628f0bd1d4	disk_usage	gauge	45.200000	{}	2025-09-04 17:13:57.894+00
b68863b3-c0eb-4bec-885d-33aa9d6e7f04	memory_usage	gauge	78.140000	{}	2025-09-04 17:14:57.895+00
de548cdd-ecc1-47d7-99bd-4b3408b9a80e	cpu_usage	gauge	5.000000	{}	2025-09-04 17:15:57.895+00
ad339200-f63c-457a-a20f-179baa4e76a5	uptime	gauge	2289.361492	{}	2025-09-04 17:16:57.895+00
b8f47ccc-b16d-4517-9c52-854e658986d6	memory_usage	gauge	84.770000	{}	2025-09-04 17:17:57.895+00
45ea65d8-b798-4612-8559-9cf08a753b08	memory_usage	gauge	77.760000	{}	2025-09-04 17:18:57.896+00
fe3d5110-4db6-4c81-b071-c2571f6cebd9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:38:57.671+00
5eaad519-da9e-44d2-8192-deba09e229f3	uptime	gauge	1509.197459	{}	2025-09-03 17:39:57.672+00
fcb9a5f2-f066-4423-a53e-863eab8edb15	disk_usage	gauge	45.200000	{}	2025-09-03 17:40:57.673+00
3e02f088-eb78-4e90-a71f-d53a1297fc24	memory_usage	gauge	75.520000	{}	2025-09-03 17:41:57.674+00
b9117f03-7c70-45a7-b915-54e761298d47	cpu_usage	gauge	6.000000	{}	2025-09-03 17:42:57.674+00
4c38d4c7-bae2-4e2e-8329-3439df3f7988	uptime	gauge	1749.198903	{}	2025-09-03 17:43:57.674+00
fee599d4-2852-4f9b-90a6-d4f8ad2829b6	disk_usage	gauge	45.200000	{}	2025-09-03 17:44:57.674+00
221199d9-7df6-47f8-909c-4905df8a7914	cpu_usage	gauge	6.000000	{}	2025-09-03 17:45:57.674+00
fffac2b1-4091-46fe-8578-36f72f214141	uptime	gauge	1929.199173	{}	2025-09-03 17:46:57.674+00
83d618c1-e142-499b-926d-d366f56f2eb6	uptime	gauge	1329.356210	{}	2025-09-04 17:00:57.89+00
cec8bb10-623a-44d0-a299-30171185ce27	memory_usage	gauge	77.510000	{}	2025-09-04 17:01:57.89+00
7dcefa3e-864f-4467-9729-3503fb876c88	memory_usage	gauge	77.500000	{}	2025-09-04 17:02:57.89+00
11c569b5-b8d4-4bbd-b79a-2a73369d7dd9	disk_usage	gauge	45.200000	{}	2025-09-04 17:03:57.89+00
8fa9ba5c-cb64-422d-9a50-decedbd0431c	cpu_usage	gauge	5.000000	{}	2025-09-04 17:04:57.891+00
fb9e4018-2a02-485f-9146-2ef0610dade0	uptime	gauge	1629.357544	{}	2025-09-04 17:05:57.891+00
4bf1f910-1900-4a54-9de2-82b969b4adca	disk_usage	gauge	45.200000	{}	2025-09-04 17:06:57.892+00
21b5b332-2617-45fe-987e-bfa37ed6ff73	memory_usage	gauge	81.710000	{}	2025-09-04 17:07:57.893+00
7edec7c1-d38c-4b6f-af4f-0d74f12d74d3	cpu_usage	gauge	5.000000	{}	2025-09-04 17:08:57.892+00
73d0241d-484f-4880-8a96-8b94d80c6ae3	uptime	gauge	1869.358948	{}	2025-09-04 17:09:57.893+00
fd5741a0-281a-415d-add3-843d07f64bc1	disk_usage	gauge	45.200000	{}	2025-09-04 17:10:57.893+00
af6a737f-7798-41f5-995c-a4e02c79c669	memory_usage	gauge	86.690000	{}	2025-09-04 17:11:57.893+00
cacf620a-736c-4b55-b9ab-e7191f67287e	cpu_usage	gauge	5.000000	{}	2025-09-04 17:12:57.893+00
db5e260e-2541-4d94-ae85-be864a5faefa	uptime	gauge	2109.360081	{}	2025-09-04 17:13:57.894+00
0e93281d-f008-4df7-b259-9f02a6674696	disk_usage	gauge	45.200000	{}	2025-09-04 17:14:57.895+00
fdec0cc6-5708-4d28-824b-5fbfbdfc3346	memory_usage	gauge	77.880000	{}	2025-09-04 17:15:57.895+00
1d616a87-ef7d-4ce0-afe3-a34b75642813	memory_usage	gauge	76.690000	{}	2025-09-04 17:16:57.895+00
d39ac3c7-61f7-45f5-a72f-8695334af12c	cpu_usage	gauge	5.000000	{}	2025-09-04 17:17:57.894+00
73f7af0c-8ffb-48e7-85c3-de364d17030e	uptime	gauge	2409.362032	{}	2025-09-04 17:18:57.896+00
8af9f7d5-29f5-4f7b-8455-a5eb1be777be	memory_usage	gauge	76.370000	{}	2025-09-03 17:38:57.671+00
799c340e-1060-4683-8785-9d6151806de5	memory_usage	gauge	74.950000	{}	2025-09-03 17:39:57.672+00
fae9ae07-0f51-4954-b795-53a814086352	memory_usage	gauge	75.310000	{}	2025-09-03 17:40:57.673+00
3008853d-9ee1-48c7-9cb5-787bfae91675	disk_usage	gauge	45.200000	{}	2025-09-03 17:41:57.674+00
7c3c6e9e-4aee-445d-b08e-46bef6f7a304	disk_usage	gauge	45.200000	{}	2025-09-03 17:42:57.674+00
6b9127fa-a1fa-4524-80c7-594a09557db2	memory_usage	gauge	75.780000	{}	2025-09-03 17:43:57.674+00
c4aff36a-f867-47bc-add7-146701fe3d8e	memory_usage	gauge	74.730000	{}	2025-09-03 17:44:57.674+00
a9dc8fa0-25ad-486a-bad1-679643469a8b	memory_usage	gauge	69.380000	{}	2025-09-03 17:45:57.674+00
29e8a401-008b-4d39-903d-98eb2ffcb34b	disk_usage	gauge	45.200000	{}	2025-09-03 17:46:57.674+00
49b1019b-3117-490a-97d1-0301c724b941	memory_usage	gauge	76.820000	{}	2025-09-04 17:19:57.897+00
baf5e2e6-c566-478c-8f1e-c8c4649d666e	cpu_usage	gauge	5.000000	{}	2025-09-04 17:20:57.898+00
89eda6af-a621-407a-81f3-c8d501ab6997	uptime	gauge	2589.364713	{}	2025-09-04 17:21:57.899+00
c762be17-4037-4897-8b85-30299762cb94	disk_usage	gauge	45.200000	{}	2025-09-04 17:22:57.899+00
c2c0cc6b-ae54-42a9-8bf6-2e0bc6533cf4	memory_usage	gauge	73.820000	{}	2025-09-04 17:23:57.9+00
9cbb552d-6a8c-45ce-b021-ef34270d849a	memory_usage	gauge	73.830000	{}	2025-09-04 17:24:57.901+00
5c50b329-cb20-44b9-9ce5-c0204c04cc81	uptime	gauge	2829.367555	{}	2025-09-04 17:25:57.901+00
44ba4ef7-1292-4de9-9488-f158f5ee78f9	memory_usage	gauge	75.460000	{}	2025-09-04 17:26:57.901+00
4302fa19-3268-4215-a7b5-f698e9d99e43	uptime	gauge	2949.367745	{}	2025-09-04 17:27:57.902+00
37416e58-6f4a-4557-b89b-92beb9a6f354	disk_usage	gauge	45.200000	{}	2025-09-04 17:28:57.903+00
575bbcb6-4fcb-49eb-83a4-f286a1467449	memory_usage	gauge	75.510000	{}	2025-09-04 17:29:57.903+00
11c13134-8ac5-4d4b-b7ea-f2aaab63b8e1	disk_usage	gauge	45.200000	{}	2025-09-04 17:30:57.904+00
277de2a8-b568-4175-92f1-150df4657215	uptime	gauge	3189.369620	{}	2025-09-04 17:31:57.903+00
b193d07d-fc23-4552-9f8f-a4fa5a0a2bcb	memory_usage	gauge	75.650000	{}	2025-09-04 17:32:57.904+00
c19481af-7fe9-499e-903b-4fe8def61abd	uptime	gauge	3309.370890	{}	2025-09-04 17:33:57.905+00
1a9804de-7f0e-4cf0-b1cd-42ee4e191036	cpu_usage	gauge	5.000000	{}	2025-09-04 17:34:57.905+00
9dafc875-42f3-4652-b6a0-b8b70eceb2ba	uptime	gauge	3429.370909	{}	2025-09-04 17:35:57.905+00
443628db-f046-4a98-aa98-dd54458daac9	memory_usage	gauge	74.330000	{}	2025-09-04 17:36:57.905+00
039fc4b6-d632-4e62-af81-bbb344ed04d6	cpu_usage	gauge	5.000000	{}	2025-09-04 17:37:57.906+00
c02dd4c7-25f3-485a-ba38-d9ac078a6ecb	uptime	gauge	3609.373008	{}	2025-09-04 17:38:57.907+00
3d64ece2-c60b-44be-bd7a-b8a3a0c16d88	disk_usage	gauge	45.200000	{}	2025-09-04 17:39:57.907+00
9bca934f-8695-46a4-8408-d4793599582e	uptime	gauge	1449.196557	{}	2025-09-03 17:38:57.672+00
89a5b4e0-6121-460c-a598-15876b8e40a0	disk_usage	gauge	45.200000	{}	2025-09-03 17:39:57.672+00
fce4ae47-dc85-4c73-8c4a-b8cdda4dae3e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:40:57.673+00
85dffb14-f790-47bd-a911-1e540456baab	uptime	gauge	1629.198934	{}	2025-09-03 17:41:57.674+00
c4ab9ca6-d1c0-40ad-9e34-d0adb0a1f722	memory_usage	gauge	69.660000	{}	2025-09-03 17:42:57.674+00
7d91ed18-0fa6-4112-b19f-25b6c8f5a509	cpu_usage	gauge	6.000000	{}	2025-09-03 17:43:57.674+00
d3abe193-3a28-4271-83e4-3465be6d48e8	uptime	gauge	1809.198974	{}	2025-09-03 17:44:57.674+00
ddc29f95-ebfe-4d68-972a-b473f5ee3697	disk_usage	gauge	45.200000	{}	2025-09-03 17:45:57.674+00
97271414-8b80-401d-9a9c-092086162181	cpu_usage	gauge	6.000000	{}	2025-09-03 17:46:57.674+00
b2d9643a-9e3c-42ce-8fe9-c0627287630c	cpu_usage	gauge	5.000000	{}	2025-09-04 17:19:57.897+00
ca4483c4-fff4-4de2-b4a9-884ee37609ee	memory_usage	gauge	87.500000	{}	2025-09-04 17:20:57.898+00
66a0476c-02a1-45eb-9770-00dfb2c6f485	cpu_usage	gauge	5.000000	{}	2025-09-04 17:21:57.898+00
a702346a-22e1-4ab5-ace8-4476a1a3be6d	uptime	gauge	2649.365507	{}	2025-09-04 17:22:57.899+00
8fdcd628-b534-416b-9ec2-103a3bf6288f	cpu_usage	gauge	5.000000	{}	2025-09-04 17:23:57.9+00
798c08f5-194f-41b0-b057-1c8d1465d16e	uptime	gauge	2769.367394	{}	2025-09-04 17:24:57.901+00
9588bfa6-db87-4031-ac91-28c303f47e8a	memory_usage	gauge	75.610000	{}	2025-09-04 17:25:57.901+00
60a74463-a5d2-44c0-b6d0-bd6c07e14392	disk_usage	gauge	45.200000	{}	2025-09-04 17:26:57.901+00
1a6fc462-c54d-4dad-a42a-2ba950f1084b	disk_usage	gauge	45.200000	{}	2025-09-04 17:27:57.902+00
d3ddae1d-ab81-499a-b211-87a0797c9c3f	memory_usage	gauge	75.370000	{}	2025-09-04 17:28:57.903+00
d1d60eae-3d28-40ef-b032-7b9182f494b5	uptime	gauge	3069.369431	{}	2025-09-04 17:29:57.903+00
e7fa72bf-92b0-4457-8529-1cca1d660b00	uptime	gauge	3129.370207	{}	2025-09-04 17:30:57.904+00
702e3a2a-bc79-429d-ad70-109e0ea8689f	cpu_usage	gauge	5.000000	{}	2025-09-04 17:31:57.903+00
782978be-18d2-470a-9043-9b8c1429d3e9	uptime	gauge	3249.370173	{}	2025-09-04 17:32:57.904+00
7ec36317-405d-4fab-aa65-c23be74f9d27	disk_usage	gauge	45.200000	{}	2025-09-04 17:33:57.905+00
5c32d559-2ba4-48a6-9e9e-fcc3306ff1f7	memory_usage	gauge	75.650000	{}	2025-09-04 17:34:57.905+00
51a1291d-b98d-4cc8-abc4-d1a66f7d6602	disk_usage	gauge	45.200000	{}	2025-09-04 17:35:57.905+00
57a3999d-6ea1-411c-a79e-b2e0e6b4eab3	cpu_usage	gauge	5.000000	{}	2025-09-04 17:36:57.905+00
8a79a013-9d37-49d1-ae4a-1ca3ce62b524	uptime	gauge	3549.371928	{}	2025-09-04 17:37:57.906+00
5ce26937-5fcf-4745-b9ab-bec2ab88f640	cpu_usage	gauge	5.000000	{}	2025-09-04 17:38:57.907+00
98b6e856-0c14-4f3e-a7a0-d725632260fc	uptime	gauge	3669.372720	{}	2025-09-04 17:39:57.907+00
b0ec73ec-05a4-41ce-a948-c185826dbd54	disk_usage	gauge	45.200000	{}	2025-09-03 17:38:57.672+00
ac9c68e5-d876-430b-91fd-0e6e2a1c3410	cpu_usage	gauge	6.000000	{}	2025-09-03 17:39:57.672+00
309b457e-be8f-409b-bb9d-a06fde29fcd8	uptime	gauge	1569.198065	{}	2025-09-03 17:40:57.673+00
d71ce269-5c80-407d-afa1-f018347e00ef	cpu_usage	gauge	6.000000	{}	2025-09-03 17:41:57.674+00
078ae03f-d1ff-46a8-a458-cfc73b02494d	uptime	gauge	1689.199280	{}	2025-09-03 17:42:57.674+00
04ee2b2c-d2dc-4d84-974c-d693aa46fb91	disk_usage	gauge	45.200000	{}	2025-09-03 17:43:57.674+00
440c1c06-07ed-4869-8e5d-2353d6b55492	cpu_usage	gauge	6.000000	{}	2025-09-03 17:44:57.674+00
8c56fa39-c143-4c5f-b813-d991ae742d5b	uptime	gauge	1869.199001	{}	2025-09-03 17:45:57.674+00
3786a258-f6c4-433c-8e6f-c638889021f2	memory_usage	gauge	70.310000	{}	2025-09-03 17:46:57.674+00
17c59373-dd7e-4221-b3a0-fda3693f8b04	uptime	gauge	2469.362921	{}	2025-09-04 17:19:57.897+00
dc5126b8-3dc6-458f-ba1c-25e363a3de90	disk_usage	gauge	45.200000	{}	2025-09-04 17:20:57.898+00
e74961a1-87c5-4180-b030-f40763066b66	memory_usage	gauge	73.780000	{}	2025-09-04 17:21:57.898+00
c2aaeedd-03f9-41c7-afeb-e2e6aa0ae314	memory_usage	gauge	73.800000	{}	2025-09-04 17:22:57.899+00
c4be3e0d-259e-4a73-940b-e063d923276d	disk_usage	gauge	45.200000	{}	2025-09-04 17:23:57.9+00
48880e8b-ca94-419b-b30f-14cdd0ca31ba	disk_usage	gauge	45.200000	{}	2025-09-04 17:24:57.901+00
d7c9df5e-192a-4518-b569-ed88eed440c7	cpu_usage	gauge	5.000000	{}	2025-09-04 17:25:57.901+00
a84c5e1d-5788-4769-b32f-14f526e8a06d	uptime	gauge	2889.367652	{}	2025-09-04 17:26:57.901+00
42642c1a-78fc-4007-8c54-230acce813f1	memory_usage	gauge	75.380000	{}	2025-09-04 17:27:57.901+00
8d18590e-b734-4bb8-95c5-f2e4e1c5b665	uptime	gauge	3009.368825	{}	2025-09-04 17:28:57.903+00
abd3e9c9-67fd-4591-a7a0-c33f9e82138f	cpu_usage	gauge	5.000000	{}	2025-09-04 17:29:57.903+00
8c85cc30-28e9-477e-8d2c-404778cc91a1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:39:23.806+00
26ebe056-6cff-4f48-a7e1-68f5417523dc	memory_usage	gauge	75.370000	{}	2025-09-03 17:39:23.806+00
f60af6e3-9040-4861-b6d3-cef212220f11	uptime	gauge	68.061418	{}	2025-09-03 17:39:23.806+00
02c86c92-611c-4d24-a2e1-cd3d0d8a548b	memory_usage	gauge	75.940000	{}	2025-09-03 17:40:23.805+00
5ddc8442-3b42-4bab-bf33-0e4ee46f2d77	disk_usage	gauge	45.200000	{}	2025-09-03 17:41:23.806+00
af6d2068-bace-4835-b683-0ce0f1f1e48c	disk_usage	gauge	45.200000	{}	2025-09-03 17:42:23.806+00
3a3b86a3-1d1c-4e06-a775-6f71bd4d1d62	disk_usage	gauge	45.200000	{}	2025-09-04 17:19:57.897+00
0e044a0f-5ade-4e19-818a-c7f5f213591b	uptime	gauge	2529.364387	{}	2025-09-04 17:20:57.898+00
b249a558-a84a-490d-bde9-a21f8796facb	disk_usage	gauge	45.200000	{}	2025-09-04 17:21:57.899+00
0150355c-5e9c-4202-83af-d0fd2d0a0281	cpu_usage	gauge	5.000000	{}	2025-09-04 17:22:57.899+00
8bdc402f-14ef-4263-bba5-389abf5cf784	uptime	gauge	2709.366162	{}	2025-09-04 17:23:57.9+00
3308a9f6-606f-4624-9499-0195e49d3836	cpu_usage	gauge	5.000000	{}	2025-09-04 17:24:57.901+00
701c761c-e234-44bd-b475-20503bf66679	disk_usage	gauge	45.200000	{}	2025-09-04 17:25:57.901+00
c4342572-85b7-4a18-8274-3f4aec50df80	cpu_usage	gauge	5.000000	{}	2025-09-04 17:26:57.901+00
7a717bcd-329b-4acf-bb0c-77b68f80c777	cpu_usage	gauge	5.000000	{}	2025-09-04 17:27:57.901+00
9db8ca3a-57c0-48ee-a61f-19facfdac2c5	cpu_usage	gauge	5.000000	{}	2025-09-04 17:28:57.902+00
c7bbf682-d88e-450c-b531-8aef29d0f601	disk_usage	gauge	45.200000	{}	2025-09-04 17:29:57.903+00
84e8e9d3-0e94-4946-9a2c-be9eb10d3ad3	memory_usage	gauge	86.140000	{}	2025-09-04 17:30:57.904+00
c5cf9cf1-4c6b-4fb4-8876-082a9ad90486	memory_usage	gauge	76.540000	{}	2025-09-04 17:31:57.903+00
c5e6d592-a241-442f-b6e9-332524554a4b	cpu_usage	gauge	5.000000	{}	2025-09-04 17:32:57.904+00
ed486426-a068-4856-bd7d-057bad2effba	cpu_usage	gauge	5.000000	{}	2025-09-04 17:33:57.905+00
12548111-e993-4f5e-87da-d85f3bb4fe7f	disk_usage	gauge	45.200000	{}	2025-09-04 17:34:57.905+00
b45ba79a-4b65-43b8-83ab-7d01922f4336	cpu_usage	gauge	5.000000	{}	2025-09-04 17:35:57.905+00
f6e9cef7-1bf2-4be8-adc4-f8c49a01ad64	uptime	gauge	3489.371689	{}	2025-09-04 17:36:57.905+00
efad62cd-5d95-4c01-8175-5a8cd53cf5b3	disk_usage	gauge	45.200000	{}	2025-09-04 17:37:57.906+00
7030ce26-a4c1-4037-a8a2-34aaa43bebc3	disk_usage	gauge	45.200000	{}	2025-09-04 17:38:57.907+00
e02c6b5a-1d42-43ba-8e24-5ca783dd0ee1	cpu_usage	gauge	5.000000	{}	2025-09-04 17:39:57.906+00
800ce171-2b79-48f1-a877-c596f7d1d5d9	disk_usage	gauge	45.200000	{}	2025-09-03 17:39:23.806+00
05d91215-4be2-4ee9-8bbb-7e17ef0c6be5	cpu_usage	gauge	6.000000	{}	2025-09-03 17:40:23.805+00
377c33d9-e54d-4934-a050-e319e14c8ca0	uptime	gauge	188.060981	{}	2025-09-03 17:41:23.806+00
9592603a-aebd-400e-aed3-292b4df76954	memory_usage	gauge	75.600000	{}	2025-09-03 17:42:23.806+00
3aae1ee8-a515-4241-9700-13b2a6951f0d	cpu_usage	gauge	5.000000	{}	2025-09-04 17:30:57.904+00
eadcdaab-b6d5-4f51-9865-bcba3e2e3ec5	disk_usage	gauge	45.200000	{}	2025-09-04 17:31:57.903+00
9f3933db-26d1-45cf-ba8e-5e34e4d6a9a9	disk_usage	gauge	45.200000	{}	2025-09-04 17:32:57.904+00
f06a3cfc-d0e0-42ee-880c-b9060e230f91	memory_usage	gauge	77.510000	{}	2025-09-04 17:33:57.905+00
7722fc42-d3fd-4d75-a05b-81f6b5270a53	uptime	gauge	3369.371182	{}	2025-09-04 17:34:57.905+00
83a9684c-f683-4ce2-a726-98a83613c89b	memory_usage	gauge	86.740000	{}	2025-09-04 17:35:57.905+00
87c2630d-747d-4ce9-9fdf-77e4095a7676	disk_usage	gauge	45.200000	{}	2025-09-04 17:36:57.905+00
6e4f39d9-4398-4e20-a4a9-9a2670e9e429	memory_usage	gauge	74.340000	{}	2025-09-04 17:37:57.906+00
85db0489-50d0-45fc-85a5-5744b3f68995	memory_usage	gauge	75.340000	{}	2025-09-04 17:38:57.907+00
101cabbe-e2d1-44a2-8330-3489fdf15177	memory_usage	gauge	75.780000	{}	2025-09-04 17:39:57.906+00
41e4600e-d2b1-474a-84cf-6c852b6e1326	disk_usage	gauge	45.200000	{}	2025-09-03 17:40:23.805+00
e36ec16a-fd6e-4c68-8460-21e79986dffd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:41:23.805+00
89d4effd-7509-4eb7-9d04-5604d97b601b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:42:23.806+00
66d39e8b-d955-4d3a-8515-4136b1f1eba0	uptime	gauge	128.060097	{}	2025-09-03 17:40:23.805+00
4d6958ef-9395-4bb6-8880-f60b7d4ba1ff	memory_usage	gauge	75.640000	{}	2025-09-03 17:41:23.805+00
daf4a31e-f83b-499b-abdb-458dd741a747	uptime	gauge	248.061567	{}	2025-09-03 17:42:23.806+00
d3e2442d-f582-479d-9cb2-17385aa5bfeb	cpu_usage	gauge	6.000000	{}	2025-09-03 17:44:34.867+00
b4ee41ec-9a53-47b0-bfee-4952c1e79fb5	memory_usage	gauge	74.730000	{}	2025-09-03 17:44:34.867+00
96785670-a783-464c-a686-3f939805ba94	disk_usage	gauge	45.200000	{}	2025-09-03 17:44:34.867+00
a8f0bf05-4139-42d9-b92f-d393075847db	uptime	gauge	67.975370	{}	2025-09-03 17:44:34.867+00
a59b9e8b-60b2-4f7d-8734-db284048f3c3	memory_usage	gauge	76.600000	{}	2025-09-03 16:48:36.215+00
763cea63-655e-43b6-a8b8-51c1a79f1f6d	memory_usage	gauge	76.550000	{}	2025-09-03 16:49:36.215+00
\.


--
-- TOC entry 4381 (class 0 OID 17239)
-- Dependencies: 253
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, user_id, user_name, user_avatar, content, rating, is_verified, is_public, is_featured, tags, metadata, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4390 (class 0 OID 17475)
-- Dependencies: 262
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, product_id, retailer_slug, rule_id, user_id_hash, status, price_paid, msrp, qty, alert_at, added_to_cart_at, purchased_at, lead_time_ms, failure_reason, region, session_fingerprint, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4367 (class 0 OID 16942)
-- Dependencies: 239
-- Data for Name: trend_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trend_analysis (id, product_id, price_trend, availability_trend, demand_score, volatility_score, analyzed_at) FROM stdin;
3732bd4a-2836-4db6-855a-40a67d36bbac	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	-0.066719	0.200000	\N	\N	2025-09-04 20:00:00.161+00
ec1fd75b-6f6a-4afa-992b-3beb194594df	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	0.024722	-0.085714	\N	\N	2025-09-04 20:00:00.162+00
f0bb2052-a6aa-4e55-a074-46eb47bf0685	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	-0.013561	0.085714	\N	\N	2025-09-04 20:00:00.163+00
e64d2560-f448-46b0-afb1-8b2cbcacc62a	89730910-09ee-4454-acb5-b5979e0d4ab7	-0.024365	-0.028571	\N	\N	2025-09-04 20:00:00.164+00
247b9cd1-b472-4b45-b069-f5394c9350b9	8ed8702f-15d5-4cf3-9555-3972d88e6c23	0.004130	0.085714	\N	\N	2025-09-04 20:00:00.165+00
56b78581-514c-4d64-9a78-056fce69b1b4	9948cf7e-41d4-4863-b36e-ec6372a7118b	0.019635	-0.085714	\N	\N	2025-09-04 20:00:00.166+00
7c25de4b-09cf-4428-afa2-36e49518b9ba	234ee314-1f17-4753-be1b-c868e441db7e	-0.017764	-0.114286	\N	\N	2025-09-04 20:00:00.167+00
6f1db51c-35a7-49bf-9d92-d3b6da40dee8	23f77789-99f9-4d89-a7f6-b48f9578c04f	0.003138	0.114286	\N	\N	2025-09-04 20:00:00.168+00
0405408e-1ce8-4cc6-8838-4dd334fff0f0	090cb184-ca13-4246-9db9-a923c68ade86	0.025081	0.057143	\N	\N	2025-09-04 20:00:00.169+00
30583c15-7ec9-47e7-8da5-0ec5b5abdaf4	454b81ef-7486-4fa8-b4f7-12284cec758a	0.002690	-0.142857	\N	\N	2025-09-04 20:00:00.17+00
f04d4c83-76c8-4ef0-b410-1f6f97140fb4	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	0.044904	-0.257143	\N	\N	2025-09-04 20:00:00.171+00
9f1bcdbc-e958-4348-90a4-1d8fa92cdbf1	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	-0.049201	0.000000	\N	\N	2025-09-04 20:00:00.173+00
566c3201-424c-46e2-804d-e15d1bdbcd92	d4cab033-1755-4548-b385-6ab1a9376a85	-0.006216	0.142857	\N	\N	2025-09-04 20:00:00.176+00
443f3951-fc40-4d25-9a93-f56e74034adf	d78dec22-022a-4177-b8be-026905a38689	0.034826	-0.142857	\N	\N	2025-09-04 20:00:00.178+00
17cf37b2-ed18-49a6-8ec9-4e08c9089b83	f94dae6d-305a-4948-8a58-0b93e0739f94	0.004809	0.085714	\N	\N	2025-09-04 20:00:00.181+00
ebc81d81-10ce-421a-9516-2bb8b4cbcd62	a9337f94-3157-4709-8026-5454ead6d708	0.000899	-0.028571	\N	\N	2025-09-04 20:00:00.187+00
5b518a14-2565-4b39-8491-3298c340e15f	b0cfc9f0-5aad-471b-809d-aab2c03485e1	-0.028038	0.085714	\N	\N	2025-09-04 20:00:00.188+00
836fc007-0d98-47b8-bc54-304ade97af19	cd48f66e-2e5c-4756-b2f0-f358eaac01da	0.007205	-0.142857	\N	\N	2025-09-04 20:00:00.19+00
7aa35d35-5f8e-445c-8a3e-38148e5c6c2c	d3399ef0-4d30-475a-940c-1d1b11481b37	0.006039	0.000000	\N	\N	2025-09-04 20:00:00.192+00
\.


--
-- TOC entry 4363 (class 0 OID 16851)
-- Dependencies: 235
-- Data for Name: unsubscribe_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unsubscribe_tokens (id, token, user_id, email_type, expires_at, used_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4397 (class 0 OID 17617)
-- Dependencies: 269
-- Data for Name: url_candidates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.url_candidates (id, product_id, retailer_id, pattern_id, url, status, score, reason, first_seen_at, last_checked_at, created_at, updated_at) FROM stdin;
d33fb560-a1df-4b7a-a8d9-3f5077d12012	b799d31f-424e-47c5-8dba-5d8a4af90512	a3d4e08f-d21d-4bad-b83c-8499566c2930	tg:search	https://www.target.com/s?searchTerm=pok%2Bmon%2Btcg%2Belite%2Btrainer%2Bbox%2Bsurging%2Bsparks	live	NaN	cta	2025-09-04 16:15:41.944+00	2025-09-04 16:16:20.09+00	2025-09-04 16:15:41.944+00	2025-09-04 16:16:20.09+00
9886d20e-c686-4162-91c9-57ec698e877f	cadea567-c448-4789-872d-49fa516ea9bb	a3d4e08f-d21d-4bad-b83c-8499566c2930	tg:search	https://www.target.com/s?searchTerm=elite%2Btrainer%2Bbox%2Bsurging%2Bsparks	unknown	0.480	http_407	2025-09-04 19:58:36.398+00	2025-09-04 22:25:06.857+00	2025-09-04 19:58:36.398+00	2025-09-04 22:25:06.857+00
c72f5930-6ee3-482c-814d-2d5617b1fdf8	cadea567-c448-4789-872d-49fa516ea9bb	a3d4e08f-d21d-4bad-b83c-8499566c2930	tg:search	https://www.target.com/s?searchTerm=pokemon%2Btcg%2Belite%2Btrainer%2Bbox%2Bsurging%2Bsparks	unknown	0.480	http_407	2025-09-04 18:01:01.98+00	2025-09-04 22:25:13.376+00	2025-09-04 18:01:01.98+00	2025-09-04 22:25:13.376+00
a7cf8d43-f17f-424d-bed4-9faf12700acd	cadea567-c448-4789-872d-49fa516ea9bb	c3755fe7-87a1-41c0-aee4-d2c90170d47f	bb:search	https://www.bestbuy.com/site/searchpage.jsp?st=pokemon%2Btcg%2Belite%2Btrainer%2Bbox%2Bsurging%2Bsparks	unknown	0.480	http_407	2025-09-04 19:58:32.958+00	2025-09-04 22:25:20.013+00	2025-09-04 19:58:32.958+00	2025-09-04 22:25:20.013+00
\.


--
-- TOC entry 4387 (class 0 OID 17385)
-- Dependencies: 259
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assignment_reason, assigned_at, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4359 (class 0 OID 16792)
-- Dependencies: 231
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, refresh_token, device_info, ip_address, user_agent, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4355 (class 0 OID 16673)
-- Dependencies: 227
-- Data for Name: user_watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_watch_packs (id, user_id, watch_pack_id, customizations, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4344 (class 0 OID 16477)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, subscription_tier, created_at, updated_at, email_verified, verification_token, reset_token, reset_token_expires, failed_login_attempts, locked_until, last_login, shipping_addresses, payment_methods, retailer_credentials, notification_settings, quiet_hours, timezone, zip_code, push_subscriptions, role, last_admin_login, admin_permissions, first_name, last_name, preferences, newsletter_subscription, terms_accepted, direct_permissions, role_last_updated, role_updated_by, permission_metadata, stripe_customer_id, subscription_id, subscription_status, subscription_start_date, subscription_end_date, trial_end_date, cancel_at_period_end, subscription_plan_id) FROM stdin;
84a8557a-b08e-405e-b391-16def0d2020d	test@boosterbeacon.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS	pro	2025-09-03 16:31:17.756398+00	2025-09-03 16:31:17.756398+00	f	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	[]	\N	\N	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
0b5d6a4f-8fd8-439b-9d75-6e0933be5b7e	derekmihlfeith@gmail.com	$2b$12$Cuy.tpIf2h6fhYRnCUfU8OwiHQ.5gCW0xEwLP48F3WHQCG5IOBfBu	free	2025-09-03 17:06:05.918057+00	2025-09-04 20:27:48.06+00	t	\N	2851a820ce70f1433cd59c4c3a8911e0e4e01f67807699393bf983d29ed0d916	2025-09-03 19:22:54.035+00	0	\N	2025-09-04 20:27:48.06+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	Derek	Mihlfeith	{}	t	t	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
a7d94af5-6a3d-4b56-bdbf-52bec13375a1	admin@boosterbeacon.com	$2b$12$ftfCcN.wcekmC0SGMXUvB.1zzyHlyl5UyqD65Ryk/YKgax5P3L8j6	pro	2025-09-03 16:53:58.366645+00	2025-09-04 22:18:18.418+00	t	\N	\N	\N	0	\N	2025-09-04 22:18:18.418+00	[]	[]	{}	{"sms": true, "email": true, "discord": true, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	super_admin	\N	["user_management", "user_suspend", "user_delete", "ml_model_training", "ml_data_review", "system_monitoring", "analytics_view", "audit_log_view"]	Admin	User	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
\.


--
-- TOC entry 4354 (class 0 OID 16656)
-- Dependencies: 226
-- Data for Name: watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watch_packs (id, name, slug, description, product_ids, is_active, auto_update, update_criteria, subscriber_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4353 (class 0 OID 16624)
-- Dependencies: 225
-- Data for Name: watches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watches (id, user_id, product_id, retailer_ids, max_price, availability_type, zip_code, radius_miles, is_active, alert_preferences, last_alerted, alert_count, created_at, updated_at, auto_purchase) FROM stdin;
ff92a949-26ce-4f3e-bae6-882db87f6802	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	d78dec22-022a-4177-b8be-026905a38689	{}	\N	both	\N	\N	t	{}	\N	0	2025-09-04 22:24:38.815013+00	2025-09-04 22:24:38.815013+00	{}
\.


--
-- TOC entry 4378 (class 0 OID 17171)
-- Dependencies: 250
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, user_id, name, url, secret, events, headers, retry_config, filters, is_active, total_calls, successful_calls, failed_calls, last_triggered, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4407 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 18, true);


--
-- TOC entry 4408 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 4010 (class 2606 OID 17076)
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3918 (class 2606 OID 16761)
-- Name: alert_deliveries alert_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_pkey PRIMARY KEY (id);


--
-- TOC entry 3904 (class 2606 OID 16715)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3970 (class 2606 OID 16928)
-- Name: availability_snapshots availability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 4111 (class 2606 OID 17500)
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- TOC entry 4071 (class 2606 OID 17360)
-- Name: comment_likes comment_likes_comment_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_user_id_unique UNIQUE (comment_id, user_id);


--
-- TOC entry 4073 (class 2606 OID 17348)
-- Name: comment_likes comment_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4055 (class 2606 OID 17284)
-- Name: community_posts community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4119 (class 2606 OID 17516)
-- Name: conversion_analytics conversion_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversion_analytics
    ADD CONSTRAINT conversion_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4039 (class 2606 OID 17207)
-- Name: csv_operations csv_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_pkey PRIMARY KEY (id);


--
-- TOC entry 4004 (class 2606 OID 17051)
-- Name: data_quality_metrics data_quality_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 17162)
-- Name: discord_servers discord_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_pkey PRIMARY KEY (id);


--
-- TOC entry 4033 (class 2606 OID 17169)
-- Name: discord_servers discord_servers_user_id_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_server_id_unique UNIQUE (user_id, server_id);


--
-- TOC entry 4127 (class 2606 OID 17561)
-- Name: drop_events drop_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drop_events
    ADD CONSTRAINT drop_events_pkey PRIMARY KEY (id);


--
-- TOC entry 4131 (class 2606 OID 17582)
-- Name: drop_outcomes drop_outcomes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drop_outcomes
    ADD CONSTRAINT drop_outcomes_pkey PRIMARY KEY (id);


--
-- TOC entry 3963 (class 2606 OID 16872)
-- Name: email_bounces email_bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_bounces
    ADD CONSTRAINT email_bounces_pkey PRIMARY KEY (id);


--
-- TOC entry 3967 (class 2606 OID 16882)
-- Name: email_complaints email_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_complaints
    ADD CONSTRAINT email_complaints_pkey PRIMARY KEY (id);


--
-- TOC entry 3950 (class 2606 OID 16850)
-- Name: email_delivery_logs email_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3941 (class 2606 OID 16840)
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 3944 (class 2606 OID 16898)
-- Name: email_preferences email_preferences_unsubscribe_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_unsubscribe_token_unique UNIQUE (unsubscribe_token);


--
-- TOC entry 3991 (class 2606 OID 17006)
-- Name: engagement_metrics engagement_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3995 (class 2606 OID 17013)
-- Name: engagement_metrics engagement_metrics_product_id_metrics_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_metrics_date_unique UNIQUE (product_id, metrics_date);


--
-- TOC entry 4122 (class 2606 OID 17542)
-- Name: external_product_map external_product_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_pkey PRIMARY KEY (id);


--
-- TOC entry 4125 (class 2606 OID 17549)
-- Name: external_product_map external_product_map_retailer_slug_external_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_retailer_slug_external_id_unique UNIQUE (retailer_slug, external_id);


--
-- TOC entry 3849 (class 2606 OID 16508)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3847 (class 2606 OID 16501)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3987 (class 2606 OID 16985)
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4014 (class 2606 OID 17111)
-- Name: ml_models ml_models_name_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_name_version_unique UNIQUE (name, version);


--
-- TOC entry 4016 (class 2606 OID 17101)
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


--
-- TOC entry 3981 (class 2606 OID 16966)
-- Name: ml_predictions ml_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_pkey PRIMARY KEY (id);


--
-- TOC entry 4021 (class 2606 OID 17124)
-- Name: ml_training_data ml_training_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4136 (class 2606 OID 17604)
-- Name: model_features model_features_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_features
    ADD CONSTRAINT model_features_pkey PRIMARY KEY (id);


--
-- TOC entry 4096 (class 2606 OID 17427)
-- Name: permission_audit_log permission_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4060 (class 2606 OID 17307)
-- Name: post_comments post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_pkey PRIMARY KEY (id);


--
-- TOC entry 4064 (class 2606 OID 17327)
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4067 (class 2606 OID 17339)
-- Name: post_likes post_likes_post_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_user_id_unique UNIQUE (post_id, user_id);


--
-- TOC entry 3922 (class 2606 OID 16777)
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3877 (class 2606 OID 16607)
-- Name: product_availability product_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_pkey PRIMARY KEY (id);


--
-- TOC entry 3880 (class 2606 OID 16619)
-- Name: product_availability product_availability_product_id_retailer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_retailer_id_unique UNIQUE (product_id, retailer_id);


--
-- TOC entry 3858 (class 2606 OID 16555)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3861 (class 2606 OID 16557)
-- Name: product_categories product_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_slug_unique UNIQUE (slug);


--
-- TOC entry 3865 (class 2606 OID 16578)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3870 (class 2606 OID 16580)
-- Name: products products_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_unique UNIQUE (slug);


--
-- TOC entry 3873 (class 2606 OID 16582)
-- Name: products products_upc_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_upc_unique UNIQUE (upc);


--
-- TOC entry 3852 (class 2606 OID 16540)
-- Name: retailers retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (id);


--
-- TOC entry 3855 (class 2606 OID 16542)
-- Name: retailers retailers_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_slug_unique UNIQUE (slug);


--
-- TOC entry 4079 (class 2606 OID 17379)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 4081 (class 2606 OID 17377)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4083 (class 2606 OID 17381)
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- TOC entry 3999 (class 2606 OID 17027)
-- Name: seasonal_patterns seasonal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 4043 (class 2606 OID 17225)
-- Name: social_shares social_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_pkey PRIMARY KEY (id);


--
-- TOC entry 4099 (class 2606 OID 17468)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4101 (class 2606 OID 17470)
-- Name: subscription_plans subscription_plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_unique UNIQUE (slug);


--
-- TOC entry 4103 (class 2606 OID 17472)
-- Name: subscription_plans subscription_plans_stripe_price_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_stripe_price_id_unique UNIQUE (stripe_price_id);


--
-- TOC entry 3937 (class 2606 OID 16824)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 4027 (class 2606 OID 17143)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4049 (class 2606 OID 17256)
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- TOC entry 4109 (class 2606 OID 17485)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3976 (class 2606 OID 16948)
-- Name: trend_analysis trend_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_pkey PRIMARY KEY (id);


--
-- TOC entry 3955 (class 2606 OID 16861)
-- Name: unsubscribe_tokens unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3958 (class 2606 OID 16894)
-- Name: unsubscribe_tokens unsubscribe_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4140 (class 2606 OID 17642)
-- Name: url_candidates uq_url_candidates_retailer_url; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url_candidates
    ADD CONSTRAINT uq_url_candidates_retailer_url UNIQUE (retailer_id, url);


--
-- TOC entry 4142 (class 2606 OID 17628)
-- Name: url_candidates url_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url_candidates
    ADD CONSTRAINT url_candidates_pkey PRIMARY KEY (id);


--
-- TOC entry 4087 (class 2606 OID 17396)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4091 (class 2606 OID 17413)
-- Name: user_roles user_roles_user_id_role_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_unique UNIQUE (user_id, role_id);


--
-- TOC entry 3930 (class 2606 OID 16802)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3933 (class 2606 OID 16809)
-- Name: user_sessions user_sessions_refresh_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_unique UNIQUE (refresh_token);


--
-- TOC entry 3897 (class 2606 OID 16684)
-- Name: user_watch_packs user_watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3900 (class 2606 OID 16696)
-- Name: user_watch_packs user_watch_packs_user_id_watch_pack_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique UNIQUE (user_id, watch_pack_id);


--
-- TOC entry 3831 (class 2606 OID 16489)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3833 (class 2606 OID 16510)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3836 (class 2606 OID 16487)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3841 (class 2606 OID 17522)
-- Name: users users_stripe_customer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_unique UNIQUE (stripe_customer_id);


--
-- TOC entry 3843 (class 2606 OID 17524)
-- Name: users users_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_subscription_id_unique UNIQUE (subscription_id);


--
-- TOC entry 3892 (class 2606 OID 16668)
-- Name: watch_packs watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3895 (class 2606 OID 16670)
-- Name: watch_packs watch_packs_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_slug_unique UNIQUE (slug);


--
-- TOC entry 3884 (class 2606 OID 16639)
-- Name: watches watches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_pkey PRIMARY KEY (id);


--
-- TOC entry 3889 (class 2606 OID 16651)
-- Name: watches watches_user_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_product_id_unique UNIQUE (user_id, product_id);


--
-- TOC entry 4035 (class 2606 OID 17187)
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 4006 (class 1259 OID 17083)
-- Name: admin_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_action_created_at_index ON public.admin_audit_log USING btree (action, created_at);


--
-- TOC entry 4007 (class 1259 OID 17082)
-- Name: admin_audit_log_admin_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_admin_user_id_created_at_index ON public.admin_audit_log USING btree (admin_user_id, created_at);


--
-- TOC entry 4008 (class 1259 OID 17085)
-- Name: admin_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_created_at_index ON public.admin_audit_log USING btree (created_at);


--
-- TOC entry 4011 (class 1259 OID 17084)
-- Name: admin_audit_log_target_type_target_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_target_type_target_id_index ON public.admin_audit_log USING btree (target_type, target_id);


--
-- TOC entry 3915 (class 1259 OID 16767)
-- Name: alert_deliveries_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_alert_id_index ON public.alert_deliveries USING btree (alert_id);


--
-- TOC entry 3916 (class 1259 OID 16768)
-- Name: alert_deliveries_channel_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_channel_index ON public.alert_deliveries USING btree (channel);


--
-- TOC entry 3919 (class 1259 OID 16770)
-- Name: alert_deliveries_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_sent_at_index ON public.alert_deliveries USING btree (sent_at);


--
-- TOC entry 3920 (class 1259 OID 16769)
-- Name: alert_deliveries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_status_index ON public.alert_deliveries USING btree (status);


--
-- TOC entry 3902 (class 1259 OID 16744)
-- Name: alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_index ON public.alerts USING btree (created_at);


--
-- TOC entry 3905 (class 1259 OID 16742)
-- Name: alerts_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_priority_index ON public.alerts USING btree (priority);


--
-- TOC entry 3906 (class 1259 OID 16737)
-- Name: alerts_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_product_id_index ON public.alerts USING btree (product_id);


--
-- TOC entry 3907 (class 1259 OID 16738)
-- Name: alerts_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_retailer_id_index ON public.alerts USING btree (retailer_id);


--
-- TOC entry 3908 (class 1259 OID 16743)
-- Name: alerts_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_scheduled_for_index ON public.alerts USING btree (scheduled_for);


--
-- TOC entry 3909 (class 1259 OID 16740)
-- Name: alerts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_index ON public.alerts USING btree (status);


--
-- TOC entry 3910 (class 1259 OID 16746)
-- Name: alerts_status_priority_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_priority_created_at_index ON public.alerts USING btree (status, priority, created_at);


--
-- TOC entry 3911 (class 1259 OID 16741)
-- Name: alerts_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_index ON public.alerts USING btree (type);


--
-- TOC entry 3912 (class 1259 OID 16736)
-- Name: alerts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_index ON public.alerts USING btree (user_id);


--
-- TOC entry 3913 (class 1259 OID 16745)
-- Name: alerts_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_status_index ON public.alerts USING btree (user_id, status);


--
-- TOC entry 3914 (class 1259 OID 16739)
-- Name: alerts_watch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_watch_id_index ON public.alerts USING btree (watch_id);


--
-- TOC entry 3971 (class 1259 OID 16939)
-- Name: availability_snapshots_product_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_product_id_snapshot_time_index ON public.availability_snapshots USING btree (product_id, snapshot_time);


--
-- TOC entry 3972 (class 1259 OID 16940)
-- Name: availability_snapshots_retailer_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_retailer_id_snapshot_time_index ON public.availability_snapshots USING btree (retailer_id, snapshot_time);


--
-- TOC entry 3973 (class 1259 OID 16941)
-- Name: availability_snapshots_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_snapshot_time_index ON public.availability_snapshots USING btree (snapshot_time);


--
-- TOC entry 4069 (class 1259 OID 17361)
-- Name: comment_likes_comment_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_comment_id_index ON public.comment_likes USING btree (comment_id);


--
-- TOC entry 4074 (class 1259 OID 17362)
-- Name: comment_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_user_id_index ON public.comment_likes USING btree (user_id);


--
-- TOC entry 4052 (class 1259 OID 17293)
-- Name: community_posts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_created_at_index ON public.community_posts USING btree (created_at);


--
-- TOC entry 4053 (class 1259 OID 17292)
-- Name: community_posts_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_is_featured_is_public_index ON public.community_posts USING btree (is_featured, is_public);


--
-- TOC entry 4056 (class 1259 OID 17291)
-- Name: community_posts_type_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_type_moderation_status_index ON public.community_posts USING btree (type, moderation_status);


--
-- TOC entry 4057 (class 1259 OID 17290)
-- Name: community_posts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_user_id_index ON public.community_posts USING btree (user_id);


--
-- TOC entry 4116 (class 1259 OID 17519)
-- Name: conversion_analytics_event_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_date_index ON public.conversion_analytics USING btree (event_date);


--
-- TOC entry 4117 (class 1259 OID 17518)
-- Name: conversion_analytics_event_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_type_index ON public.conversion_analytics USING btree (event_type);


--
-- TOC entry 4120 (class 1259 OID 17517)
-- Name: conversion_analytics_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_user_id_index ON public.conversion_analytics USING btree (user_id);


--
-- TOC entry 4037 (class 1259 OID 17214)
-- Name: csv_operations_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_created_at_index ON public.csv_operations USING btree (created_at);


--
-- TOC entry 4040 (class 1259 OID 17213)
-- Name: csv_operations_user_id_operation_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_user_id_operation_type_index ON public.csv_operations USING btree (user_id, operation_type);


--
-- TOC entry 4001 (class 1259 OID 17058)
-- Name: data_quality_metrics_assessed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_assessed_at_index ON public.data_quality_metrics USING btree (assessed_at);


--
-- TOC entry 4002 (class 1259 OID 17059)
-- Name: data_quality_metrics_overall_quality_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_overall_quality_score_index ON public.data_quality_metrics USING btree (overall_quality_score);


--
-- TOC entry 4005 (class 1259 OID 17057)
-- Name: data_quality_metrics_product_id_data_source_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_product_id_data_source_index ON public.data_quality_metrics USING btree (product_id, data_source);


--
-- TOC entry 4031 (class 1259 OID 17170)
-- Name: discord_servers_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX discord_servers_user_id_is_active_index ON public.discord_servers USING btree (user_id, is_active);


--
-- TOC entry 3960 (class 1259 OID 16909)
-- Name: email_bounces_bounce_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_bounce_type_index ON public.email_bounces USING btree (bounce_type);


--
-- TOC entry 3961 (class 1259 OID 16895)
-- Name: email_bounces_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_message_id_index ON public.email_bounces USING btree (message_id);


--
-- TOC entry 3964 (class 1259 OID 16914)
-- Name: email_bounces_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_timestamp_index ON public.email_bounces USING btree ("timestamp");


--
-- TOC entry 3965 (class 1259 OID 16896)
-- Name: email_complaints_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_message_id_index ON public.email_complaints USING btree (message_id);


--
-- TOC entry 3968 (class 1259 OID 16910)
-- Name: email_complaints_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_timestamp_index ON public.email_complaints USING btree ("timestamp");


--
-- TOC entry 3946 (class 1259 OID 16916)
-- Name: email_delivery_logs_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_alert_id_index ON public.email_delivery_logs USING btree (alert_id);


--
-- TOC entry 3947 (class 1259 OID 16921)
-- Name: email_delivery_logs_email_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_email_type_index ON public.email_delivery_logs USING btree (email_type);


--
-- TOC entry 3948 (class 1259 OID 16918)
-- Name: email_delivery_logs_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_message_id_index ON public.email_delivery_logs USING btree (message_id);


--
-- TOC entry 3951 (class 1259 OID 16920)
-- Name: email_delivery_logs_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_sent_at_index ON public.email_delivery_logs USING btree (sent_at);


--
-- TOC entry 3952 (class 1259 OID 16912)
-- Name: email_delivery_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_user_id_index ON public.email_delivery_logs USING btree (user_id);


--
-- TOC entry 3942 (class 1259 OID 16915)
-- Name: email_preferences_unsubscribe_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_unsubscribe_token_index ON public.email_preferences USING btree (unsubscribe_token);


--
-- TOC entry 3945 (class 1259 OID 16911)
-- Name: email_preferences_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_user_id_index ON public.email_preferences USING btree (user_id);


--
-- TOC entry 3989 (class 1259 OID 17015)
-- Name: engagement_metrics_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_metrics_date_index ON public.engagement_metrics USING btree (metrics_date);


--
-- TOC entry 3992 (class 1259 OID 17014)
-- Name: engagement_metrics_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_index ON public.engagement_metrics USING btree (product_id);


--
-- TOC entry 3993 (class 1259 OID 17016)
-- Name: engagement_metrics_product_id_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_metrics_date_index ON public.engagement_metrics USING btree (product_id, metrics_date);


--
-- TOC entry 4123 (class 1259 OID 17550)
-- Name: external_product_map_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_product_map_product_id_index ON public.external_product_map USING btree (product_id);


--
-- TOC entry 4112 (class 1259 OID 17501)
-- Name: idx_billing_events_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_customer ON public.billing_events USING btree (stripe_customer_id);


--
-- TOC entry 4113 (class 1259 OID 17503)
-- Name: idx_billing_events_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_invoice ON public.billing_events USING btree (invoice_id);


--
-- TOC entry 4114 (class 1259 OID 17502)
-- Name: idx_billing_events_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_subscription ON public.billing_events USING btree (subscription_id);


--
-- TOC entry 4115 (class 1259 OID 17504)
-- Name: idx_billing_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_type ON public.billing_events USING btree (event_type);


--
-- TOC entry 4128 (class 1259 OID 17572)
-- Name: idx_drop_events_prod_retailer_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drop_events_prod_retailer_time ON public.drop_events USING btree (product_id, retailer_id, observed_at);


--
-- TOC entry 4129 (class 1259 OID 17573)
-- Name: idx_drop_events_type_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drop_events_type_time ON public.drop_events USING btree (signal_type, observed_at);


--
-- TOC entry 4132 (class 1259 OID 17593)
-- Name: idx_drop_outcomes_prod_retailer_dropat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drop_outcomes_prod_retailer_dropat ON public.drop_outcomes USING btree (product_id, retailer_id, drop_at);


--
-- TOC entry 4133 (class 1259 OID 17615)
-- Name: idx_model_features_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_features_key ON public.model_features USING btree (product_id, retailer_id, as_of);


--
-- TOC entry 4134 (class 1259 OID 17616)
-- Name: idx_model_features_split; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_features_split ON public.model_features USING btree (split_tag);


--
-- TOC entry 4104 (class 1259 OID 17487)
-- Name: idx_transactions_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_product ON public.transactions USING btree (product_id);


--
-- TOC entry 4105 (class 1259 OID 17488)
-- Name: idx_transactions_retailer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_retailer ON public.transactions USING btree (retailer_slug);


--
-- TOC entry 4106 (class 1259 OID 17489)
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- TOC entry 4107 (class 1259 OID 17486)
-- Name: idx_transactions_user_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_hash ON public.transactions USING btree (user_id_hash);


--
-- TOC entry 4137 (class 1259 OID 17639)
-- Name: idx_url_candidates_prod_retailer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_url_candidates_prod_retailer ON public.url_candidates USING btree (product_id, retailer_id);


--
-- TOC entry 4138 (class 1259 OID 17640)
-- Name: idx_url_candidates_retailer_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_url_candidates_retailer_status ON public.url_candidates USING btree (retailer_id, status);


--
-- TOC entry 3825 (class 1259 OID 16490)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3826 (class 1259 OID 16829)
-- Name: idx_users_push_subscriptions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_push_subscriptions ON public.users USING btree (id);


--
-- TOC entry 3827 (class 1259 OID 17525)
-- Name: idx_users_stripe_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_stripe_customer ON public.users USING btree (stripe_customer_id);


--
-- TOC entry 3828 (class 1259 OID 17526)
-- Name: idx_users_subscription_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_subscription_status ON public.users USING btree (subscription_status);


--
-- TOC entry 3984 (class 1259 OID 16988)
-- Name: ml_model_metrics_last_evaluated_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_last_evaluated_at_index ON public.ml_model_metrics USING btree (last_evaluated_at);


--
-- TOC entry 3985 (class 1259 OID 16986)
-- Name: ml_model_metrics_model_name_model_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_model_name_model_version_index ON public.ml_model_metrics USING btree (model_name, model_version);


--
-- TOC entry 3988 (class 1259 OID 16987)
-- Name: ml_model_metrics_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_prediction_type_index ON public.ml_model_metrics USING btree (prediction_type);


--
-- TOC entry 4012 (class 1259 OID 17107)
-- Name: ml_models_name_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_name_status_created_at_index ON public.ml_models USING btree (name, status, created_at);


--
-- TOC entry 4017 (class 1259 OID 17108)
-- Name: ml_models_status_deployed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_status_deployed_at_index ON public.ml_models USING btree (status, deployed_at);


--
-- TOC entry 4018 (class 1259 OID 17109)
-- Name: ml_models_trained_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_trained_by_index ON public.ml_models USING btree (trained_by);


--
-- TOC entry 3979 (class 1259 OID 16973)
-- Name: ml_predictions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_expires_at_index ON public.ml_predictions USING btree (expires_at);


--
-- TOC entry 3982 (class 1259 OID 16972)
-- Name: ml_predictions_product_id_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_index ON public.ml_predictions USING btree (product_id, prediction_type);


--
-- TOC entry 3983 (class 1259 OID 16974)
-- Name: ml_predictions_product_id_prediction_type_timeframe_days_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_timeframe_days_index ON public.ml_predictions USING btree (product_id, prediction_type, timeframe_days);


--
-- TOC entry 4019 (class 1259 OID 17131)
-- Name: ml_training_data_dataset_name_data_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_dataset_name_data_type_index ON public.ml_training_data USING btree (dataset_name, data_type);


--
-- TOC entry 4022 (class 1259 OID 17132)
-- Name: ml_training_data_reviewed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_reviewed_by_index ON public.ml_training_data USING btree (reviewed_by);


--
-- TOC entry 4023 (class 1259 OID 17130)
-- Name: ml_training_data_status_data_type_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_status_data_type_created_at_index ON public.ml_training_data USING btree (status, data_type, created_at);


--
-- TOC entry 4092 (class 1259 OID 17440)
-- Name: permission_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_action_created_at_index ON public.permission_audit_log USING btree (action, created_at);


--
-- TOC entry 4093 (class 1259 OID 17439)
-- Name: permission_audit_log_actor_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_actor_user_id_created_at_index ON public.permission_audit_log USING btree (actor_user_id, created_at);


--
-- TOC entry 4094 (class 1259 OID 17441)
-- Name: permission_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_created_at_index ON public.permission_audit_log USING btree (created_at);


--
-- TOC entry 4097 (class 1259 OID 17438)
-- Name: permission_audit_log_target_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_target_user_id_created_at_index ON public.permission_audit_log USING btree (target_user_id, created_at);


--
-- TOC entry 4058 (class 1259 OID 17320)
-- Name: post_comments_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_created_at_index ON public.post_comments USING btree (created_at);


--
-- TOC entry 4061 (class 1259 OID 17318)
-- Name: post_comments_post_id_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_post_id_moderation_status_index ON public.post_comments USING btree (post_id, moderation_status);


--
-- TOC entry 4062 (class 1259 OID 17319)
-- Name: post_comments_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_user_id_index ON public.post_comments USING btree (user_id);


--
-- TOC entry 4065 (class 1259 OID 17340)
-- Name: post_likes_post_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_post_id_index ON public.post_likes USING btree (post_id);


--
-- TOC entry 4068 (class 1259 OID 17341)
-- Name: post_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_user_id_index ON public.post_likes USING btree (user_id);


--
-- TOC entry 3923 (class 1259 OID 16788)
-- Name: price_history_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_index ON public.price_history USING btree (product_id);


--
-- TOC entry 3924 (class 1259 OID 16791)
-- Name: price_history_product_id_retailer_id_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_retailer_id_recorded_at_index ON public.price_history USING btree (product_id, retailer_id, recorded_at);


--
-- TOC entry 3925 (class 1259 OID 16790)
-- Name: price_history_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_recorded_at_index ON public.price_history USING btree (recorded_at);


--
-- TOC entry 3926 (class 1259 OID 16789)
-- Name: price_history_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_retailer_id_index ON public.price_history USING btree (retailer_id);


--
-- TOC entry 3874 (class 1259 OID 16622)
-- Name: product_availability_in_stock_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_in_stock_index ON public.product_availability USING btree (in_stock);


--
-- TOC entry 3875 (class 1259 OID 16623)
-- Name: product_availability_last_checked_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_last_checked_index ON public.product_availability USING btree (last_checked);


--
-- TOC entry 3878 (class 1259 OID 16620)
-- Name: product_availability_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_product_id_index ON public.product_availability USING btree (product_id);


--
-- TOC entry 3881 (class 1259 OID 16621)
-- Name: product_availability_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_retailer_id_index ON public.product_availability USING btree (retailer_id);


--
-- TOC entry 3856 (class 1259 OID 16564)
-- Name: product_categories_parent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_parent_id_index ON public.product_categories USING btree (parent_id);


--
-- TOC entry 3859 (class 1259 OID 16563)
-- Name: product_categories_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_slug_index ON public.product_categories USING btree (slug);


--
-- TOC entry 3862 (class 1259 OID 16590)
-- Name: products_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_index ON public.products USING btree (category_id);


--
-- TOC entry 3863 (class 1259 OID 16592)
-- Name: products_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_is_active_index ON public.products USING btree (is_active);


--
-- TOC entry 3866 (class 1259 OID 16593)
-- Name: products_release_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_release_date_index ON public.products USING btree (release_date);


--
-- TOC entry 3867 (class 1259 OID 16591)
-- Name: products_set_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_set_name_index ON public.products USING btree (set_name);


--
-- TOC entry 3868 (class 1259 OID 16588)
-- Name: products_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_index ON public.products USING btree (slug);


--
-- TOC entry 3871 (class 1259 OID 16589)
-- Name: products_upc_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_upc_index ON public.products USING btree (upc);


--
-- TOC entry 3850 (class 1259 OID 16544)
-- Name: retailers_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_is_active_index ON public.retailers USING btree (is_active);


--
-- TOC entry 3853 (class 1259 OID 16543)
-- Name: retailers_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_slug_index ON public.retailers USING btree (slug);


--
-- TOC entry 4075 (class 1259 OID 17384)
-- Name: roles_created_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_created_by_index ON public.roles USING btree (created_by);


--
-- TOC entry 4076 (class 1259 OID 17382)
-- Name: roles_is_system_role_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_is_system_role_is_active_index ON public.roles USING btree (is_system_role, is_active);


--
-- TOC entry 4077 (class 1259 OID 17383)
-- Name: roles_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_level_index ON public.roles USING btree (level);


--
-- TOC entry 3996 (class 1259 OID 17039)
-- Name: seasonal_patterns_category_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_category_id_pattern_type_index ON public.seasonal_patterns USING btree (category_id, pattern_type);


--
-- TOC entry 3997 (class 1259 OID 17040)
-- Name: seasonal_patterns_pattern_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_pattern_name_index ON public.seasonal_patterns USING btree (pattern_name);


--
-- TOC entry 4000 (class 1259 OID 17038)
-- Name: seasonal_patterns_product_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_product_id_pattern_type_index ON public.seasonal_patterns USING btree (product_id, pattern_type);


--
-- TOC entry 4041 (class 1259 OID 17237)
-- Name: social_shares_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_alert_id_index ON public.social_shares USING btree (alert_id);


--
-- TOC entry 4044 (class 1259 OID 17238)
-- Name: social_shares_shared_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_shared_at_index ON public.social_shares USING btree (shared_at);


--
-- TOC entry 4045 (class 1259 OID 17236)
-- Name: social_shares_user_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_user_id_platform_index ON public.social_shares USING btree (user_id, platform);


--
-- TOC entry 3935 (class 1259 OID 16827)
-- Name: system_health_checked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_checked_at_index ON public.system_health USING btree (checked_at);


--
-- TOC entry 3938 (class 1259 OID 16825)
-- Name: system_health_service_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_service_name_index ON public.system_health USING btree (service_name);


--
-- TOC entry 3939 (class 1259 OID 16826)
-- Name: system_health_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_status_index ON public.system_health USING btree (status);


--
-- TOC entry 4024 (class 1259 OID 17144)
-- Name: system_metrics_metric_name_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_name_recorded_at_index ON public.system_metrics USING btree (metric_name, recorded_at);


--
-- TOC entry 4025 (class 1259 OID 17145)
-- Name: system_metrics_metric_type_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_type_recorded_at_index ON public.system_metrics USING btree (metric_type, recorded_at);


--
-- TOC entry 4028 (class 1259 OID 17146)
-- Name: system_metrics_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_recorded_at_index ON public.system_metrics USING btree (recorded_at);


--
-- TOC entry 4046 (class 1259 OID 17264)
-- Name: testimonials_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_is_featured_is_public_index ON public.testimonials USING btree (is_featured, is_public);


--
-- TOC entry 4047 (class 1259 OID 17263)
-- Name: testimonials_moderation_status_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_moderation_status_is_public_index ON public.testimonials USING btree (moderation_status, is_public);


--
-- TOC entry 4050 (class 1259 OID 17265)
-- Name: testimonials_rating_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_rating_index ON public.testimonials USING btree (rating);


--
-- TOC entry 4051 (class 1259 OID 17262)
-- Name: testimonials_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_user_id_index ON public.testimonials USING btree (user_id);


--
-- TOC entry 3974 (class 1259 OID 16955)
-- Name: trend_analysis_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_analyzed_at_index ON public.trend_analysis USING btree (analyzed_at);


--
-- TOC entry 3977 (class 1259 OID 16956)
-- Name: trend_analysis_product_id_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_analyzed_at_index ON public.trend_analysis USING btree (product_id, analyzed_at);


--
-- TOC entry 3978 (class 1259 OID 16954)
-- Name: trend_analysis_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_index ON public.trend_analysis USING btree (product_id);


--
-- TOC entry 3953 (class 1259 OID 16919)
-- Name: unsubscribe_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_expires_at_index ON public.unsubscribe_tokens USING btree (expires_at);


--
-- TOC entry 3956 (class 1259 OID 16913)
-- Name: unsubscribe_tokens_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_token_index ON public.unsubscribe_tokens USING btree (token);


--
-- TOC entry 3959 (class 1259 OID 16917)
-- Name: unsubscribe_tokens_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_user_id_index ON public.unsubscribe_tokens USING btree (user_id);


--
-- TOC entry 4084 (class 1259 OID 17416)
-- Name: user_roles_assigned_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_assigned_by_index ON public.user_roles USING btree (assigned_by);


--
-- TOC entry 4085 (class 1259 OID 17417)
-- Name: user_roles_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_expires_at_index ON public.user_roles USING btree (expires_at);


--
-- TOC entry 4088 (class 1259 OID 17415)
-- Name: user_roles_role_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_role_id_is_active_index ON public.user_roles USING btree (role_id, is_active);


--
-- TOC entry 4089 (class 1259 OID 17414)
-- Name: user_roles_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_user_id_is_active_index ON public.user_roles USING btree (user_id, is_active);


--
-- TOC entry 3927 (class 1259 OID 16812)
-- Name: user_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_expires_at_index ON public.user_sessions USING btree (expires_at);


--
-- TOC entry 3928 (class 1259 OID 16813)
-- Name: user_sessions_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_is_active_index ON public.user_sessions USING btree (is_active);


--
-- TOC entry 3931 (class 1259 OID 16811)
-- Name: user_sessions_refresh_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_refresh_token_index ON public.user_sessions USING btree (refresh_token);


--
-- TOC entry 3934 (class 1259 OID 16810)
-- Name: user_sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_user_id_index ON public.user_sessions USING btree (user_id);


--
-- TOC entry 3898 (class 1259 OID 16697)
-- Name: user_watch_packs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_user_id_index ON public.user_watch_packs USING btree (user_id);


--
-- TOC entry 3901 (class 1259 OID 16698)
-- Name: user_watch_packs_watch_pack_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_watch_pack_id_index ON public.user_watch_packs USING btree (watch_pack_id);


--
-- TOC entry 3829 (class 1259 OID 16511)
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- TOC entry 3834 (class 1259 OID 17064)
-- Name: users_last_admin_login_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_last_admin_login_index ON public.users USING btree (last_admin_login);


--
-- TOC entry 3837 (class 1259 OID 16522)
-- Name: users_reset_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reset_token_index ON public.users USING btree (reset_token);


--
-- TOC entry 3838 (class 1259 OID 17449)
-- Name: users_role_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_created_at_index ON public.users USING btree (role, created_at);


--
-- TOC entry 3839 (class 1259 OID 17063)
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- TOC entry 3844 (class 1259 OID 17527)
-- Name: users_subscription_plan_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_subscription_plan_id_index ON public.users USING btree (subscription_plan_id);


--
-- TOC entry 3845 (class 1259 OID 16521)
-- Name: users_verification_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_verification_token_index ON public.users USING btree (verification_token);


--
-- TOC entry 3890 (class 1259 OID 16672)
-- Name: watch_packs_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_is_active_index ON public.watch_packs USING btree (is_active);


--
-- TOC entry 3893 (class 1259 OID 16671)
-- Name: watch_packs_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_slug_index ON public.watch_packs USING btree (slug);


--
-- TOC entry 3882 (class 1259 OID 16654)
-- Name: watches_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_is_active_index ON public.watches USING btree (is_active);


--
-- TOC entry 3885 (class 1259 OID 16653)
-- Name: watches_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_product_id_index ON public.watches USING btree (product_id);


--
-- TOC entry 3886 (class 1259 OID 16652)
-- Name: watches_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_index ON public.watches USING btree (user_id);


--
-- TOC entry 3887 (class 1259 OID 16655)
-- Name: watches_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_is_active_index ON public.watches USING btree (user_id, is_active);


--
-- TOC entry 4036 (class 1259 OID 17193)
-- Name: webhooks_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_user_id_is_active_index ON public.webhooks USING btree (user_id, is_active);


--
-- TOC entry 4172 (class 2606 OID 17077)
-- Name: admin_audit_log admin_audit_log_admin_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_user_id_foreign FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4156 (class 2606 OID 16762)
-- Name: alert_deliveries alert_deliveries_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4152 (class 2606 OID 16721)
-- Name: alerts alerts_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4153 (class 2606 OID 16726)
-- Name: alerts alerts_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4154 (class 2606 OID 16716)
-- Name: alerts alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4155 (class 2606 OID 16731)
-- Name: alerts alerts_watch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watch_id_foreign FOREIGN KEY (watch_id) REFERENCES public.watches(id) ON DELETE SET NULL;


--
-- TOC entry 4164 (class 2606 OID 16929)
-- Name: availability_snapshots availability_snapshots_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4165 (class 2606 OID 16934)
-- Name: availability_snapshots availability_snapshots_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4186 (class 2606 OID 17349)
-- Name: comment_likes comment_likes_comment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_foreign FOREIGN KEY (comment_id) REFERENCES public.post_comments(id) ON DELETE CASCADE;


--
-- TOC entry 4187 (class 2606 OID 17354)
-- Name: comment_likes comment_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4181 (class 2606 OID 17285)
-- Name: community_posts community_posts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4177 (class 2606 OID 17208)
-- Name: csv_operations csv_operations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4171 (class 2606 OID 17052)
-- Name: data_quality_metrics data_quality_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4175 (class 2606 OID 17163)
-- Name: discord_servers discord_servers_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4194 (class 2606 OID 17562)
-- Name: drop_events drop_events_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drop_events
    ADD CONSTRAINT drop_events_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4195 (class 2606 OID 17567)
-- Name: drop_events drop_events_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drop_events
    ADD CONSTRAINT drop_events_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4196 (class 2606 OID 17583)
-- Name: drop_outcomes drop_outcomes_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drop_outcomes
    ADD CONSTRAINT drop_outcomes_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4197 (class 2606 OID 17588)
-- Name: drop_outcomes drop_outcomes_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drop_outcomes
    ADD CONSTRAINT drop_outcomes_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4161 (class 2606 OID 16899)
-- Name: email_delivery_logs email_delivery_logs_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE SET NULL;


--
-- TOC entry 4162 (class 2606 OID 16888)
-- Name: email_delivery_logs email_delivery_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4160 (class 2606 OID 16883)
-- Name: email_preferences email_preferences_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4168 (class 2606 OID 17007)
-- Name: engagement_metrics engagement_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4193 (class 2606 OID 17543)
-- Name: external_product_map external_product_map_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4173 (class 2606 OID 17102)
-- Name: ml_models ml_models_trained_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_trained_by_foreign FOREIGN KEY (trained_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4167 (class 2606 OID 16967)
-- Name: ml_predictions ml_predictions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4174 (class 2606 OID 17125)
-- Name: ml_training_data ml_training_data_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4198 (class 2606 OID 17605)
-- Name: model_features model_features_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_features
    ADD CONSTRAINT model_features_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4199 (class 2606 OID 17610)
-- Name: model_features model_features_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_features
    ADD CONSTRAINT model_features_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4191 (class 2606 OID 17428)
-- Name: permission_audit_log permission_audit_log_actor_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_actor_user_id_foreign FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- TOC entry 4192 (class 2606 OID 17433)
-- Name: permission_audit_log permission_audit_log_target_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_target_user_id_foreign FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- TOC entry 4182 (class 2606 OID 17308)
-- Name: post_comments post_comments_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4183 (class 2606 OID 17313)
-- Name: post_comments post_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4184 (class 2606 OID 17328)
-- Name: post_likes post_likes_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4185 (class 2606 OID 17333)
-- Name: post_likes post_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4157 (class 2606 OID 16778)
-- Name: price_history price_history_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4158 (class 2606 OID 16783)
-- Name: price_history price_history_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4146 (class 2606 OID 16608)
-- Name: product_availability product_availability_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4147 (class 2606 OID 16613)
-- Name: product_availability product_availability_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4144 (class 2606 OID 16558)
-- Name: product_categories product_categories_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4145 (class 2606 OID 16583)
-- Name: products products_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4169 (class 2606 OID 17033)
-- Name: seasonal_patterns seasonal_patterns_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE CASCADE;


--
-- TOC entry 4170 (class 2606 OID 17028)
-- Name: seasonal_patterns seasonal_patterns_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4178 (class 2606 OID 17231)
-- Name: social_shares social_shares_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4179 (class 2606 OID 17226)
-- Name: social_shares social_shares_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4180 (class 2606 OID 17257)
-- Name: testimonials testimonials_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4166 (class 2606 OID 16949)
-- Name: trend_analysis trend_analysis_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4163 (class 2606 OID 16904)
-- Name: unsubscribe_tokens unsubscribe_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4200 (class 2606 OID 17629)
-- Name: url_candidates url_candidates_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url_candidates
    ADD CONSTRAINT url_candidates_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4201 (class 2606 OID 17634)
-- Name: url_candidates url_candidates_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.url_candidates
    ADD CONSTRAINT url_candidates_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4188 (class 2606 OID 17407)
-- Name: user_roles user_roles_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- TOC entry 4189 (class 2606 OID 17402)
-- Name: user_roles user_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4190 (class 2606 OID 17397)
-- Name: user_roles user_roles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4159 (class 2606 OID 16803)
-- Name: user_sessions user_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4150 (class 2606 OID 16685)
-- Name: user_watch_packs user_watch_packs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4151 (class 2606 OID 16690)
-- Name: user_watch_packs user_watch_packs_watch_pack_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_watch_pack_id_foreign FOREIGN KEY (watch_pack_id) REFERENCES public.watch_packs(id) ON DELETE CASCADE;


--
-- TOC entry 4143 (class 2606 OID 17444)
-- Name: users users_role_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_updated_by_foreign FOREIGN KEY (role_updated_by) REFERENCES public.users(id);


--
-- TOC entry 4148 (class 2606 OID 16645)
-- Name: watches watches_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4149 (class 2606 OID 16640)
-- Name: watches watches_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4176 (class 2606 OID 17188)
-- Name: webhooks webhooks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-09-04 22:29:18 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict SUGcbrgtXE1uztLa7TCxqzyx4WABQ8yPCpJmronw2DfjjevVAb5crY2XRX3Iugv

