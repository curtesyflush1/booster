--
-- PostgreSQL database dump
--

\restrict kDUKucF6QhaMcZyTfFUpcQN9CpUGtPLegptnqufDqy5S1kXGxKebO47TEIzMlS3

-- Dumped from database version 15.14
-- Dumped by pg_dump version 17.6

-- Started on 2025-08-31 01:47:13 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_product_id_foreign;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_role_updated_by_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_watch_pack_id_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_foreign;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_role_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_assigned_by_foreign;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_user_id_foreign;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_product_id_foreign;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_alert_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_product_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_category_id_foreign;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_category_id_foreign;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_parent_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_retailer_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_retailer_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_product_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_user_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_user_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_post_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_target_user_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_actor_user_id_foreign;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_reviewed_by_foreign;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_product_id_foreign;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_trained_by_foreign;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_foreign;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_alert_id_foreign;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_foreign;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_product_id_foreign;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_user_id_foreign;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_retailer_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_product_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_watch_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_user_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_retailer_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_product_id_foreign;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_alert_id_foreign;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_admin_user_id_foreign;
DROP INDEX public.webhooks_user_id_is_active_index;
DROP INDEX public.watches_user_id_is_active_index;
DROP INDEX public.watches_user_id_index;
DROP INDEX public.watches_product_id_index;
DROP INDEX public.watches_is_active_index;
DROP INDEX public.watch_packs_slug_index;
DROP INDEX public.watch_packs_is_active_index;
DROP INDEX public.users_verification_token_index;
DROP INDEX public.users_role_index;
DROP INDEX public.users_role_created_at_index;
DROP INDEX public.users_reset_token_index;
DROP INDEX public.users_last_admin_login_index;
DROP INDEX public.users_email_index;
DROP INDEX public.user_watch_packs_watch_pack_id_index;
DROP INDEX public.user_watch_packs_user_id_index;
DROP INDEX public.user_sessions_user_id_index;
DROP INDEX public.user_sessions_refresh_token_index;
DROP INDEX public.user_sessions_is_active_index;
DROP INDEX public.user_sessions_expires_at_index;
DROP INDEX public.user_roles_user_id_is_active_index;
DROP INDEX public.user_roles_role_id_is_active_index;
DROP INDEX public.user_roles_expires_at_index;
DROP INDEX public.user_roles_assigned_by_index;
DROP INDEX public.unsubscribe_tokens_user_id_index;
DROP INDEX public.unsubscribe_tokens_token_index;
DROP INDEX public.unsubscribe_tokens_expires_at_index;
DROP INDEX public.trend_analysis_product_id_index;
DROP INDEX public.trend_analysis_product_id_analyzed_at_index;
DROP INDEX public.trend_analysis_analyzed_at_index;
DROP INDEX public.testimonials_user_id_index;
DROP INDEX public.testimonials_rating_index;
DROP INDEX public.testimonials_moderation_status_is_public_index;
DROP INDEX public.testimonials_is_featured_is_public_index;
DROP INDEX public.system_metrics_recorded_at_index;
DROP INDEX public.system_metrics_metric_type_recorded_at_index;
DROP INDEX public.system_metrics_metric_name_recorded_at_index;
DROP INDEX public.system_health_status_index;
DROP INDEX public.system_health_service_name_index;
DROP INDEX public.system_health_checked_at_index;
DROP INDEX public.social_shares_user_id_platform_index;
DROP INDEX public.social_shares_shared_at_index;
DROP INDEX public.social_shares_alert_id_index;
DROP INDEX public.seasonal_patterns_product_id_pattern_type_index;
DROP INDEX public.seasonal_patterns_pattern_name_index;
DROP INDEX public.seasonal_patterns_category_id_pattern_type_index;
DROP INDEX public.roles_level_index;
DROP INDEX public.roles_is_system_role_is_active_index;
DROP INDEX public.roles_created_by_index;
DROP INDEX public.retailers_slug_index;
DROP INDEX public.retailers_is_active_index;
DROP INDEX public.products_upc_index;
DROP INDEX public.products_slug_index;
DROP INDEX public.products_set_name_index;
DROP INDEX public.products_release_date_index;
DROP INDEX public.products_is_active_index;
DROP INDEX public.products_category_id_index;
DROP INDEX public.product_categories_slug_index;
DROP INDEX public.product_categories_parent_id_index;
DROP INDEX public.product_availability_retailer_id_index;
DROP INDEX public.product_availability_product_id_index;
DROP INDEX public.product_availability_last_checked_index;
DROP INDEX public.product_availability_in_stock_index;
DROP INDEX public.price_history_retailer_id_index;
DROP INDEX public.price_history_recorded_at_index;
DROP INDEX public.price_history_product_id_retailer_id_recorded_at_index;
DROP INDEX public.price_history_product_id_index;
DROP INDEX public.post_likes_user_id_index;
DROP INDEX public.post_likes_post_id_index;
DROP INDEX public.post_comments_user_id_index;
DROP INDEX public.post_comments_post_id_moderation_status_index;
DROP INDEX public.post_comments_created_at_index;
DROP INDEX public.permission_audit_log_target_user_id_created_at_index;
DROP INDEX public.permission_audit_log_created_at_index;
DROP INDEX public.permission_audit_log_actor_user_id_created_at_index;
DROP INDEX public.permission_audit_log_action_created_at_index;
DROP INDEX public.ml_training_data_status_data_type_created_at_index;
DROP INDEX public.ml_training_data_reviewed_by_index;
DROP INDEX public.ml_training_data_dataset_name_data_type_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_timeframe_days_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_index;
DROP INDEX public.ml_predictions_expires_at_index;
DROP INDEX public.ml_models_trained_by_index;
DROP INDEX public.ml_models_status_deployed_at_index;
DROP INDEX public.ml_models_name_status_created_at_index;
DROP INDEX public.ml_model_metrics_prediction_type_index;
DROP INDEX public.ml_model_metrics_model_name_model_version_index;
DROP INDEX public.ml_model_metrics_last_evaluated_at_index;
DROP INDEX public.idx_users_push_subscriptions;
DROP INDEX public.idx_users_email;
DROP INDEX public.engagement_metrics_product_id_metrics_date_index;
DROP INDEX public.engagement_metrics_product_id_index;
DROP INDEX public.engagement_metrics_metrics_date_index;
DROP INDEX public.email_preferences_user_id_index;
DROP INDEX public.email_preferences_unsubscribe_token_index;
DROP INDEX public.email_delivery_logs_user_id_index;
DROP INDEX public.email_delivery_logs_sent_at_index;
DROP INDEX public.email_delivery_logs_message_id_index;
DROP INDEX public.email_delivery_logs_email_type_index;
DROP INDEX public.email_delivery_logs_alert_id_index;
DROP INDEX public.email_complaints_timestamp_index;
DROP INDEX public.email_complaints_message_id_index;
DROP INDEX public.email_bounces_timestamp_index;
DROP INDEX public.email_bounces_message_id_index;
DROP INDEX public.email_bounces_bounce_type_index;
DROP INDEX public.discord_servers_user_id_is_active_index;
DROP INDEX public.data_quality_metrics_product_id_data_source_index;
DROP INDEX public.data_quality_metrics_overall_quality_score_index;
DROP INDEX public.data_quality_metrics_assessed_at_index;
DROP INDEX public.csv_operations_user_id_operation_type_index;
DROP INDEX public.csv_operations_created_at_index;
DROP INDEX public.community_posts_user_id_index;
DROP INDEX public.community_posts_type_moderation_status_index;
DROP INDEX public.community_posts_is_featured_is_public_index;
DROP INDEX public.community_posts_created_at_index;
DROP INDEX public.comment_likes_user_id_index;
DROP INDEX public.comment_likes_comment_id_index;
DROP INDEX public.availability_snapshots_snapshot_time_index;
DROP INDEX public.availability_snapshots_retailer_id_snapshot_time_index;
DROP INDEX public.availability_snapshots_product_id_snapshot_time_index;
DROP INDEX public.alerts_watch_id_index;
DROP INDEX public.alerts_user_id_status_index;
DROP INDEX public.alerts_user_id_index;
DROP INDEX public.alerts_type_index;
DROP INDEX public.alerts_status_priority_created_at_index;
DROP INDEX public.alerts_status_index;
DROP INDEX public.alerts_scheduled_for_index;
DROP INDEX public.alerts_retailer_id_index;
DROP INDEX public.alerts_product_id_index;
DROP INDEX public.alerts_priority_index;
DROP INDEX public.alerts_created_at_index;
DROP INDEX public.alert_deliveries_status_index;
DROP INDEX public.alert_deliveries_sent_at_index;
DROP INDEX public.alert_deliveries_channel_index;
DROP INDEX public.alert_deliveries_alert_id_index;
DROP INDEX public.admin_audit_log_target_type_target_id_index;
DROP INDEX public.admin_audit_log_created_at_index;
DROP INDEX public.admin_audit_log_admin_user_id_created_at_index;
DROP INDEX public.admin_audit_log_action_created_at_index;
ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_pkey;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_product_id_unique;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_pkey;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_slug_unique;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_pkey;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_refresh_token_unique;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_pkey;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_role_id_unique;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_pkey;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_token_unique;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_pkey;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_pkey;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_pkey;
ALTER TABLE ONLY public.system_metrics DROP CONSTRAINT system_metrics_pkey;
ALTER TABLE ONLY public.system_health DROP CONSTRAINT system_health_pkey;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_stripe_price_id_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_slug_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_pkey;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_pkey;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_slug_unique;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_name_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_slug_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_upc_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_slug_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_slug_unique;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_pkey;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_retailer_id_unique;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_pkey;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_pkey;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_user_id_unique;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_pkey;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_pkey;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_pkey;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_pkey;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_name_version_unique;
ALTER TABLE ONLY public.ml_model_metrics DROP CONSTRAINT ml_model_metrics_pkey;
ALTER TABLE ONLY public.knex_migrations DROP CONSTRAINT knex_migrations_pkey;
ALTER TABLE ONLY public.knex_migrations_lock DROP CONSTRAINT knex_migrations_lock_pkey;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_metrics_date_unique;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_pkey;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_unsubscribe_token_unique;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_pkey;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_pkey;
ALTER TABLE ONLY public.email_complaints DROP CONSTRAINT email_complaints_pkey;
ALTER TABLE ONLY public.email_bounces DROP CONSTRAINT email_bounces_pkey;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_server_id_unique;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_pkey;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_pkey;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_pkey;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_user_id_unique;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_pkey;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_pkey;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_pkey;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_pkey;
ALTER TABLE public.knex_migrations_lock ALTER COLUMN index DROP DEFAULT;
ALTER TABLE public.knex_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.webhooks;
DROP TABLE public.watches;
DROP TABLE public.watch_packs;
DROP TABLE public.users;
DROP TABLE public.user_watch_packs;
DROP TABLE public.user_sessions;
DROP TABLE public.user_roles;
DROP TABLE public.unsubscribe_tokens;
DROP TABLE public.trend_analysis;
DROP TABLE public.testimonials;
DROP TABLE public.system_metrics;
DROP TABLE public.system_health;
DROP TABLE public.subscription_plans;
DROP TABLE public.social_shares;
DROP TABLE public.seasonal_patterns;
DROP TABLE public.roles;
DROP TABLE public.retailers;
DROP TABLE public.products;
DROP TABLE public.product_categories;
DROP TABLE public.product_availability;
DROP TABLE public.price_history;
DROP TABLE public.post_likes;
DROP TABLE public.post_comments;
DROP TABLE public.permission_audit_log;
DROP TABLE public.ml_training_data;
DROP TABLE public.ml_predictions;
DROP TABLE public.ml_models;
DROP TABLE public.ml_model_metrics;
DROP SEQUENCE public.knex_migrations_lock_index_seq;
DROP TABLE public.knex_migrations_lock;
DROP SEQUENCE public.knex_migrations_id_seq;
DROP TABLE public.knex_migrations;
DROP TABLE public.engagement_metrics;
DROP TABLE public.email_preferences;
DROP TABLE public.email_delivery_logs;
DROP TABLE public.email_complaints;
DROP TABLE public.email_bounces;
DROP TABLE public.discord_servers;
DROP TABLE public.data_quality_metrics;
DROP TABLE public.csv_operations;
DROP TABLE public.community_posts;
DROP TABLE public.comment_likes;
DROP TABLE public.availability_snapshots;
DROP TABLE public.alerts;
DROP TABLE public.alert_deliveries;
DROP TABLE public.admin_audit_log;
DROP TYPE public.billing_period_enum;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pg_trgm;
--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4272 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4273 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1057 (class 1247 OID 18413)
-- Name: billing_period_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.billing_period_enum AS ENUM (
    'monthly',
    'yearly'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 18024)
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50),
    target_id character varying(255),
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT admin_audit_log_check CHECK ((((target_type IS NULL) AND (target_id IS NULL)) OR ((target_type IS NOT NULL) AND (target_id IS NOT NULL))))
);


--
-- TOC entry 229 (class 1259 OID 17706)
-- Name: alert_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id uuid NOT NULL,
    channel text NOT NULL,
    status text DEFAULT 'pending'::text,
    external_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alert_deliveries_channel_check CHECK ((channel = ANY (ARRAY['web_push'::text, 'email'::text, 'sms'::text, 'discord'::text]))),
    CONSTRAINT alert_deliveries_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'delivered'::text, 'failed'::text, 'bounced'::text])))
);


--
-- TOC entry 228 (class 1259 OID 17658)
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    watch_id uuid,
    type text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text,
    delivery_channels jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    sent_at timestamp with time zone,
    read_at timestamp with time zone,
    clicked_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alerts_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'urgent'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'failed'::text, 'read'::text]))),
    CONSTRAINT alerts_type_check CHECK ((type = ANY (ARRAY['restock'::text, 'price_drop'::text, 'low_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 238 (class 1259 OID 17881)
-- Name: availability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    stock_level integer,
    last_checked timestamp with time zone,
    snapshot_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 257 (class 1259 OID 18298)
-- Name: comment_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 254 (class 1259 OID 18222)
-- Name: community_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.community_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    type text NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    images jsonb DEFAULT '[]'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    likes integer DEFAULT 0,
    comments_count integer DEFAULT 0,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT community_posts_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT community_posts_type_check CHECK ((type = ANY (ARRAY['success_story'::text, 'tip'::text, 'collection_showcase'::text, 'deal_share'::text, 'question'::text])))
);


--
-- TOC entry 251 (class 1259 OID 18150)
-- Name: csv_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csv_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    operation_type text NOT NULL,
    filename character varying(255),
    total_rows integer,
    successful_rows integer,
    failed_rows integer,
    errors jsonb DEFAULT '[]'::jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT csv_operations_operation_type_check CHECK ((operation_type = ANY (ARRAY['import'::text, 'export'::text]))),
    CONSTRAINT csv_operations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text])))
);


--
-- TOC entry 244 (class 1259 OID 18000)
-- Name: data_quality_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_quality_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    data_source character varying(255) NOT NULL,
    completeness_score numeric(5,2),
    freshness_hours numeric(8,2),
    accuracy_score numeric(5,2),
    missing_fields jsonb DEFAULT '[]'::jsonb,
    overall_quality_score numeric(5,2),
    recommendations jsonb DEFAULT '[]'::jsonb,
    assessed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 249 (class 1259 OID 18106)
-- Name: discord_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discord_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    server_id character varying(255) NOT NULL,
    channel_id character varying(255) NOT NULL,
    token text,
    alert_filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_alerts_sent integer DEFAULT 0,
    last_alert_sent timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 17821)
-- Name: email_bounces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_bounces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    bounce_type text NOT NULL,
    bounce_sub_type character varying(255) NOT NULL,
    bounced_recipients jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_bounces_bounce_type_check CHECK ((bounce_type = ANY (ARRAY['permanent'::text, 'transient'::text])))
);


--
-- TOC entry 237 (class 1259 OID 17832)
-- Name: email_complaints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_complaints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    complained_recipients jsonb NOT NULL,
    feedback_type character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 17800)
-- Name: email_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_delivery_logs (
    id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    alert_id uuid,
    email_type text NOT NULL,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message_id character varying(255),
    sent_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    bounced_at timestamp with time zone,
    complained_at timestamp with time zone,
    bounce_reason text,
    complaint_reason text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_delivery_logs_email_type_check CHECK ((email_type = ANY (ARRAY['alert'::text, 'welcome'::text, 'marketing'::text, 'digest'::text, 'system'::text])))
);


--
-- TOC entry 233 (class 1259 OID 17789)
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    alert_emails boolean DEFAULT true,
    marketing_emails boolean DEFAULT true,
    weekly_digest boolean DEFAULT true,
    unsubscribe_token character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 17948)
-- Name: engagement_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    watch_count integer DEFAULT 0,
    alert_count integer DEFAULT 0,
    click_count integer DEFAULT 0,
    click_through_rate numeric(5,2) DEFAULT '0'::numeric,
    search_volume integer DEFAULT 0,
    social_mentions integer DEFAULT 0,
    engagement_score numeric(5,2) DEFAULT '0'::numeric,
    trend_direction text DEFAULT 'stable'::text,
    metrics_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT engagement_metrics_trend_direction_check CHECK ((trend_direction = ANY (ARRAY['rising'::text, 'falling'::text, 'stable'::text])))
);


--
-- TOC entry 218 (class 1259 OID 16492)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- TOC entry 217 (class 1259 OID 16491)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4274 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 220 (class 1259 OID 16499)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- TOC entry 219 (class 1259 OID 16498)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4275 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 241 (class 1259 OID 17934)
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_model_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(255) NOT NULL,
    prediction_type text NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    mean_absolute_error numeric(10,4),
    root_mean_square_error numeric(10,4),
    training_data_size integer,
    prediction_count integer DEFAULT 0,
    avg_processing_time numeric(8,2),
    last_trained_at timestamp with time zone,
    last_evaluated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_model_metrics_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 246 (class 1259 OID 18045)
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    status text DEFAULT 'training'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    model_path character varying(500),
    training_started_at timestamp with time zone,
    training_completed_at timestamp with time zone,
    deployed_at timestamp with time zone,
    trained_by uuid,
    training_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_models_check CHECK (((status <> 'active'::text) OR (deployed_at IS NOT NULL))),
    CONSTRAINT ml_models_check1 CHECK (((status <> 'training'::text) OR (training_started_at IS NOT NULL))),
    CONSTRAINT ml_models_status_check CHECK ((status = ANY (ARRAY['training'::text, 'active'::text, 'deprecated'::text, 'failed'::text])))
);


--
-- TOC entry 240 (class 1259 OID 17916)
-- Name: ml_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_predictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    prediction_type text NOT NULL,
    prediction_data jsonb NOT NULL,
    timeframe_days integer,
    input_price numeric(10,2),
    confidence_score numeric(5,2),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_predictions_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 247 (class 1259 OID 18071)
-- Name: ml_training_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_training_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dataset_name character varying(200) NOT NULL,
    data_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_training_data_check CHECK (((status = 'pending'::text) OR ((reviewed_by IS NOT NULL) AND (reviewed_at IS NOT NULL)))),
    CONSTRAINT ml_training_data_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 260 (class 1259 OID 18374)
-- Name: permission_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid NOT NULL,
    target_user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    permission_or_role character varying(100),
    old_value json,
    new_value json,
    reason text,
    ip_address character varying(45),
    user_agent text,
    metadata json DEFAULT '{}'::json,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 255 (class 1259 OID 18250)
-- Name: post_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    likes integer DEFAULT 0,
    is_public boolean DEFAULT true,
    moderation_status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT post_comments_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 256 (class 1259 OID 18277)
-- Name: post_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 17730)
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 224 (class 1259 OID 17553)
-- Name: product_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_availability (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean DEFAULT false,
    price numeric(10,2),
    original_price numeric(10,2),
    availability_status text,
    product_url character varying(255) NOT NULL,
    cart_url character varying(255),
    stock_level integer,
    store_locations jsonb DEFAULT '[]'::jsonb,
    last_checked timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_in_stock timestamp with time zone,
    last_price_change timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_availability_availability_status_check CHECK ((availability_status = ANY (ARRAY['in_stock'::text, 'low_stock'::text, 'out_of_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 222 (class 1259 OID 17504)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    parent_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 17524)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    sku character varying(255),
    upc character varying(255),
    category_id uuid,
    set_name character varying(255),
    series character varying(255),
    release_date date,
    msrp numeric(10,2),
    image_url character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    popularity_score integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT products_popularity_score_check CHECK (((popularity_score >= 0) AND (popularity_score <= 1000)))
);


--
-- TOC entry 221 (class 1259 OID 17482)
-- Name: retailers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retailers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    website_url character varying(255) NOT NULL,
    api_type text NOT NULL,
    api_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    rate_limit_per_minute integer DEFAULT 60,
    health_score integer DEFAULT 100,
    last_health_check timestamp with time zone,
    supported_features jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT retailers_api_type_check CHECK ((api_type = ANY (ARRAY['official'::text, 'affiliate'::text, 'scraping'::text]))),
    CONSTRAINT retailers_health_score_check CHECK (((health_score >= 0) AND (health_score <= 100))),
    CONSTRAINT retailers_rate_limit_per_minute_check CHECK (((rate_limit_per_minute >= 1) AND (rate_limit_per_minute <= 10000)))
);


--
-- TOC entry 258 (class 1259 OID 18319)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    permissions json DEFAULT '[]'::json,
    is_system_role boolean DEFAULT false,
    categories json DEFAULT '[]'::json,
    level integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 17976)
-- Name: seasonal_patterns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasonal_patterns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    category_id uuid,
    pattern_type character varying(255) NOT NULL,
    pattern_name character varying(255) NOT NULL,
    avg_price_change numeric(5,2),
    availability_change numeric(5,2),
    demand_multiplier numeric(4,2) DEFAULT '1'::numeric,
    historical_occurrences integer DEFAULT 1,
    confidence numeric(5,2),
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 252 (class 1259 OID 18171)
-- Name: social_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    alert_id uuid,
    platform character varying(255) NOT NULL,
    share_type character varying(255) DEFAULT 'manual'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    shared_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 261 (class 1259 OID 18417)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    billing_period public.billing_period_enum NOT NULL,
    stripe_price_id character varying(255),
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    limits jsonb DEFAULT '{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT name_not_empty CHECK ((length(TRIM(BOTH FROM name)) > 0)),
    CONSTRAINT price_non_negative CHECK ((price >= (0)::numeric))
);


--
-- TOC entry 232 (class 1259 OID 17773)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    status text NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    message text,
    checked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_health_status_check CHECK ((status = ANY (ARRAY['healthy'::text, 'degraded'::text, 'down'::text])))
);


--
-- TOC entry 248 (class 1259 OID 18092)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type text NOT NULL,
    value numeric(15,6) NOT NULL,
    labels jsonb DEFAULT '{}'::jsonb NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['gauge'::text, 'counter'::text, 'histogram'::text, 'summary'::text])))
);


--
-- TOC entry 253 (class 1259 OID 18195)
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    rating integer NOT NULL,
    is_verified boolean DEFAULT false,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT testimonials_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- TOC entry 239 (class 1259 OID 17901)
-- Name: trend_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trend_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    price_trend numeric(10,6),
    availability_trend numeric(10,6),
    demand_score numeric(5,2),
    volatility_score numeric(5,2),
    analyzed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 17810)
-- Name: unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unsubscribe_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    email_type text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT unsubscribe_tokens_email_type_check CHECK ((email_type = ANY (ARRAY['all'::text, 'alerts'::text, 'marketing'::text, 'digest'::text])))
);


--
-- TOC entry 259 (class 1259 OID 18341)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assignment_reason text,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 17751)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    refresh_token character varying(255) NOT NULL,
    device_info character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 17632)
-- Name: user_watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    watch_pack_id uuid NOT NULL,
    customizations jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16477)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    subscription_tier character varying(20) DEFAULT 'free'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_verified boolean DEFAULT false,
    verification_token character varying(255),
    reset_token character varying(255),
    reset_token_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login timestamp with time zone,
    shipping_addresses jsonb DEFAULT '[]'::jsonb,
    payment_methods jsonb DEFAULT '[]'::jsonb,
    retailer_credentials jsonb DEFAULT '{}'::jsonb,
    notification_settings jsonb DEFAULT '{"sms": false, "email": true, "discord": false, "web_push": true}'::jsonb,
    quiet_hours jsonb DEFAULT '{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}'::jsonb,
    timezone character varying(255) DEFAULT 'UTC'::character varying,
    zip_code character varying(255),
    push_subscriptions jsonb DEFAULT '[]'::jsonb,
    role text DEFAULT 'user'::text NOT NULL,
    last_admin_login timestamp with time zone,
    admin_permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    direct_permissions json DEFAULT '[]'::json,
    role_last_updated timestamp with time zone,
    role_updated_by uuid,
    permission_metadata json DEFAULT '{}'::json,
    first_name character varying(255),
    last_name character varying(255),
    preferences jsonb DEFAULT '{}'::jsonb,
    newsletter_subscription boolean DEFAULT false,
    terms_accepted boolean DEFAULT false,
    CONSTRAINT users_failed_login_attempts_check CHECK (((failed_login_attempts >= 0) AND (failed_login_attempts <= 10))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['user'::text, 'admin'::text, 'super_admin'::text])))
);


--
-- TOC entry 226 (class 1259 OID 17615)
-- Name: watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    product_ids jsonb NOT NULL,
    is_active boolean DEFAULT true,
    auto_update boolean DEFAULT true,
    update_criteria character varying(255),
    subscriber_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 17583)
-- Name: watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_ids jsonb DEFAULT '[]'::jsonb,
    max_price numeric(10,2),
    availability_type text DEFAULT 'both'::text,
    zip_code character varying(255),
    radius_miles integer,
    is_active boolean DEFAULT true,
    alert_preferences jsonb DEFAULT '{}'::jsonb,
    last_alerted timestamp with time zone,
    alert_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT watches_availability_type_check CHECK ((availability_type = ANY (ARRAY['online'::text, 'in_store'::text, 'both'::text])))
);


--
-- TOC entry 250 (class 1259 OID 18127)
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret text,
    events jsonb NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb,
    retry_config jsonb DEFAULT '{"maxRetries": 3, "retryDelay": 1000, "backoffMultiplier": 2}'::jsonb,
    filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_calls integer DEFAULT 0,
    successful_calls integer DEFAULT 0,
    failed_calls integer DEFAULT 0,
    last_triggered timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3516 (class 2604 OID 16495)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3517 (class 2604 OID 16502)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 4250 (class 0 OID 18024)
-- Dependencies: 245
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, details, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4234 (class 0 OID 17706)
-- Dependencies: 229
-- Data for Name: alert_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_deliveries (id, alert_id, channel, status, external_id, metadata, sent_at, delivered_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4233 (class 0 OID 17658)
-- Dependencies: 228
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, product_id, retailer_id, watch_id, type, priority, data, status, delivery_channels, scheduled_for, sent_at, read_at, clicked_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4243 (class 0 OID 17881)
-- Dependencies: 238
-- Data for Name: availability_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_snapshots (id, product_id, retailer_id, in_stock, availability_status, stock_level, last_checked, snapshot_time) FROM stdin;
\.


--
-- TOC entry 4262 (class 0 OID 18298)
-- Dependencies: 257
-- Data for Name: comment_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_likes (id, comment_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4259 (class 0 OID 18222)
-- Dependencies: 254
-- Data for Name: community_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.community_posts (id, user_id, user_name, user_avatar, type, title, content, images, tags, likes, comments_count, is_public, is_featured, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4256 (class 0 OID 18150)
-- Dependencies: 251
-- Data for Name: csv_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.csv_operations (id, user_id, operation_type, filename, total_rows, successful_rows, failed_rows, errors, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4249 (class 0 OID 18000)
-- Dependencies: 244
-- Data for Name: data_quality_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_quality_metrics (id, product_id, data_source, completeness_score, freshness_hours, accuracy_score, missing_fields, overall_quality_score, recommendations, assessed_at) FROM stdin;
\.


--
-- TOC entry 4254 (class 0 OID 18106)
-- Dependencies: 249
-- Data for Name: discord_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discord_servers (id, user_id, server_id, channel_id, token, alert_filters, is_active, total_alerts_sent, last_alert_sent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4241 (class 0 OID 17821)
-- Dependencies: 236
-- Data for Name: email_bounces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_bounces (id, message_id, bounce_type, bounce_sub_type, bounced_recipients, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4242 (class 0 OID 17832)
-- Dependencies: 237
-- Data for Name: email_complaints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_complaints (id, message_id, complained_recipients, feedback_type, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4239 (class 0 OID 17800)
-- Dependencies: 234
-- Data for Name: email_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_delivery_logs (id, user_id, alert_id, email_type, recipient_email, subject, message_id, sent_at, delivered_at, bounced_at, complained_at, bounce_reason, complaint_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4238 (class 0 OID 17789)
-- Dependencies: 233
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_preferences (id, user_id, alert_emails, marketing_emails, weekly_digest, unsubscribe_token, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4247 (class 0 OID 17948)
-- Dependencies: 242
-- Data for Name: engagement_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.engagement_metrics (id, product_id, watch_count, alert_count, click_count, click_through_rate, search_volume, social_mentions, engagement_score, trend_direction, metrics_date, calculated_at) FROM stdin;
\.


--
-- TOC entry 4223 (class 0 OID 16492)
-- Dependencies: 218
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
11	001_initial_schema.js	1	2025-08-30 19:16:35.718+00
12	20250826174814_expand_core_schema.js	1	2025-08-30 19:16:36.065+00
13	20250826180000_add_push_subscriptions.js	1	2025-08-30 19:16:36.068+00
14	20250827000001_email_system.js	1	2025-08-30 19:16:36.127+00
15	20250827130000_add_ml_tables.js	1	2025-08-30 19:16:36.208+00
16	20250827140000_add_user_roles.js	1	2025-08-30 19:16:36.256+00
17	20250827140005_validate_admin_setup.js	1	2025-08-30 19:16:36.275+00
18	20250827150000_add_community_integration_tables.js	1	2025-08-30 19:16:36.387+00
19	20250827160000_implement_granular_rbac.js	1	2025-08-30 19:16:36.437+00
20	20250827140001_add_missing_user_fields.js	2	2025-08-30 19:17:45.307+00
21	20250827140006_add_registration_fields.js	3	2025-08-30 19:18:27.136+00
22	20250829151931_create_subscription_plans_table.js	4	2025-08-31 01:39:56.136+00
\.


--
-- TOC entry 4225 (class 0 OID 16499)
-- Dependencies: 220
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- TOC entry 4246 (class 0 OID 17934)
-- Dependencies: 241
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_model_metrics (id, model_name, model_version, prediction_type, accuracy, "precision", recall, f1_score, mean_absolute_error, root_mean_square_error, training_data_size, prediction_count, avg_processing_time, last_trained_at, last_evaluated_at, created_at) FROM stdin;
\.


--
-- TOC entry 4251 (class 0 OID 18045)
-- Dependencies: 246
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, version, status, config, metrics, model_path, training_started_at, training_completed_at, deployed_at, trained_by, training_notes, created_at, updated_at) FROM stdin;
3b992e78-8e61-4d99-9253-ebb27e4c7e76	price_prediction	v1.0	active	{"algorithm": "ARIMA", "forecast_days": 7, "lookback_days": 30}	{"mae": 2.34, "rmse": 3.12, "accuracy": 0.85}	\N	2025-08-24 01:40:00.108+00	2025-08-25 01:40:00.108+00	2025-08-25 01:40:00.108+00	\N	\N	2025-08-31 01:40:00.109313+00	2025-08-31 01:40:00.109313+00
c4eb34a1-47ef-4ea6-a7e5-14928b7e7b5b	sellout_risk	v1.2	active	{"features": ["price_history", "availability_patterns", "user_engagement"], "algorithm": "Random Forest"}	{"recall": 0.94, "accuracy": 0.92, "precision": 0.89}	\N	2025-08-28 01:40:00.108+00	2025-08-29 01:40:00.108+00	2025-08-29 01:40:00.108+00	\N	\N	2025-08-31 01:40:00.109313+00	2025-08-31 01:40:00.109313+00
2009e6ee-12bf-4482-83a9-e77989e92de7	roi_estimation	v0.8	training	{"algorithm": "LSTM", "hidden_units": 128, "sequence_length": 14}	{}	\N	2025-08-30 01:40:00.108+00	\N	\N	\N	\N	2025-08-31 01:40:00.109313+00	2025-08-31 01:40:00.109313+00
\.


--
-- TOC entry 4245 (class 0 OID 17916)
-- Dependencies: 240
-- Data for Name: ml_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_predictions (id, product_id, prediction_type, prediction_data, timeframe_days, input_price, confidence_score, expires_at, created_at) FROM stdin;
\.


--
-- TOC entry 4252 (class 0 OID 18071)
-- Dependencies: 247
-- Data for Name: ml_training_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_training_data (id, dataset_name, data_type, data, status, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4265 (class 0 OID 18374)
-- Dependencies: 260
-- Data for Name: permission_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_audit_log (id, actor_user_id, target_user_id, action, permission_or_role, old_value, new_value, reason, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4260 (class 0 OID 18250)
-- Dependencies: 255
-- Data for Name: post_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_comments (id, post_id, user_id, user_name, user_avatar, content, likes, is_public, moderation_status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4261 (class 0 OID 18277)
-- Dependencies: 256
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_likes (id, post_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4235 (class 0 OID 17730)
-- Dependencies: 230
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, product_id, retailer_id, price, original_price, in_stock, availability_status, recorded_at) FROM stdin;
bd668645-fb73-40f4-89ae-3a2deeecc65c	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	136.96	143.64	t	in_stock	2025-08-01 01:39:59.874+00
ebba2fce-5a62-4dbc-bef4-c3a0ecdd397f	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	134.46	143.64	t	in_stock	2025-08-02 01:39:59.874+00
1024a85a-1fd2-4bef-8ef8-c1f1a35eb19d	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	138.70	143.64	t	in_stock	2025-08-03 01:39:59.874+00
48b14e7b-4c6f-4620-aa1b-96557a8e2226	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	150.07	143.64	f	out_of_stock	2025-08-04 01:39:59.874+00
56046ec7-6743-4c4c-819a-fade5aa4b80b	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	151.19	143.64	t	in_stock	2025-08-05 01:39:59.874+00
d9d95aa2-2697-4f5b-9a22-0c3ef083b225	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	144.40	143.64	t	in_stock	2025-08-06 01:39:59.874+00
fb181b54-7075-4841-baf6-1b5066f95d37	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	142.00	143.64	t	in_stock	2025-08-07 01:39:59.874+00
2f4c4a31-0591-488d-827a-9cffe19ea098	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	137.10	143.64	t	in_stock	2025-08-08 01:39:59.874+00
37adc910-d6aa-44f6-b4fd-ad163c98dc93	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	133.69	143.64	t	in_stock	2025-08-09 01:39:59.874+00
d8ec44a8-ecad-49b1-a60b-085ddce479ea	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	146.75	143.64	t	in_stock	2025-08-10 01:39:59.874+00
452e87a6-b371-4d5f-a317-cea4c86b37eb	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	153.70	143.64	f	out_of_stock	2025-08-11 01:39:59.874+00
98618c14-345f-4704-9e6e-906e401664a7	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	152.30	143.64	t	in_stock	2025-08-12 01:39:59.874+00
d03de5ce-8baf-415c-a911-c6e9be73c1d8	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	146.09	143.64	t	in_stock	2025-08-13 01:39:59.874+00
bccfab3c-4695-4ae0-ad52-5a8e086af30c	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	139.92	143.64	t	in_stock	2025-08-14 01:39:59.874+00
7fa07e96-0948-400a-943c-522252a85cee	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	144.51	143.64	t	in_stock	2025-08-15 01:39:59.874+00
118b1b22-f081-4b21-85d3-1e339970f9d3	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	147.42	143.64	t	in_stock	2025-08-16 01:39:59.874+00
fd33a910-3de4-4995-af51-de1184f2b8b6	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	142.55	143.64	t	in_stock	2025-08-17 01:39:59.874+00
ec6806fa-81d0-40ed-9035-15d1c5b52769	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	143.06	143.64	t	in_stock	2025-08-18 01:39:59.874+00
bb2212f8-2a26-4ae5-bbd6-06eb0ad4b8a1	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	140.12	143.64	t	in_stock	2025-08-19 01:39:59.874+00
ec6dca05-e46e-4a2a-9294-7004cf59548b	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	134.44	143.64	f	out_of_stock	2025-08-20 01:39:59.874+00
b6993a4b-dcad-45c0-b198-df764266e673	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	137.53	143.64	t	in_stock	2025-08-21 01:39:59.874+00
c5da0aff-38cc-4214-a542-e6d05e634be5	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	146.37	143.64	t	in_stock	2025-08-22 01:39:59.874+00
ddfd8a39-c7bc-4f81-9fd1-98ef801e1af2	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	149.75	143.64	t	in_stock	2025-08-23 01:39:59.874+00
8a6e79e2-903a-468d-becc-6cbdb44c3b56	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	144.46	143.64	t	in_stock	2025-08-24 01:39:59.874+00
3d76e75f-337a-4eb7-a774-4854fd5d4093	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	148.72	143.64	t	in_stock	2025-08-25 01:39:59.874+00
36a2c50f-b433-4161-a40a-79af63d17c7d	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	149.42	143.64	t	in_stock	2025-08-26 01:39:59.874+00
1e53c6cf-ba7d-4984-9146-aca420c4fc7e	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	149.83	143.64	t	in_stock	2025-08-27 01:39:59.874+00
08386118-043d-42ee-bcdd-eb4127d8d72f	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	144.28	143.64	f	out_of_stock	2025-08-28 01:39:59.874+00
cea611b0-4b4a-484a-ae81-7437aa51a665	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	146.61	143.64	t	in_stock	2025-08-29 01:39:59.874+00
75bd67d8-3fc1-4cc5-aec8-a0597e792f1a	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	153.13	143.64	f	out_of_stock	2025-08-30 01:39:59.874+00
11e50879-8be3-4596-97e1-ca2bd58e2ac3	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	148.26	143.64	t	in_stock	2025-08-31 01:39:59.874+00
f3780748-ff40-41bf-aff2-bb372708cf6c	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	147.38	143.64	t	in_stock	2025-08-01 01:39:59.874+00
069d0616-08f1-42a6-ae09-a2d432da87e7	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	133.62	143.64	t	in_stock	2025-08-02 01:39:59.874+00
6f2839f8-5eb8-47ea-b0f4-192acefb003d	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	154.24	143.64	t	in_stock	2025-08-03 01:39:59.874+00
0d23040f-6bc1-4b44-81e7-06c179245953	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	152.48	143.64	t	in_stock	2025-08-04 01:39:59.874+00
785ec0cf-7c19-4a3f-9bc3-92a0742345d4	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	135.04	143.64	t	in_stock	2025-08-05 01:39:59.874+00
043d0039-974f-428b-bba2-90e8f81635de	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	135.76	143.64	t	in_stock	2025-08-06 01:39:59.874+00
15cb92c6-fdfe-4a87-9c7a-971f8b3e3208	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	150.29	143.64	t	in_stock	2025-08-07 01:39:59.874+00
d362fe66-8e41-466d-adc3-10d7b582b7d4	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	140.50	143.64	f	out_of_stock	2025-08-08 01:39:59.874+00
7d955f3d-4ed4-443b-b9c6-a6fb1f51206f	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	148.89	143.64	t	in_stock	2025-08-09 01:39:59.874+00
dd5da686-d43a-4277-a8c8-2fb57ba5790c	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	132.94	143.64	t	in_stock	2025-08-10 01:39:59.874+00
098087d4-1899-4d34-b315-443f9a77b96d	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	145.83	143.64	t	in_stock	2025-08-11 01:39:59.874+00
a62d6057-bcde-4922-9876-710f9265349a	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	137.91	143.64	t	in_stock	2025-08-12 01:39:59.874+00
6d44b81c-4273-41a8-9d8f-7b3eb60a61dd	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	142.49	143.64	t	in_stock	2025-08-13 01:39:59.874+00
791a0677-9d9b-4bf5-8cbe-56097a6a917d	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	154.17	143.64	t	in_stock	2025-08-14 01:39:59.874+00
9a2592c5-93cb-4dbb-aab7-904bb97f85f9	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	145.53	143.64	t	in_stock	2025-08-15 01:39:59.874+00
d9dd76d1-a86d-4c24-b395-ba5c1b3298e6	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	141.12	143.64	f	out_of_stock	2025-08-16 01:39:59.874+00
405be861-b81e-4789-9ed7-64121fb0f8a1	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	140.17	143.64	t	in_stock	2025-08-17 01:39:59.874+00
2aae3400-c729-42db-94d9-0f44b71c1719	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	139.81	143.64	t	in_stock	2025-08-18 01:39:59.874+00
88b9fa79-50ab-4a14-82e7-86a4a877345e	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	141.78	143.64	f	out_of_stock	2025-08-19 01:39:59.874+00
7f174c54-ba51-4b88-ac4c-5e4dcb3c2c29	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	138.27	143.64	t	in_stock	2025-08-20 01:39:59.874+00
cfb28c7b-d5bb-4612-8e6a-3ec348202b81	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	145.72	143.64	t	in_stock	2025-08-21 01:39:59.874+00
ae996688-7c8e-4d20-9b67-34bf91b0b595	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	135.12	143.64	t	in_stock	2025-08-22 01:39:59.874+00
cebb5c27-a3f2-492d-94cd-929d9c8ba7cb	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	147.26	143.64	f	out_of_stock	2025-08-23 01:39:59.874+00
e4eeed1f-944e-44f0-b66f-f406c686f69b	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	141.12	143.64	t	in_stock	2025-08-24 01:39:59.874+00
54368a6b-7494-4c6e-9023-0a8244d6b081	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	133.00	143.64	f	out_of_stock	2025-08-25 01:39:59.874+00
b9f745f1-2959-4f3d-8cd5-a7402b493821	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	145.48	143.64	t	in_stock	2025-08-26 01:39:59.874+00
bb1d48c8-bfc1-4434-bb7b-e24d84bf0bd3	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	153.02	143.64	t	in_stock	2025-08-27 01:39:59.874+00
349619a3-551c-4acc-9f29-ba0fbde4e07d	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	150.27	143.64	t	in_stock	2025-08-28 01:39:59.874+00
d93aed76-1953-4060-ae69-a8a59cad482a	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	136.60	143.64	t	in_stock	2025-08-29 01:39:59.874+00
ad706706-6d24-4907-ba3a-5e0a4fe8d8c1	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	138.58	143.64	t	in_stock	2025-08-30 01:39:59.874+00
8b9e4ba1-ae7f-4d4d-913d-ee9ef16e0dd8	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	137.77	143.64	t	in_stock	2025-08-31 01:39:59.874+00
68b12afa-fac4-41cf-962a-e92eea5cf055	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	149.09	143.64	t	in_stock	2025-08-01 01:39:59.874+00
9e4ae21e-039a-4ddd-a763-c44b4558d84c	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	143.41	143.64	f	out_of_stock	2025-08-02 01:39:59.874+00
2007ead5-a0fb-41e6-9e77-87d6caab6530	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	146.58	143.64	t	in_stock	2025-08-03 01:39:59.874+00
a4388059-1983-423d-8dfc-ba83d350a350	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	140.08	143.64	t	in_stock	2025-08-04 01:39:59.874+00
67c390d2-62af-4ddb-a74a-54982d7c03eb	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	144.51	143.64	t	in_stock	2025-08-05 01:39:59.874+00
31963ee6-95f8-4350-8441-454c28f9e5bf	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	132.89	143.64	t	in_stock	2025-08-06 01:39:59.874+00
f189fc64-5db1-4206-9c18-403674d9a327	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	138.25	143.64	t	in_stock	2025-08-07 01:39:59.874+00
9fdd2f3f-b560-4228-8876-670747378763	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	143.30	143.64	t	in_stock	2025-08-08 01:39:59.874+00
bd2c7fdd-3df8-41fa-bf1f-422f9911808c	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	151.61	143.64	f	out_of_stock	2025-08-09 01:39:59.874+00
360dd16c-3103-4451-bd07-ead477d68dd0	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	139.77	143.64	f	out_of_stock	2025-08-10 01:39:59.874+00
b70087f0-afa9-43fc-b9ff-51e6fb1a5031	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	149.70	143.64	t	in_stock	2025-08-11 01:39:59.874+00
4d49b902-bd90-47b9-bd73-074218f0d2d4	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	148.94	143.64	t	in_stock	2025-08-12 01:39:59.874+00
f219e357-3887-4d52-b99e-77d64a940060	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	141.91	143.64	t	in_stock	2025-08-13 01:39:59.874+00
993e905d-87f9-485c-ab7c-661a3bb4d915	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	142.84	143.64	t	in_stock	2025-08-14 01:39:59.874+00
e5895711-dbbc-4b9d-88de-800ce1685c42	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	142.23	143.64	f	out_of_stock	2025-08-15 01:39:59.874+00
fbf1cd45-7a98-4486-9728-2cec681e5ccf	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	147.09	143.64	t	in_stock	2025-08-16 01:39:59.874+00
a7e2f86e-5ba9-4084-afa3-43bdc1c9d9f4	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	151.68	143.64	t	in_stock	2025-08-17 01:39:59.874+00
aa8ab646-a961-4534-894f-443fc8af0057	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	142.72	143.64	t	in_stock	2025-08-18 01:39:59.874+00
ca91540b-98b6-439f-b3b2-813be50803f5	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	134.26	143.64	t	in_stock	2025-08-19 01:39:59.874+00
046db751-36d1-44c5-803a-6af6bb674328	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	149.27	143.64	t	in_stock	2025-08-20 01:39:59.874+00
5b44adfe-3894-425c-b381-dd2bc853879b	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	152.91	143.64	t	in_stock	2025-08-21 01:39:59.874+00
e399f9ca-26d9-4a33-ad1a-9ea0a94775a2	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	147.69	143.64	t	in_stock	2025-08-22 01:39:59.874+00
fd897062-dbff-4aa4-86a9-81a2be9bb599	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	151.42	143.64	t	in_stock	2025-08-23 01:39:59.874+00
782abfb0-8f75-4c32-a381-c822570010d6	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	149.93	143.64	t	in_stock	2025-08-24 01:39:59.874+00
0bf37598-7f25-473e-a81c-5da4f3c970a3	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	153.57	143.64	t	in_stock	2025-08-25 01:39:59.874+00
60f9b9bd-8021-43e3-bddf-8ce69579a519	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	153.03	143.64	t	in_stock	2025-08-26 01:39:59.874+00
55d4f3fe-81b7-40de-acef-c722f0bd0db5	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	152.92	143.64	f	out_of_stock	2025-08-27 01:39:59.874+00
9b2f9d68-444b-409a-b838-6475d360646c	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	135.66	143.64	t	in_stock	2025-08-28 01:39:59.874+00
9801a0eb-afc2-47fb-a60e-3712a91ef378	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	144.92	143.64	f	out_of_stock	2025-08-29 01:39:59.874+00
d1463519-3ded-4358-8924-b595417086c2	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	148.18	143.64	t	in_stock	2025-08-30 01:39:59.874+00
1a183569-4b99-4def-b56e-1dc278e541e6	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	148.46	143.64	t	in_stock	2025-08-31 01:39:59.874+00
827be5d5-64e0-4f77-a0b0-939d84401d34	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	147.36	143.64	t	in_stock	2025-08-01 01:39:59.874+00
23285400-e5ea-4736-ad5b-ced75a83fd54	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	140.61	143.64	t	in_stock	2025-08-02 01:39:59.874+00
ef679505-f51d-493b-b229-b383e1e473da	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	154.31	143.64	t	in_stock	2025-08-03 01:39:59.874+00
b82c918b-df87-4f8a-a3af-ac72e6002cd7	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	133.88	143.64	f	out_of_stock	2025-08-04 01:39:59.874+00
3ff151f4-7fea-47d8-99bd-6f9861ffbda4	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	148.78	143.64	f	out_of_stock	2025-08-05 01:39:59.874+00
f5694afe-d99a-4ae3-afbd-603ca2e9f23f	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	149.08	143.64	t	in_stock	2025-08-06 01:39:59.874+00
5bc2ed15-8959-4962-9c84-de6da7ed7f82	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	139.14	143.64	t	in_stock	2025-08-07 01:39:59.874+00
fe9f5541-40a6-4198-8ff0-c14477923f9e	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	133.87	143.64	t	in_stock	2025-08-08 01:39:59.874+00
bd77fedb-23b5-45bc-804e-63a37a280fdd	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	147.51	143.64	t	in_stock	2025-08-09 01:39:59.874+00
ebbc26eb-7113-4543-81f2-07ab0d382238	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	133.58	143.64	t	in_stock	2025-08-10 01:39:59.874+00
8e3f3362-bb25-440c-ab2c-17f94610f20f	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	145.07	143.64	t	in_stock	2025-08-11 01:39:59.874+00
3a13460c-88ec-43bf-8de3-cf4b885ca170	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	152.73	143.64	t	in_stock	2025-08-12 01:39:59.874+00
ffb63066-10df-4a42-a0af-21977bc283d3	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	134.36	143.64	t	in_stock	2025-08-13 01:39:59.874+00
6a10cb26-7184-4979-8ef5-74ccc1ad10b2	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	137.32	143.64	t	in_stock	2025-08-14 01:39:59.874+00
a6446ba4-f7de-4edd-a68f-16a933f702b4	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	149.29	143.64	t	in_stock	2025-08-15 01:39:59.874+00
20e5bf7b-797d-49d3-8dc4-8588d9ec533f	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	140.27	143.64	t	in_stock	2025-08-16 01:39:59.874+00
7cbcaf1b-96f9-46b9-9c12-d10bf351bd23	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	145.29	143.64	t	in_stock	2025-08-17 01:39:59.874+00
d87e9103-dd6f-4eed-8e04-6a99603e190f	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	141.58	143.64	t	in_stock	2025-08-18 01:39:59.874+00
55d79ea4-3551-4640-8a0f-9394e508bbf4	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	138.88	143.64	f	out_of_stock	2025-08-19 01:39:59.874+00
bdbadb02-2102-4cca-a290-1c8ac87a8b45	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	133.64	143.64	f	out_of_stock	2025-08-20 01:39:59.874+00
d8eeecf2-eafb-4c30-8ab9-e1976beab3d1	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	137.31	143.64	f	out_of_stock	2025-08-21 01:39:59.874+00
fb9c646b-d137-4347-ac54-8962b2c37282	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	134.01	143.64	f	out_of_stock	2025-08-22 01:39:59.874+00
96d74c3a-0fba-4d3b-9736-9f34a4afc500	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	145.90	143.64	t	in_stock	2025-08-23 01:39:59.874+00
8802886e-81c4-4b68-8ffb-f3d246fbc333	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	148.72	143.64	t	in_stock	2025-08-24 01:39:59.874+00
d561fe20-2316-4978-a079-2fbf565fa3a5	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	135.51	143.64	f	out_of_stock	2025-08-25 01:39:59.874+00
1fe32aa6-98ec-4137-8072-7dd938495471	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	134.27	143.64	t	in_stock	2025-08-26 01:39:59.874+00
eb2b10a6-8963-45e6-b7d4-67858849d5f0	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	138.79	143.64	t	in_stock	2025-08-27 01:39:59.874+00
2abb343b-dfe7-4a66-b204-5a56d4bbe8bc	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	142.88	143.64	t	in_stock	2025-08-28 01:39:59.874+00
526fb2d9-0df7-4750-9ab5-7072a75a5465	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	144.49	143.64	t	in_stock	2025-08-29 01:39:59.874+00
7e62a686-e41d-4e9b-b8dd-244745d592b2	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	152.50	143.64	t	in_stock	2025-08-30 01:39:59.874+00
80f3c5c8-0ab9-4198-8cee-d9ff489f2848	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	149.61	143.64	t	in_stock	2025-08-31 01:39:59.874+00
6a8a25ad-323d-41d4-b841-f014da4efb8d	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.87	49.99	f	out_of_stock	2025-08-01 01:39:59.874+00
72b412dd-8b9e-4c98-9187-5cc7dbca4d08	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	51.62	49.99	f	out_of_stock	2025-08-02 01:39:59.874+00
fdb6aa1d-f263-4760-8b4a-de8ec8f83456	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.23	49.99	t	in_stock	2025-08-03 01:39:59.874+00
508cd028-05cc-490d-91e2-7a586e84dcd0	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.94	49.99	t	in_stock	2025-08-04 01:39:59.874+00
c52d3f5d-e684-49b7-a21f-d2fd34ed5332	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	51.34	49.99	t	in_stock	2025-08-05 01:39:59.874+00
7b1bd3aa-6c88-4328-94d3-d5b6327d6e67	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	52.64	49.99	t	in_stock	2025-08-06 01:39:59.874+00
99c590f8-2cff-4419-914e-6304172f7b42	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	51.81	49.99	t	in_stock	2025-08-07 01:39:59.874+00
bb318e0d-d805-4c1c-83f3-851e2e8886bf	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.97	49.99	t	in_stock	2025-08-08 01:39:59.874+00
7e775fa9-8bd7-4483-9967-7acb3067bcb6	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	48.63	49.99	t	in_stock	2025-08-09 01:39:59.874+00
9ac9f7e3-0cba-4313-8ba6-b94758c15f0c	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	48.43	49.99	t	in_stock	2025-08-10 01:39:59.874+00
65022d9d-25e2-4d4d-9bc5-983b6269e88f	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.72	49.99	t	in_stock	2025-08-11 01:39:59.874+00
0c9f68f0-afc7-419a-86fb-eb48c42ca9af	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	50.55	49.99	t	in_stock	2025-08-12 01:39:59.874+00
fae78ffe-e02b-41e9-bfd4-03add40ccf95	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	50.44	49.99	f	out_of_stock	2025-08-13 01:39:59.874+00
27a12164-5e55-4107-8ded-9a1bef767451	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	46.65	49.99	t	in_stock	2025-08-14 01:39:59.874+00
16da01be-50ba-4020-ad91-05955ae6d5b8	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	53.01	49.99	t	in_stock	2025-08-15 01:39:59.874+00
bb7c3256-d78f-4e8b-9d5b-991781b56a25	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	48.35	49.99	t	in_stock	2025-08-16 01:39:59.874+00
0474e03b-2830-4d73-9cb2-bf702be75070	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	47.13	49.99	f	out_of_stock	2025-08-17 01:39:59.874+00
8435a659-9677-45bd-942a-08eba2e71ac6	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	46.87	49.99	t	in_stock	2025-08-18 01:39:59.874+00
0545ecca-c7f1-43d0-bf13-809ebf40b12d	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	46.47	49.99	t	in_stock	2025-08-19 01:39:59.874+00
58164f9c-078c-416c-bfc6-cc111b346ee9	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.58	49.99	t	in_stock	2025-08-20 01:39:59.874+00
8594b869-ed04-4e73-b303-be7a99e1f9dc	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.38	49.99	t	in_stock	2025-08-21 01:39:59.874+00
17d33666-e411-4fd2-b41a-6f09638087be	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	51.24	49.99	f	out_of_stock	2025-08-22 01:39:59.874+00
97acff75-574e-41e5-91bf-c45530d69baa	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	52.69	49.99	t	in_stock	2025-08-23 01:39:59.874+00
f1b4597a-10ba-45df-b5f3-330c9ed93673	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.83	49.99	f	out_of_stock	2025-08-24 01:39:59.874+00
924ef7ef-4324-49a2-bfc9-d117bde2ba4e	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	51.71	49.99	f	out_of_stock	2025-08-25 01:39:59.874+00
1f08ce17-54d0-464a-833f-732db301ac6c	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	50.32	49.99	t	in_stock	2025-08-26 01:39:59.874+00
41647d99-8af8-43dc-be2b-900f7504a0bd	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	48.24	49.99	t	in_stock	2025-08-27 01:39:59.874+00
108bfcee-b465-498b-af19-5fb19c14b247	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	50.60	49.99	t	in_stock	2025-08-28 01:39:59.874+00
2f4950d5-3192-4e14-b32f-0adcad8edd38	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	47.49	49.99	t	in_stock	2025-08-29 01:39:59.874+00
33375a1d-978c-4411-b64a-686c90782bba	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	49.34	49.99	t	in_stock	2025-08-30 01:39:59.874+00
3363b2a4-21fd-4e45-9d09-decc778bcd86	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	46.84	49.99	f	out_of_stock	2025-08-31 01:39:59.874+00
44c0bffa-4439-4c3f-8be5-4b6c5eb84ba2	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	48.79	49.99	t	in_stock	2025-08-01 01:39:59.874+00
0bf14eb5-2683-48de-8aad-f20f2a9c549f	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	48.19	49.99	t	in_stock	2025-08-02 01:39:59.874+00
21d7a2ad-6e8c-47c3-9866-885f71359b21	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	46.52	49.99	t	in_stock	2025-08-03 01:39:59.874+00
5b040da6-7c4d-49ff-9aeb-8ff33af22614	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.54	49.99	t	in_stock	2025-08-04 01:39:59.874+00
d9108ae9-d2bf-47cf-845f-144b6026f012	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	50.06	49.99	t	in_stock	2025-08-05 01:39:59.874+00
b562fd3b-9a6b-4c85-bec1-3f1560dfe8c5	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	46.39	49.99	t	in_stock	2025-08-06 01:39:59.874+00
c99e6490-91a1-4075-ad57-d25cfbee864a	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	46.90	49.99	t	in_stock	2025-08-07 01:39:59.874+00
15066352-eb66-4bb8-9caf-1bb8d130bd4e	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.53	49.99	t	in_stock	2025-08-08 01:39:59.874+00
bd0495d4-abbb-47ea-bb43-3542692a4a6e	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	47.89	49.99	t	in_stock	2025-08-09 01:39:59.874+00
d094e453-07b1-45cc-a292-45c6fc876a48	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.12	49.99	t	in_stock	2025-08-10 01:39:59.874+00
1659d24e-3f11-40fb-a871-6b19c08af2f8	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.53	49.99	t	in_stock	2025-08-11 01:39:59.874+00
fd3107d0-a9ac-4ba0-9ac8-2d780d5bd3c3	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	53.54	49.99	t	in_stock	2025-08-12 01:39:59.874+00
7f4d6d74-1e4b-4de1-8148-637ba805b25f	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	51.63	49.99	t	in_stock	2025-08-13 01:39:59.874+00
8ae1a3ca-1fbd-491f-b0ff-f5579ac3fe87	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.75	49.99	t	in_stock	2025-08-14 01:39:59.874+00
7b5b37c8-d776-494a-b530-ea96ae1a0ce1	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.48	49.99	t	in_stock	2025-08-15 01:39:59.874+00
bfccef4a-083c-4db1-86db-ae41ef091e8f	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.40	49.99	t	in_stock	2025-08-16 01:39:59.874+00
6b8e322c-e6c8-4342-9ee3-f201b0e3c224	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	47.00	49.99	t	in_stock	2025-08-17 01:39:59.874+00
a24a7c1e-2b39-439b-92eb-e0d0324d73db	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	47.73	49.99	t	in_stock	2025-08-18 01:39:59.874+00
97298e1a-48c3-4d71-85f9-0f3dc378eea7	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.45	49.99	t	in_stock	2025-08-19 01:39:59.874+00
6489a214-38d2-454b-9d3e-4a140d5ec392	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	53.03	49.99	t	in_stock	2025-08-20 01:39:59.874+00
e00b9cf1-601e-43ea-8571-4b9adeb17e91	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.28	49.99	f	out_of_stock	2025-08-21 01:39:59.874+00
8dec4bfc-a992-46b8-aead-b9fda7359579	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.29	49.99	t	in_stock	2025-08-22 01:39:59.874+00
2c71b079-b7e1-4c17-b089-f55d00e7000a	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.06	49.99	t	in_stock	2025-08-23 01:39:59.874+00
9d882326-47bb-4d29-924f-eceef5334f67	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.27	49.99	t	in_stock	2025-08-24 01:39:59.874+00
67cd79a4-1cda-44f4-a083-67b82fbb3fcb	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.20	49.99	t	in_stock	2025-08-25 01:39:59.874+00
42140cdb-c2c5-42bd-9c61-5e0eb64323e1	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	49.73	49.99	t	in_stock	2025-08-26 01:39:59.874+00
a365f5e4-0b4c-4365-8818-a44697711237	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.72	49.99	t	in_stock	2025-08-27 01:39:59.874+00
0282af49-d2b9-4146-87d9-25241a4f4863	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	46.81	49.99	t	in_stock	2025-08-28 01:39:59.874+00
cadffaf4-c014-4f20-b6b5-ad536ee35acd	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	52.94	49.99	t	in_stock	2025-08-29 01:39:59.874+00
b7958d1b-f50d-435d-8ad9-41e832b55951	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	50.44	49.99	t	in_stock	2025-08-30 01:39:59.874+00
01540e4b-c837-47c8-bc91-5e5313b3ebb8	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	50.54	49.99	t	in_stock	2025-08-31 01:39:59.874+00
\.


--
-- TOC entry 4229 (class 0 OID 17553)
-- Dependencies: 224
-- Data for Name: product_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_availability (id, product_id, retailer_id, in_stock, price, original_price, availability_status, product_url, cart_url, stock_level, store_locations, last_checked, last_in_stock, last_price_change, created_at, updated_at) FROM stdin;
d2deab4b-bc02-4c56-9575-640da4c7f952	e13c3459-c478-4eff-9e72-e2669f31a188	68c60cf5-e984-4329-b736-19ada4d400ef	t	139.74	143.64	low_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-base-booster-box	https://www.bestbuy.com/cart/add/SV01-BB-EN	45	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
4e9a8f66-f0d5-41fb-86bc-85e26a75359f	e13c3459-c478-4eff-9e72-e2669f31a188	423da5b6-2d85-46b3-9f03-17f683667b41	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
d19b9c41-b718-4741-af17-54ab9ecff057	e13c3459-c478-4eff-9e72-e2669f31a188	740af55f-1546-413a-a896-3a7ce9c335f5	t	130.53	143.64	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-base-booster-box	\N	45	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
09a00d06-8e41-41f5-a793-7ae3e761cb3a	e13c3459-c478-4eff-9e72-e2669f31a188	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
d6e42aaf-cbc3-4760-b409-bcab71ff6712	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	68c60cf5-e984-4329-b736-19ada4d400ef	t	153.39	143.64	in_stock	https://www.bestbuy.com/products/pokemon-paldea-evolved-booster-box	https://www.bestbuy.com/cart/add/SV02-BB-EN	4	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
f1fd5ca0-e46d-45cf-9c9f-0a442a276f22	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	423da5b6-2d85-46b3-9f03-17f683667b41	t	153.40	143.64	low_stock	https://www.walmart.com/products/pokemon-paldea-evolved-booster-box	\N	43	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
63f4ea8b-5acd-4ded-82eb-574c501cccbe	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	740af55f-1546-413a-a896-3a7ce9c335f5	t	151.56	143.64	in_stock	https://www.costco.com/products/pokemon-paldea-evolved-booster-box	\N	28	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
fee83649-48f6-4375-a3eb-4f918abc3382	6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-paldea-evolved-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
fbd5504b-19d5-4d2c-9645-805ff9e3d2d1	1f551d14-60b3-4205-97fd-5530a2f94f41	68c60cf5-e984-4329-b736-19ada4d400ef	t	45.01	49.99	in_stock	https://www.bestbuy.com/products/pokemon-151-elite-trainer-box	https://www.bestbuy.com/cart/add/SV3.5-ETB-EN	37	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
c9d454d8-853b-40c2-9923-582ac0d221ed	1f551d14-60b3-4205-97fd-5530a2f94f41	423da5b6-2d85-46b3-9f03-17f683667b41	t	47.13	49.99	in_stock	https://www.walmart.com/products/pokemon-151-elite-trainer-box	\N	21	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
05d0a5b3-b3db-4f9e-a9ed-479b84b9ae0e	1f551d14-60b3-4205-97fd-5530a2f94f41	740af55f-1546-413a-a896-3a7ce9c335f5	t	45.98	49.99	in_stock	https://www.costco.com/products/pokemon-151-elite-trainer-box	\N	37	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
876fb5f4-869a-4f78-8e53-7f60f9e15be2	1f551d14-60b3-4205-97fd-5530a2f94f41	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
f0a2a93c-c8c5-49a7-9e50-5fb5e7869337	8b4f830e-ca9c-4efa-bb1a-5aab08d5d327	68c60cf5-e984-4329-b736-19ada4d400ef	t	125.15	119.99	in_stock	https://www.bestbuy.com/products/charizard-ex-super-premium-collection	https://www.bestbuy.com/cart/add/SV-CHAR-SPC	6	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
2d76c11d-5ed1-404d-86f3-d879eb9c4ce2	8b4f830e-ca9c-4efa-bb1a-5aab08d5d327	423da5b6-2d85-46b3-9f03-17f683667b41	t	124.56	119.99	in_stock	https://www.walmart.com/products/charizard-ex-super-premium-collection	\N	3	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
3232ff5f-fb64-449e-ad86-3206bde5a1ad	8b4f830e-ca9c-4efa-bb1a-5aab08d5d327	740af55f-1546-413a-a896-3a7ce9c335f5	t	116.16	119.99	in_stock	https://www.costco.com/products/charizard-ex-super-premium-collection	\N	32	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
5178012a-0f35-46df-a2da-999b9614dbe3	8b4f830e-ca9c-4efa-bb1a-5aab08d5d327	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	124.53	119.99	in_stock	https://www.samsclub.com/products/charizard-ex-super-premium-collection	\N	13	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
54c5d1ec-12ee-4e19-b30e-36a760e683ad	92c4c240-9f03-4332-8974-e827d9e504d3	68c60cf5-e984-4329-b736-19ada4d400ef	t	3.70	3.99	in_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-booster-pack	https://www.bestbuy.com/cart/add/SV01-BP-EN	46	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
377cac1c-83fe-465c-9338-d1ce2a280805	92c4c240-9f03-4332-8974-e827d9e504d3	423da5b6-2d85-46b3-9f03-17f683667b41	f	\N	3.99	out_of_stock	https://www.walmart.com/products/pokemon-scarlet-violet-booster-pack	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
55dbd826-50f8-4adf-aa83-16b5eed7d86b	92c4c240-9f03-4332-8974-e827d9e504d3	740af55f-1546-413a-a896-3a7ce9c335f5	t	3.88	3.99	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-booster-pack	\N	19	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
b3661445-d2c4-4091-b6f0-411da6b5767d	92c4c240-9f03-4332-8974-e827d9e504d3	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	3.93	3.99	low_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-booster-pack	\N	3	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
a91858ee-a078-4620-a43f-c1a17c5dd635	bf797e99-5e9a-44c8-bf93-1f2835709a7c	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
67be3045-b748-4d5c-85a2-6369e13f366c	bf797e99-5e9a-44c8-bf93-1f2835709a7c	423da5b6-2d85-46b3-9f03-17f683667b41	t	136.04	143.64	in_stock	https://www.walmart.com/products/pokemon-obsidian-flames-booster-box	\N	39	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
34b4319b-6fa7-4753-9878-4550b4ae2536	bf797e99-5e9a-44c8-bf93-1f2835709a7c	740af55f-1546-413a-a896-3a7ce9c335f5	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
d06f4f72-d6f5-4eca-ba22-0f1b4b1bf45e	bf797e99-5e9a-44c8-bf93-1f2835709a7c	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	133.70	143.64	in_stock	https://www.samsclub.com/products/pokemon-obsidian-flames-booster-box	\N	1	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
3c6d2505-f717-4b65-806a-d22527bcc218	6b595da3-9ab0-4e5f-9dfb-da1299d97dd2	68c60cf5-e984-4329-b736-19ada4d400ef	t	131.16	143.64	in_stock	https://www.bestbuy.com/products/pokemon-paradox-rift-booster-box	https://www.bestbuy.com/cart/add/SV04-BB-EN	42	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
711bfb79-48c8-458a-941b-f2ac2840906e	6b595da3-9ab0-4e5f-9dfb-da1299d97dd2	423da5b6-2d85-46b3-9f03-17f683667b41	t	132.84	143.64	in_stock	https://www.walmart.com/products/pokemon-paradox-rift-booster-box	\N	6	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
347b725a-5fb0-4a68-bcc2-8523ce90db6b	6b595da3-9ab0-4e5f-9dfb-da1299d97dd2	740af55f-1546-413a-a896-3a7ce9c335f5	t	133.07	143.64	in_stock	https://www.costco.com/products/pokemon-paradox-rift-booster-box	\N	49	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
f4c1665b-daef-4763-8386-f4d4d4fee09f	6b595da3-9ab0-4e5f-9dfb-da1299d97dd2	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
a092bd2c-285f-42f3-8bfd-dbefb9369b2c	d86b2717-a9d6-4e60-b3c7-2ab84474112e	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-paldean-fates-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
95aad0b4-f1d6-426f-867e-88c9c28f5c0f	d86b2717-a9d6-4e60-b3c7-2ab84474112e	423da5b6-2d85-46b3-9f03-17f683667b41	t	46.53	49.99	in_stock	https://www.walmart.com/products/pokemon-paldean-fates-elite-trainer-box	\N	27	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
cdfc095f-b24b-47a8-9c69-389fdf3509b6	d86b2717-a9d6-4e60-b3c7-2ab84474112e	740af55f-1546-413a-a896-3a7ce9c335f5	t	46.60	49.99	in_stock	https://www.costco.com/products/pokemon-paldean-fates-elite-trainer-box	\N	28	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
3c669c3c-1f68-4ad4-9cc8-bf10863eaca8	d86b2717-a9d6-4e60-b3c7-2ab84474112e	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	47.03	49.99	in_stock	https://www.samsclub.com/products/pokemon-paldean-fates-elite-trainer-box	\N	26	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
2a624f8d-3652-4dce-95cc-27d3547e9231	ab6376ec-2da1-4d5a-8a07-6fd6908020c2	68c60cf5-e984-4329-b736-19ada4d400ef	t	141.63	143.64	in_stock	https://www.bestbuy.com/products/pokemon-temporal-forces-booster-box	https://www.bestbuy.com/cart/add/SV05-BB-EN	42	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
aa1fc423-5fe1-4b27-90ee-88ee8aebe51e	ab6376ec-2da1-4d5a-8a07-6fd6908020c2	423da5b6-2d85-46b3-9f03-17f683667b41	t	129.33	143.64	in_stock	https://www.walmart.com/products/pokemon-temporal-forces-booster-box	\N	13	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
76c4053a-e0b1-460c-9ab9-51f95a946d87	ab6376ec-2da1-4d5a-8a07-6fd6908020c2	740af55f-1546-413a-a896-3a7ce9c335f5	t	148.39	143.64	in_stock	https://www.costco.com/products/pokemon-temporal-forces-booster-box	\N	6	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
57ae5bfd-0c0c-4d18-bdda-28386fbfba32	ab6376ec-2da1-4d5a-8a07-6fd6908020c2	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	136.90	143.64	in_stock	https://www.samsclub.com/products/pokemon-temporal-forces-booster-box	\N	41	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
aba78fbc-1b85-4a05-94ac-2c92e0bd3d03	04e816b8-fdd8-4ff6-b50f-b955170d0902	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
062faba7-7be7-4f16-8b7f-0a4a19aac5d3	04e816b8-fdd8-4ff6-b50f-b955170d0902	423da5b6-2d85-46b3-9f03-17f683667b41	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
91dd6015-55d3-40a3-ab09-2d363ac01de6	04e816b8-fdd8-4ff6-b50f-b955170d0902	740af55f-1546-413a-a896-3a7ce9c335f5	f	\N	49.99	out_of_stock	https://www.costco.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
2692ca61-66f6-4d7f-888d-aecc4de186a1	04e816b8-fdd8-4ff6-b50f-b955170d0902	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
89d5e0a6-9af2-4255-8a1e-ce5c92942ebf	d97f280c-ba44-4fa5-8888-91ba13a2372e	68c60cf5-e984-4329-b736-19ada4d400ef	t	139.75	143.64	in_stock	https://www.bestbuy.com/products/pokemon-evolving-skies-booster-box	https://www.bestbuy.com/cart/add/SWSH07-BB-EN	21	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
235134ad-03b7-4b14-a962-39a0394d9706	d97f280c-ba44-4fa5-8888-91ba13a2372e	423da5b6-2d85-46b3-9f03-17f683667b41	t	154.56	143.64	in_stock	https://www.walmart.com/products/pokemon-evolving-skies-booster-box	\N	39	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
e510cbc7-bda3-4e6d-80f5-844b95ba0105	d97f280c-ba44-4fa5-8888-91ba13a2372e	740af55f-1546-413a-a896-3a7ce9c335f5	t	155.57	143.64	in_stock	https://www.costco.com/products/pokemon-evolving-skies-booster-box	\N	12	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
2fd52639-a3b1-4196-b543-d6f18d3b78ae	d97f280c-ba44-4fa5-8888-91ba13a2372e	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-evolving-skies-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
9669cf69-80f9-4732-a851-f36808ea3429	8e6bed2d-90fa-4f95-86d8-09b2e19d4283	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
c8ce9bc2-2972-4afa-957c-9ec037a102e5	8e6bed2d-90fa-4f95-86d8-09b2e19d4283	423da5b6-2d85-46b3-9f03-17f683667b41	t	143.02	143.64	in_stock	https://www.walmart.com/products/pokemon-brilliant-stars-booster-box	\N	2	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
17f4b65b-1598-4576-b57d-03e55cf076b4	8e6bed2d-90fa-4f95-86d8-09b2e19d4283	740af55f-1546-413a-a896-3a7ce9c335f5	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
e45a73d9-c435-4819-a76f-21e1e7c5b13f	8e6bed2d-90fa-4f95-86d8-09b2e19d4283	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
9d80963f-f1aa-4aae-8430-62b84393e435	b3e058a8-b998-4bc2-8a88-d8c131b1ae1f	68c60cf5-e984-4329-b736-19ada4d400ef	t	137.28	143.64	in_stock	https://www.bestbuy.com/products/pokemon-lost-origin-booster-box	https://www.bestbuy.com/cart/add/SWSH11-BB-EN	12	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
8c1f2646-9d57-40ff-9f2b-0819f61f211a	b3e058a8-b998-4bc2-8a88-d8c131b1ae1f	423da5b6-2d85-46b3-9f03-17f683667b41	t	129.85	143.64	low_stock	https://www.walmart.com/products/pokemon-lost-origin-booster-box	\N	41	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
650ac668-e597-4a1e-85ce-bf3a92cabf8d	b3e058a8-b998-4bc2-8a88-d8c131b1ae1f	740af55f-1546-413a-a896-3a7ce9c335f5	t	130.09	143.64	in_stock	https://www.costco.com/products/pokemon-lost-origin-booster-box	\N	1	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
4d0f8ef9-2a69-4648-adab-a4f618216e40	b3e058a8-b998-4bc2-8a88-d8c131b1ae1f	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	132.97	143.64	in_stock	https://www.samsclub.com/products/pokemon-lost-origin-booster-box	\N	42	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
51736c03-129a-4717-b29d-68642acd12fe	39c2e288-f88c-4e2a-a9b0-6a4856c211ec	68c60cf5-e984-4329-b736-19ada4d400ef	t	132.45	143.64	in_stock	https://www.bestbuy.com/products/pokemon-astral-radiance-booster-box	https://www.bestbuy.com/cart/add/SWSH10-BB-EN	37	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
20357e10-905d-4fd3-829f-f7581be9694f	39c2e288-f88c-4e2a-a9b0-6a4856c211ec	423da5b6-2d85-46b3-9f03-17f683667b41	t	145.80	143.64	in_stock	https://www.walmart.com/products/pokemon-astral-radiance-booster-box	\N	5	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
8be83401-1ffd-493e-a45b-a9e107275bce	39c2e288-f88c-4e2a-a9b0-6a4856c211ec	740af55f-1546-413a-a896-3a7ce9c335f5	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-astral-radiance-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
67b70324-7764-4496-85e8-bb17ae787f04	39c2e288-f88c-4e2a-a9b0-6a4856c211ec	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	137.40	143.64	low_stock	https://www.samsclub.com/products/pokemon-astral-radiance-booster-box	\N	14	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
880a02d4-ab9b-469c-8c6d-eb5dbf298494	457c94ae-082a-4851-9e89-659f515ba41e	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
1e8f1bd1-7329-4702-aa4f-dc1e681a0833	457c94ae-082a-4851-9e89-659f515ba41e	423da5b6-2d85-46b3-9f03-17f683667b41	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
ce1f61bf-64dc-4270-89f6-f3a3ff091e90	457c94ae-082a-4851-9e89-659f515ba41e	740af55f-1546-413a-a896-3a7ce9c335f5	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
99b9f7e9-a99f-40bd-88bc-f666ce89992b	457c94ae-082a-4851-9e89-659f515ba41e	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	133.98	143.64	in_stock	https://www.samsclub.com/products/pokemon-fusion-strike-booster-box	\N	34	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
cfc72d14-e80b-48ac-a683-78346914f2bc	ea99354e-219c-4112-8159-a39ef9e958d6	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
0ba4cb13-943d-46d3-b768-0d69b3301045	ea99354e-219c-4112-8159-a39ef9e958d6	423da5b6-2d85-46b3-9f03-17f683667b41	t	53.66	49.99	in_stock	https://www.walmart.com/products/pokemon-celebrations-elite-trainer-box	\N	32	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
724b85d7-5262-4ac6-821c-a55e90976e75	ea99354e-219c-4112-8159-a39ef9e958d6	740af55f-1546-413a-a896-3a7ce9c335f5	t	50.38	49.99	low_stock	https://www.costco.com/products/pokemon-celebrations-elite-trainer-box	\N	3	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
7e1ccfdd-911a-462d-a546-e87eda04f3bc	ea99354e-219c-4112-8159-a39ef9e958d6	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	53.69	49.99	in_stock	https://www.samsclub.com/products/pokemon-celebrations-elite-trainer-box	\N	50	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
6e1bc020-2d66-47a2-a35b-595433dd1378	123222d0-1632-4b6c-b488-9847b5d2de33	68c60cf5-e984-4329-b736-19ada4d400ef	t	45.51	49.99	in_stock	https://www.bestbuy.com/products/pokemon-shining-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SWSH4.5-ETB-EN	27	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
b746284c-49c9-44d8-b191-d16d49519fc2	123222d0-1632-4b6c-b488-9847b5d2de33	423da5b6-2d85-46b3-9f03-17f683667b41	t	54.11	49.99	in_stock	https://www.walmart.com/products/pokemon-shining-fates-elite-trainer-box	\N	39	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
e725fe88-905c-4be1-9fe0-4e29c39d5d97	123222d0-1632-4b6c-b488-9847b5d2de33	740af55f-1546-413a-a896-3a7ce9c335f5	t	45.42	49.99	low_stock	https://www.costco.com/products/pokemon-shining-fates-elite-trainer-box	\N	32	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
8a353f8a-0ed1-4d28-83d9-c432159060b6	123222d0-1632-4b6c-b488-9847b5d2de33	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	46.15	49.99	low_stock	https://www.samsclub.com/products/pokemon-shining-fates-elite-trainer-box	\N	8	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
527d1409-11c9-4fb2-ab7b-f4db6606ef98	6cf1ac8e-196c-41cf-b60f-e2630bc54b6b	68c60cf5-e984-4329-b736-19ada4d400ef	t	50.31	49.99	in_stock	https://www.bestbuy.com/products/pokemon-hidden-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SM11.5-ETB-EN	3	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
dccbef2a-1a49-4ea3-8238-acd2bcd76a26	6cf1ac8e-196c-41cf-b60f-e2630bc54b6b	423da5b6-2d85-46b3-9f03-17f683667b41	t	51.42	49.99	in_stock	https://www.walmart.com/products/pokemon-hidden-fates-elite-trainer-box	\N	43	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
8745abe9-c504-4eeb-baee-92ac4ffcec00	6cf1ac8e-196c-41cf-b60f-e2630bc54b6b	740af55f-1546-413a-a896-3a7ce9c335f5	f	\N	49.99	out_of_stock	https://www.costco.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
74a36d9c-ea3b-41b7-a87a-b4015410fb36	6cf1ac8e-196c-41cf-b60f-e2630bc54b6b	02ab5814-6bda-485f-a2b5-d9271e5674e2	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
5cb0bbb4-dc14-45db-9b7b-288b82bae4f2	9a4f0144-22e3-437b-ad58-5ba8ea22265d	68c60cf5-e984-4329-b736-19ada4d400ef	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-chilling-reign-booster-box	\N	0	[]	2025-08-31 01:39:59.866327+00	\N	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
799d4544-c5c5-4486-9499-2077cc9f2e0e	9a4f0144-22e3-437b-ad58-5ba8ea22265d	423da5b6-2d85-46b3-9f03-17f683667b41	t	150.97	143.64	in_stock	https://www.walmart.com/products/pokemon-chilling-reign-booster-box	\N	14	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
2aa051e8-9991-498b-a2fb-6040c9df87c6	9a4f0144-22e3-437b-ad58-5ba8ea22265d	740af55f-1546-413a-a896-3a7ce9c335f5	t	142.38	143.64	low_stock	https://www.costco.com/products/pokemon-chilling-reign-booster-box	\N	15	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
121bc86b-6df7-4a82-b000-20b289e2f011	9a4f0144-22e3-437b-ad58-5ba8ea22265d	02ab5814-6bda-485f-a2b5-d9271e5674e2	t	136.86	143.64	low_stock	https://www.samsclub.com/products/pokemon-chilling-reign-booster-box	\N	27	[]	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00	2025-08-31 01:39:59.866327+00
\.


--
-- TOC entry 4227 (class 0 OID 17504)
-- Dependencies: 222
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name, slug, description, parent_id, sort_order, created_at, updated_at) FROM stdin;
e2eed297-f19a-41aa-a9f5-45652a86d247	Booster Boxes	booster-boxes	Complete booster boxes containing multiple booster packs	\N	1	2025-08-31 01:39:59.852122+00	2025-08-31 01:39:59.852122+00
2b863a9f-b9af-4008-9703-faee327fa078	Booster Packs	booster-packs	Individual booster packs	\N	2	2025-08-31 01:39:59.852122+00	2025-08-31 01:39:59.852122+00
c336d639-ba86-4ab3-b94f-459c9f9d404b	Elite Trainer Boxes	elite-trainer-boxes	Elite Trainer Boxes with booster packs and accessories	\N	3	2025-08-31 01:39:59.852122+00	2025-08-31 01:39:59.852122+00
a69103e8-21f2-49cd-a99d-e326ddadf012	Collection Boxes	collection-boxes	Special collection boxes and premium products	\N	4	2025-08-31 01:39:59.852122+00	2025-08-31 01:39:59.852122+00
917a3fc8-4e48-4cb8-9aa5-c836fed12300	Starter Decks	starter-decks	Theme decks and starter products	\N	5	2025-08-31 01:39:59.852122+00	2025-08-31 01:39:59.852122+00
\.


--
-- TOC entry 4228 (class 0 OID 17524)
-- Dependencies: 223
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, slug, sku, upc, category_id, set_name, series, release_date, msrp, image_url, description, metadata, is_active, popularity_score, created_at, updated_at) FROM stdin;
e13c3459-c478-4eff-9e72-e2669f31a188	Pokémon Scarlet & Violet Base Set Booster Box	pokemon-scarlet-violet-base-booster-box	SV01-BB-EN	820650850011	e2eed297-f19a-41aa-a9f5-45652a86d247	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	143.64	https://images.pokemontcg.io/sv1/logo.png	Scarlet & Violet Base Set Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV01", "pack_count": 36, "cards_per_pack": 11, "rarity_distribution": {"common": 7, "uncommon": 3, "rare_or_higher": 1}}	t	95	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
6f9cac49-eb51-4ae2-9b80-3438dd12f9fc	Pokémon Paldea Evolved Booster Box	pokemon-paldea-evolved-booster-box	SV02-BB-EN	820650850028	e2eed297-f19a-41aa-a9f5-45652a86d247	Paldea Evolved	Scarlet & Violet	2023-06-09	143.64	https://images.pokemontcg.io/sv2/logo.png	Paldea Evolved Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV02", "pack_count": 36, "cards_per_pack": 11}	t	88	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
1f551d14-60b3-4205-97fd-5530a2f94f41	Pokémon 151 Elite Trainer Box	pokemon-151-elite-trainer-box	SV3.5-ETB-EN	820650851001	c336d639-ba86-4ab3-b94f-459c9f9d404b	Pokémon 151	Scarlet & Violet	2023-09-22	49.99	https://images.pokemontcg.io/sv3pt5/logo.png	Pokémon 151 Elite Trainer Box with 9 booster packs and accessories	{"includes": ["9 Pokémon 151 booster packs", "65 card sleeves", "45 Energy cards", "Player's guide", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "Collector's box"], "language": "English", "set_code": "SV3.5", "pack_count": 9, "cards_per_pack": 11}	t	100	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
8b4f830e-ca9c-4efa-bb1a-5aab08d5d327	Charizard ex Super Premium Collection	charizard-ex-super-premium-collection	SV-CHAR-SPC	820650852001	a69103e8-21f2-49cd-a99d-e326ddadf012	Special Collection	Scarlet & Violet	2023-12-01	119.99	https://images.pokemontcg.io/sv-promo/charizard-ex.png	Charizard ex Super Premium Collection with exclusive cards and accessories	{"includes": ["1 foil promo card featuring Charizard ex", "1 foil promo card featuring Charmander", "1 foil promo card featuring Charmeleon", "16 Pokémon TCG booster packs", "1 playmat featuring Charizard ex", "65 card sleeves featuring Charizard ex", "1 metal coin featuring Charizard ex", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "1 collector's box"], "language": "English", "set_code": "SV-PROMO", "pack_count": 16}	t	92	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
92c4c240-9f03-4332-8974-e827d9e504d3	Pokémon Scarlet & Violet Booster Pack	pokemon-scarlet-violet-booster-pack	SV01-BP-EN	820650850035	2b863a9f-b9af-4008-9703-faee327fa078	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	3.99	https://images.pokemontcg.io/sv1/pack.png	Single Scarlet & Violet Base Set booster pack	{"language": "English", "set_code": "SV01", "cards_per_pack": 11}	t	75	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
bf797e99-5e9a-44c8-bf93-1f2835709a7c	Pokémon Obsidian Flames Booster Box	pokemon-obsidian-flames-booster-box	SV03-BB-EN	820650850059	e2eed297-f19a-41aa-a9f5-45652a86d247	Obsidian Flames	Scarlet & Violet	2023-08-11	143.64	https://images.pokemontcg.io/sv3/logo.png	Obsidian Flames Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV03", "pack_count": 36, "cards_per_pack": 11}	t	90	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
6b595da3-9ab0-4e5f-9dfb-da1299d97dd2	Pokémon Paradox Rift Booster Box	pokemon-paradox-rift-booster-box	SV04-BB-EN	820650850066	e2eed297-f19a-41aa-a9f5-45652a86d247	Paradox Rift	Scarlet & Violet	2023-11-03	143.64	https://images.pokemontcg.io/sv4/logo.png	Paradox Rift Booster Box with 36 booster packs	{"language": "English", "set_code": "SV04", "pack_count": 36, "cards_per_pack": 11}	t	89	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
d86b2717-a9d6-4e60-b3c7-2ab84474112e	Pokémon Paldean Fates Elite Trainer Box	pokemon-paldean-fates-elite-trainer-box	SV4.5-ETB-EN	0820650852441	c336d639-ba86-4ab3-b94f-459c9f9d404b	Paldean Fates	Scarlet & Violet	2024-01-26	49.99	https://images.pokemontcg.io/sv4pt5/logo.png	Paldean Fates Elite Trainer Box including 9 booster packs and accessories	{"includes": ["9 Paldean Fates booster packs", "Card sleeves", "Energy cards", "Dice", "Markers"], "language": "English", "set_code": "SV4.5", "pack_count": 9}	t	93	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
ab6376ec-2da1-4d5a-8a07-6fd6908020c2	Pokémon Temporal Forces Booster Box	pokemon-temporal-forces-booster-box	SV05-BB-EN	0820650852519	e2eed297-f19a-41aa-a9f5-45652a86d247	Temporal Forces	Scarlet & Violet	2024-03-22	143.64	https://images.pokemontcg.io/sv5/logo.png	Temporal Forces Booster Box with 36 booster packs	{"language": "English", "set_code": "SV05", "pack_count": 36, "cards_per_pack": 11}	t	87	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
04e816b8-fdd8-4ff6-b50f-b955170d0902	Pokémon Crown Zenith Elite Trainer Box	pokemon-crown-zenith-elite-trainer-box	SWSH12.5-ETB-EN	0820650852625	c336d639-ba86-4ab3-b94f-459c9f9d404b	Crown Zenith	Sword & Shield	2023-01-20	49.99	https://images.pokemontcg.io/swsh12pt5/logo.png	Crown Zenith Elite Trainer Box featuring special Galarian Gallery cards	{"language": "English", "set_code": "SWSH12.5", "pack_count": 10}	t	98	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
d97f280c-ba44-4fa5-8888-91ba13a2372e	Pokémon Evolving Skies Booster Box	pokemon-evolving-skies-booster-box	SWSH07-BB-EN	0820650453693	e2eed297-f19a-41aa-a9f5-45652a86d247	Evolving Skies	Sword & Shield	2021-08-27	143.64	https://images.pokemontcg.io/swsh7/logo.png	Evolving Skies Booster Box featuring Eeveelutions and Dragon-type Pokémon	{"language": "English", "set_code": "SWSH07", "pack_count": 36, "cards_per_pack": 10}	t	100	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
8e6bed2d-90fa-4f95-86d8-09b2e19d4283	Pokémon Brilliant Stars Booster Box	pokemon-brilliant-stars-booster-box	SWSH09-BB-EN	0820650459541	e2eed297-f19a-41aa-a9f5-45652a86d247	Brilliant Stars	Sword & Shield	2022-02-25	143.64	https://images.pokemontcg.io/swsh9/logo.png	Brilliant Stars Booster Box featuring the Trainer Gallery subset	{"language": "English", "set_code": "SWSH09", "pack_count": 36, "cards_per_pack": 10}	t	94	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
b3e058a8-b998-4bc2-8a88-d8c131b1ae1f	Pokémon Lost Origin Booster Box	pokemon-lost-origin-booster-box	SWSH11-BB-EN	0820650460233	e2eed297-f19a-41aa-a9f5-45652a86d247	Lost Origin	Sword & Shield	2022-09-09	143.64	https://images.pokemontcg.io/swsh11/logo.png	Lost Origin Booster Box featuring the Lost Zone mechanic	{"language": "English", "set_code": "SWSH11", "pack_count": 36, "cards_per_pack": 10}	t	91	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
39c2e288-f88c-4e2a-a9b0-6a4856c211ec	Pokémon Astral Radiance Booster Box	pokemon-astral-radiance-booster-box	SWSH10-BB-EN	0820650460134	e2eed297-f19a-41aa-a9f5-45652a86d247	Astral Radiance	Sword & Shield	2022-05-27	143.64	https://images.pokemontcg.io/swsh10/logo.png	Astral Radiance Booster Box featuring Hisuian Pokémon	{"language": "English", "set_code": "SWSH10", "pack_count": 36, "cards_per_pack": 10}	t	88	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
457c94ae-082a-4851-9e89-659f515ba41e	Pokémon Fusion Strike Booster Box	pokemon-fusion-strike-booster-box	SWSH08-BB-EN	0820650459275	e2eed297-f19a-41aa-a9f5-45652a86d247	Fusion Strike	Sword & Shield	2021-11-12	143.64	https://images.pokemontcg.io/swsh8/logo.png	Fusion Strike Booster Box featuring Mew VMAX and Gengar VMAX	{"language": "English", "set_code": "SWSH08", "pack_count": 36, "cards_per_pack": 10}	t	86	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
ea99354e-219c-4112-8159-a39ef9e958d6	Pokémon Celebrations Elite Trainer Box	pokemon-celebrations-elite-trainer-box	SWSH25-ETB-EN	0820650459299	c336d639-ba86-4ab3-b94f-459c9f9d404b	Celebrations	Sword & Shield	2021-10-08	49.99	https://images.pokemontcg.io/swsh45/logo.png	25th Anniversary Celebrations Elite Trainer Box with special mini-packs	{"language": "English", "pack_count": 10}	t	97	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
123222d0-1632-4b6c-b488-9847b5d2de33	Pokémon Shining Fates Elite Trainer Box	pokemon-shining-fates-elite-trainer-box	SWSH4.5-ETB-EN	0820650457448	c336d639-ba86-4ab3-b94f-459c9f9d404b	Shining Fates	Sword & Shield	2021-02-19	49.99	https://images.pokemontcg.io/swsh45/logo.png	Shining Fates Elite Trainer Box featuring shiny vault cards	{"language": "English", "pack_count": 10}	t	92	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
6cf1ac8e-196c-41cf-b60f-e2630bc54b6b	Pokémon Hidden Fates Elite Trainer Box	pokemon-hidden-fates-elite-trainer-box	SM11.5-ETB-EN	0820650451491	c336d639-ba86-4ab3-b94f-459c9f9d404b	Hidden Fates	Sun & Moon	2019-09-20	49.99	https://images.pokemontcg.io/sm115/logo.png	Hidden Fates Elite Trainer Box with the iconic shiny vault	{"language": "English", "pack_count": 10}	t	99	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
9a4f0144-22e3-437b-ad58-5ba8ea22265d	Pokémon Chilling Reign Booster Box	pokemon-chilling-reign-booster-box	SWSH06-BB-EN	0820650458858	e2eed297-f19a-41aa-a9f5-45652a86d247	Chilling Reign	Sword & Shield	2021-06-18	143.64	https://images.pokemontcg.io/swsh6/logo.png	Chilling Reign Booster Box featuring the Calyrex forms	{"language": "English", "set_code": "SWSH06", "pack_count": 36, "cards_per_pack": 10}	t	84	2025-08-31 01:39:59.855171+00	2025-08-31 01:39:59.855171+00
\.


--
-- TOC entry 4226 (class 0 OID 17482)
-- Dependencies: 221
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retailers (id, name, slug, website_url, api_type, api_config, is_active, rate_limit_per_minute, health_score, last_health_check, supported_features, created_at, updated_at) FROM stdin;
68c60cf5-e984-4329-b736-19ada4d400ef	Best Buy	best-buy	https://www.bestbuy.com	official	{"api_key": "placeholder", "base_url": "https://api.bestbuy.com/v1"}	t	60	95	\N	["cart_links", "inventory_check", "price_tracking"]	2025-08-31 01:39:59.848501+00	2025-08-31 01:39:59.848501+00
423da5b6-2d85-46b3-9f03-17f683667b41	Walmart	walmart	https://www.walmart.com	affiliate	{"api_key": "placeholder", "affiliate_id": "placeholder"}	t	100	90	\N	["affiliate_links", "price_tracking"]	2025-08-31 01:39:59.848501+00	2025-08-31 01:39:59.848501+00
740af55f-1546-413a-a896-3a7ce9c335f5	Costco	costco	https://www.costco.com	scraping	{"base_url": "https://www.costco.com", "user_agent": "BoosterBeacon/1.0"}	t	30	85	\N	["price_tracking"]	2025-08-31 01:39:59.848501+00	2025-08-31 01:39:59.848501+00
02ab5814-6bda-485f-a2b5-d9271e5674e2	Sam's Club	sams-club	https://www.samsclub.com	scraping	{"base_url": "https://www.samsclub.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-08-31 01:39:59.848501+00	2025-08-31 01:39:59.848501+00
\.


--
-- TOC entry 4263 (class 0 OID 18319)
-- Dependencies: 258
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, slug, description, permissions, is_system_role, categories, level, is_active, created_by, created_at, updated_at) FROM stdin;
b3094d25-46ac-4ab3-ac2c-a13cbd7a0952	Super Administrator	super_admin	Full system access with all permissions	[]	t	["user_management","system_administration","ml_operations","analytics","content_management","security","billing","monitoring"]	100	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
9db72cc4-e783-4eef-8bab-5e92d90f439a	Administrator	admin	Administrative access with most permissions	[]	t	["user_management","system_administration","analytics","content_management","security","monitoring"]	80	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
ed8a3d68-1378-4e2c-8676-183b680f753e	User Manager	user_manager	Manage users and basic administrative tasks	[]	t	["user_management","analytics"]	60	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
573e49a4-0ad2-4c83-a571-b7182b89d6f7	Content Manager	content_manager	Manage products, retailers, and content	[]	t	["content_management","analytics"]	50	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
5655a0f5-b596-4e87-8930-ae3318f8824d	ML Engineer	ml_engineer	Manage machine learning models and data	[]	t	["ml_operations","analytics"]	50	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
03b5b0f5-e09d-43ad-b5ab-f790fe2a17f8	Analyst	analyst	View and analyze system data and metrics	[]	t	["analytics"]	40	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
9799cff8-84b0-4721-92b1-caf1ba8c8993	Support Agent	support_agent	Provide customer support and basic user management	[]	t	["user_management"]	30	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
1452765f-8f61-4620-98ca-b47a8abff059	Billing Manager	billing_manager	Manage billing, subscriptions, and financial data	[]	t	["billing","analytics"]	50	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
475fdfb5-1645-4467-b54c-a199fee1b5cd	Security Officer	security_officer	Manage security, audit logs, and compliance	[]	t	["security","monitoring"]	70	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
0697833c-f584-472b-a3dd-a5e2ee33bf02	User	user	Standard user with no administrative permissions	[]	t	[]	0	t	\N	2025-08-30 19:16:35.697581+00	2025-08-30 19:16:35.697581+00
\.


--
-- TOC entry 4248 (class 0 OID 17976)
-- Dependencies: 243
-- Data for Name: seasonal_patterns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasonal_patterns (id, product_id, category_id, pattern_type, pattern_name, avg_price_change, availability_change, demand_multiplier, historical_occurrences, confidence, last_updated) FROM stdin;
\.


--
-- TOC entry 4257 (class 0 OID 18171)
-- Dependencies: 252
-- Data for Name: social_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_shares (id, user_id, alert_id, platform, share_type, metadata, shared_at) FROM stdin;
\.


--
-- TOC entry 4266 (class 0 OID 18417)
-- Dependencies: 261
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, slug, description, price, billing_period, stripe_price_id, features, limits, is_active, trial_days, created_at, updated_at) FROM stdin;
aee4c579-9ab5-41cf-99a6-f76bd0c82010	Free	free	Basic alerts for casual collectors	0.00	monthly	\N	["Up to 5 product watches", "Basic email alerts", "Web push notifications", "Community support"]	{"max_watches": 5, "api_rate_limit": 1000, "max_alerts_per_day": 50}	t	0	2025-08-31 01:39:59.896849+00	2025-08-31 01:39:59.896849+00
975800ca-27ab-4075-953d-e8a19560a7dd	Pro Monthly	pro-monthly	Unlimited alerts for serious collectors	9.99	monthly	price_pro_monthly	["Unlimited product watches", "Priority alerts (5-second delivery)", "SMS notifications", "Discord integration", "Advanced filtering", "Price history & analytics", "Browser extension access", "Priority support"]	{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-08-31 01:39:59.896849+00	2025-08-31 01:39:59.896849+00
65f20fc3-ac87-4e2d-b6c2-24b95216dd00	Pro Yearly	pro-yearly	Unlimited alerts with 2 months free	99.99	yearly	price_pro_yearly	["Unlimited product watches", "Priority alerts (5-second delivery)", "SMS notifications", "Discord integration", "Advanced filtering", "Price history & analytics", "Browser extension access", "Priority support", "2 months free (17% savings)"]	{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}	t	14	2025-08-31 01:39:59.896849+00	2025-08-31 01:39:59.896849+00
\.


--
-- TOC entry 4237 (class 0 OID 17773)
-- Dependencies: 232
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, service_name, status, metrics, message, checked_at) FROM stdin;
\.


--
-- TOC entry 4253 (class 0 OID 18092)
-- Dependencies: 248
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_metrics (id, metric_name, metric_type, value, labels, recorded_at) FROM stdin;
992ef755-a610-4f60-af58-ac92cf15126c	cpu_usage	gauge	7.000000	{}	2025-08-30 19:16:54.161+00
4e34b7f8-4aef-4236-bd80-45171e689361	memory_usage	gauge	66.170000	{}	2025-08-30 19:16:54.161+00
2e80118f-58a0-4042-add4-cfa234b312af	disk_usage	gauge	45.200000	{}	2025-08-30 19:16:54.161+00
1e0d1b74-10cd-46bb-85f4-2ee7363986e6	uptime	gauge	69.188808	{}	2025-08-30 19:16:54.161+00
cfbd6c1e-7af8-491e-a0af-66a0ae444137	cpu_usage	gauge	7.000000	{}	2025-08-30 19:17:54.16+00
9217a0eb-b931-4f2d-acd7-59bece54b7d8	uptime	gauge	129.187558	{}	2025-08-30 19:17:54.16+00
8fbaf5a6-c301-4760-a943-7ea10a668cf6	memory_usage	gauge	66.250000	{}	2025-08-30 19:17:54.16+00
43931d6b-42e8-495a-ad43-3fc7f7c66e43	disk_usage	gauge	45.200000	{}	2025-08-30 19:17:54.16+00
044cd6a2-ff33-4cb2-bdb5-eaa6533490d4	cpu_usage	gauge	7.000000	{}	2025-08-30 19:19:52.405+00
24115c47-760a-401b-aa2f-050142f89dce	memory_usage	gauge	68.150000	{}	2025-08-30 19:19:52.406+00
afa2e9af-6783-4fca-a261-25fcbadb708d	disk_usage	gauge	45.200000	{}	2025-08-30 19:19:52.406+00
a358475c-bc83-4a80-8f80-fc4b96039d7f	uptime	gauge	68.672668	{}	2025-08-30 19:19:52.406+00
4f3279c1-c864-4f4d-89ac-1a93f5aae539	cpu_usage	gauge	7.000000	{}	2025-08-30 19:20:52.405+00
afe035d7-ef2f-4de5-93cd-62307d960e48	uptime	gauge	128.672406	{}	2025-08-30 19:20:52.406+00
549fc7b1-1544-42be-a314-139a2a7be5f3	memory_usage	gauge	68.630000	{}	2025-08-30 19:20:52.406+00
30d35a54-5743-4fe7-980d-49660e6983d5	disk_usage	gauge	45.200000	{}	2025-08-30 19:20:52.406+00
b2f69b33-a710-4c6d-9302-059579ff3770	cpu_usage	gauge	7.000000	{}	2025-08-30 19:22:29.914+00
e278b3d7-34c5-4f9b-82bb-63f3cd24396f	memory_usage	gauge	68.600000	{}	2025-08-30 19:22:29.914+00
f78fc63c-b5d2-4bce-97f4-73ab50b671d3	disk_usage	gauge	45.200000	{}	2025-08-30 19:22:29.915+00
c3f16ca8-7de2-49f7-8df9-7764b9d3d25c	uptime	gauge	70.073036	{}	2025-08-30 19:22:29.915+00
9b075c6a-b7b6-4160-b259-41c9c2a73be2	cpu_usage	gauge	7.000000	{}	2025-08-30 19:23:29.914+00
daa51932-1b78-4729-b75a-a35bf13e62e0	uptime	gauge	130.072279	{}	2025-08-30 19:23:29.914+00
ef67dd13-0a0e-4eed-aaef-37c79639058a	memory_usage	gauge	68.980000	{}	2025-08-30 19:23:29.914+00
66795433-a317-47f3-bb97-bb31dae9fb3b	disk_usage	gauge	45.200000	{}	2025-08-30 19:23:29.914+00
97e37ae8-0f8e-406c-b7dd-b52437083c41	cpu_usage	gauge	7.000000	{}	2025-08-30 19:24:29.916+00
fa4c2e44-45ac-4ace-8d11-4f7acf1c9754	memory_usage	gauge	69.090000	{}	2025-08-30 19:24:29.916+00
237cda71-76b3-445b-9c15-a6dada983ebc	disk_usage	gauge	45.200000	{}	2025-08-30 19:24:29.916+00
ade09f2b-9ad0-45e6-aa2e-bbcd1077bd53	uptime	gauge	190.074123	{}	2025-08-30 19:24:29.916+00
57839fbb-b2d2-4c4a-bb83-4aabbf039ab7	cpu_usage	gauge	7.000000	{}	2025-08-30 19:25:29.917+00
96647e24-7e8b-426b-8384-fc63edc4ed93	memory_usage	gauge	69.970000	{}	2025-08-30 19:25:29.917+00
c3e9bef8-028a-40d9-97d2-241136f6983c	disk_usage	gauge	45.200000	{}	2025-08-30 19:25:29.917+00
eadf490a-9f34-4af5-822c-e977150916a1	uptime	gauge	250.075275	{}	2025-08-30 19:25:29.917+00
a4f9482f-edf3-4700-9c7e-5420b38e74a1	memory_usage	gauge	69.060000	{}	2025-08-30 19:26:29.925+00
badeb895-8558-431f-8903-059a1409f4ba	cpu_usage	gauge	7.000000	{}	2025-08-30 19:26:29.925+00
7ed3c076-3766-4c99-843a-0322c22c8e23	disk_usage	gauge	45.200000	{}	2025-08-30 19:26:29.925+00
b66771f8-d443-4da9-b5ac-7886483e7650	uptime	gauge	310.083724	{}	2025-08-30 19:26:29.925+00
1ea5e7cf-6705-4f3b-9fca-99fa8cc2e5fe	cpu_usage	gauge	7.000000	{}	2025-08-30 19:27:29.925+00
8a7e954b-da69-4b58-8682-d1208305b990	memory_usage	gauge	69.020000	{}	2025-08-30 19:27:29.925+00
04384f0f-dd99-4a46-b8d8-6daad83baed2	disk_usage	gauge	45.200000	{}	2025-08-30 19:27:29.925+00
6eb7a675-7841-4dd3-abcd-198efd51f989	uptime	gauge	370.083813	{}	2025-08-30 19:27:29.925+00
6b2a2fbe-2efb-4174-ab8a-f68b9cf8e8c3	cpu_usage	gauge	7.000000	{}	2025-08-30 19:28:29.925+00
a0b7a97c-dc8c-4f47-afd1-08efce883cc9	memory_usage	gauge	69.390000	{}	2025-08-30 19:28:29.925+00
fc1483c7-cb44-47ca-89d7-7251f1b3b80c	disk_usage	gauge	45.200000	{}	2025-08-30 19:28:29.926+00
a747e5e9-d831-4a43-a07b-635be9f1ae5b	uptime	gauge	430.083954	{}	2025-08-30 19:28:29.926+00
f59cdaac-e5d7-4ed2-90a3-d861d36fcd2d	cpu_usage	gauge	7.000000	{}	2025-08-30 19:29:29.925+00
f4b82a80-8b7d-4ac9-aec1-1be5af969677	memory_usage	gauge	69.210000	{}	2025-08-30 19:29:29.925+00
d4d47f8d-9955-4aff-8d56-1de0eafdaaf2	disk_usage	gauge	45.200000	{}	2025-08-30 19:29:29.925+00
69d63110-5826-4ce9-beed-7c6bcb87ee0a	uptime	gauge	490.083640	{}	2025-08-30 19:29:29.925+00
192464b4-c99f-43c9-8374-38569dada5fa	cpu_usage	gauge	7.000000	{}	2025-08-30 19:30:29.925+00
87771984-b28d-4371-b35a-5826e0f231a4	memory_usage	gauge	70.020000	{}	2025-08-30 19:30:29.925+00
6e8c4d71-5ffb-4133-a2e0-12aee00a8768	disk_usage	gauge	45.200000	{}	2025-08-30 19:30:29.925+00
524994c5-3c87-46bd-b74e-2e1104bb5cc2	uptime	gauge	550.083718	{}	2025-08-30 19:30:29.925+00
4a7b1df3-4d46-4516-8106-bb0a4e8eeefa	cpu_usage	gauge	7.000000	{}	2025-08-30 19:31:29.925+00
66425b09-4f20-44c3-ac52-c600d3e525e5	disk_usage	gauge	45.200000	{}	2025-08-30 19:31:29.925+00
c32d07d7-130e-4c71-897e-4e720d7310b8	memory_usage	gauge	69.230000	{}	2025-08-30 19:31:29.925+00
660906ab-9422-4221-b79b-269bc6ecd9c9	uptime	gauge	610.083351	{}	2025-08-30 19:31:29.925+00
237058e9-31e6-44a5-8111-49634bf2a6e4	cpu_usage	gauge	7.000000	{}	2025-08-30 19:32:29.926+00
e7945e27-5e26-477b-9fa1-827ca472018a	memory_usage	gauge	65.480000	{}	2025-08-30 19:32:29.926+00
0cad8c91-d243-443d-a1ec-17980962d835	disk_usage	gauge	45.200000	{}	2025-08-30 19:32:29.926+00
5b53214d-3192-4b0d-8962-ec0596ba6bc6	uptime	gauge	670.084632	{}	2025-08-30 19:32:29.926+00
5e619793-46c8-4a12-9f7b-83883977a138	cpu_usage	gauge	7.000000	{}	2025-08-30 19:33:29.926+00
93efa96e-ac37-4dfa-9647-e359de327bac	memory_usage	gauge	66.180000	{}	2025-08-30 19:33:29.927+00
6efca183-54e4-42de-b93d-f51b17523c77	disk_usage	gauge	45.200000	{}	2025-08-30 19:33:29.927+00
8d444dcf-cd5a-49be-b071-bfd8e53191a1	uptime	gauge	730.084977	{}	2025-08-30 19:33:29.927+00
ea45687b-2ec5-41a7-b673-546c75e75356	cpu_usage	gauge	7.000000	{}	2025-08-30 19:34:29.926+00
ed266f56-4ac4-4289-9aec-ef35278fed49	memory_usage	gauge	66.330000	{}	2025-08-30 19:34:29.926+00
becdeba1-c288-4b0d-8d2e-45a53f2528b4	disk_usage	gauge	45.200000	{}	2025-08-30 19:34:29.926+00
f1bb74f0-4fbe-43f1-9ae7-a50012a1ef65	uptime	gauge	790.084694	{}	2025-08-30 19:34:29.926+00
d6aedbed-1ce3-4ced-a4f9-de01a7d9b9c2	cpu_usage	gauge	7.000000	{}	2025-08-30 19:35:29.926+00
71b387d6-66c0-455f-ae21-f2700b65c74d	memory_usage	gauge	65.970000	{}	2025-08-30 19:35:29.927+00
fe84219e-c13c-4758-a073-601c72a8e422	disk_usage	gauge	45.200000	{}	2025-08-30 19:35:29.927+00
16c5d3bd-e055-4229-83bc-7e16c9fc0a00	uptime	gauge	850.084953	{}	2025-08-30 19:35:29.927+00
bf4a5c3a-0eed-40f1-b9e0-8eb0da8214e2	cpu_usage	gauge	7.000000	{}	2025-08-30 19:36:29.926+00
4c8efd9e-a3b3-4912-b56c-e7b1d802597f	memory_usage	gauge	66.010000	{}	2025-08-30 19:36:29.926+00
cb4b267d-7f07-443b-9668-d98103e7b583	disk_usage	gauge	45.200000	{}	2025-08-30 19:36:29.926+00
fec988f9-0cc4-45da-af26-5ed797f73efa	uptime	gauge	910.084677	{}	2025-08-30 19:36:29.926+00
f2163241-f5a9-4c72-a353-d851438da7ca	cpu_usage	gauge	7.000000	{}	2025-08-30 19:37:29.927+00
f010227a-29bc-42f0-9551-079da952b222	memory_usage	gauge	66.050000	{}	2025-08-30 19:37:29.927+00
d289c0bc-2255-4864-8203-5cf3f7911996	disk_usage	gauge	45.200000	{}	2025-08-30 19:37:29.927+00
12288569-45a0-481a-9411-26caa9cfdd62	uptime	gauge	970.085696	{}	2025-08-30 19:37:29.927+00
c1ea580a-fc92-4661-a22a-b51a2ef2e34d	cpu_usage	gauge	7.000000	{}	2025-08-30 19:38:29.927+00
e0183fa5-d9a5-481b-9411-35231af0c202	memory_usage	gauge	65.180000	{}	2025-08-30 19:38:29.927+00
e9f920ba-cd76-4fa4-8ca0-21ecf0037ddd	disk_usage	gauge	45.200000	{}	2025-08-30 19:38:29.927+00
1e22a84c-5342-419f-90f4-a23afdee9c55	uptime	gauge	1030.085576	{}	2025-08-30 19:38:29.927+00
9ecc868e-8aa3-43e9-8121-65dca270c0f0	cpu_usage	gauge	8.000000	{}	2025-08-30 19:39:29.927+00
c15753a7-81ae-432e-9a6e-c3227a08bc67	memory_usage	gauge	66.390000	{}	2025-08-30 19:39:29.927+00
28212dab-6fd0-43f3-8a16-4e75aa9b47c3	disk_usage	gauge	45.200000	{}	2025-08-30 19:39:29.927+00
a62d9e92-7e2e-4b31-bebd-2dfbc48af92f	uptime	gauge	1090.085796	{}	2025-08-30 19:39:29.927+00
b03489c3-9fd7-4eeb-ab21-a9aba471d0c8	cpu_usage	gauge	8.000000	{}	2025-08-30 19:40:29.927+00
007a78d3-3b66-4cad-a8e7-cf9cde643406	memory_usage	gauge	67.220000	{}	2025-08-30 19:40:29.927+00
db0c48e1-1c32-43c9-bc50-5ca5e6258af2	disk_usage	gauge	45.200000	{}	2025-08-30 19:40:29.927+00
30dacb05-bef0-4f72-a984-12b8e45e6b35	uptime	gauge	1150.085166	{}	2025-08-30 19:40:29.927+00
db164783-d56b-4c6c-b350-4d2d90ae6eaa	cpu_usage	gauge	8.000000	{}	2025-08-30 19:41:29.927+00
c99b49b8-75b2-49b8-ba33-db09ab9e2765	memory_usage	gauge	66.770000	{}	2025-08-30 19:41:29.927+00
001e4815-fa93-4480-aad0-b1fdbef4abfd	disk_usage	gauge	45.200000	{}	2025-08-30 19:41:29.927+00
25bf3eb9-500e-41a4-a4da-66aadab1f403	uptime	gauge	1210.085836	{}	2025-08-30 19:41:29.927+00
c124ac1b-03d2-49b1-b39b-b4a9f8969f26	cpu_usage	gauge	8.000000	{}	2025-08-30 19:43:56.516+00
a53ae1eb-f80d-4971-af66-5b6e9c3007f4	memory_usage	gauge	66.310000	{}	2025-08-30 19:43:56.517+00
eabef735-a001-4316-a7ad-3a686ed6a59a	disk_usage	gauge	45.200000	{}	2025-08-30 19:43:56.517+00
e2b49b23-9607-4968-bc38-c4ca85417ec4	uptime	gauge	69.664246	{}	2025-08-30 19:43:56.517+00
b0dd0fc4-1f53-4cec-877b-e6934335e94c	cpu_usage	gauge	8.000000	{}	2025-08-30 19:44:56.517+00
b7e3b31a-b77a-42f8-8e64-8659dd4e74fd	uptime	gauge	129.664370	{}	2025-08-30 19:44:56.517+00
7487abbb-e468-4d44-9a28-8fe7e05003f0	memory_usage	gauge	66.080000	{}	2025-08-30 19:44:56.517+00
73ca37b8-c798-4555-8b4c-58f6e3345fd4	disk_usage	gauge	45.200000	{}	2025-08-30 19:44:56.517+00
b74f31e2-4c03-4b5e-a4b2-e54261674f14	cpu_usage	gauge	8.000000	{}	2025-08-30 19:45:56.517+00
4f6c982d-2a85-445e-ae1b-26263d9ddef3	memory_usage	gauge	66.320000	{}	2025-08-30 19:45:56.518+00
42aa4b64-0285-415d-9d35-5d0db7cd9d95	disk_usage	gauge	45.200000	{}	2025-08-30 19:45:56.518+00
6bbb0699-377e-4b12-b572-b1f4be247283	uptime	gauge	189.665021	{}	2025-08-30 19:45:56.518+00
ca66dde1-f64c-4358-bfc3-c8bc18b2007a	cpu_usage	gauge	8.000000	{}	2025-08-30 19:46:56.518+00
9af111c7-d990-42a6-b17c-95a0fc2d992d	memory_usage	gauge	67.230000	{}	2025-08-30 19:46:56.518+00
3bb1cf99-1e9d-4b28-b480-29fcb1d9b8ca	uptime	gauge	249.665867	{}	2025-08-30 19:46:56.518+00
f66a5264-c909-4c4b-844d-98bd9c14f597	disk_usage	gauge	45.200000	{}	2025-08-30 19:46:56.518+00
beafeda3-d052-4b2e-8b1e-b370fe70d809	cpu_usage	gauge	8.000000	{}	2025-08-30 19:47:56.519+00
7a6bdaa5-4544-47d0-b4cb-85333bca6cd3	memory_usage	gauge	66.540000	{}	2025-08-30 19:47:56.519+00
0974d521-2636-4abd-8303-f974303b9a08	disk_usage	gauge	45.200000	{}	2025-08-30 19:47:56.519+00
e890480b-91b4-498b-b112-b2977621fdf8	uptime	gauge	309.666115	{}	2025-08-30 19:47:56.519+00
0a219325-5407-4ae4-a9f9-a037d3ac8d57	cpu_usage	gauge	8.000000	{}	2025-08-30 19:48:56.519+00
dc6acb0c-afd3-426c-a34f-bff7962ac49a	disk_usage	gauge	45.200000	{}	2025-08-30 19:48:56.519+00
419b6d83-4635-44be-9a28-6b5e02aea4f7	memory_usage	gauge	66.730000	{}	2025-08-30 19:48:56.519+00
6e31ae6f-4931-460e-a6c9-9d38884f0175	uptime	gauge	369.666846	{}	2025-08-30 19:48:56.519+00
1e6dcdfb-9fc3-4bac-b196-b7999ff3aeae	cpu_usage	gauge	8.000000	{}	2025-08-30 19:49:56.52+00
09432058-94a7-42fd-a78e-73e9aabb6e30	memory_usage	gauge	66.600000	{}	2025-08-30 19:49:56.52+00
75e0d978-d99c-4bc8-b45c-24e16fda4549	disk_usage	gauge	45.200000	{}	2025-08-30 19:49:56.52+00
d6aaaaa3-330e-4da7-b6f4-15e463fac6ff	uptime	gauge	429.667104	{}	2025-08-30 19:49:56.52+00
92183338-2240-4895-8b80-799f7f0dea9c	cpu_usage	gauge	8.000000	{}	2025-08-30 19:50:56.52+00
e31e072d-61f9-4c5e-8185-48b3bb8cd1a0	memory_usage	gauge	65.820000	{}	2025-08-30 19:50:56.52+00
9b666237-1d15-4f25-b797-e434370d8473	disk_usage	gauge	45.200000	{}	2025-08-30 19:50:56.52+00
18bfa372-e20f-4632-b8d5-834135a0566b	uptime	gauge	489.667497	{}	2025-08-30 19:50:56.52+00
6d23ffa2-13ef-4708-9892-2a2f5f2f2d66	cpu_usage	gauge	8.000000	{}	2025-08-30 19:51:56.52+00
14743096-a528-4806-9093-4a92e5b339c4	memory_usage	gauge	65.840000	{}	2025-08-30 19:51:56.52+00
496720ad-02da-4f48-aacc-185a5ab0d1ab	disk_usage	gauge	45.200000	{}	2025-08-30 19:51:56.52+00
15d1696c-22df-44d7-aab8-ed28f1e8cf3f	uptime	gauge	549.667618	{}	2025-08-30 19:51:56.52+00
8c761757-dc69-4a17-808b-9bfa5422fa39	cpu_usage	gauge	8.000000	{}	2025-08-30 19:52:56.52+00
d9d00178-50e9-4dce-b9a1-07d38d5cd483	memory_usage	gauge	67.080000	{}	2025-08-30 19:52:56.52+00
09f93c18-8d69-4f17-833a-b8b94747bf22	disk_usage	gauge	45.200000	{}	2025-08-30 19:52:56.52+00
f8e72928-87aa-4340-8bec-c61af80d7569	uptime	gauge	609.667883	{}	2025-08-30 19:52:56.52+00
9f9a5d45-3637-47c6-beec-86bb5076ad30	cpu_usage	gauge	8.000000	{}	2025-08-30 19:53:56.52+00
116e020a-7314-4dfd-89cc-ff879e02e9e8	memory_usage	gauge	66.690000	{}	2025-08-30 19:53:56.52+00
c5942d1d-9f7e-4513-a7d3-89b0fad46bc6	disk_usage	gauge	45.200000	{}	2025-08-30 19:53:56.52+00
c694729b-8969-4457-a783-35bee71759c3	uptime	gauge	669.667196	{}	2025-08-30 19:53:56.52+00
4c8e3501-57a8-4b37-a982-666e230f223f	cpu_usage	gauge	8.000000	{}	2025-08-30 19:54:56.521+00
01665e5f-5048-4ef9-80b1-27b46b5ce690	memory_usage	gauge	65.870000	{}	2025-08-30 19:54:56.521+00
2f8c271e-d079-453a-aa78-e957301a1b2e	disk_usage	gauge	45.200000	{}	2025-08-30 19:54:56.521+00
7eb3be57-2505-43a2-905d-45de4fdb63b0	uptime	gauge	729.668076	{}	2025-08-30 19:54:56.521+00
ba173c75-2b99-4eba-87a1-4ab0b345cc54	cpu_usage	gauge	8.000000	{}	2025-08-30 19:55:56.522+00
5e8b706a-4c5e-406f-9180-44f373608f64	memory_usage	gauge	64.790000	{}	2025-08-30 19:55:56.522+00
3e93645b-30d5-49bc-91ea-9af2fc903004	disk_usage	gauge	45.200000	{}	2025-08-30 19:55:56.522+00
0ec0054a-3762-49d6-a3a5-023e639c3d47	uptime	gauge	789.669868	{}	2025-08-30 19:55:56.522+00
7013d067-cd74-4ed9-b575-a0bb323d8b8e	cpu_usage	gauge	8.000000	{}	2025-08-30 19:56:56.524+00
b6283e83-b76a-42e9-b8f7-f52b47a235b5	memory_usage	gauge	65.970000	{}	2025-08-30 19:56:56.524+00
7455540f-566f-49a7-8041-f66f4bca5254	disk_usage	gauge	45.200000	{}	2025-08-30 19:56:56.524+00
c8fbc359-09b9-4118-8068-367fcf6e20b1	uptime	gauge	849.671070	{}	2025-08-30 19:56:56.524+00
82297530-5cf1-4de0-897e-0467ad3b9095	cpu_usage	gauge	8.000000	{}	2025-08-30 20:00:08.692+00
915b1c41-405b-4c17-8270-fcd06315384c	memory_usage	gauge	66.120000	{}	2025-08-30 20:00:08.692+00
22dcb858-256e-4fc7-aa45-0cd7b97aadcb	disk_usage	gauge	45.200000	{}	2025-08-30 20:00:08.692+00
7e9ae1f1-1792-4fe2-b5bf-5734f0f99588	uptime	gauge	69.838935	{}	2025-08-30 20:00:08.692+00
796d98b3-f98e-41d5-9b16-e73e07429c3c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:01:08.691+00
73cbdfbf-538e-4abd-ab67-9826748dcefd	memory_usage	gauge	66.280000	{}	2025-08-30 20:01:08.692+00
b38bde99-ddfe-4035-82e2-ba2f515e0ef4	disk_usage	gauge	45.200000	{}	2025-08-30 20:01:08.692+00
3051ec89-d88f-4070-8eff-955b8f47db33	uptime	gauge	129.838710	{}	2025-08-30 20:01:08.692+00
7617297a-7ee5-4549-af71-91cd7ff6fe48	cpu_usage	gauge	8.000000	{}	2025-08-30 20:02:08.692+00
f8abb53d-5d75-4401-a2ac-cef4b47c9e9c	memory_usage	gauge	67.500000	{}	2025-08-30 20:02:08.692+00
2405a631-c4a1-4b09-95c9-e5eab165c759	disk_usage	gauge	45.200000	{}	2025-08-30 20:02:08.692+00
3edba49e-a3e2-40c7-934c-47a75d67b492	uptime	gauge	189.838955	{}	2025-08-30 20:02:08.692+00
1097f201-38b7-4f5e-bf30-6afa7e729f12	cpu_usage	gauge	8.000000	{}	2025-08-30 20:03:08.692+00
f5a6a9cc-a559-4279-a986-c0f75849545c	memory_usage	gauge	67.010000	{}	2025-08-30 20:03:08.692+00
8731cf88-9b0a-47bb-b3e6-3f27d88ac3bc	disk_usage	gauge	45.200000	{}	2025-08-30 20:03:08.692+00
e777d369-bb8c-4cda-b3ad-a81ee5e3505f	uptime	gauge	249.839448	{}	2025-08-30 20:03:08.692+00
ff0b612c-f6e3-4e9e-8e6b-9432b5f52c6b	cpu_usage	gauge	8.000000	{}	2025-08-30 20:04:08.699+00
0acc15f4-9fae-44bb-9ebd-d00576a85147	memory_usage	gauge	67.140000	{}	2025-08-30 20:04:08.699+00
e10daf10-d737-44c6-8d4a-c1e9eaa40792	disk_usage	gauge	45.200000	{}	2025-08-30 20:04:08.699+00
ecf44d97-97b0-47af-95bd-8ab740f45cb0	uptime	gauge	309.846084	{}	2025-08-30 20:04:08.699+00
54df2496-d41b-4801-a114-4f80001ec77a	memory_usage	gauge	66.130000	{}	2025-08-30 20:07:26.347+00
3df352e5-61e1-400a-a174-bbad43f27f03	cpu_usage	gauge	8.000000	{}	2025-08-30 20:07:26.347+00
11ffaa6b-f05d-4605-b6a7-7ad9020d4296	disk_usage	gauge	45.200000	{}	2025-08-30 20:07:26.347+00
c16fc79a-73b8-44a1-b2dd-6c2d6dedb24c	uptime	gauge	69.465695	{}	2025-08-30 20:07:26.347+00
7f97cb25-9d72-4e0e-80d3-e0ca3ebb3c9c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:08:26.347+00
61fb30be-7321-4f6a-a1b1-fc69c2ec8f08	memory_usage	gauge	65.760000	{}	2025-08-30 20:08:26.348+00
fdd259a2-3b17-4e12-a386-7fa1596b35a8	disk_usage	gauge	45.200000	{}	2025-08-30 20:08:26.348+00
219d73f8-fe19-49ac-8c54-af910d6a8464	uptime	gauge	129.465837	{}	2025-08-30 20:08:26.348+00
d1e680a3-b4e2-4d8c-b7c6-a1563a9f6cae	cpu_usage	gauge	8.000000	{}	2025-08-30 20:09:26.348+00
c5dbc99f-38db-4a5f-b9a8-6b00dccd8dcd	memory_usage	gauge	65.400000	{}	2025-08-30 20:09:26.348+00
ae7c6da2-84ea-4b67-a44a-cfc83100ca8f	disk_usage	gauge	45.200000	{}	2025-08-30 20:09:26.348+00
c55589cc-844c-4ae2-98ea-27e39996657b	uptime	gauge	189.466242	{}	2025-08-30 20:09:26.348+00
e4f5ab50-982f-446d-967a-328001933760	cpu_usage	gauge	8.000000	{}	2025-08-30 20:10:26.348+00
980d62a5-41b7-40f6-8cfb-758d234e1318	memory_usage	gauge	65.090000	{}	2025-08-30 20:10:26.348+00
07d08b9e-ac1d-4a9e-88d8-abdd70d90a76	disk_usage	gauge	45.200000	{}	2025-08-30 20:10:26.348+00
5e54aaae-cc03-48ec-874e-a16e4015918e	uptime	gauge	249.466121	{}	2025-08-30 20:10:26.348+00
7180c5b7-9cd5-42fe-a4c5-5f25361c0f62	cpu_usage	gauge	8.000000	{}	2025-08-30 20:17:22.828+00
c98fc1ee-7277-4d68-b860-ec951531a2b5	memory_usage	gauge	66.500000	{}	2025-08-30 20:17:22.828+00
be8ffaca-9542-48e1-9baa-78df3fd65ed4	disk_usage	gauge	45.200000	{}	2025-08-30 20:17:22.828+00
e5d54374-d1f1-4fe3-a7a1-47c9d7823741	uptime	gauge	68.648636	{}	2025-08-30 20:17:22.828+00
373c88ed-a8eb-44ca-a0ec-ba54f42d9aa0	uptime	gauge	128.648813	{}	2025-08-30 20:18:22.828+00
6c7fd5e4-2d6b-4746-9503-3fbfe467b8bd	cpu_usage	gauge	8.000000	{}	2025-08-30 20:18:22.828+00
9fceee65-4eca-44f3-9d43-aab1549ffd66	memory_usage	gauge	66.230000	{}	2025-08-30 20:18:22.828+00
c26e5cee-5eda-4c92-857c-af8c825195af	disk_usage	gauge	45.200000	{}	2025-08-30 20:18:22.828+00
b646f826-2c7b-475f-a548-96e098cd2a48	cpu_usage	gauge	8.000000	{}	2025-08-30 20:19:22.828+00
93b624eb-a46f-4c97-9c32-089f9d4fce8d	disk_usage	gauge	45.200000	{}	2025-08-30 20:19:22.828+00
92be45fe-d31a-4ef8-bca5-b846b90a34a8	memory_usage	gauge	66.270000	{}	2025-08-30 20:20:22.829+00
32265389-8d7d-412f-ae1f-38c8e9a5652d	uptime	gauge	248.649329	{}	2025-08-30 20:20:22.829+00
3b82c0a5-2160-4cd1-bbf6-f48044e145a2	memory_usage	gauge	66.510000	{}	2025-08-30 20:21:22.835+00
6aec7e6d-689c-40e1-b21c-61becf865663	disk_usage	gauge	45.200000	{}	2025-08-30 20:21:22.835+00
b0f9f9e1-d32e-42b8-bca3-909d35583cf5	memory_usage	gauge	66.040000	{}	2025-08-30 20:22:22.835+00
a7185d0b-1d28-41e5-8267-4489f90e121f	disk_usage	gauge	45.200000	{}	2025-08-30 20:22:22.835+00
8320ec41-c342-47ce-a835-cb7588a1c1a3	memory_usage	gauge	66.020000	{}	2025-08-30 20:23:22.835+00
ecc9162d-d222-46b2-83c5-00e71d89cc45	disk_usage	gauge	45.200000	{}	2025-08-30 20:23:22.836+00
3e63c1cf-68d2-483f-8607-9db522b89c3d	memory_usage	gauge	66.040000	{}	2025-08-30 20:24:22.836+00
6cfa7c59-68b6-4a15-b6fc-745cdbc63a61	uptime	gauge	488.656079	{}	2025-08-30 20:24:22.836+00
5bc20e07-a520-4c80-b72b-24fc196a08b7	memory_usage	gauge	65.990000	{}	2025-08-30 20:25:22.837+00
0815a13d-e98c-4483-a869-86de52fa7fdc	disk_usage	gauge	45.200000	{}	2025-08-30 20:25:22.837+00
27fdb134-fd4b-4a58-a58f-b4c9ddf74d71	cpu_usage	gauge	8.000000	{}	2025-08-30 20:26:22.839+00
0b60bc03-a5bd-4fcb-b098-892b4d18cbf8	uptime	gauge	608.659743	{}	2025-08-30 20:26:22.839+00
d05f90a1-4960-41a4-818b-1e024110995d	memory_usage	gauge	65.970000	{}	2025-08-30 20:27:22.841+00
f2e40c1c-e521-458a-bea8-47d2357d1dc0	uptime	gauge	668.661151	{}	2025-08-30 20:27:22.841+00
9a81284d-3e41-4f3f-962a-08e7699c3d34	cpu_usage	gauge	8.000000	{}	2025-08-30 20:28:22.843+00
e5efe55f-94f0-4c8f-8829-76ea6fc5308a	disk_usage	gauge	45.200000	{}	2025-08-30 20:28:22.843+00
503db074-fe6a-42ec-a720-fcd839c1488b	disk_usage	gauge	45.200000	{}	2025-08-30 20:29:22.844+00
825c514f-9dbb-42cb-b0d9-ce2f7a12d387	uptime	gauge	788.664391	{}	2025-08-30 20:29:22.844+00
bf278ba5-8c43-4484-9530-01f5265007b9	memory_usage	gauge	84.410000	{}	2025-08-31 00:38:38.449+00
e9e96ff9-fa34-41cd-a70c-3398dfc01141	cpu_usage	gauge	8.000000	{}	2025-08-31 00:38:38.449+00
fdd405ad-6369-47d1-aecc-3978bb75d6ce	cpu_usage	gauge	8.000000	{}	2025-08-31 00:39:38.45+00
8470a1e4-dc22-40f5-8250-43f559e31678	memory_usage	gauge	83.490000	{}	2025-08-31 00:39:38.45+00
0b31f493-e68a-403a-a113-4b512b72f3d7	disk_usage	gauge	45.200000	{}	2025-08-31 00:40:38.45+00
be4a638d-fd7c-4a51-b2ea-ff1dee2ef38b	uptime	gauge	7629.309640	{}	2025-08-31 00:40:38.45+00
ead1cc46-d96d-438a-be6e-cdc4ebc0abd3	cpu_usage	gauge	8.000000	{}	2025-08-31 00:41:38.45+00
4113305b-4d5f-483d-a691-b2f99362447e	disk_usage	gauge	45.200000	{}	2025-08-31 00:41:38.45+00
4e0fe554-ed55-4b96-a5d8-d86afb91144c	memory_usage	gauge	83.620000	{}	2025-08-31 00:42:38.45+00
bbab97d5-e55f-4707-98b8-7616c7838723	uptime	gauge	7749.309271	{}	2025-08-31 00:42:38.45+00
8a16b8d7-f2b0-4df3-b409-02748304e131	cpu_usage	gauge	8.000000	{}	2025-08-31 00:43:38.45+00
50dc1a74-c91b-465a-98e8-2f8f662c235d	memory_usage	gauge	84.370000	{}	2025-08-31 00:43:38.45+00
2a8746ec-18a8-4bff-8572-ef612a2d0ebb	memory_usage	gauge	80.540000	{}	2025-08-31 00:55:49.569+00
e7c42e65-de93-41b6-a2b2-79c136f23469	memory_usage	gauge	80.920000	{}	2025-08-31 00:56:49.569+00
b7145839-7796-4f72-85f7-8e99453eca6f	cpu_usage	gauge	8.000000	{}	2025-08-31 00:57:49.569+00
c2b54d25-e1b5-4805-847c-ebae1c4d7e7f	uptime	gauge	369.955581	{}	2025-08-31 00:58:49.569+00
d55fb701-d65c-467d-865c-f98fda8a1266	disk_usage	gauge	45.200000	{}	2025-08-31 00:59:49.57+00
0ead6aea-a07b-447d-ab37-79d524c25c0b	memory_usage	gauge	78.510000	{}	2025-08-31 01:40:01.633+00
ddefe2f4-3bd3-4005-93ed-99d0c5109801	memory_usage	gauge	66.310000	{}	2025-08-30 20:19:22.828+00
50795be2-a100-433f-bbca-253759482550	cpu_usage	gauge	8.000000	{}	2025-08-30 20:20:22.829+00
8acc197a-d5c5-4e77-907c-d02e4a46da89	uptime	gauge	308.655095	{}	2025-08-30 20:21:22.835+00
e64185ad-11b0-4ded-a3ab-15b74ec9580c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:22:22.835+00
1f0383f7-aa64-46b5-92ce-f3df91651af3	uptime	gauge	428.656325	{}	2025-08-30 20:23:22.836+00
919501ac-fe51-4f5b-a05e-bfbe61a6b6a9	disk_usage	gauge	45.200000	{}	2025-08-30 20:24:22.836+00
f3f1d2e2-8862-4027-9db2-9730f71a870c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:25:22.837+00
d196ce61-de0c-4e97-bb02-0bf3abd23aab	disk_usage	gauge	45.200000	{}	2025-08-30 20:26:22.839+00
9bf589e4-49d5-4192-8d39-eb92a898823d	disk_usage	gauge	45.200000	{}	2025-08-30 20:27:22.841+00
e19a597a-b8ab-4ca3-b8b7-3bf7e3390e8e	memory_usage	gauge	65.970000	{}	2025-08-30 20:28:22.843+00
a2dafbc5-187e-44f8-9e6e-b25795352cac	memory_usage	gauge	66.000000	{}	2025-08-30 20:29:22.844+00
063fec18-c8d1-480a-b6b9-0730771877cb	disk_usage	gauge	45.200000	{}	2025-08-31 00:38:38.449+00
e7b4acb6-5580-4f65-8c5d-ff4a3f49c775	uptime	gauge	7569.309069	{}	2025-08-31 00:39:38.45+00
d061d2b7-7b11-408e-a338-4010fedeb47e	memory_usage	gauge	83.580000	{}	2025-08-31 00:40:38.45+00
6ea682a7-3cb8-4629-9991-51e75b3ddee7	memory_usage	gauge	84.010000	{}	2025-08-31 00:41:38.45+00
f105254e-8d82-4f2d-a82d-a7f7674cddc0	cpu_usage	gauge	8.000000	{}	2025-08-31 00:42:38.45+00
e071f882-6be0-4f98-888e-c44f999fd699	uptime	gauge	7809.309365	{}	2025-08-31 00:43:38.45+00
ecc05673-a182-4560-ba78-5a02b6b6e2dd	disk_usage	gauge	45.200000	{}	2025-08-31 00:55:49.569+00
1df9d3e1-fdf5-470e-b249-d974bd5148a5	cpu_usage	gauge	8.000000	{}	2025-08-31 00:56:49.569+00
725451ae-332f-4bbe-acf2-3507e2171753	uptime	gauge	309.955489	{}	2025-08-31 00:57:49.569+00
69837dc4-9aa7-45c1-a05c-b549aa648543	disk_usage	gauge	45.200000	{}	2025-08-31 00:58:49.569+00
aeb46591-babd-4321-8372-66fe28e67adc	memory_usage	gauge	80.840000	{}	2025-08-31 00:59:49.57+00
8b8711e2-31b1-4108-b51f-9988bd0795ea	cpu_usage	gauge	8.000000	{}	2025-08-31 01:41:01.633+00
96b4e9bc-a56f-4150-b4d5-fa6faa79478a	uptime	gauge	188.648683	{}	2025-08-30 20:19:22.828+00
ec6adcfa-816f-4308-b855-0a50dbf08bc7	disk_usage	gauge	45.200000	{}	2025-08-30 20:20:22.829+00
0758a768-b4a9-4362-817f-23c0a0240ed2	cpu_usage	gauge	8.000000	{}	2025-08-30 20:21:22.835+00
358d9e0d-2246-4588-839d-7ff0ccd85d4e	uptime	gauge	368.655187	{}	2025-08-30 20:22:22.835+00
fc7b0eea-4a31-4fca-a452-9697be7f00aa	cpu_usage	gauge	8.000000	{}	2025-08-30 20:23:22.835+00
ed999597-4a64-4cc6-99a4-2191c1505af4	cpu_usage	gauge	8.000000	{}	2025-08-30 20:24:22.835+00
4c012a97-e273-4228-88a0-8be089f86f1a	uptime	gauge	548.657708	{}	2025-08-30 20:25:22.837+00
caebee30-46b2-45c7-82c5-2b6a41e834d9	memory_usage	gauge	66.200000	{}	2025-08-30 20:26:22.839+00
36949c57-670f-46a3-831c-8be201a5ea24	cpu_usage	gauge	8.000000	{}	2025-08-30 20:27:22.841+00
93335764-ec1e-459b-84a3-6d0ddeeaaca7	uptime	gauge	728.663645	{}	2025-08-30 20:28:22.843+00
4c6b62e9-30cd-4da6-a663-dc3c3ed94dc4	cpu_usage	gauge	8.000000	{}	2025-08-30 20:29:22.844+00
42a28576-37ed-44e7-9f93-53ffe710a464	memory_usage	gauge	65.850000	{}	2025-08-30 20:30:22.845+00
3beddb9d-4957-487c-b3a9-ace98d0a8102	cpu_usage	gauge	8.000000	{}	2025-08-30 20:30:22.844+00
e4736476-d3e2-45f9-99f1-4f194ebb7c19	uptime	gauge	848.665074	{}	2025-08-30 20:30:22.845+00
3facc67e-b1d3-445d-9bc6-898e80f88091	disk_usage	gauge	45.200000	{}	2025-08-30 20:30:22.845+00
ab9bee31-6174-4d57-b828-107f892105d7	cpu_usage	gauge	8.000000	{}	2025-08-30 20:31:22.846+00
de08561b-0bbd-4728-af35-cff909a5d55f	memory_usage	gauge	66.150000	{}	2025-08-30 20:31:22.846+00
1a59100d-d3e8-4e58-8063-9124a18271ea	disk_usage	gauge	45.200000	{}	2025-08-30 20:31:22.846+00
f1ae39ae-09dd-456b-aaea-ad6714964646	uptime	gauge	908.666640	{}	2025-08-30 20:31:22.846+00
2d7786fd-afc8-4324-9ca0-01b9375ad084	cpu_usage	gauge	8.000000	{}	2025-08-30 20:32:22.846+00
7796c77c-177b-4f36-ae17-6a8e21584fcf	memory_usage	gauge	66.110000	{}	2025-08-30 20:32:22.846+00
f7244dbc-54d4-497f-968f-fcee0902bfcc	disk_usage	gauge	45.200000	{}	2025-08-30 20:32:22.846+00
470d663c-d8a5-494e-a0fb-6169271eda3c	uptime	gauge	968.666728	{}	2025-08-30 20:32:22.846+00
c9a614cd-6b97-4f2c-94f2-7ce8b7356924	cpu_usage	gauge	8.000000	{}	2025-08-30 20:33:22.846+00
95de1334-9345-4ee7-95f3-df3a91db6fb3	memory_usage	gauge	65.850000	{}	2025-08-30 20:33:22.846+00
cfc5ada6-b750-4fd9-99f9-942cb71558c5	disk_usage	gauge	45.200000	{}	2025-08-30 20:33:22.846+00
95be3c04-771e-47b8-8cfe-d0449e412319	uptime	gauge	1028.666524	{}	2025-08-30 20:33:22.846+00
6d63f30b-1fa1-4361-9f4c-4df52105e57d	cpu_usage	gauge	8.000000	{}	2025-08-30 20:34:22.846+00
dfa92c68-ec27-4c76-9504-7d12d94f2bbb	memory_usage	gauge	65.740000	{}	2025-08-30 20:34:22.846+00
db54b4d5-5308-41db-be5a-c9ab06510c72	disk_usage	gauge	45.200000	{}	2025-08-30 20:34:22.846+00
acace17d-4ef9-4a51-a5e5-1a4a96d65646	uptime	gauge	1088.666920	{}	2025-08-30 20:34:22.846+00
85372800-5ad4-4760-a0a0-a16935304d61	cpu_usage	gauge	8.000000	{}	2025-08-30 20:35:22.847+00
0c13390d-7056-46ab-8919-104149a57bc7	memory_usage	gauge	65.920000	{}	2025-08-30 20:35:22.847+00
c910811d-3162-496f-802f-ea6ed9280c2f	disk_usage	gauge	45.200000	{}	2025-08-30 20:35:22.847+00
d710fd1e-2c6d-40cd-8bde-0159698cd08a	uptime	gauge	1148.667308	{}	2025-08-30 20:35:22.847+00
0d9f38ab-2d1d-4a25-8d82-8c5ee401a8fa	cpu_usage	gauge	8.000000	{}	2025-08-30 20:36:22.847+00
7da6c1fc-9e42-41f4-a883-8a1e23ba7a84	memory_usage	gauge	65.990000	{}	2025-08-30 20:36:22.847+00
ebd961de-e17a-4235-bf4b-f249a85eb4c9	disk_usage	gauge	45.200000	{}	2025-08-30 20:36:22.847+00
2abea78c-2e66-4049-9f2f-20dbc03536ed	uptime	gauge	1208.667518	{}	2025-08-30 20:36:22.847+00
aa5beb7d-2ab8-4525-88d0-4c536e33de34	cpu_usage	gauge	8.000000	{}	2025-08-30 20:37:22.847+00
b9aeaf7b-28fd-4ddb-a290-d65bdce57c56	memory_usage	gauge	65.940000	{}	2025-08-30 20:37:22.847+00
547b02e0-675d-4ac9-ab77-c900df21ed70	disk_usage	gauge	45.200000	{}	2025-08-30 20:37:22.847+00
eb078abf-ac46-4377-b258-b94abd7c0cee	uptime	gauge	1268.667365	{}	2025-08-30 20:37:22.847+00
51e7920c-258e-4537-8785-995c8e4d75ac	cpu_usage	gauge	8.000000	{}	2025-08-30 20:38:22.848+00
c986739e-b046-4082-811f-e0f0c54e52f3	memory_usage	gauge	65.890000	{}	2025-08-30 20:38:22.848+00
1d65696c-129e-42a5-b013-9d54780f0cf7	disk_usage	gauge	45.200000	{}	2025-08-30 20:38:22.848+00
bbea1e25-eaa7-428e-9865-1e7816a0caad	uptime	gauge	1328.668484	{}	2025-08-30 20:38:22.848+00
6360657b-ec44-43e9-a3e7-4e40e5e77283	cpu_usage	gauge	8.000000	{}	2025-08-30 20:39:22.848+00
e5e7956c-42cf-4cda-b800-ed5c8aae079d	memory_usage	gauge	66.050000	{}	2025-08-30 20:39:22.848+00
d6da8794-ecff-4d39-9fa3-37b96e856975	disk_usage	gauge	45.200000	{}	2025-08-30 20:39:22.848+00
aa4502f6-459c-4b20-aba4-a05c9aa96330	uptime	gauge	1388.668576	{}	2025-08-30 20:39:22.848+00
03ed3cc1-3f75-4891-95cb-fbae5a749208	cpu_usage	gauge	8.000000	{}	2025-08-30 20:40:22.849+00
edda9b4d-5af9-4907-a1c9-34ab247e1eba	memory_usage	gauge	65.860000	{}	2025-08-30 20:40:22.849+00
1e6cf2b3-e07d-4cf4-83a9-1d3f6fc01f6c	disk_usage	gauge	45.200000	{}	2025-08-30 20:40:22.849+00
9600ca55-7c29-4734-b657-c88139c238dd	uptime	gauge	1448.669160	{}	2025-08-30 20:40:22.849+00
6623e190-03ae-4d62-a564-3fb9d6cfaf3c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:41:22.849+00
f9b5b43a-45eb-4176-96bf-22d19c7fc3d9	memory_usage	gauge	65.350000	{}	2025-08-30 20:41:22.849+00
95be0829-f335-407f-bc47-a1631cabc6dc	disk_usage	gauge	45.200000	{}	2025-08-30 20:41:22.849+00
3a607a9c-71aa-44f5-ac5b-a288756a2343	uptime	gauge	1508.669147	{}	2025-08-30 20:41:22.849+00
84a59b6d-5c98-4361-8587-6d1f7c788eae	cpu_usage	gauge	8.000000	{}	2025-08-30 20:42:22.85+00
4002cc27-aad7-4de4-af98-f1e2ba04eb6b	memory_usage	gauge	65.480000	{}	2025-08-30 20:42:22.85+00
cddd54b5-b881-4086-a67a-e0aaaf864ead	disk_usage	gauge	45.200000	{}	2025-08-30 20:42:22.851+00
f5a77b86-cbba-49d4-a6e9-e0b2cbb07027	uptime	gauge	1568.670986	{}	2025-08-30 20:42:22.851+00
4d228ebf-4452-4f6f-8568-1c26db973a1a	cpu_usage	gauge	8.000000	{}	2025-08-30 20:43:22.851+00
009b97b5-25a2-47d2-9f7c-7b31fba981d8	memory_usage	gauge	65.730000	{}	2025-08-30 20:43:22.851+00
f2eb99e3-8b2e-4add-b351-e48c4d73c490	disk_usage	gauge	45.200000	{}	2025-08-30 20:43:22.851+00
c5a66c63-c3f0-473f-b1a6-9c153d260b0c	uptime	gauge	1628.671785	{}	2025-08-30 20:43:22.851+00
9cea6493-b5fa-4475-a5a8-ece3536aa0c9	cpu_usage	gauge	8.000000	{}	2025-08-30 20:44:22.852+00
34640804-36ce-4de3-adee-37612db5f2a7	memory_usage	gauge	65.880000	{}	2025-08-30 20:44:22.853+00
63602446-e305-4bed-ac93-46bfe3e1fbfe	disk_usage	gauge	45.200000	{}	2025-08-30 20:44:22.853+00
4909d3bf-f121-4847-af98-e8bf8fbe4ee1	uptime	gauge	1688.673027	{}	2025-08-30 20:44:22.853+00
632566d2-39c3-4305-b678-27885f07a96b	cpu_usage	gauge	8.000000	{}	2025-08-30 20:45:22.853+00
f4b3191b-94f8-46e0-8f42-a07dcb92fa1a	memory_usage	gauge	65.540000	{}	2025-08-30 20:45:22.853+00
4e803c54-a745-40d0-8c7d-18fcef093303	disk_usage	gauge	45.200000	{}	2025-08-30 20:45:22.853+00
93ad2b69-ff79-471f-b6b1-db23590b1d1f	uptime	gauge	1748.673665	{}	2025-08-30 20:45:22.853+00
ffca9106-533b-4489-bdf4-d8a904b91075	cpu_usage	gauge	8.000000	{}	2025-08-30 20:46:22.854+00
51993ae1-7fa6-4af4-b9c7-3dd400595d82	memory_usage	gauge	65.670000	{}	2025-08-30 20:46:22.854+00
8daf1acc-f60a-45d4-9135-8eb619f86d99	disk_usage	gauge	45.200000	{}	2025-08-30 20:46:22.854+00
ab56ccae-9337-41ab-ab74-861c27a8a25f	uptime	gauge	1808.674884	{}	2025-08-30 20:46:22.854+00
4ca8aa68-98de-4efb-9587-94f3ba66ad5c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:47:22.855+00
76267c3a-6aba-44fa-857e-885f56a6abd8	memory_usage	gauge	65.460000	{}	2025-08-30 20:47:22.855+00
f9820ff1-bb3f-4ed2-a434-59649696c3bb	disk_usage	gauge	45.200000	{}	2025-08-30 20:47:22.855+00
b6286458-5196-42b2-ad36-9a8b784cf4cf	uptime	gauge	1868.675266	{}	2025-08-30 20:47:22.855+00
79b53ecb-1e96-4076-ac99-bacbe0cc7f95	cpu_usage	gauge	8.000000	{}	2025-08-30 20:48:22.856+00
65d59d2d-44bd-4f27-bfad-676f4f9a36f2	memory_usage	gauge	65.730000	{}	2025-08-30 20:48:22.856+00
b9d6a895-6d34-40c2-8474-9e42fc2082d2	disk_usage	gauge	45.200000	{}	2025-08-30 20:48:22.856+00
851ddd8d-c82f-491e-9cc4-4c3715bc61ab	uptime	gauge	1928.676079	{}	2025-08-30 20:48:22.856+00
c5b7f335-7018-4cee-af6b-fe7dbc0748ce	memory_usage	gauge	65.700000	{}	2025-08-30 20:49:22.857+00
d04a4fc0-eca1-49f9-b0d6-da4adf7f1eaf	cpu_usage	gauge	8.000000	{}	2025-08-30 20:49:22.857+00
1b640dda-6e50-4a52-a519-f4974041a5bd	uptime	gauge	1988.677968	{}	2025-08-30 20:49:22.858+00
7b0d66d8-9515-45d6-a3c9-519c8cff6e09	disk_usage	gauge	45.200000	{}	2025-08-30 20:49:22.858+00
d4301fc6-3577-4c08-9625-03dec8b57c07	cpu_usage	gauge	8.000000	{}	2025-08-30 20:50:22.857+00
c5e636a8-4fad-405d-8e37-5c88b66585a3	memory_usage	gauge	65.650000	{}	2025-08-30 20:50:22.857+00
714a2646-6167-44c1-9a2b-bcdcd1bc0a02	disk_usage	gauge	45.200000	{}	2025-08-30 20:50:22.857+00
e6613a01-1a60-4b7d-ac16-a7796d22189b	uptime	gauge	2048.677662	{}	2025-08-30 20:50:22.857+00
3c4d7b57-1d3d-4812-9e0c-9fa11a9f0689	cpu_usage	gauge	8.000000	{}	2025-08-30 20:51:22.857+00
ed10a6c8-2804-49ef-866b-17079e02c41a	memory_usage	gauge	65.810000	{}	2025-08-30 20:51:22.857+00
f763d7f3-f28e-4b9a-9781-82b094e805f3	disk_usage	gauge	45.200000	{}	2025-08-30 20:51:22.857+00
6371daea-6988-4473-ad27-9fa0b128c0c7	memory_usage	gauge	65.770000	{}	2025-08-30 20:52:22.858+00
e72ab7eb-f878-46b5-93bd-1959982ebc2b	memory_usage	gauge	65.750000	{}	2025-08-30 20:53:22.859+00
1ea91121-0604-49cb-8f99-d53765d2d63a	cpu_usage	gauge	8.000000	{}	2025-08-30 20:54:22.859+00
73e45d42-af27-4e86-8278-409f7831b4ac	uptime	gauge	2348.680335	{}	2025-08-30 20:55:22.86+00
7d6c5b5f-6414-4353-a23a-00a41fece36a	cpu_usage	gauge	8.000000	{}	2025-08-30 20:56:22.86+00
38704237-d8e0-46b8-b912-dadb211e39ed	uptime	gauge	2468.680130	{}	2025-08-30 20:57:22.86+00
24f59da5-ae92-474e-8318-f55ca7adb41e	memory_usage	gauge	66.140000	{}	2025-08-30 20:58:22.86+00
94a40a7d-cd43-42a8-a692-fa51ef776460	disk_usage	gauge	45.200000	{}	2025-08-30 20:59:22.86+00
a05e94c3-5038-4c5c-9096-f450257cde6d	cpu_usage	gauge	8.000000	{}	2025-08-30 21:00:22.861+00
d9b4ec69-9a3b-4d98-9a99-95339f7877f3	uptime	gauge	2708.682822	{}	2025-08-30 21:01:22.862+00
be092e62-12b5-45be-942a-54058a93c031	cpu_usage	gauge	8.000000	{}	2025-08-30 21:02:22.864+00
ab8e450f-ec27-4a17-b074-2e30bdbffdf1	uptime	gauge	2828.684942	{}	2025-08-30 21:03:22.865+00
4b783e70-e783-4ebb-b71f-242a62b66bf9	cpu_usage	gauge	8.000000	{}	2025-08-30 21:04:22.867+00
3c894fca-4a25-473f-8088-408735889dcc	uptime	gauge	2948.686625	{}	2025-08-30 21:05:22.866+00
1d14ff75-8c5c-4b87-868c-f72ea459db11	cpu_usage	gauge	8.000000	{}	2025-08-30 21:06:22.867+00
082dfca0-4cab-4d79-b584-a77b1894dcd7	uptime	gauge	3068.688612	{}	2025-08-30 21:07:22.868+00
7527747f-b6a9-4ea1-b17a-7b6b2a645d86	disk_usage	gauge	45.200000	{}	2025-08-30 21:08:22.869+00
f5f795bf-6930-44ed-a072-511b564a9368	disk_usage	gauge	45.200000	{}	2025-08-30 21:09:22.869+00
866f0a3d-dba8-4468-8c72-e99855ab0b6c	uptime	gauge	7509.308250	{}	2025-08-31 00:38:38.449+00
db7d524e-e853-40ef-b9b2-1e395b3abcb5	disk_usage	gauge	45.200000	{}	2025-08-31 00:39:38.45+00
67ea4263-6860-4563-a305-b79773963ab4	cpu_usage	gauge	8.000000	{}	2025-08-31 00:40:38.45+00
e891e002-4c79-4ab3-a27e-ff8050db6c83	uptime	gauge	7689.309435	{}	2025-08-31 00:41:38.45+00
0805ff65-125e-41cd-99b6-cd2bb563518a	disk_usage	gauge	45.200000	{}	2025-08-31 00:42:38.45+00
b8ee7c1f-2c3f-4d09-9182-b8a01ef1bca7	disk_usage	gauge	45.200000	{}	2025-08-31 00:43:38.45+00
ebebf3a0-e3ab-4158-b8a2-bf12ca104a5e	uptime	gauge	189.955374	{}	2025-08-31 00:55:49.569+00
c3e13c3b-d80b-4c90-b030-f2b877dbcc2f	disk_usage	gauge	45.200000	{}	2025-08-31 00:56:49.569+00
f2974797-404f-4b92-b270-47b27e5332e7	memory_usage	gauge	81.330000	{}	2025-08-31 00:57:49.569+00
c913242e-2f96-47dc-bcae-c45e58f7db5f	memory_usage	gauge	80.010000	{}	2025-08-31 00:58:49.569+00
4960e819-7728-4a70-bec3-6e3ce7b26f6a	cpu_usage	gauge	8.000000	{}	2025-08-31 00:59:49.57+00
5cab57f0-c319-45e9-849b-1a0315f2dc49	disk_usage	gauge	45.200000	{}	2025-08-31 01:41:01.633+00
20556e41-8310-412d-8097-cfd6535f58dd	disk_usage	gauge	45.200000	{}	2025-08-30 20:52:22.858+00
19174ba7-1272-402e-9d96-dbde9383d300	cpu_usage	gauge	8.000000	{}	2025-08-30 20:53:22.859+00
25b34b40-5bf4-4caa-ba8d-f5349e99997e	uptime	gauge	2288.679702	{}	2025-08-30 20:54:22.859+00
56e28cdd-8cf7-425e-a205-ae233e9bae5d	memory_usage	gauge	65.930000	{}	2025-08-30 20:55:22.86+00
7e452868-7d57-440d-8428-5a4a91259358	memory_usage	gauge	66.080000	{}	2025-08-30 20:56:22.86+00
62e036e7-4d30-4562-8443-39f2e6dcc48e	cpu_usage	gauge	8.000000	{}	2025-08-30 20:57:22.86+00
99106e23-0cab-46a1-8d74-81407ddd63f0	uptime	gauge	2528.680870	{}	2025-08-30 20:58:22.86+00
a397c459-366a-4ce9-8221-55ff13059e6f	memory_usage	gauge	66.320000	{}	2025-08-30 20:59:22.86+00
3b912cb4-24e6-4e07-9a7a-f91e488b04ea	disk_usage	gauge	45.200000	{}	2025-08-30 21:00:22.862+00
c31be96b-7f0a-4442-a2f9-c7e44a83706e	cpu_usage	gauge	8.000000	{}	2025-08-30 21:01:22.862+00
d57d6f37-bf9c-475a-9a35-cf6ba0731fb0	uptime	gauge	2768.684593	{}	2025-08-30 21:02:22.864+00
804206ed-97a2-4921-ab6f-e6e38567ceba	cpu_usage	gauge	8.000000	{}	2025-08-30 21:03:22.864+00
d8393d37-4af4-4e7c-896c-522c9a59da59	uptime	gauge	2888.687342	{}	2025-08-30 21:04:22.867+00
5eb3236d-4173-4f1e-a7fc-7245ef837360	disk_usage	gauge	45.200000	{}	2025-08-30 21:05:22.866+00
ed63ca2b-de7f-4cb7-8c62-636473666ec5	disk_usage	gauge	45.200000	{}	2025-08-30 21:06:22.867+00
4ebcef2c-f586-4e50-b841-f64aecd3667c	memory_usage	gauge	66.210000	{}	2025-08-30 21:07:22.868+00
b0878ee9-2882-4588-844f-b2394558e879	cpu_usage	gauge	8.000000	{}	2025-08-30 21:08:22.868+00
aa9a0365-9b83-4e65-964c-bfeef319b91d	uptime	gauge	3188.689470	{}	2025-08-30 21:09:22.869+00
a3e4b0ee-2764-459b-ae10-42ba29b2897d	cpu_usage	gauge	8.000000	{}	2025-08-30 22:34:38.388+00
5deed1a1-1fa8-4f06-a08c-ccda08e56a67	memory_usage	gauge	67.460000	{}	2025-08-30 22:37:38.387+00
35496b61-6c8d-4f17-884e-c352970d84a3	disk_usage	gauge	45.200000	{}	2025-08-30 22:38:38.388+00
ee614f6b-765d-4623-99cf-b8ba775b67c5	uptime	gauge	369.247374	{}	2025-08-30 22:39:38.388+00
e7ff464b-76eb-41da-990b-c619bd84a5db	cpu_usage	gauge	8.000000	{}	2025-08-30 22:40:38.389+00
582a4eee-060c-48c3-bebc-fb18d064a904	uptime	gauge	489.249070	{}	2025-08-30 22:41:38.39+00
4138cc18-d5bf-424d-b124-54e399e0c908	disk_usage	gauge	45.200000	{}	2025-08-30 22:42:38.391+00
bfad809d-1d20-42ec-828d-dce0a3300d69	memory_usage	gauge	66.490000	{}	2025-08-30 22:43:38.392+00
b4c346c9-6d2c-4130-8c9b-1e0436fadab3	uptime	gauge	669.252131	{}	2025-08-30 22:44:38.393+00
cdea9ec9-ecc9-4d56-967b-2c9e76c77ac0	cpu_usage	gauge	8.000000	{}	2025-08-30 22:45:38.393+00
74194ab4-b71a-43dc-900f-3121640e8b62	uptime	gauge	789.252810	{}	2025-08-30 22:46:38.393+00
47a7b4bd-59ba-4b04-a477-4dddc0cf54f5	disk_usage	gauge	45.200000	{}	2025-08-30 22:47:38.394+00
4b2620b9-d500-41a6-9632-0593d9eca600	cpu_usage	gauge	8.000000	{}	2025-08-30 22:48:38.394+00
389b5841-dfc2-4a54-95c8-7f1d7e3d42d2	uptime	gauge	969.253712	{}	2025-08-30 22:49:38.394+00
5737aba7-7142-49a7-a6db-ddfc61bbf669	memory_usage	gauge	70.620000	{}	2025-08-30 22:50:38.395+00
f2a0be50-1591-43fb-80b6-979953013ece	uptime	gauge	1089.254962	{}	2025-08-30 22:51:38.396+00
1c2ef221-453b-4a11-826c-84d17773f1ac	disk_usage	gauge	45.200000	{}	2025-08-30 22:52:38.396+00
7f3f25bf-1d21-4ba6-93c7-de8ac4f7aa72	cpu_usage	gauge	8.000000	{}	2025-08-30 22:53:38.396+00
b795f665-423f-4040-af1a-144580c5748b	disk_usage	gauge	45.200000	{}	2025-08-30 22:54:38.397+00
df299823-cdbb-4eac-b4e6-adcb8354c309	disk_usage	gauge	45.200000	{}	2025-08-30 22:55:38.397+00
f4a1125b-ee17-4823-8193-2ce12efd1256	cpu_usage	gauge	8.000000	{}	2025-08-30 22:56:38.397+00
26c4a0a7-e082-4fcf-8f6a-4c078dd8ccc7	uptime	gauge	1449.256974	{}	2025-08-30 22:57:38.398+00
0b4de8e5-7b19-4767-8548-381f27355bd1	memory_usage	gauge	80.750000	{}	2025-08-30 22:58:38.397+00
d2659727-0be4-4b80-867c-8b5d6f3023af	memory_usage	gauge	82.800000	{}	2025-08-31 00:10:38.434+00
e0fed11c-4d4a-4091-a896-a7b8f2a7e628	disk_usage	gauge	45.200000	{}	2025-08-31 00:11:38.436+00
94edae9b-5c24-48ed-9bf9-0c6ab4faf536	disk_usage	gauge	45.200000	{}	2025-08-31 00:12:38.437+00
1d2729b0-0684-4e00-8710-790d1f4018a3	memory_usage	gauge	82.600000	{}	2025-08-31 00:13:38.438+00
113dc56f-7af4-42e1-b713-192019aec65b	disk_usage	gauge	45.200000	{}	2025-08-31 00:14:38.439+00
2363afa4-33d7-4d05-8bda-a16de57e3df4	cpu_usage	gauge	8.000000	{}	2025-08-31 00:15:38.439+00
927f7a0e-fe82-4271-a3ef-9132555b3a2e	uptime	gauge	6189.299838	{}	2025-08-31 00:16:38.44+00
2153d235-6c77-4a50-ad62-ed8ac775b2b7	cpu_usage	gauge	8.000000	{}	2025-08-31 00:17:38.44+00
87b074c8-7fe7-42ec-8911-79232d8c7fac	cpu_usage	gauge	8.000000	{}	2025-08-31 00:18:38.44+00
7f513833-ba5b-436e-a6f4-c15933a9cad5	disk_usage	gauge	45.200000	{}	2025-08-31 00:19:38.442+00
e51f778c-9b42-4dea-8897-21ba5876b003	memory_usage	gauge	83.900000	{}	2025-08-31 00:20:38.442+00
700dc3e6-f28b-4ff8-bd63-076090a7f0e5	cpu_usage	gauge	8.000000	{}	2025-08-31 00:21:38.442+00
c7204bce-0e49-45ac-b3c1-173f715d528f	disk_usage	gauge	45.200000	{}	2025-08-31 00:22:38.442+00
b22520c9-eb39-4c30-ab66-9367c778802c	cpu_usage	gauge	8.000000	{}	2025-08-31 00:23:38.442+00
1c8bf5da-d8ff-4f97-92bd-bd14a799249f	disk_usage	gauge	45.200000	{}	2025-08-31 00:24:38.442+00
939bc3e2-ebab-4f15-8112-7e0d08393b92	cpu_usage	gauge	8.000000	{}	2025-08-31 00:25:38.442+00
c6e80089-bb4b-440e-8633-97fab5a81807	cpu_usage	gauge	8.000000	{}	2025-08-31 00:50:04.827+00
a7e922ae-aa41-4ec5-acb1-35c0121e9c6c	memory_usage	gauge	81.220000	{}	2025-08-31 00:50:04.827+00
b18a98ff-9602-4efd-9c4b-df6bddc0c75a	disk_usage	gauge	45.200000	{}	2025-08-31 00:50:04.827+00
647c39c1-bd5d-416a-a40b-b1ec021c38b4	uptime	gauge	68.346836	{}	2025-08-31 00:50:04.828+00
ebc6c6ba-fe6b-4cea-b0f3-f2f74ee2041f	uptime	gauge	128.346534	{}	2025-08-31 00:51:04.827+00
a9911f02-ac39-4c2e-88e1-9db0179a7e76	uptime	gauge	188.345953	{}	2025-08-31 00:52:04.827+00
9ee6c91f-2dbd-4236-bf6c-0d2325740294	uptime	gauge	428.361964	{}	2025-08-31 00:56:04.843+00
15d774aa-3e50-40ff-a6ad-a8d173af1044	disk_usage	gauge	45.200000	{}	2025-08-31 00:57:04.842+00
69511753-88cf-4700-8bf6-809258942406	disk_usage	gauge	45.200000	{}	2025-08-31 00:58:04.842+00
afdea935-4ab1-454e-b30e-60a652cff865	memory_usage	gauge	79.990000	{}	2025-08-31 00:59:04.843+00
c125fc11-4e1b-4f5d-8033-d821bf1a53de	uptime	gauge	668.363670	{}	2025-08-31 01:00:04.844+00
899134a9-fdf8-4103-8139-9ff92552849e	memory_usage	gauge	79.420000	{}	2025-08-31 01:41:01.633+00
7d7ec274-511e-484f-bdf9-6f34a28b72a7	uptime	gauge	2168.678168	{}	2025-08-30 20:52:22.858+00
db28d58f-6555-4f97-b2bd-3e73f75cf6a4	disk_usage	gauge	45.200000	{}	2025-08-30 20:53:22.859+00
b6904fde-a582-4d71-824e-cf195c7c53c1	disk_usage	gauge	45.200000	{}	2025-08-30 20:54:22.859+00
cfccfaf5-e1f7-439d-9d1a-dde5453b617c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:55:22.86+00
843ce41c-0659-401b-a34b-d1b45ab86c7e	uptime	gauge	2408.681899	{}	2025-08-30 20:56:22.861+00
b020290a-0145-4b49-ace2-8e1ad6fae256	memory_usage	gauge	66.010000	{}	2025-08-30 20:57:22.86+00
9569f721-af3c-4691-a75c-2de0165d535c	cpu_usage	gauge	8.000000	{}	2025-08-30 20:58:22.86+00
c67bad77-d81a-45f5-b386-be5a61b2a289	uptime	gauge	2588.680512	{}	2025-08-30 20:59:22.86+00
770b967b-b915-4b70-b52f-9ab8c78e8d93	memory_usage	gauge	66.030000	{}	2025-08-30 21:00:22.861+00
101deabb-08c8-45b6-a274-9dcdc76067d4	memory_usage	gauge	66.290000	{}	2025-08-30 21:01:22.862+00
93f380ac-01ec-40cd-a4ae-c3737fc79815	memory_usage	gauge	66.450000	{}	2025-08-30 21:02:22.864+00
88685b5a-58ca-4071-be1d-cef9a9a5436b	memory_usage	gauge	66.240000	{}	2025-08-30 21:03:22.864+00
d24e2a1c-0d3c-4051-af13-6275703f9f87	memory_usage	gauge	66.290000	{}	2025-08-30 21:04:22.867+00
2aff111a-f5ff-4b11-9845-cd7aa3afd411	cpu_usage	gauge	8.000000	{}	2025-08-30 21:05:22.866+00
49f6f554-ffe1-4635-9073-d2de1443d5c7	uptime	gauge	3008.687888	{}	2025-08-30 21:06:22.867+00
00c5872f-c5b0-4728-989a-73e398b38c90	cpu_usage	gauge	8.000000	{}	2025-08-30 21:07:22.868+00
6909957a-8013-4862-b3e3-83df4ccfc4f9	uptime	gauge	3128.689051	{}	2025-08-30 21:08:22.869+00
1df89264-3235-481a-b04f-4711274b4d41	memory_usage	gauge	65.870000	{}	2025-08-30 21:09:22.869+00
ce3d2dbb-9d3c-41e4-9d21-71b649ab0106	disk_usage	gauge	45.200000	{}	2025-08-30 22:34:38.388+00
aadd8aae-65ef-40d6-8613-9fe25c9e317c	disk_usage	gauge	45.200000	{}	2025-08-30 22:37:38.388+00
7d0ca6b6-723d-4f40-921e-e4af13b19482	memory_usage	gauge	83.810000	{}	2025-08-31 00:26:38.443+00
d21ede81-b27a-45bd-95de-30d47458044b	uptime	gauge	6849.302083	{}	2025-08-31 00:27:38.443+00
a9ee4052-aa69-4dab-8d0c-262850337330	disk_usage	gauge	45.200000	{}	2025-08-31 00:28:38.443+00
3a86bbb5-f9f2-4c27-967f-f9c944810faf	memory_usage	gauge	85.220000	{}	2025-08-31 00:29:38.444+00
ef2ef887-5c7d-4835-b509-cdbb5ac3c068	uptime	gauge	7029.304945	{}	2025-08-31 00:30:38.446+00
3bff7646-6dfc-4b4a-97c2-4ca714419206	memory_usage	gauge	83.940000	{}	2025-08-31 00:31:38.447+00
9997b6f9-b9c8-470a-bc7b-346f03239623	disk_usage	gauge	45.200000	{}	2025-08-31 00:32:38.448+00
46cbfe42-f8e0-45c2-9899-8eb40377f5a3	memory_usage	gauge	83.950000	{}	2025-08-31 00:33:38.448+00
b60e30f0-f1a3-4a20-90db-749cdab3fa88	disk_usage	gauge	45.200000	{}	2025-08-31 00:34:38.448+00
ebd7faff-c9e7-4ff2-bb05-196d6b165deb	memory_usage	gauge	84.360000	{}	2025-08-31 00:35:38.448+00
7294e9e5-20f7-4e14-a655-867834403e76	uptime	gauge	7389.307934	{}	2025-08-31 00:36:38.449+00
a1db9e33-01db-4301-b8ce-baf7c6c4583a	disk_usage	gauge	45.200000	{}	2025-08-31 00:37:38.448+00
a63674be-9b7e-4a13-85c4-8ec4b78c9a70	cpu_usage	gauge	8.000000	{}	2025-08-31 00:50:32.773+00
682d1320-121c-4a12-bcb8-6f6fe35c2918	memory_usage	gauge	81.660000	{}	2025-08-31 00:50:32.773+00
d07bf6e9-0127-4abd-9853-6d3cb87862e5	disk_usage	gauge	45.200000	{}	2025-08-31 00:50:32.773+00
78b7ef5f-2ed2-4257-bfb2-ed5491abea60	uptime	gauge	69.888534	{}	2025-08-31 00:50:32.773+00
a88c351e-b803-4662-8739-a27de731cf52	uptime	gauge	129.889075	{}	2025-08-31 00:51:32.774+00
961243a4-777f-4e7a-ad7e-78d50d4d685d	disk_usage	gauge	45.200000	{}	2025-08-31 00:52:32.773+00
b8c92b4a-001a-458f-859e-4896b0ed0361	cpu_usage	gauge	8.000000	{}	2025-08-31 01:01:23.206+00
3e73044d-ec51-4fc6-be01-7d1fea7e1e9f	memory_usage	gauge	79.790000	{}	2025-08-31 01:01:23.206+00
444d2641-3663-453d-9013-eeb8b58e3257	disk_usage	gauge	45.200000	{}	2025-08-31 01:01:23.207+00
efa5f293-afc2-4918-b10d-fe7ccae0ce58	uptime	gauge	70.163008	{}	2025-08-31 01:01:23.207+00
fb9b735a-7617-432c-9c7d-dbfa0fefc959	uptime	gauge	668.248358	{}	2025-08-31 01:41:01.633+00
575615c9-d108-4ee3-8380-7001436032fa	cpu_usage	gauge	8.000000	{}	2025-08-30 21:10:22.87+00
44237085-5b89-443b-b807-f38e8c9cd731	uptime	gauge	3308.691638	{}	2025-08-30 21:11:22.871+00
c45e71d9-3d3f-4c09-b92f-8d65383af235	cpu_usage	gauge	8.000000	{}	2025-08-30 21:12:22.871+00
bb26bc24-2f35-4d05-8b80-9a6fcf72ec6f	uptime	gauge	3428.692044	{}	2025-08-30 21:13:22.872+00
d13f1f52-f168-4f89-b1a5-17e3b7fe4a7d	cpu_usage	gauge	8.000000	{}	2025-08-30 21:14:22.871+00
3f3256b1-d92c-4a9c-bd48-7e24f42c0851	uptime	gauge	3548.692206	{}	2025-08-30 21:15:22.872+00
8df94851-1ab4-4e3b-931c-782cd36b43a3	disk_usage	gauge	45.200000	{}	2025-08-30 21:16:22.873+00
e5f73eb5-e5d0-43aa-8692-2116b419d84e	memory_usage	gauge	65.950000	{}	2025-08-30 21:17:22.874+00
840ac147-a4ef-474f-a35d-0e912c2758b9	memory_usage	gauge	66.110000	{}	2025-08-30 21:18:22.876+00
fb9e7d0a-693b-4153-b596-349d84834dda	memory_usage	gauge	66.220000	{}	2025-08-30 21:19:22.878+00
40111c98-52b3-45dc-b447-67a48238f263	disk_usage	gauge	45.200000	{}	2025-08-30 21:20:22.879+00
8d651201-bc37-4c95-9ec2-329ac29cf762	disk_usage	gauge	45.200000	{}	2025-08-30 21:21:22.879+00
90574f9d-4c5e-4152-bb12-5b99656d0ae5	cpu_usage	gauge	8.000000	{}	2025-08-30 21:22:22.878+00
dfe634f9-eb06-43ed-8113-daf11257e444	uptime	gauge	4028.699798	{}	2025-08-30 21:23:22.879+00
5f849bdb-83ac-4a0e-adb1-25de9abd7fff	cpu_usage	gauge	8.000000	{}	2025-08-30 21:24:22.88+00
115ef85a-79fa-4437-b958-a9830cfbc310	uptime	gauge	4148.701586	{}	2025-08-30 21:25:22.881+00
6ce61cd6-23da-47b7-b096-832fd4d57dd6	cpu_usage	gauge	8.000000	{}	2025-08-30 21:26:22.882+00
cb3fa5b0-8c05-4394-9f92-6e1476617b9f	cpu_usage	gauge	8.000000	{}	2025-08-30 21:27:22.883+00
63d625b2-6f6b-4366-bae4-c81158f99e54	uptime	gauge	4328.704485	{}	2025-08-30 21:28:22.884+00
80b9f009-be78-4153-b0e1-e4128109efc5	memory_usage	gauge	66.290000	{}	2025-08-30 21:29:22.885+00
c3df1e75-5079-4de3-8be3-d11158d52825	memory_usage	gauge	66.340000	{}	2025-08-30 21:30:22.885+00
9cbd6d5e-31e1-4e94-9af4-110869749180	memory_usage	gauge	66.560000	{}	2025-08-30 21:31:22.886+00
f8efc8b1-1b7c-40b1-9e73-b229e7cad6dc	disk_usage	gauge	45.200000	{}	2025-08-30 21:32:22.887+00
9cf7350d-0850-441a-9561-5cdc53dc6048	memory_usage	gauge	66.630000	{}	2025-08-30 22:34:38.388+00
a52e1eda-de99-43a9-8f09-dc8a7b2a039c	uptime	gauge	189.246393	{}	2025-08-30 22:36:38.387+00
cb882093-2da3-4f42-acee-1f979d6cc831	disk_usage	gauge	45.200000	{}	2025-08-31 00:26:38.443+00
93773f95-b26d-4641-9b90-285833b50ee4	memory_usage	gauge	83.780000	{}	2025-08-31 00:27:38.443+00
1bbcf100-879b-4656-aa6e-d2ef01aa8e8d	cpu_usage	gauge	8.000000	{}	2025-08-31 00:28:38.443+00
5bd79222-9d6d-4caf-91ae-f7ce99804cfc	cpu_usage	gauge	8.000000	{}	2025-08-31 00:29:38.444+00
e9e4bfe6-3d1f-4b8e-b4b2-0c65fa4e641f	memory_usage	gauge	84.020000	{}	2025-08-31 00:30:38.446+00
4de9b7d0-15eb-486c-8589-8bf8aaed7760	uptime	gauge	7089.306331	{}	2025-08-31 00:31:38.447+00
ced60389-4613-4430-b9ef-f3cc69d6b07b	cpu_usage	gauge	8.000000	{}	2025-08-31 00:32:38.448+00
8c7a765c-b159-47ec-8f36-372292aeb209	disk_usage	gauge	45.200000	{}	2025-08-31 00:33:38.448+00
983870dc-6a91-42a3-b4c2-61b002ed766c	cpu_usage	gauge	8.000000	{}	2025-08-31 00:34:38.448+00
ec1c198a-13de-4515-b082-688ce315389c	cpu_usage	gauge	8.000000	{}	2025-08-31 00:35:38.448+00
e5cd746e-c0d2-46bf-af92-500b46568512	memory_usage	gauge	84.030000	{}	2025-08-31 00:36:38.449+00
e12aa843-616f-4622-a993-9f85f448a2d5	memory_usage	gauge	83.960000	{}	2025-08-31 00:37:38.448+00
d0e5fc9f-3f38-4c51-8918-1bcbec034912	cpu_usage	gauge	8.000000	{}	2025-08-31 00:51:04.827+00
58f1daed-46c3-4bbb-982e-2b90fdf39e98	cpu_usage	gauge	8.000000	{}	2025-08-31 00:52:04.826+00
2fb5b755-897c-4aea-aa93-7ae7b13b6b5e	cpu_usage	gauge	8.000000	{}	2025-08-31 01:09:25.277+00
931ec846-2e0a-4991-ac74-50d84e1c4c08	cpu_usage	gauge	8.000000	{}	2025-08-31 01:43:13.118+00
47ad33a1-ec71-4a0c-8b62-907e585f033b	memory_usage	gauge	80.480000	{}	2025-08-31 01:43:13.118+00
da0444e5-28f9-40a5-b159-5d98ca3ab714	disk_usage	gauge	45.200000	{}	2025-08-31 01:43:13.118+00
9d548f10-ed51-4115-b05d-90b3add9e1c4	uptime	gauge	70.887681	{}	2025-08-31 01:43:13.118+00
f1eb2fc1-0def-4a7c-8612-704b12bae543	uptime	gauge	130.886995	{}	2025-08-31 01:44:13.117+00
15314bcf-c766-495d-b553-ad612115cfbe	memory_usage	gauge	79.640000	{}	2025-08-31 01:45:13.117+00
bf1ed545-f6ab-4894-889c-c4553d969046	memory_usage	gauge	79.740000	{}	2025-08-31 01:46:13.117+00
c6e76847-06d0-4e73-a66b-9e2b2f48bdc7	cpu_usage	gauge	8.000000	{}	2025-08-31 01:47:13.117+00
1ffd373d-00ad-47d2-8ab6-230203c44a7b	memory_usage	gauge	65.890000	{}	2025-08-30 21:10:22.871+00
9ae956e5-7be2-4f12-976f-1368cd4cab1d	cpu_usage	gauge	8.000000	{}	2025-08-30 21:11:22.871+00
1395eaf1-8653-4dd2-8255-2655f14f8abb	uptime	gauge	3368.691787	{}	2025-08-30 21:12:22.871+00
d3647c76-e038-469f-a3c9-fa62f16ed173	cpu_usage	gauge	8.000000	{}	2025-08-30 21:13:22.871+00
8dbcc265-52fe-4de5-82d4-6c266e74db55	uptime	gauge	3488.691831	{}	2025-08-30 21:14:22.871+00
d9dd730d-7ef5-4c22-9fd6-f4157fc5ffb1	memory_usage	gauge	65.930000	{}	2025-08-30 21:15:22.872+00
72c6dcf2-a4c8-43e6-9461-7f77f6d78677	memory_usage	gauge	66.000000	{}	2025-08-30 21:16:22.872+00
7662791d-88fc-4881-a2d5-c59fd7bdca09	cpu_usage	gauge	8.000000	{}	2025-08-30 21:17:22.874+00
15e4f409-013c-4186-9372-ce484f1e7e19	uptime	gauge	3728.696137	{}	2025-08-30 21:18:22.876+00
481ebecd-f310-44d1-ab33-6d8e6d1d9161	disk_usage	gauge	45.200000	{}	2025-08-30 21:19:22.878+00
4456f2f9-f53f-4aa1-9c20-6aa595b60c77	memory_usage	gauge	66.240000	{}	2025-08-30 21:20:22.879+00
2d4ffe14-c2bc-465c-8a14-7b62a4be75fc	cpu_usage	gauge	8.000000	{}	2025-08-30 21:21:22.879+00
07fb4df8-b71e-428b-8a5e-cf48f09b586b	uptime	gauge	3968.698974	{}	2025-08-30 21:22:22.879+00
2f074e4f-8307-41a6-af12-187eedc224ad	memory_usage	gauge	66.160000	{}	2025-08-30 21:23:22.879+00
f7fdb1fe-ab63-4f01-a8c8-3264064a9194	uptime	gauge	4088.700542	{}	2025-08-30 21:24:22.88+00
9524a9be-0100-4709-9f44-03ec11ce68dd	disk_usage	gauge	45.200000	{}	2025-08-30 21:25:22.881+00
f1fdfb76-c713-43ee-bebb-1347b8b7c92b	disk_usage	gauge	45.200000	{}	2025-08-30 21:26:22.882+00
8d4b0db8-2506-4c72-b9cb-da2e90795a0d	disk_usage	gauge	45.200000	{}	2025-08-30 21:27:22.884+00
539c0686-7c53-4e02-8af8-974bed21e740	disk_usage	gauge	45.200000	{}	2025-08-30 21:28:22.884+00
4fb45426-2463-41aa-a8b8-16e035bcb386	disk_usage	gauge	45.200000	{}	2025-08-30 21:29:22.885+00
fd37a638-ec26-468d-87ce-784a70ea2389	cpu_usage	gauge	8.000000	{}	2025-08-30 21:30:22.885+00
42b28868-924d-45e4-b340-39196d249a50	uptime	gauge	4508.706137	{}	2025-08-30 21:31:22.886+00
1c147a46-2ba5-4f69-ac20-6edc1c3fa479	memory_usage	gauge	66.110000	{}	2025-08-30 21:32:22.887+00
ff80ea79-affd-40bf-be12-cca64d9f4390	uptime	gauge	69.247189	{}	2025-08-30 22:34:38.388+00
e3970b91-4292-4052-8160-736d71eb4dfe	uptime	gauge	309.247346	{}	2025-08-30 22:38:38.388+00
bd2d229f-8a5d-4afe-8189-6788508707b8	memory_usage	gauge	68.200000	{}	2025-08-30 22:39:38.388+00
0031b1f3-3229-4f7d-ae70-e6aa5f930de1	disk_usage	gauge	45.200000	{}	2025-08-30 22:40:38.389+00
d1436af8-e71b-432e-a1b2-5db86d9281d6	cpu_usage	gauge	8.000000	{}	2025-08-30 22:41:38.39+00
065dc22e-2369-428f-a949-5d3f9cb6c216	uptime	gauge	549.250162	{}	2025-08-30 22:42:38.391+00
2872a045-2218-4905-9886-2e6f7f158122	disk_usage	gauge	45.200000	{}	2025-08-30 22:43:38.392+00
c0138cec-0c03-48ac-a354-db469d4682b0	disk_usage	gauge	45.200000	{}	2025-08-30 22:44:38.393+00
455aa214-134f-417d-8d4f-c0ef0fc21174	disk_usage	gauge	45.200000	{}	2025-08-30 22:45:38.393+00
3be81acf-70a5-4521-84a3-46066f6c0ea8	memory_usage	gauge	65.650000	{}	2025-08-30 22:46:38.393+00
0323b8ee-0d58-4a7b-bcd6-3f44532d1953	memory_usage	gauge	66.100000	{}	2025-08-30 22:47:38.394+00
cd210c64-f377-4f81-9e4e-b0fcece929ee	memory_usage	gauge	66.090000	{}	2025-08-30 22:48:38.394+00
fe3e218b-7362-448b-9f86-e03b9da14ef7	disk_usage	gauge	45.200000	{}	2025-08-30 22:49:38.394+00
db264818-0ebc-4d72-aa9f-45878ce0643e	cpu_usage	gauge	8.000000	{}	2025-08-30 22:50:38.395+00
a8f69bd9-1a52-4ca3-8a90-cbcaa007695e	cpu_usage	gauge	8.000000	{}	2025-08-31 00:26:38.443+00
391c46ca-c5d9-4d1b-8957-7ca782abeb92	cpu_usage	gauge	8.000000	{}	2025-08-31 00:27:38.443+00
cab82bc4-daff-4ade-a10c-d3eaebf14773	uptime	gauge	6909.302761	{}	2025-08-31 00:28:38.443+00
f68d8023-d76f-41fc-9658-ff546e0d45ff	disk_usage	gauge	45.200000	{}	2025-08-31 00:29:38.444+00
491fae1a-32ce-4315-8a50-c1d90d717776	cpu_usage	gauge	8.000000	{}	2025-08-31 00:30:38.445+00
ff210f95-f03c-4ff8-8aa9-c82ae24ea62c	disk_usage	gauge	45.200000	{}	2025-08-31 00:31:38.447+00
ebef0b21-0be7-46ad-9072-0dea9d546931	memory_usage	gauge	83.810000	{}	2025-08-31 00:32:38.448+00
28553751-2d76-4f98-a2b8-0f0dbacb5c2c	uptime	gauge	7209.307799	{}	2025-08-31 00:33:38.448+00
d0419fc6-3f5c-421b-8b86-41ff39441c7f	memory_usage	gauge	83.950000	{}	2025-08-31 00:34:38.448+00
bb3c519d-e8fe-4546-adf5-0633c2a37994	uptime	gauge	7329.307773	{}	2025-08-31 00:35:38.448+00
bc2afb04-9b8c-4917-a434-dd96ec5afcf3	disk_usage	gauge	45.200000	{}	2025-08-31 00:36:38.449+00
5e121ce1-d7f3-4339-8dc1-6f05b260b6e5	cpu_usage	gauge	8.000000	{}	2025-08-31 00:37:38.448+00
37562ab2-5374-414c-88cb-81a6afd0d2f0	memory_usage	gauge	81.230000	{}	2025-08-31 00:51:04.827+00
5d822f6e-7de2-43c6-b61f-967995c52aac	disk_usage	gauge	45.200000	{}	2025-08-31 00:52:04.827+00
0d23b932-920c-4f15-ab0b-fee072fd4d17	disk_usage	gauge	45.200000	{}	2025-08-31 00:53:04.827+00
dc7fdaf3-a861-405d-9e59-926618a23d48	uptime	gauge	308.361897	{}	2025-08-31 00:54:04.843+00
58b1d83b-a758-4a4e-b057-6ee83dcc1162	memory_usage	gauge	75.970000	{}	2025-08-31 01:09:25.278+00
5481cab3-0375-4c9e-b843-ab70092f2940	cpu_usage	gauge	8.000000	{}	2025-08-31 01:44:13.117+00
47667352-7e1a-4176-8611-fe041476cc6d	uptime	gauge	190.886913	{}	2025-08-31 01:45:13.117+00
92c5f8b9-84f6-4cb2-a6f4-343a9ee4f0d0	disk_usage	gauge	45.200000	{}	2025-08-31 01:46:13.117+00
7dbaf167-6caf-44ba-8ff3-729c206647e9	memory_usage	gauge	79.570000	{}	2025-08-31 01:47:13.117+00
ee4143e6-72ad-4923-84aa-a24ad1af0bb3	disk_usage	gauge	45.200000	{}	2025-08-30 21:10:22.871+00
944a6058-ebbe-45f4-b591-30e3b97f318b	memory_usage	gauge	65.670000	{}	2025-08-30 21:11:22.871+00
a42dece4-41a4-4441-90a9-e67e9e222cb7	disk_usage	gauge	45.200000	{}	2025-08-30 21:12:22.871+00
cc041d18-568e-4c01-a3b0-258b5ea8572b	memory_usage	gauge	65.770000	{}	2025-08-30 21:13:22.872+00
76ffaef1-9752-4574-9b58-94b8786c89ee	memory_usage	gauge	65.900000	{}	2025-08-30 21:14:22.871+00
6eec0d28-b569-459c-9d3e-867d41104610	disk_usage	gauge	45.200000	{}	2025-08-30 21:15:22.872+00
2a634072-f6a7-4fe9-9ab9-0377acc5771e	cpu_usage	gauge	8.000000	{}	2025-08-30 21:16:22.872+00
9e273bee-7c35-46cf-b5e4-b39609b9d057	uptime	gauge	3668.694465	{}	2025-08-30 21:17:22.874+00
c5870164-267b-4058-9b23-0da819e04c78	disk_usage	gauge	45.200000	{}	2025-08-30 21:18:22.876+00
5e775223-6f2b-4647-8463-f6341896aac5	cpu_usage	gauge	8.000000	{}	2025-08-30 21:19:22.878+00
5b6e2a75-1fc7-4f0d-87a9-e751f422ba55	uptime	gauge	3848.699300	{}	2025-08-30 21:20:22.879+00
d69b62e3-8f35-4e40-8584-6a9389dcc4db	memory_usage	gauge	66.280000	{}	2025-08-30 21:21:22.879+00
f979f73b-1eae-4c53-ae72-d244041b8112	memory_usage	gauge	65.980000	{}	2025-08-30 21:22:22.878+00
37d26bc6-72b2-4c9b-8491-0ad3c5826d68	cpu_usage	gauge	8.000000	{}	2025-08-30 21:23:22.879+00
310cd410-857d-415a-81ed-0245dd867584	memory_usage	gauge	66.230000	{}	2025-08-30 21:24:22.88+00
cffd0344-d4c8-4bf9-8896-17b7e7b959aa	cpu_usage	gauge	8.000000	{}	2025-08-30 21:25:22.881+00
91aaa662-c976-4655-8949-64535c59d00d	uptime	gauge	4208.702717	{}	2025-08-30 21:26:22.882+00
b15545b9-209b-4299-a8cd-a564ef351fee	memory_usage	gauge	66.090000	{}	2025-08-30 21:27:22.883+00
c6d3b0c7-aa61-40e0-936c-e0f47e2cba94	cpu_usage	gauge	8.000000	{}	2025-08-30 21:28:22.884+00
0aa78d59-694e-45db-91ab-f2815e1b0952	uptime	gauge	4388.705280	{}	2025-08-30 21:29:22.885+00
41d4786f-bcb4-445e-940a-9f952b23cf40	disk_usage	gauge	45.200000	{}	2025-08-30 21:30:22.885+00
e18b7057-0bef-4388-a954-aaac0ca3e034	cpu_usage	gauge	8.000000	{}	2025-08-30 21:31:22.886+00
04debee8-782a-4d78-bfad-0a8442bc07cc	uptime	gauge	4568.707135	{}	2025-08-30 21:32:22.887+00
2f28dd5b-a23f-4dc9-bde2-d3b3f449b352	cpu_usage	gauge	8.000000	{}	2025-08-30 22:35:38.387+00
8bba76e5-1c6e-44dc-869b-f66c38ac9dc0	memory_usage	gauge	68.450000	{}	2025-08-30 22:36:38.387+00
a59295a8-41bb-42f8-b7c6-6fd4c5639108	uptime	gauge	6789.302710	{}	2025-08-31 00:26:38.443+00
e987ee11-f393-4b1d-8550-0e26796de02c	disk_usage	gauge	45.200000	{}	2025-08-31 00:27:38.443+00
52911589-a6c0-454b-b3c8-e3cba38787d8	memory_usage	gauge	83.820000	{}	2025-08-31 00:28:38.443+00
5f2ee986-e4b9-4b20-b526-fad5545b0f59	uptime	gauge	6969.303539	{}	2025-08-31 00:29:38.444+00
74bad82f-e412-439f-9bdc-3bbb52ff25d5	disk_usage	gauge	45.200000	{}	2025-08-31 00:30:38.446+00
a070ccf6-0a7d-46eb-b7a3-562bd2c38023	cpu_usage	gauge	8.000000	{}	2025-08-31 00:31:38.447+00
52e99c6b-0db0-4ed3-81f2-8587f6c55334	uptime	gauge	7149.307742	{}	2025-08-31 00:32:38.448+00
65a6d3b7-47ce-4dd5-8f7b-d5de3bbf88d6	cpu_usage	gauge	8.000000	{}	2025-08-31 00:33:38.448+00
1736d80c-f65c-4c17-93a3-fd6ff51d673e	uptime	gauge	7269.307650	{}	2025-08-31 00:34:38.448+00
6ae162b6-60cf-40e8-88db-5f5562742057	disk_usage	gauge	45.200000	{}	2025-08-31 00:35:38.448+00
23b94184-3ff5-4c52-b728-37cee3de06e0	cpu_usage	gauge	8.000000	{}	2025-08-31 00:36:38.448+00
549e67cc-ac8e-4fc3-9568-fa0329f3c4a9	uptime	gauge	7449.307451	{}	2025-08-31 00:37:38.448+00
60fbf14e-6f15-47da-8ad2-516261e9a427	disk_usage	gauge	45.200000	{}	2025-08-31 00:51:04.827+00
643bd11f-0035-4acd-9352-c93fda8d9b48	memory_usage	gauge	81.130000	{}	2025-08-31 00:52:04.827+00
19df296b-e079-4fd1-98ba-ee8d5424d8e4	disk_usage	gauge	45.200000	{}	2025-08-31 01:09:25.278+00
0316d9be-6dc6-4dd2-b4e8-6c97f5f3a12b	memory_usage	gauge	81.220000	{}	2025-08-31 01:44:13.117+00
de7e9147-fce9-4f27-8af3-eec0fa9d3893	disk_usage	gauge	45.200000	{}	2025-08-31 01:45:13.117+00
4d61b8ef-9616-4edd-856e-5448330f0a57	cpu_usage	gauge	8.000000	{}	2025-08-31 01:46:13.117+00
7185f3bd-5aaa-466f-873b-48ca57519d25	uptime	gauge	310.887134	{}	2025-08-31 01:47:13.117+00
28739df4-6aba-4472-afb1-1dcd316fab84	uptime	gauge	3248.691030	{}	2025-08-30 21:10:22.871+00
071fe226-bd66-4114-a2dd-98a2c3782208	disk_usage	gauge	45.200000	{}	2025-08-30 21:11:22.871+00
df7de057-6a67-4d34-bc82-884b18a4db49	memory_usage	gauge	65.890000	{}	2025-08-30 21:12:22.871+00
62e68089-ac60-49a8-999f-06cffb15395b	disk_usage	gauge	45.200000	{}	2025-08-30 21:13:22.872+00
4e355b60-455b-47a4-aa47-9ab8a0fa7e7b	disk_usage	gauge	45.200000	{}	2025-08-30 21:14:22.871+00
396819c8-da51-4c70-a68d-cb08a1ffd246	cpu_usage	gauge	8.000000	{}	2025-08-30 21:15:22.872+00
e441cde9-e6c4-425b-8727-e38f29a5f927	uptime	gauge	3608.692943	{}	2025-08-30 21:16:22.873+00
ba554838-1a6d-45f3-93d8-b5a8212dae56	disk_usage	gauge	45.200000	{}	2025-08-30 21:17:22.874+00
0619f974-a95d-47ac-8fae-5e8c587fca55	cpu_usage	gauge	8.000000	{}	2025-08-30 21:18:22.876+00
0d2fb154-f667-4843-8374-4038b7db8c14	uptime	gauge	3788.698206	{}	2025-08-30 21:19:22.878+00
878004ee-c71c-4db1-8429-3e4f7ca7dbea	cpu_usage	gauge	8.000000	{}	2025-08-30 21:20:22.879+00
244f4bee-0fe5-4efd-9d70-5eba0a5dd7a1	uptime	gauge	3908.699611	{}	2025-08-30 21:21:22.879+00
fafba7ac-b0b3-4afa-a0eb-7cfff73f4fbc	disk_usage	gauge	45.200000	{}	2025-08-30 21:22:22.879+00
7558b6e5-46e3-4ad4-8e3a-5c61583b4412	disk_usage	gauge	45.200000	{}	2025-08-30 21:23:22.879+00
3c871c0c-7a9e-49de-a5f3-824eda3aeb93	disk_usage	gauge	45.200000	{}	2025-08-30 21:24:22.88+00
79fcb9eb-ae8b-44d0-9aa4-5da3d44995e9	memory_usage	gauge	66.050000	{}	2025-08-30 21:25:22.881+00
d935e91c-3fc7-486c-b9ab-2d9f5b9ccb08	memory_usage	gauge	66.310000	{}	2025-08-30 21:26:22.882+00
d8752830-3f42-44ed-ac11-52bb6cd96ffc	uptime	gauge	4268.703957	{}	2025-08-30 21:27:22.884+00
e4cad89a-116a-46c5-a977-48013a7f06ed	memory_usage	gauge	66.180000	{}	2025-08-30 21:28:22.884+00
ea4c1daf-b8de-467e-b477-2c928bd1f0a8	cpu_usage	gauge	8.000000	{}	2025-08-30 21:29:22.885+00
ae880eb6-6d02-461e-b347-8e68349ed931	uptime	gauge	4448.705843	{}	2025-08-30 21:30:22.885+00
ae19669e-ea24-4195-b2c0-56a3e763f1bd	disk_usage	gauge	45.200000	{}	2025-08-30 21:31:22.886+00
13da3962-ef31-4b4b-b42b-1bf96e7a103b	cpu_usage	gauge	8.000000	{}	2025-08-30 21:32:22.887+00
b306de85-b531-4c61-8951-4abe008b4e3c	memory_usage	gauge	67.440000	{}	2025-08-30 22:35:38.387+00
92eb9859-dc38-450d-a2c3-23cefe59a652	cpu_usage	gauge	8.000000	{}	2025-08-30 22:38:38.388+00
e18a6c10-23e5-444c-a956-033a1a754595	disk_usage	gauge	45.200000	{}	2025-08-30 22:39:38.388+00
51df7e5b-1ed9-4ab0-9550-3f1ace7c3aa8	memory_usage	gauge	67.110000	{}	2025-08-30 22:40:38.389+00
6cba1096-9446-4694-8092-76da26264171	disk_usage	gauge	45.200000	{}	2025-08-30 22:41:38.39+00
169a6aed-e62c-4e77-b25e-669588e52ce4	cpu_usage	gauge	8.000000	{}	2025-08-30 22:42:38.391+00
ba36d4e1-0c9a-432a-9986-c07f92eb11c6	uptime	gauge	609.251412	{}	2025-08-30 22:43:38.392+00
5dd88b59-3409-4c52-8054-aee4cf6fc026	cpu_usage	gauge	8.000000	{}	2025-08-30 22:44:38.393+00
6821a5bf-306a-4a64-bcbe-5b674fc9dd9c	uptime	gauge	729.252822	{}	2025-08-30 22:45:38.393+00
530ceb3a-5987-4cf5-9d57-0e836b5b76b2	disk_usage	gauge	45.200000	{}	2025-08-30 22:46:38.393+00
2da18fa9-644a-4b36-b580-4312702a9a25	cpu_usage	gauge	8.000000	{}	2025-08-30 22:47:38.394+00
3b5d0d40-f195-41bc-8104-79be314bccf2	uptime	gauge	909.253799	{}	2025-08-30 22:48:38.394+00
cfe75f2a-24a4-462f-bd70-a062dd67162b	cpu_usage	gauge	8.000000	{}	2025-08-30 22:49:38.394+00
c1a44985-dde5-410d-980b-2c9bbbd2c7ad	uptime	gauge	1029.254899	{}	2025-08-30 22:50:38.396+00
1e3b10e7-221e-41c7-ad01-3d5bd359e85f	cpu_usage	gauge	8.000000	{}	2025-08-31 00:51:32.773+00
2df70149-94ba-4fec-88c2-f1e3497d9aa6	uptime	gauge	189.888817	{}	2025-08-31 00:52:32.773+00
4d9f8ba7-4d86-40d2-9f52-742765aa289f	uptime	gauge	68.637489	{}	2025-08-31 01:09:25.278+00
b62ca65d-e38b-40d2-87c5-6be7ab9b9f13	disk_usage	gauge	45.200000	{}	2025-08-31 01:44:13.117+00
16729aaf-c2d5-4d0b-bb45-cdac28f36311	cpu_usage	gauge	8.000000	{}	2025-08-31 01:45:13.117+00
68a36e0b-41e9-4cef-a37a-2895208d8d61	uptime	gauge	250.886980	{}	2025-08-31 01:46:13.117+00
6a2d0620-e8cd-4c44-8c10-79513452e0e3	disk_usage	gauge	45.200000	{}	2025-08-31 01:47:13.117+00
4a16eec6-0383-474e-8777-fa7560c4dd42	cpu_usage	gauge	8.000000	{}	2025-08-30 21:33:22.887+00
47279e8f-b81c-42cb-894e-eb65c94ae4ca	uptime	gauge	4688.707778	{}	2025-08-30 21:34:22.887+00
5b118051-5111-43ac-ac85-3ab5c9061ce7	cpu_usage	gauge	8.000000	{}	2025-08-30 21:35:22.888+00
e71789fb-416b-4691-89b5-412101aa1582	uptime	gauge	4808.710102	{}	2025-08-30 21:36:22.89+00
02b66f3b-4b80-4c95-84c7-6c8af8e7329b	disk_usage	gauge	45.200000	{}	2025-08-30 21:37:22.89+00
d8865467-7465-448d-844c-fd428b7d3491	disk_usage	gauge	45.200000	{}	2025-08-30 21:38:22.891+00
9eee50b1-d1a6-4601-8bba-dadc58c8bbed	memory_usage	gauge	66.240000	{}	2025-08-30 21:39:22.892+00
4c2dc7b3-5183-4148-bb7a-9637be08aaab	disk_usage	gauge	45.200000	{}	2025-08-30 21:40:22.892+00
d060e1a2-5ba4-4d4a-bc23-bdbacb02b664	memory_usage	gauge	66.290000	{}	2025-08-30 21:41:22.893+00
31f10203-b6ef-4aed-ae8f-ff03cbaecf37	memory_usage	gauge	66.410000	{}	2025-08-30 21:42:22.895+00
8f43cdb9-9a1e-4271-93b9-7cc50e849455	memory_usage	gauge	65.990000	{}	2025-08-30 21:43:22.895+00
b0c0caf9-941a-4337-8f27-7806d7586220	memory_usage	gauge	66.090000	{}	2025-08-30 21:44:22.894+00
893aed2e-f186-4ad0-8cda-fc07715b9105	memory_usage	gauge	66.100000	{}	2025-08-30 21:45:22.894+00
e61b3a16-73c8-4b7e-ac6f-cebbd7c1d0d9	memory_usage	gauge	65.880000	{}	2025-08-30 21:46:22.895+00
9c292d2c-4de1-4f19-875b-01410e47e868	memory_usage	gauge	66.120000	{}	2025-08-30 21:47:22.895+00
2fa91ab6-d1e7-423c-9f09-a93fe3bb7e1a	cpu_usage	gauge	8.000000	{}	2025-08-30 21:48:22.896+00
573bba8c-9301-4a42-b58c-1d618b499994	uptime	gauge	5588.716934	{}	2025-08-30 21:49:22.896+00
60d5cebe-bbfd-4204-89af-40ffb44a79e9	memory_usage	gauge	66.190000	{}	2025-08-30 21:50:22.897+00
4bceb327-2103-4235-af7a-c2d093af5d4c	cpu_usage	gauge	8.000000	{}	2025-08-30 21:51:22.898+00
9ec67ee4-b2bc-4064-826d-57fc0dc63e00	uptime	gauge	5768.719658	{}	2025-08-30 21:52:22.899+00
0c779d94-6229-42e2-8a03-3d7c04452f03	cpu_usage	gauge	8.000000	{}	2025-08-30 21:53:22.899+00
d0a32349-ca5f-4c4a-9a82-b4b5650640a0	uptime	gauge	5888.720188	{}	2025-08-30 21:54:22.9+00
35cad887-62fe-49a1-b902-e4ab15ae2b74	cpu_usage	gauge	8.000000	{}	2025-08-30 21:55:22.9+00
898142b1-b622-4d40-a2eb-1c9ca196c4fb	uptime	gauge	6008.722094	{}	2025-08-30 21:56:22.902+00
eb3d6e32-008b-45ac-9a22-3a42ff1613bf	disk_usage	gauge	45.200000	{}	2025-08-30 21:57:22.903+00
ccea65d2-edb5-4955-adea-952db423a187	disk_usage	gauge	45.200000	{}	2025-08-30 22:35:38.387+00
7c72307c-0613-4215-8ae7-5608b316c02c	cpu_usage	gauge	8.000000	{}	2025-08-30 22:37:38.387+00
c6ec2fd5-ec1f-494b-8233-192957fb97e7	memory_usage	gauge	81.170000	{}	2025-08-31 00:51:32.773+00
3f8b97db-15f0-45b7-855f-192f5fe46bf1	cpu_usage	gauge	8.000000	{}	2025-08-31 00:52:32.773+00
70e45508-5c26-48c1-aa74-32ae230d6ad8	cpu_usage	gauge	8.000000	{}	2025-08-31 01:14:47.682+00
4af276a2-4d49-45cc-9fac-6e5726258ed3	uptime	gauge	488.741723	{}	2025-08-31 01:21:47.692+00
f70f2a65-d2a4-480b-96ab-424600389fc6	disk_usage	gauge	45.200000	{}	2025-08-31 01:23:47.692+00
22a3074b-9ec1-46da-a664-74fbc6faa547	memory_usage	gauge	77.410000	{}	2025-08-31 01:24:47.692+00
0b4272b4-7c51-426e-bf45-46ae1c76e583	memory_usage	gauge	65.900000	{}	2025-08-30 21:33:22.887+00
448131d1-1334-4022-b4aa-01ce24ff73a5	memory_usage	gauge	65.900000	{}	2025-08-30 21:34:22.887+00
4932b0c4-a169-4ff7-9a32-5783c257270c	memory_usage	gauge	66.190000	{}	2025-08-30 21:35:22.888+00
a4881c1f-e866-44a3-b2eb-3f53ad274cd1	memory_usage	gauge	66.020000	{}	2025-08-30 21:36:22.89+00
c69b75a5-3454-4f47-84dc-717b7adffba2	cpu_usage	gauge	8.000000	{}	2025-08-30 21:37:22.89+00
a62b4e59-c1c2-4473-9be2-b0f06e1ae75d	uptime	gauge	4928.711384	{}	2025-08-30 21:38:22.891+00
b749227e-ed08-4ba2-8780-5b5ff94f9e59	disk_usage	gauge	45.200000	{}	2025-08-30 21:39:22.892+00
31076a3a-5016-4fbc-b8d4-9cb4f5d13e6f	memory_usage	gauge	66.340000	{}	2025-08-30 21:40:22.892+00
d389f2a3-65f5-4e67-aa19-5462558377dc	disk_usage	gauge	45.200000	{}	2025-08-30 21:41:22.894+00
ee0b4d0a-2717-41ee-a743-b66a0b55723d	disk_usage	gauge	45.200000	{}	2025-08-30 21:42:22.895+00
32fa80e5-b56c-45cb-bfa2-cd681606c204	disk_usage	gauge	45.200000	{}	2025-08-30 21:43:22.896+00
e04e5a35-b711-4f14-9915-e25fd536d3db	cpu_usage	gauge	8.000000	{}	2025-08-30 21:44:22.894+00
bf9216f9-1527-4a16-9a2f-3366124227ef	uptime	gauge	5348.714775	{}	2025-08-30 21:45:22.894+00
27ea1c85-4a25-4d0a-9caa-1271e244d7d2	disk_usage	gauge	45.200000	{}	2025-08-30 21:46:22.895+00
a20a9ddc-1591-493c-9932-da35981d37d1	cpu_usage	gauge	8.000000	{}	2025-08-30 21:47:22.895+00
76c9c070-f887-40d9-99ca-d942fef459d7	uptime	gauge	5528.716501	{}	2025-08-30 21:48:22.896+00
6c236314-f240-4989-9abe-27bda313d61e	disk_usage	gauge	45.200000	{}	2025-08-30 21:49:22.896+00
18eaefb4-8cf5-4b75-bd1c-e2c6af7a74f2	disk_usage	gauge	45.200000	{}	2025-08-30 21:50:22.897+00
e6808588-d5e3-4a64-8cc8-b800fd82a6a1	memory_usage	gauge	66.380000	{}	2025-08-30 21:51:22.898+00
cf19911f-f204-4c30-810e-925b5af928e0	memory_usage	gauge	66.020000	{}	2025-08-30 21:52:22.899+00
12b1373f-73b7-438b-8425-4de1e134c7e3	memory_usage	gauge	66.400000	{}	2025-08-30 21:53:22.899+00
80793a30-3594-4ae9-bb16-f65e26305dfa	memory_usage	gauge	66.540000	{}	2025-08-30 21:54:22.9+00
448a49b8-21dd-487f-81c4-f1d9a840f808	memory_usage	gauge	66.360000	{}	2025-08-30 21:55:22.9+00
f0e7cd9f-abce-402c-abc3-202de1178f03	memory_usage	gauge	66.520000	{}	2025-08-30 21:56:22.902+00
c0f0ae12-d820-4fdf-9df5-60f58fb593e5	memory_usage	gauge	65.910000	{}	2025-08-30 21:57:22.903+00
d36c2310-d015-49ef-b16d-85ab499d56f1	uptime	gauge	129.246783	{}	2025-08-30 22:35:38.387+00
2bdc8279-2b46-4d3f-b5e1-7b1162a0b196	cpu_usage	gauge	8.000000	{}	2025-08-30 22:36:38.387+00
fde55aa0-17e6-49b3-9086-b66a1977f557	disk_usage	gauge	45.200000	{}	2025-08-31 00:51:32.774+00
b2689391-4f67-4ffa-95e1-56ae1f8d11a0	memory_usage	gauge	81.410000	{}	2025-08-31 00:52:32.773+00
932d2a4e-13fd-4d6e-9505-43767fe76aab	memory_usage	gauge	77.930000	{}	2025-08-31 01:14:47.682+00
fcc036e4-f6e9-41e6-a0d2-bbe3fd19919f	memory_usage	gauge	77.900000	{}	2025-08-31 01:15:47.683+00
bbbfa820-491f-4e34-b33a-62d1041fe255	cpu_usage	gauge	8.000000	{}	2025-08-31 01:16:47.683+00
016e6cc4-ed9a-45bc-bf6f-c17c80149f72	memory_usage	gauge	79.040000	{}	2025-08-31 01:17:47.685+00
be28acd4-1713-4122-b3dd-6319c659c155	disk_usage	gauge	45.200000	{}	2025-08-30 21:33:22.887+00
2636ebe7-4e15-4cba-91c3-2b68963732a9	disk_usage	gauge	45.200000	{}	2025-08-30 21:34:22.887+00
9e3e3232-e420-4298-bb87-14e3890e5edf	disk_usage	gauge	45.200000	{}	2025-08-30 21:35:22.888+00
a0e21564-658e-425b-9170-a47694d2669f	cpu_usage	gauge	8.000000	{}	2025-08-30 21:36:22.89+00
d829411b-6508-4186-877e-370b9ca9b7f0	uptime	gauge	4868.710429	{}	2025-08-30 21:37:22.89+00
4343aedc-6c69-4169-b284-734b7fb076c7	cpu_usage	gauge	8.000000	{}	2025-08-30 21:38:22.891+00
5ec90d9b-98ea-4aea-8a5b-c89bfaa085ce	uptime	gauge	4988.712559	{}	2025-08-30 21:39:22.892+00
b2dd3a5d-c173-435f-ae65-005cb9b196ca	cpu_usage	gauge	8.000000	{}	2025-08-30 21:40:22.892+00
341f71f4-3739-472c-b4c5-5e2306eef964	uptime	gauge	5108.713947	{}	2025-08-30 21:41:22.894+00
477e1b49-dd84-40d0-848c-9ca6cc79f7e8	cpu_usage	gauge	8.000000	{}	2025-08-30 21:42:22.895+00
57c58d9a-f1b6-4c16-a4dd-2f8d3b04d993	uptime	gauge	5228.715981	{}	2025-08-30 21:43:22.896+00
705eb852-e427-4e56-a61b-b0e7d2df5a73	disk_usage	gauge	45.200000	{}	2025-08-30 21:44:22.894+00
cd469539-0e36-418f-b5b5-64a803e7130e	disk_usage	gauge	45.200000	{}	2025-08-30 21:45:22.894+00
f58df720-66d8-483b-95bb-65825f77cc7f	cpu_usage	gauge	8.000000	{}	2025-08-30 21:46:22.895+00
4fbb00ca-e07b-488a-9211-00d87f0178d7	uptime	gauge	5468.715359	{}	2025-08-30 21:47:22.895+00
90aedde8-3097-4686-a6c9-0bec34cb3756	disk_usage	gauge	45.200000	{}	2025-08-30 21:48:22.896+00
bc9809fb-ad91-4d6b-b248-0ab9dfb0d965	memory_usage	gauge	66.140000	{}	2025-08-30 21:49:22.896+00
349384e8-1551-4d0d-af7c-37b30aa8e342	cpu_usage	gauge	8.000000	{}	2025-08-30 21:50:22.897+00
e128532b-a3c5-4a41-adcd-29b2e5d8a2d5	uptime	gauge	5708.718118	{}	2025-08-30 21:51:22.898+00
bb4cb042-0254-46e3-99df-f2c884774930	cpu_usage	gauge	8.000000	{}	2025-08-30 21:52:22.899+00
10a0848f-27ea-4024-93f4-01c8596ee542	uptime	gauge	5828.719922	{}	2025-08-30 21:53:22.899+00
cd23f768-e829-4b11-9a5d-e9e730e1948a	disk_usage	gauge	45.200000	{}	2025-08-30 21:54:22.9+00
be4917d4-a1d4-46bb-b375-9ea0f786d8c5	disk_usage	gauge	45.200000	{}	2025-08-30 21:55:22.9+00
82592110-56ac-4b64-a417-2444b6afcc13	disk_usage	gauge	45.200000	{}	2025-08-30 21:56:22.902+00
f29f44f1-c7bd-44f4-9b8e-506491d01be9	cpu_usage	gauge	8.000000	{}	2025-08-30 21:57:22.903+00
3ab81eb9-3b80-4478-9e34-6de48b7fada3	disk_usage	gauge	45.200000	{}	2025-08-30 22:36:38.387+00
65a3d469-9ac2-4377-a5b8-c5c992967add	uptime	gauge	249.247809	{}	2025-08-30 22:37:38.388+00
0c0d6ce9-cbf0-4ba3-9ebc-80adab11e17d	memory_usage	gauge	67.530000	{}	2025-08-30 22:38:38.388+00
0e199dc6-6cff-4d41-952a-6aaf6f659752	cpu_usage	gauge	8.000000	{}	2025-08-30 22:39:38.388+00
8114895e-466e-4b59-811f-49f7ac674918	uptime	gauge	429.248252	{}	2025-08-30 22:40:38.389+00
c99647b1-a891-40a0-ac54-42c6d03921d3	memory_usage	gauge	67.250000	{}	2025-08-30 22:41:38.39+00
984db503-f6a2-46be-ba2d-288a147f99d4	memory_usage	gauge	66.480000	{}	2025-08-30 22:42:38.391+00
0757278d-0774-42e2-a2de-d9be0e9dbc83	cpu_usage	gauge	8.000000	{}	2025-08-30 22:43:38.392+00
99536057-6685-4edd-a0dd-1e8a379031af	memory_usage	gauge	66.050000	{}	2025-08-30 22:44:38.393+00
49861abf-fd25-459f-807b-df3ed8734932	memory_usage	gauge	65.750000	{}	2025-08-30 22:45:38.393+00
a0069309-39d4-42d5-b12f-d21409704f12	cpu_usage	gauge	8.000000	{}	2025-08-30 22:46:38.393+00
7b6216f1-a1d4-45e0-9035-e9e43f8cf27d	uptime	gauge	849.252979	{}	2025-08-30 22:47:38.394+00
a29dbb34-48a6-406e-8cfb-9c43eeae6ad7	disk_usage	gauge	45.200000	{}	2025-08-30 22:48:38.394+00
a837bfcc-a6f5-4b38-a787-80f9504b6c9a	memory_usage	gauge	66.150000	{}	2025-08-30 22:49:38.394+00
b8a99c58-6e4e-4db4-89e8-46c9c8d42ff2	disk_usage	gauge	45.200000	{}	2025-08-30 22:50:38.396+00
b340c70c-c351-4f49-8190-bc3dc5406860	cpu_usage	gauge	8.000000	{}	2025-08-30 22:51:38.396+00
154647d7-8fcc-445f-8110-bed04b904c9c	uptime	gauge	1149.255478	{}	2025-08-30 22:52:38.396+00
425fa119-0ce5-44bc-b715-2082540f3f04	uptime	gauge	1209.255501	{}	2025-08-30 22:53:38.396+00
d0fef90f-812c-41a9-b6fc-a938950fc90e	memory_usage	gauge	68.150000	{}	2025-08-30 22:54:38.397+00
adfb50eb-fa12-4b01-a122-6d3774289b1b	memory_usage	gauge	79.930000	{}	2025-08-30 22:55:38.397+00
ab68227c-ef4f-49cc-a0b2-6c0e55344995	memory_usage	gauge	78.450000	{}	2025-08-30 22:56:38.397+00
616c97ec-806e-48da-908c-cc5c9c700427	memory_usage	gauge	81.180000	{}	2025-08-30 22:57:38.398+00
8f5caddf-8c88-4368-812f-862ca482283b	uptime	gauge	1509.256307	{}	2025-08-30 22:58:38.397+00
a543c0cf-eac3-4f29-a24c-612c4fb58f58	cpu_usage	gauge	8.000000	{}	2025-08-31 00:53:04.827+00
e4f56058-a5a4-429f-8852-74a344f29211	disk_usage	gauge	45.200000	{}	2025-08-31 00:54:04.843+00
b8bac5f1-ea8d-4536-940a-b7750b10cdc6	disk_usage	gauge	45.200000	{}	2025-08-31 01:14:47.682+00
a0c33d4c-6abe-49ca-905d-3873183c7136	cpu_usage	gauge	8.000000	{}	2025-08-31 01:15:47.683+00
9ece9cc5-2d65-470b-a747-014b571d5575	uptime	gauge	188.733046	{}	2025-08-31 01:16:47.683+00
05ac2f2c-fc65-4846-bb4f-a2c13efb1e72	cpu_usage	gauge	8.000000	{}	2025-08-31 01:17:47.685+00
fada5409-cfba-4d46-8596-c367892af8ef	disk_usage	gauge	45.200000	{}	2025-08-31 01:18:47.691+00
9f86f014-5adc-4c3f-910c-35580402a43e	uptime	gauge	368.741209	{}	2025-08-31 01:19:47.692+00
dc92b742-9f81-4f8f-996b-e9e95c9171c9	cpu_usage	gauge	8.000000	{}	2025-08-31 01:20:47.692+00
0acf9be6-47d2-4cf4-b3a5-3e2f0db2f7a6	uptime	gauge	608.741984	{}	2025-08-31 01:23:47.692+00
5f9db06e-caef-4696-bc68-f0fac36c72d1	uptime	gauge	668.741720	{}	2025-08-31 01:24:47.692+00
95dd248f-098a-4123-8653-37ba72f5c2dd	uptime	gauge	728.742228	{}	2025-08-31 01:25:47.693+00
b155923c-6990-42d8-a930-7b77dd220ac7	cpu_usage	gauge	8.000000	{}	2025-08-31 01:26:47.693+00
50ef6e43-afd2-45f1-8420-d96367c4355d	uptime	gauge	4628.707111	{}	2025-08-30 21:33:22.887+00
97774373-e9e1-4b1d-a8a9-84ec31fbca7a	cpu_usage	gauge	8.000000	{}	2025-08-30 21:34:22.887+00
81194e0d-a333-4565-a615-bb2df259a65f	uptime	gauge	4748.708373	{}	2025-08-30 21:35:22.888+00
21d67ad5-10c5-4933-89f7-b2852e357aff	disk_usage	gauge	45.200000	{}	2025-08-30 21:36:22.89+00
1a5e3c7e-e26d-4431-a7e1-9685f12957fe	memory_usage	gauge	66.180000	{}	2025-08-30 21:37:22.89+00
34d741b4-2bbd-4ca4-97f3-5d6d89945e35	memory_usage	gauge	66.280000	{}	2025-08-30 21:38:22.891+00
f7183e01-4282-41ec-a81a-99a39f993d16	cpu_usage	gauge	8.000000	{}	2025-08-30 21:39:22.892+00
1ff7e348-ed93-4b88-a805-38da24dd1c03	uptime	gauge	5048.712886	{}	2025-08-30 21:40:22.892+00
823be3df-fa81-4a70-a760-687be31d180b	cpu_usage	gauge	8.000000	{}	2025-08-30 21:41:22.893+00
a4af82c7-c17f-4692-a4bc-fc3c80063d41	uptime	gauge	5168.715257	{}	2025-08-30 21:42:22.895+00
4d52fe61-86ce-4d01-bb4d-3a8da641885b	cpu_usage	gauge	8.000000	{}	2025-08-30 21:43:22.895+00
ecf6cbe4-fd6f-499d-a0b7-74ed420c475f	uptime	gauge	5288.714541	{}	2025-08-30 21:44:22.894+00
98f60362-4b74-4049-b881-d67fb8f04f06	cpu_usage	gauge	8.000000	{}	2025-08-30 21:45:22.894+00
ea4e30ba-50c5-445f-94a8-1535842e54f3	uptime	gauge	5408.715490	{}	2025-08-30 21:46:22.895+00
58dd46c9-cd9c-4f00-bcaf-fc3eac0c4259	disk_usage	gauge	45.200000	{}	2025-08-30 21:47:22.895+00
cb7b2b84-ffe3-46b0-acfc-fb696d22b3f1	memory_usage	gauge	66.010000	{}	2025-08-30 21:48:22.896+00
ef1b2a2b-b83b-4d30-89d8-b3ea0df1d6a6	cpu_usage	gauge	8.000000	{}	2025-08-30 21:49:22.896+00
89217e35-cca8-4712-ba50-a0b231d2e128	uptime	gauge	5648.717900	{}	2025-08-30 21:50:22.897+00
9535a331-10f5-44b3-8097-7a1bf7cd9c9a	disk_usage	gauge	45.200000	{}	2025-08-30 21:51:22.898+00
85a0d8e6-547d-4928-998c-b85cc68ff25c	disk_usage	gauge	45.200000	{}	2025-08-30 21:52:22.899+00
636e29dd-bf8b-424e-9538-0f770925f478	disk_usage	gauge	45.200000	{}	2025-08-30 21:53:22.899+00
5a2f2671-8053-4f18-a195-c53358622fb0	cpu_usage	gauge	8.000000	{}	2025-08-30 21:54:22.9+00
d3cc6adf-04bc-4c7c-825d-d67e34449295	uptime	gauge	5948.720739	{}	2025-08-30 21:55:22.9+00
34f870a7-3426-4c14-be71-fc78f74dd680	cpu_usage	gauge	8.000000	{}	2025-08-30 21:56:22.902+00
1f4e471b-778a-44d1-95e1-8f4322759b02	uptime	gauge	6068.723498	{}	2025-08-30 21:57:22.903+00
279fd667-257a-418f-9a11-da023e69992a	memory_usage	gauge	66.970000	{}	2025-08-30 22:51:38.396+00
fbeb8504-927a-4b47-8543-a1c5c083c511	cpu_usage	gauge	8.000000	{}	2025-08-30 22:52:38.396+00
2758dad1-7c08-4108-b896-1ffc8030e10d	memory_usage	gauge	66.970000	{}	2025-08-30 22:53:38.396+00
0cda7395-c0e9-42df-a468-a7763786f326	uptime	gauge	1269.256208	{}	2025-08-30 22:54:38.397+00
23304415-c5ab-4b12-a5d1-b447235b9b57	cpu_usage	gauge	8.000000	{}	2025-08-30 22:55:38.397+00
32487d41-60c7-47f4-9cff-3abb765b1fd8	uptime	gauge	1389.256506	{}	2025-08-30 22:56:38.397+00
e6b0091a-d27b-4da9-a4ef-10645631ed03	disk_usage	gauge	45.200000	{}	2025-08-30 22:57:38.398+00
176115b3-9211-40de-bd07-a639a496f3ae	disk_usage	gauge	45.200000	{}	2025-08-30 22:58:38.397+00
b35f8306-3b9e-42ce-8548-0e6d2b96a5ca	memory_usage	gauge	81.440000	{}	2025-08-31 00:53:04.827+00
8edf4c42-a2a9-422c-a103-c572c4b7584a	memory_usage	gauge	80.810000	{}	2025-08-31 00:54:04.842+00
14742519-b5cf-4cfd-9ece-e84bafa10d40	uptime	gauge	68.731595	{}	2025-08-31 01:14:47.682+00
8466b333-ee45-42c1-a303-d3706f3e9ad5	uptime	gauge	848.742706	{}	2025-08-31 01:27:47.693+00
849dc17a-aee3-4e08-aa0f-c93de5900ed5	memory_usage	gauge	78.490000	{}	2025-08-31 01:28:47.693+00
63a87062-b31c-425f-b89b-e0f8f94edd92	cpu_usage	gauge	8.000000	{}	2025-08-30 21:58:22.904+00
f11da787-827a-4b21-85dc-0a302e0399d6	uptime	gauge	6188.725004	{}	2025-08-30 21:59:22.905+00
2cd4d2c3-fefd-4761-a38e-0fb19a1d97e3	memory_usage	gauge	66.010000	{}	2025-08-30 22:00:22.906+00
1a85fad1-5394-4396-bdb6-ebc1925c83a7	cpu_usage	gauge	8.000000	{}	2025-08-30 22:01:22.907+00
b9337acb-b0b0-42c7-938f-ad8428891b8e	uptime	gauge	6368.727425	{}	2025-08-30 22:02:22.907+00
2c6d22ee-c4e3-40a3-aae7-7fa47d425f91	disk_usage	gauge	45.200000	{}	2025-08-30 22:03:22.908+00
b89561aa-66c7-42d3-8d54-c13de8a72962	cpu_usage	gauge	8.000000	{}	2025-08-30 22:04:22.909+00
9d253414-4faf-4a5d-a540-2bdaefeff6cc	uptime	gauge	6548.729320	{}	2025-08-30 22:05:22.909+00
f1c635d0-9fb6-408b-94e3-0c0a0c2b3a9a	disk_usage	gauge	45.200000	{}	2025-08-30 22:06:22.909+00
8d364424-c98c-4ea3-a766-a7c519c85325	memory_usage	gauge	66.140000	{}	2025-08-30 22:07:22.909+00
a87cc87f-d54e-4367-9e82-289494b9ed08	cpu_usage	gauge	8.000000	{}	2025-08-30 22:08:22.91+00
b8b02102-3286-4731-8495-91abd8e87988	uptime	gauge	6788.732071	{}	2025-08-30 22:09:22.912+00
33f56bc6-8330-4eba-9670-bb32ca38b6fc	disk_usage	gauge	45.200000	{}	2025-08-30 22:10:22.912+00
38ee3bc4-c398-40c9-a9fa-1f8e6e33099c	memory_usage	gauge	66.260000	{}	2025-08-30 22:11:22.914+00
2801dbb3-d664-48b6-9598-3735e9fe96da	cpu_usage	gauge	8.000000	{}	2025-08-30 22:12:22.915+00
61198a90-5095-47ec-a5e6-236abc8bc995	uptime	gauge	7028.736169	{}	2025-08-30 22:13:22.916+00
2041eea0-9de2-4f37-b530-18a7f2ef2fb4	disk_usage	gauge	45.200000	{}	2025-08-30 22:14:22.917+00
0f6453e0-96d8-4f89-accd-d8e9ee9b10e7	cpu_usage	gauge	8.000000	{}	2025-08-30 22:15:22.917+00
8592c177-edac-4491-8a02-c892d6b883d8	uptime	gauge	7208.737766	{}	2025-08-30 22:16:22.917+00
f72e12a1-593a-43cd-b5d3-05b55eee0c04	cpu_usage	gauge	8.000000	{}	2025-08-30 22:17:22.918+00
e68a628d-0a12-4def-9e58-e02b654a5c57	uptime	gauge	7328.738603	{}	2025-08-30 22:18:22.918+00
ba3f8b17-d1f6-4578-9551-32b96e7793b2	disk_usage	gauge	45.200000	{}	2025-08-30 22:19:22.918+00
84fb389e-bec9-4d6c-9c84-73157bace570	disk_usage	gauge	45.200000	{}	2025-08-30 22:20:22.919+00
0a017fe9-10c5-4e84-bd64-a464d75f7d3a	cpu_usage	gauge	8.000000	{}	2025-08-30 22:21:22.92+00
596aa3d9-31b9-49da-a919-e0b1be320bd5	uptime	gauge	7568.741636	{}	2025-08-30 22:22:22.921+00
56fd4ce8-6af4-4b7c-a272-4f2b4cb1eddf	disk_usage	gauge	45.200000	{}	2025-08-30 22:23:22.921+00
a900fc48-0249-40a9-97de-994f87ad5c00	memory_usage	gauge	66.090000	{}	2025-08-30 22:24:22.922+00
78162eb5-3b96-4d03-8a81-db15b040313f	memory_usage	gauge	65.950000	{}	2025-08-30 22:25:22.922+00
ae5db401-c056-47fb-b67d-f8fb09cff470	disk_usage	gauge	45.200000	{}	2025-08-30 22:51:38.396+00
0552e64d-172a-434a-b9ad-037f5cb29345	memory_usage	gauge	66.800000	{}	2025-08-30 22:52:38.396+00
eba2bb1d-455b-4c49-8839-8d0cb6341ad3	disk_usage	gauge	45.200000	{}	2025-08-30 22:53:38.396+00
924bca7d-315c-4b7a-bd66-ef84aaf7040b	cpu_usage	gauge	8.000000	{}	2025-08-30 22:54:38.397+00
c4f57d33-b07d-4540-9b43-a3b6de52ef3e	uptime	gauge	1329.256418	{}	2025-08-30 22:55:38.397+00
8c750e02-150d-40c8-a500-8064606693b7	disk_usage	gauge	45.200000	{}	2025-08-30 22:56:38.397+00
cbdafc40-6296-44b5-8fa8-255eef75958b	cpu_usage	gauge	8.000000	{}	2025-08-30 22:57:38.398+00
8de31660-9921-4a6e-a85f-4efa78b2757a	cpu_usage	gauge	8.000000	{}	2025-08-30 22:58:38.397+00
def23786-b604-4634-960f-8ba4919a61ce	uptime	gauge	248.346732	{}	2025-08-31 00:53:04.827+00
4cf0bf3d-f778-4f4c-b6b0-b2459dc225d7	cpu_usage	gauge	8.000000	{}	2025-08-31 00:54:04.842+00
bd92009a-6a6a-44de-9775-d07886e511c7	disk_usage	gauge	45.200000	{}	2025-08-31 01:15:47.683+00
8fe1ef17-3116-4e7a-8109-08f7d532d468	memory_usage	gauge	77.970000	{}	2025-08-31 01:16:47.683+00
67d6f1ff-bcdb-4330-a659-285222e2c9dc	uptime	gauge	248.734333	{}	2025-08-31 01:17:47.685+00
328a0a5c-7fc1-4d67-b364-c1ed81208def	disk_usage	gauge	45.200000	{}	2025-08-31 01:21:47.692+00
462ab868-7986-4b9c-9827-ecf849009f5d	cpu_usage	gauge	8.000000	{}	2025-08-31 01:22:47.692+00
2ab6b4de-40db-4367-9577-9753ee98d5fe	memory_usage	gauge	77.340000	{}	2025-08-31 01:23:47.692+00
a37dd0fd-61c2-4a70-b5f0-c80d4ff480e9	disk_usage	gauge	45.200000	{}	2025-08-31 01:25:47.693+00
405ab520-309b-469a-b110-013c8726dfbb	memory_usage	gauge	77.930000	{}	2025-08-31 01:26:47.693+00
4d83d800-0393-423a-9ebd-3db5825ee878	disk_usage	gauge	45.200000	{}	2025-08-31 01:27:47.693+00
7c4b3752-0d8a-40b4-a240-366b75972908	disk_usage	gauge	45.200000	{}	2025-08-31 01:28:47.693+00
956493ff-340c-4733-bc68-00ba5250d206	memory_usage	gauge	66.120000	{}	2025-08-30 21:58:22.904+00
da1e09ee-a5c2-4a91-9249-7f45f808c185	disk_usage	gauge	45.200000	{}	2025-08-30 21:59:22.905+00
77d06e99-bca3-42c1-904a-a3068d2fcc14	disk_usage	gauge	45.200000	{}	2025-08-30 22:00:22.906+00
6b273035-0626-4fa1-9c04-b49f0bb738dd	disk_usage	gauge	45.200000	{}	2025-08-30 22:01:22.907+00
393d480a-b3d2-4850-81f5-2b61e7495d63	cpu_usage	gauge	8.000000	{}	2025-08-30 22:02:22.907+00
e8e13141-5041-44d6-b08e-d43a061e438d	uptime	gauge	6428.728182	{}	2025-08-30 22:03:22.908+00
aeae0e31-cf34-49f4-ada5-37fa47c4d9a7	disk_usage	gauge	45.200000	{}	2025-08-30 22:04:22.909+00
7890dbbb-2abe-4a6c-9c45-ceaada4dd71e	cpu_usage	gauge	8.000000	{}	2025-08-30 22:05:22.909+00
55e9cdda-976b-47c8-a596-5bbb224084ba	uptime	gauge	6608.729064	{}	2025-08-30 22:06:22.909+00
15d7f107-e639-4330-90ab-7250b2c6c99f	disk_usage	gauge	45.200000	{}	2025-08-30 22:07:22.91+00
ffe5e658-8e3f-4c9a-a186-18cd43547557	memory_usage	gauge	66.220000	{}	2025-08-30 22:08:22.91+00
3487cfb2-21d2-4c43-9e1f-7cb652f26baa	disk_usage	gauge	45.200000	{}	2025-08-30 22:09:22.912+00
e82d78a2-f70a-498f-b66b-ccdf0d89e197	memory_usage	gauge	66.170000	{}	2025-08-30 22:10:22.912+00
546f8c52-30ba-49a0-ac04-34587a41be3d	cpu_usage	gauge	8.000000	{}	2025-08-30 22:11:22.914+00
f7f19729-a5db-4911-8956-96c0c69a64ee	uptime	gauge	6968.735623	{}	2025-08-30 22:12:22.915+00
9e8c206f-34d6-44bb-b236-501f96385b76	disk_usage	gauge	45.200000	{}	2025-08-30 22:13:22.916+00
1bae4e7b-3503-42e4-b33d-dd79e5f7ceda	cpu_usage	gauge	8.000000	{}	2025-08-30 22:14:22.917+00
80e14d2c-8eb7-439c-9c1a-f4c25ab584a6	uptime	gauge	7148.737809	{}	2025-08-30 22:15:22.917+00
2158578f-5f05-47f2-b994-43bba9a7e345	disk_usage	gauge	45.200000	{}	2025-08-30 22:16:22.917+00
784fa840-3b28-4136-8d32-ffb082400208	memory_usage	gauge	66.680000	{}	2025-08-30 22:17:22.918+00
c9d67533-faab-44d4-a979-76932d2ba956	memory_usage	gauge	66.290000	{}	2025-08-30 22:18:22.918+00
c03c6fb6-7eb8-4672-8647-eda0cad28b97	cpu_usage	gauge	8.000000	{}	2025-08-30 22:19:22.918+00
9525633f-4e22-4b44-9071-3df73af23942	cpu_usage	gauge	8.000000	{}	2025-08-30 22:20:22.919+00
e12672c0-5297-4c1e-84f8-391c2d1793ec	disk_usage	gauge	45.200000	{}	2025-08-30 22:21:22.92+00
52a4a156-9e8d-46f2-807c-a8084806ff89	memory_usage	gauge	65.750000	{}	2025-08-30 22:22:22.921+00
7ede9306-28ab-475c-b872-2fe1bf3c28c2	cpu_usage	gauge	8.000000	{}	2025-08-30 22:23:22.921+00
5a139336-36c4-4da4-bb8a-179b68514482	uptime	gauge	7688.742765	{}	2025-08-30 22:24:22.922+00
7e222f73-8eb9-496c-ba29-950a753644b0	disk_usage	gauge	45.200000	{}	2025-08-30 22:25:22.922+00
8ae08acb-a576-41b3-9320-eb7d9cb37eab	memory_usage	gauge	82.910000	{}	2025-08-30 22:59:38.398+00
edde86a6-b38f-4727-9ee7-bcf6ee580c17	cpu_usage	gauge	8.000000	{}	2025-08-30 22:59:38.398+00
1f40b199-df24-4e31-bc5f-355cb6aa3c45	memory_usage	gauge	84.150000	{}	2025-08-30 23:00:38.399+00
c8110613-f3af-464c-8a06-5c3bdfd5478b	uptime	gauge	1629.258007	{}	2025-08-30 23:00:38.399+00
1f9b30bf-9a59-4d76-8cd2-94566fe176b9	cpu_usage	gauge	8.000000	{}	2025-08-30 23:01:38.4+00
7953f742-5bf6-4fa2-bee6-751d6aeedfd6	memory_usage	gauge	83.940000	{}	2025-08-30 23:01:38.4+00
2ab0a456-3276-4470-8ff6-662c4fc150ca	cpu_usage	gauge	8.000000	{}	2025-08-30 23:02:38.4+00
d4b32eca-dffb-4163-8686-99ff4b18a082	uptime	gauge	1749.259075	{}	2025-08-30 23:02:38.4+00
9b954cfb-6bc3-44ee-ae21-1653031d5a1d	memory_usage	gauge	81.660000	{}	2025-08-30 23:03:38.399+00
dddd5b93-4f23-4423-878f-94b9dcbe4212	disk_usage	gauge	45.200000	{}	2025-08-30 23:03:38.4+00
d989b4d3-cd44-42e6-b341-e286d79f6e06	cpu_usage	gauge	8.000000	{}	2025-08-30 23:04:38.4+00
e50d31f3-3886-4aff-9e06-f3c98c980c4d	memory_usage	gauge	81.780000	{}	2025-08-30 23:04:38.4+00
9538aaae-65e7-4bf5-a8ad-946af87a7ebc	memory_usage	gauge	81.510000	{}	2025-08-30 23:05:38.4+00
12d1a676-bcca-4a3c-aabe-f6b91efe325b	uptime	gauge	1929.259239	{}	2025-08-30 23:05:38.4+00
20e2b687-f8af-49ba-95c6-043b9f2fb302	memory_usage	gauge	81.900000	{}	2025-08-30 23:06:38.4+00
a58b7093-bde4-411b-b341-d4c17dcc9871	disk_usage	gauge	45.200000	{}	2025-08-30 23:06:38.4+00
28819408-ac43-4763-bba2-5055a51b8afc	memory_usage	gauge	81.790000	{}	2025-08-30 23:07:38.401+00
d221cfd8-8922-4220-a74e-aa57a31988cb	disk_usage	gauge	45.200000	{}	2025-08-30 23:07:38.401+00
1f358f70-4683-482a-a36c-e47b4550db2c	cpu_usage	gauge	8.000000	{}	2025-08-30 23:08:38.401+00
73c865b6-5d8c-47ea-90dc-0ca906d0c6b9	memory_usage	gauge	81.990000	{}	2025-08-30 23:08:38.401+00
486b65c2-7ff4-4f82-81c4-e5b8a188ce45	cpu_usage	gauge	8.000000	{}	2025-08-30 23:09:38.402+00
38b6e38e-3524-49e3-8217-91de3682a4c4	uptime	gauge	2169.261447	{}	2025-08-30 23:09:38.402+00
ed6f41e9-c8f0-4e1b-93c2-04d9ff8ede7b	memory_usage	gauge	82.290000	{}	2025-08-30 23:10:38.402+00
585b4158-2dd1-499a-aa91-a79ff3151f0e	uptime	gauge	2229.261379	{}	2025-08-30 23:10:38.402+00
e4c0a5d3-779a-46f1-a07c-aa6506a0fe1b	memory_usage	gauge	81.920000	{}	2025-08-30 23:11:38.402+00
2103bd7e-ee83-4690-911e-a8e10b508d4d	disk_usage	gauge	45.200000	{}	2025-08-30 23:11:38.402+00
91f2dcb0-f321-4845-8c4c-4358ef0e0194	cpu_usage	gauge	8.000000	{}	2025-08-30 23:12:38.403+00
8b937de7-1200-4440-aff2-aca644d68262	memory_usage	gauge	81.870000	{}	2025-08-30 23:12:38.403+00
7a471d53-6489-42e3-82aa-cb3aeedd361c	cpu_usage	gauge	8.000000	{}	2025-08-30 23:13:38.403+00
5aefde4f-ce45-483e-884d-98f18b50d5aa	uptime	gauge	2409.262236	{}	2025-08-30 23:13:38.403+00
f0e83269-d956-4abe-af07-a56acdb5ac83	disk_usage	gauge	45.200000	{}	2025-08-30 23:14:38.404+00
177e79fd-1db0-462c-8d04-83617955f3df	uptime	gauge	2469.262945	{}	2025-08-30 23:14:38.404+00
c6265415-3efe-4b19-952d-8237dd14f239	cpu_usage	gauge	8.000000	{}	2025-08-30 23:15:38.403+00
8d47c547-187a-4991-a376-61e35594999e	disk_usage	gauge	45.200000	{}	2025-08-30 23:15:38.403+00
4312e4c8-703a-49ca-b746-6e2273a42f7c	memory_usage	gauge	82.430000	{}	2025-08-30 23:16:38.404+00
75f44686-83c1-4b08-8a65-f904b5b504a9	disk_usage	gauge	45.200000	{}	2025-08-30 23:16:38.404+00
c9118909-d3a0-4da2-8edd-fb794cf39c10	cpu_usage	gauge	8.000000	{}	2025-08-30 23:17:38.405+00
54170f0b-998d-4ecb-8c1a-e5cd901a81ea	memory_usage	gauge	82.070000	{}	2025-08-30 23:17:38.405+00
8815093c-7561-4434-ab1c-1595ee01f510	disk_usage	gauge	45.200000	{}	2025-08-30 23:18:38.406+00
6b1e289d-bf98-4639-9b4f-2d5616ede683	uptime	gauge	2709.265148	{}	2025-08-30 23:18:38.406+00
a9584d53-2eb4-4aac-8397-3cb6da91cf6a	cpu_usage	gauge	8.000000	{}	2025-08-30 23:19:38.407+00
bee11764-ee67-40a7-b060-e931237342f2	disk_usage	gauge	45.200000	{}	2025-08-30 23:19:38.407+00
30043b0d-23f8-4147-8dfe-14c2915a5d67	cpu_usage	gauge	8.000000	{}	2025-08-30 23:20:38.408+00
734990d1-8ed2-4858-8cfe-e652a5e040a0	uptime	gauge	2829.267041	{}	2025-08-30 23:20:38.408+00
ee2a72b5-7c3b-4ca8-8707-40bc0c7cdb09	memory_usage	gauge	82.820000	{}	2025-08-30 23:21:38.408+00
70d4aacc-dddf-4de3-a1f3-f687b7d81bf4	uptime	gauge	2889.267788	{}	2025-08-30 23:21:38.408+00
66b35971-0efd-485c-a121-2460493dfdc1	memory_usage	gauge	82.920000	{}	2025-08-30 23:22:38.408+00
cf1780a6-b7e8-41cd-b8b7-b2cb6632bcf8	disk_usage	gauge	45.200000	{}	2025-08-30 23:22:38.408+00
dcd8f3ee-ab3d-497c-9e65-2f43bae09079	cpu_usage	gauge	8.000000	{}	2025-08-30 23:23:38.408+00
572e6397-a1b1-4d4f-a6ee-2014a1dbd7f5	disk_usage	gauge	45.200000	{}	2025-08-30 23:23:38.408+00
61cc09ae-268b-40cf-adae-34757f456db5	disk_usage	gauge	45.200000	{}	2025-08-30 23:24:38.409+00
f7e25217-44ce-4827-bcbd-855ff007f1bb	uptime	gauge	3069.268353	{}	2025-08-30 23:24:38.409+00
16b7906c-d47d-4abf-9ff2-9c4cd2c62a38	memory_usage	gauge	82.550000	{}	2025-08-30 23:25:38.409+00
0d5b9abf-acf1-4f9f-afd9-9ec76fc3411f	disk_usage	gauge	45.200000	{}	2025-08-30 23:25:38.41+00
a19bcd57-0471-48a5-ab8b-5d556c64cf21	cpu_usage	gauge	8.000000	{}	2025-08-30 23:26:38.409+00
9fe72db9-0f59-45f3-9f3e-3772e2e12a27	memory_usage	gauge	82.410000	{}	2025-08-30 23:26:38.409+00
cf0b9de0-0f2d-4b7d-8608-9f52466085e2	memory_usage	gauge	82.410000	{}	2025-08-30 23:27:38.409+00
14ec08fc-35d1-4639-a636-03faded12893	uptime	gauge	3249.268660	{}	2025-08-30 23:27:38.409+00
810d71cb-92d0-4539-b34e-a3c19f25a63c	memory_usage	gauge	82.690000	{}	2025-08-30 23:28:38.409+00
5bcddff8-459a-4d92-81d1-94247976cef8	disk_usage	gauge	45.200000	{}	2025-08-30 23:28:38.409+00
08951a26-7760-42b4-ba79-585cd76c2169	memory_usage	gauge	82.230000	{}	2025-08-30 23:29:38.41+00
6bd39be2-65b0-4111-a786-ba05f4b70be3	uptime	gauge	3369.269205	{}	2025-08-30 23:29:38.41+00
8cf042e5-1cd8-4da4-9f4f-e0ee00fdaaf6	cpu_usage	gauge	8.000000	{}	2025-08-30 23:30:38.409+00
57ba2779-f2e3-42c9-9c6d-50fe6fe49725	memory_usage	gauge	82.770000	{}	2025-08-30 23:30:38.409+00
3c1c3301-a68a-4ecf-a471-1367b2f00b31	memory_usage	gauge	82.670000	{}	2025-08-30 23:31:38.41+00
c28c48fe-bcd0-414e-882d-f6c064bd4f3d	uptime	gauge	3489.269233	{}	2025-08-30 23:31:38.41+00
dfe1b175-e8ca-4ad8-993f-c4df8dd392fe	cpu_usage	gauge	8.000000	{}	2025-08-30 23:32:38.41+00
92f5d2bd-0cad-4599-ba35-fd5b592ecfc4	disk_usage	gauge	45.200000	{}	2025-08-30 23:32:38.41+00
bee1a16f-208f-4f4e-afe6-18f3b101b70d	cpu_usage	gauge	8.000000	{}	2025-08-31 00:53:49.57+00
e8e56d38-7747-42a3-a991-755ddc2e02ef	disk_usage	gauge	45.200000	{}	2025-08-30 21:58:22.905+00
db197f77-7cbf-45c3-aded-ed850d4de665	cpu_usage	gauge	8.000000	{}	2025-08-30 21:59:22.904+00
70003df7-df96-4780-a9e2-142f3ee3abd3	uptime	gauge	6248.726182	{}	2025-08-30 22:00:22.906+00
53cbd463-fe3a-4239-9e25-63256e867d19	memory_usage	gauge	66.150000	{}	2025-08-30 22:01:22.907+00
5451529d-e057-4b2b-8426-bfb84f85aeb0	memory_usage	gauge	65.970000	{}	2025-08-30 22:02:22.907+00
4ffccbde-3e58-4e25-be49-1b9f51360233	cpu_usage	gauge	8.000000	{}	2025-08-30 22:03:22.908+00
c5b809d1-3c65-4d25-a728-e79efe8894e3	uptime	gauge	6488.729311	{}	2025-08-30 22:04:22.909+00
47d4ca6d-720c-49d4-9a29-3ee2595a4210	disk_usage	gauge	45.200000	{}	2025-08-30 22:05:22.909+00
fc36ff8a-4ab8-4790-9cbd-f5955dbf28b2	memory_usage	gauge	66.450000	{}	2025-08-30 22:06:22.909+00
4d981de1-e006-4cf4-a7f1-d2a4184d22ff	cpu_usage	gauge	8.000000	{}	2025-08-30 22:07:22.909+00
898826c6-d105-4d63-b559-a8a4c7080e1a	uptime	gauge	6728.730570	{}	2025-08-30 22:08:22.91+00
53a5a189-f5fe-4a04-b511-ef54f8eaf8c4	memory_usage	gauge	66.270000	{}	2025-08-30 22:09:22.912+00
ade14620-95f5-430b-a131-dd41873c46d4	cpu_usage	gauge	8.000000	{}	2025-08-30 22:10:22.912+00
21aee8a2-e6ba-4a88-88a8-2ac1663aca74	uptime	gauge	6908.734331	{}	2025-08-30 22:11:22.914+00
199fb854-107c-469e-b1cb-7b846ec2c88f	disk_usage	gauge	45.200000	{}	2025-08-30 22:12:22.915+00
2815b126-d50f-4d75-9aaa-ab973689227f	memory_usage	gauge	66.470000	{}	2025-08-30 22:13:22.916+00
e4e6915b-924b-4a6d-a4d0-3fd0d589bfc1	memory_usage	gauge	66.360000	{}	2025-08-30 22:14:22.917+00
552d297c-7849-4665-a1f6-01e00cc09941	disk_usage	gauge	45.200000	{}	2025-08-30 22:15:22.917+00
e505349b-10c1-492b-a5c6-1c4b0cbe17c0	cpu_usage	gauge	8.000000	{}	2025-08-30 22:16:22.917+00
42e00300-da95-4179-987f-f0e2379df0ef	uptime	gauge	7268.738593	{}	2025-08-30 22:17:22.918+00
ef739fbe-9fe5-4ea1-b096-c3188956ae13	cpu_usage	gauge	8.000000	{}	2025-08-30 22:18:22.918+00
32d44674-d0dd-4b0c-904a-74c88eae3855	uptime	gauge	7388.738789	{}	2025-08-30 22:19:22.918+00
09ff0839-c90e-48e6-9886-ee45207dab54	memory_usage	gauge	66.340000	{}	2025-08-30 22:20:22.919+00
3d5a7075-2c75-42ec-b1c0-7ee576e59f0d	uptime	gauge	7508.740877	{}	2025-08-30 22:21:22.92+00
f9f814ac-119a-4a77-b98a-9f942782513c	disk_usage	gauge	45.200000	{}	2025-08-30 22:22:22.921+00
dfffdb75-8006-4ee3-a694-a2c058336457	memory_usage	gauge	65.970000	{}	2025-08-30 22:23:22.921+00
569dc33f-1860-4de7-9388-24cdddc54f0d	cpu_usage	gauge	8.000000	{}	2025-08-30 22:24:22.922+00
9f39401b-4212-40e6-bd1e-ce272ac29898	uptime	gauge	7748.742697	{}	2025-08-30 22:25:22.922+00
789d44a8-99d5-4c37-bae7-f240ed63338a	disk_usage	gauge	45.200000	{}	2025-08-30 22:59:38.398+00
25689723-c631-47ca-8e08-aacb2e4efb0d	cpu_usage	gauge	8.000000	{}	2025-08-30 23:00:38.399+00
f057c42f-b19d-4315-939f-400436b364ae	uptime	gauge	1689.259275	{}	2025-08-30 23:01:38.4+00
64706b1d-8e32-429b-81da-751bec5c5cdd	disk_usage	gauge	45.200000	{}	2025-08-30 23:02:38.4+00
47f2cc15-c323-4a43-a881-19a8ce0054f4	cpu_usage	gauge	8.000000	{}	2025-08-30 23:03:38.399+00
ae54640d-bf16-4303-abff-5fecd0531b28	uptime	gauge	1869.259825	{}	2025-08-30 23:04:38.4+00
ec335412-317a-4d02-ac38-487d8bdc6a0c	disk_usage	gauge	45.200000	{}	2025-08-30 23:05:38.4+00
e7ffd54e-c7ce-408e-9fb8-c9d023c3381c	cpu_usage	gauge	8.000000	{}	2025-08-30 23:06:38.4+00
0bd2b81f-62f8-4337-9f6c-d2ff7d80639d	uptime	gauge	2049.260347	{}	2025-08-30 23:07:38.401+00
dc0ab48d-194e-4654-9d1e-88fac0b22c0a	disk_usage	gauge	45.200000	{}	2025-08-30 23:08:38.401+00
e99f58de-6a3f-4165-8d6b-cb455c13c42c	memory_usage	gauge	81.940000	{}	2025-08-30 23:09:38.402+00
4a12c1be-c88a-4744-bc93-06ed25150045	disk_usage	gauge	45.200000	{}	2025-08-30 23:10:38.402+00
0e13c80d-9756-4111-aebe-f25536560438	cpu_usage	gauge	8.000000	{}	2025-08-30 23:11:38.402+00
c1df733f-f7ca-4948-86fe-f8c300d96372	uptime	gauge	2349.262295	{}	2025-08-30 23:12:38.403+00
3f1eb526-6d96-40da-bc55-104f5822f566	disk_usage	gauge	45.200000	{}	2025-08-30 23:13:38.403+00
614f6e31-e12f-49c3-a354-42a66e8eae98	cpu_usage	gauge	8.000000	{}	2025-08-30 23:14:38.403+00
579fa0a4-c82a-4bb2-b3e2-bf834adeca9c	uptime	gauge	2529.262486	{}	2025-08-30 23:15:38.403+00
d6213591-112e-480c-ad73-9ff835ed844e	cpu_usage	gauge	8.000000	{}	2025-08-30 23:16:38.404+00
25210cc2-1a74-4b10-b1e0-1d4f481fdc2c	uptime	gauge	2649.264072	{}	2025-08-30 23:17:38.405+00
7f18d073-fc7a-4b76-8590-5b62bc7c14d2	cpu_usage	gauge	8.000000	{}	2025-08-30 23:18:38.406+00
bd3919cd-f100-4c0e-ae7a-3ea4c6d739c8	uptime	gauge	2769.265973	{}	2025-08-30 23:19:38.407+00
5ea10dc0-78c8-42fe-aa57-ce0389e1679f	disk_usage	gauge	45.200000	{}	2025-08-30 23:20:38.408+00
50cf32eb-a16e-4506-9ba3-adcbc57af961	disk_usage	gauge	45.200000	{}	2025-08-30 23:21:38.408+00
9a6fbe4a-46f0-42b1-96dc-daf99f6bdead	cpu_usage	gauge	8.000000	{}	2025-08-30 23:22:38.408+00
266c31cc-f05d-49d3-a8c2-a1fa794a81af	uptime	gauge	3009.267829	{}	2025-08-30 23:23:38.408+00
50a10597-3fbb-430f-a156-cf5640a5e7cd	memory_usage	gauge	82.410000	{}	2025-08-30 23:24:38.409+00
07bbff1a-1e29-4ccd-91bf-957c596325dc	cpu_usage	gauge	8.000000	{}	2025-08-30 23:25:38.409+00
2e88b59c-a648-469b-9484-53fac8e3c485	uptime	gauge	3189.268361	{}	2025-08-30 23:26:38.409+00
00794dc5-e889-4a45-8aea-eb8a86ca43b6	disk_usage	gauge	45.200000	{}	2025-08-30 23:27:38.409+00
6dc57273-9ff9-49ee-94eb-f6610711ba76	cpu_usage	gauge	8.000000	{}	2025-08-30 23:28:38.409+00
704b91aa-d3f9-42c6-986d-1fd44bdc8ab3	disk_usage	gauge	45.200000	{}	2025-08-30 23:29:38.41+00
dbdbf7fa-9eb3-454f-b6c2-3f3f8cf41a09	disk_usage	gauge	45.200000	{}	2025-08-30 23:30:38.41+00
206c93d2-a6bf-4589-ad58-8e01b92a19f6	cpu_usage	gauge	8.000000	{}	2025-08-30 23:31:38.41+00
65aa6634-e98a-4b52-8dcb-14818b74cd29	uptime	gauge	3549.269231	{}	2025-08-30 23:32:38.41+00
fd0a5e81-1dae-4c4c-8d13-3c04686d84d3	memory_usage	gauge	80.080000	{}	2025-08-31 00:53:49.57+00
27d5106f-765f-4347-87d0-4b6690d7ba49	disk_usage	gauge	45.200000	{}	2025-08-31 00:53:49.571+00
4cbfb96f-642e-4c6e-b463-6fae8b1917cb	uptime	gauge	69.956642	{}	2025-08-31 00:53:49.571+00
899b60d8-ccaf-4249-bc0d-a1d5c5b19659	uptime	gauge	129.955774	{}	2025-08-31 00:54:49.57+00
0e143e5b-03a7-47b9-bf71-783bbc8d272b	uptime	gauge	128.732276	{}	2025-08-31 01:15:47.683+00
e6df9209-6c76-45dd-99c5-c5ab707faf5e	disk_usage	gauge	45.200000	{}	2025-08-31 01:16:47.683+00
14f1e46d-00d2-4aea-9598-e51ba50c3e4d	disk_usage	gauge	45.200000	{}	2025-08-31 01:17:47.685+00
8ac50b75-2216-412c-a044-eef13db3e6c8	uptime	gauge	308.740561	{}	2025-08-31 01:18:47.691+00
3abcdaa7-c74a-46ba-b659-2933d49a7fee	disk_usage	gauge	45.200000	{}	2025-08-31 01:19:47.692+00
50ac57a6-4a73-4908-a8c2-9bdf9820e7b8	disk_usage	gauge	45.200000	{}	2025-08-31 01:20:47.692+00
78dea260-84e9-42fa-9305-1572a396d305	memory_usage	gauge	76.620000	{}	2025-08-31 01:21:47.692+00
27425f95-f20e-4990-91db-bf7f94e8c8a2	disk_usage	gauge	45.200000	{}	2025-08-31 01:22:47.692+00
bfdf062b-bf81-4272-998f-e804f4f9794a	disk_usage	gauge	45.200000	{}	2025-08-31 01:24:47.692+00
a9429d33-ea79-41d0-a2c5-ae2977301b4a	cpu_usage	gauge	8.000000	{}	2025-08-31 01:27:47.693+00
72d55a3e-badb-43dc-ae30-37f8abc9660b	uptime	gauge	908.742380	{}	2025-08-31 01:28:47.693+00
25cd65e0-d930-4392-ac83-7c1867a3e43c	uptime	gauge	6128.725307	{}	2025-08-30 21:58:22.905+00
5c9716f1-6031-4816-bada-fc817c3a10c5	memory_usage	gauge	66.240000	{}	2025-08-30 21:59:22.905+00
89d6de2c-5b1b-4965-841e-dbdec2a65db1	cpu_usage	gauge	8.000000	{}	2025-08-30 22:00:22.906+00
4d54d933-f5fd-468b-980b-e4b78ff594c7	uptime	gauge	6308.727442	{}	2025-08-30 22:01:22.907+00
37ed3b56-7187-445e-aa8f-12f2aadfa1c4	disk_usage	gauge	45.200000	{}	2025-08-30 22:02:22.907+00
9ce4a8ae-77bd-444b-8d06-932ebd917554	memory_usage	gauge	65.940000	{}	2025-08-30 22:03:22.908+00
1a074c1d-7996-47ee-ba7d-c17dc464cb1b	memory_usage	gauge	66.090000	{}	2025-08-30 22:04:22.909+00
4b9f10fe-39f4-4104-b256-9ffd97fdad19	memory_usage	gauge	66.150000	{}	2025-08-30 22:05:22.909+00
1d0eb7f8-6fc6-43aa-b85b-aedc9c3fd340	cpu_usage	gauge	8.000000	{}	2025-08-30 22:06:22.908+00
e3bb9d00-e3c8-4745-8f21-7780ff348d1b	uptime	gauge	6668.729981	{}	2025-08-30 22:07:22.91+00
7cbd07c0-b880-4454-bc19-4e4c10096059	disk_usage	gauge	45.200000	{}	2025-08-30 22:08:22.91+00
57dc297d-8dba-4e5c-9984-91ae139218b6	cpu_usage	gauge	8.000000	{}	2025-08-30 22:09:22.912+00
9c9fccd7-6a74-4d42-896e-6f42cde22370	uptime	gauge	6848.732417	{}	2025-08-30 22:10:22.912+00
1646b3b7-3f33-48e6-a03d-012e2342b946	disk_usage	gauge	45.200000	{}	2025-08-30 22:11:22.914+00
b4f768a4-9895-4dd9-b5bd-27908b6da1ad	memory_usage	gauge	66.350000	{}	2025-08-30 22:12:22.915+00
bf899538-9513-43b1-8e8b-a55352628660	cpu_usage	gauge	8.000000	{}	2025-08-30 22:13:22.916+00
1b3c5ba7-237a-4f46-87c9-5913ef65f508	uptime	gauge	7088.737323	{}	2025-08-30 22:14:22.917+00
2cb7e252-c56c-4217-8714-38215135d29f	memory_usage	gauge	66.650000	{}	2025-08-30 22:15:22.917+00
e406f533-3f70-4596-ae91-fc614153ec8a	memory_usage	gauge	66.650000	{}	2025-08-30 22:16:22.917+00
6fa73c55-5c2b-4151-a97e-8f4710f2a2aa	disk_usage	gauge	45.200000	{}	2025-08-30 22:17:22.918+00
6bdc96fa-47b9-4123-b453-2b36b4ba6cfc	disk_usage	gauge	45.200000	{}	2025-08-30 22:18:22.918+00
15df6804-d726-438a-a87e-8cbc1c981ef7	memory_usage	gauge	66.380000	{}	2025-08-30 22:19:22.918+00
93aa0f5a-a27d-42b9-a216-e67b9128958c	uptime	gauge	7448.739517	{}	2025-08-30 22:20:22.919+00
f2e9825d-ba04-4820-a594-9956fd0e9bad	memory_usage	gauge	66.180000	{}	2025-08-30 22:21:22.92+00
0dffcb32-8fc6-4517-9891-a1981a4bcd5c	cpu_usage	gauge	8.000000	{}	2025-08-30 22:22:22.921+00
307dbe92-d7b5-4053-89ff-d1708c87cded	uptime	gauge	7628.741660	{}	2025-08-30 22:23:22.921+00
94cdcaaf-ff34-4b90-b483-bad9a6bdc5e5	disk_usage	gauge	45.200000	{}	2025-08-30 22:24:22.922+00
1d4ff7e1-e853-4075-b4ef-3f3e153bd3c5	cpu_usage	gauge	8.000000	{}	2025-08-30 22:25:22.922+00
dfecc40c-d2fb-44fd-8c6e-73949a3e8d8e	uptime	gauge	1569.257213	{}	2025-08-30 22:59:38.398+00
7dee2cea-ec37-4612-812a-da299676568b	disk_usage	gauge	45.200000	{}	2025-08-30 23:00:38.399+00
16aa31c5-2053-4c13-8494-2b2519c3faf2	disk_usage	gauge	45.200000	{}	2025-08-30 23:01:38.4+00
11aa4a39-b027-4c60-b9df-fed220c40242	memory_usage	gauge	81.820000	{}	2025-08-30 23:02:38.4+00
335aea71-263b-49e7-af86-864aeab3dd34	uptime	gauge	1809.258905	{}	2025-08-30 23:03:38.4+00
a4a133fc-b0a2-488a-bc7b-f128c88cb2da	disk_usage	gauge	45.200000	{}	2025-08-30 23:04:38.4+00
4cb4e813-f78d-4dc6-8c77-547b59b32e91	cpu_usage	gauge	8.000000	{}	2025-08-30 23:05:38.4+00
ce1696a2-869c-4f42-b686-56ddd9b3ada5	uptime	gauge	1989.259533	{}	2025-08-30 23:06:38.4+00
3ed7410a-3919-45d1-9dde-db9bee078d29	cpu_usage	gauge	8.000000	{}	2025-08-30 23:07:38.401+00
ac9f8cb6-8b7a-42b7-86de-f15b4774d6f8	uptime	gauge	2109.260749	{}	2025-08-30 23:08:38.401+00
c6344439-0917-4972-b6e1-aaac1828c384	disk_usage	gauge	45.200000	{}	2025-08-30 23:09:38.402+00
6e068caf-1337-473c-931a-b5cea65cfb61	cpu_usage	gauge	8.000000	{}	2025-08-30 23:10:38.402+00
09e24125-ae87-4504-9182-2176f49d7a76	uptime	gauge	2289.261352	{}	2025-08-30 23:11:38.402+00
d4cd5ca4-658f-4749-af70-338db5217a30	disk_usage	gauge	45.200000	{}	2025-08-30 23:12:38.403+00
7dd3a28f-efb7-4007-96a6-b5813dc8973a	memory_usage	gauge	82.090000	{}	2025-08-30 23:13:38.403+00
5e895965-82b4-40c6-89b7-a84fcbd648f1	memory_usage	gauge	82.530000	{}	2025-08-30 23:14:38.404+00
78501785-811d-4735-95ff-b8c8555e4f93	memory_usage	gauge	82.310000	{}	2025-08-30 23:15:38.403+00
58f800e7-f3f8-4e8e-944e-15e8824c0992	uptime	gauge	2589.263394	{}	2025-08-30 23:16:38.404+00
07dbf0ae-440f-4cd8-beb5-e4207b44a204	disk_usage	gauge	45.200000	{}	2025-08-30 23:17:38.405+00
68f593be-2224-4d86-81e3-0749608a4c7c	memory_usage	gauge	83.100000	{}	2025-08-30 23:18:38.406+00
4f7e0df6-1ac9-46cd-ae90-c1728ffcf4f5	memory_usage	gauge	83.150000	{}	2025-08-30 23:19:38.407+00
d585a0d2-06d8-41e0-bdbc-e92296b8438e	memory_usage	gauge	83.090000	{}	2025-08-30 23:20:38.408+00
c7779db9-7924-4cfe-91c1-e0eaf84db171	cpu_usage	gauge	8.000000	{}	2025-08-30 23:21:38.408+00
85f9822a-1365-40b7-aca3-e104dd555556	uptime	gauge	2949.267758	{}	2025-08-30 23:22:38.408+00
8e7b9b13-9309-4c85-bee3-d4a3ffdb0e08	memory_usage	gauge	82.860000	{}	2025-08-30 23:23:38.408+00
1249f093-c80f-4fc6-aaec-c12004d8cf56	cpu_usage	gauge	8.000000	{}	2025-08-30 23:24:38.409+00
d19dcf3b-a453-4b94-95f5-548782039ae0	uptime	gauge	3129.269518	{}	2025-08-30 23:25:38.41+00
044e072e-c292-4efc-b3a9-0c344d7868c1	disk_usage	gauge	45.200000	{}	2025-08-30 23:26:38.409+00
2250e95e-a5e8-49cd-bee8-9ff35ea1d5d9	cpu_usage	gauge	8.000000	{}	2025-08-30 23:27:38.409+00
03778cec-169f-4198-b6c4-3f14ed487e57	uptime	gauge	3309.268462	{}	2025-08-30 23:28:38.409+00
ced73673-8f07-4518-9752-320cfdccdb61	cpu_usage	gauge	8.000000	{}	2025-08-30 23:29:38.41+00
291168cb-37c6-4511-bed0-0f7e114ab24e	uptime	gauge	3429.268907	{}	2025-08-30 23:30:38.41+00
2f0a24e5-9a68-4566-be5f-a8354c8a026e	disk_usage	gauge	45.200000	{}	2025-08-30 23:31:38.41+00
0e723dab-7f64-4656-834e-86dbf0969fd6	memory_usage	gauge	82.590000	{}	2025-08-30 23:32:38.41+00
a6cf186f-2c5a-4739-b7d9-88be8bc636d9	memory_usage	gauge	81.420000	{}	2025-08-31 00:54:49.569+00
a4c0dbe1-21b8-4489-8e8c-b3ba0c494cfa	cpu_usage	gauge	8.000000	{}	2025-08-31 01:18:47.691+00
03611013-5790-471d-a27b-bee770e667f2	cpu_usage	gauge	8.000000	{}	2025-08-31 01:19:47.691+00
e2b104f1-1e81-467c-9f0d-6fc137618720	uptime	gauge	428.741909	{}	2025-08-31 01:20:47.692+00
b21dabbe-f298-4e2e-b526-80b2431984cd	cpu_usage	gauge	8.000000	{}	2025-08-31 01:21:47.692+00
4c9e4633-8929-45a9-995d-f103a1f9e103	uptime	gauge	548.741453	{}	2025-08-31 01:22:47.692+00
fbf5ef17-3b23-42a9-9d85-a4c1b1b35cf0	memory_usage	gauge	77.430000	{}	2025-08-31 01:25:47.693+00
875bea5b-d3f1-46ac-9811-14f853849b11	uptime	gauge	788.742525	{}	2025-08-31 01:26:47.693+00
c30c8787-7793-44ab-9a2a-ceba7ba78834	cpu_usage	gauge	8.000000	{}	2025-08-30 22:26:22.922+00
d960cbdb-f693-4bc1-9aef-71314126d350	uptime	gauge	7868.744105	{}	2025-08-30 22:27:22.924+00
3237c0cc-bc8d-47c4-8b32-7139a04cb49b	cpu_usage	gauge	7.000000	{}	2025-08-30 22:28:22.925+00
06e0a8e6-85f8-4f84-9702-91b665da1b7b	uptime	gauge	7988.746445	{}	2025-08-30 22:29:22.926+00
4cd99d6b-61a2-4c77-b749-2d6870a4492f	cpu_usage	gauge	8.000000	{}	2025-08-30 23:33:38.411+00
5fe652cc-5153-49bd-9beb-f3965514a53c	uptime	gauge	3669.270491	{}	2025-08-30 23:34:38.411+00
5e26ecb4-6de2-4b6e-8e46-bfe8f959cfa8	memory_usage	gauge	82.680000	{}	2025-08-30 23:35:38.412+00
077a7930-f723-4d65-be85-7a60a1f7b2e7	disk_usage	gauge	45.200000	{}	2025-08-30 23:36:38.413+00
d537bdfb-8d6c-48fc-b504-ff7de8df4fb4	cpu_usage	gauge	8.000000	{}	2025-08-30 23:37:38.413+00
c4057dda-1d57-4784-8720-c16ad776f0da	uptime	gauge	3909.273697	{}	2025-08-30 23:38:38.414+00
635f7de8-900e-4744-b0fb-4cf0ce2fc85f	disk_usage	gauge	45.200000	{}	2025-08-30 23:39:38.414+00
13e52270-140f-49b6-b476-f721a8a29126	disk_usage	gauge	45.200000	{}	2025-08-30 23:40:38.415+00
50aa90d4-2e2d-454e-b50c-e7236caa5448	memory_usage	gauge	83.000000	{}	2025-08-30 23:41:38.415+00
f7a17112-38f2-42f2-9f66-6c93c2a5c926	uptime	gauge	4149.274893	{}	2025-08-30 23:42:38.416+00
5424371e-5375-4b11-8b6d-3177457f6f2c	memory_usage	gauge	82.980000	{}	2025-08-30 23:43:38.414+00
e6a4cea4-f238-40a1-bb2e-0743dac03857	disk_usage	gauge	45.200000	{}	2025-08-30 23:44:38.416+00
50c229d7-b7ce-4ed9-8182-f2234a0174cc	cpu_usage	gauge	8.000000	{}	2025-08-30 23:45:38.417+00
8527ab73-fc01-4fd1-9273-17fbbe47fc21	uptime	gauge	4389.277981	{}	2025-08-30 23:46:38.419+00
074654d6-2472-4877-9c13-abb9fe90d590	disk_usage	gauge	45.200000	{}	2025-08-30 23:47:38.419+00
dd990a14-c9ed-4150-b6ab-a7f9040317e2	disk_usage	gauge	45.200000	{}	2025-08-30 23:48:38.42+00
d16de92f-479d-4c57-9cea-19cf0fb13807	disk_usage	gauge	45.200000	{}	2025-08-30 23:49:38.421+00
3207f12c-991b-4b06-8732-0e066104f495	memory_usage	gauge	82.530000	{}	2025-08-30 23:50:38.42+00
a741981d-a903-48db-aa16-6d3f7582b8e5	uptime	gauge	4689.280065	{}	2025-08-30 23:51:38.421+00
a18e1590-70cf-41fe-9ec9-32c58c5293b5	disk_usage	gauge	45.200000	{}	2025-08-30 23:52:38.423+00
38fbcf3c-60d8-4ac7-8557-48323da28b11	cpu_usage	gauge	8.000000	{}	2025-08-30 23:53:38.424+00
6d00195d-9053-415f-b5ef-04c2cdf6eeed	uptime	gauge	4869.284349	{}	2025-08-30 23:54:38.425+00
7adcae0b-27c1-4c85-affd-97fa83052bf1	disk_usage	gauge	45.200000	{}	2025-08-30 23:55:38.426+00
98eab4fa-0217-47b4-9356-29d793ee009a	memory_usage	gauge	82.660000	{}	2025-08-30 23:56:38.427+00
84a3cef5-c355-4b5e-8e13-d8d308f62ea8	memory_usage	gauge	82.830000	{}	2025-08-30 23:57:38.428+00
f777c62a-84c4-44b9-9032-572db2e27b01	cpu_usage	gauge	8.000000	{}	2025-08-30 23:58:38.429+00
6e51bbe4-7cbb-4d68-a92b-f7ccf2311318	uptime	gauge	5169.289015	{}	2025-08-30 23:59:38.43+00
4eaea63e-9f41-4e5c-82cb-2e41add38d97	disk_usage	gauge	45.200000	{}	2025-08-31 00:00:38.431+00
2285eab6-2326-4b48-8efb-1718d7070607	memory_usage	gauge	83.060000	{}	2025-08-31 00:01:38.431+00
18e58da1-1d71-4186-aa25-5231f469317b	memory_usage	gauge	82.840000	{}	2025-08-31 00:02:38.431+00
8b8e5b44-f70b-481b-b0ec-aaed0176c7a7	disk_usage	gauge	45.200000	{}	2025-08-31 00:03:38.431+00
857174c6-f478-496e-adb0-52e3a3f24cbc	cpu_usage	gauge	8.000000	{}	2025-08-31 00:04:38.431+00
1f6da024-7e2e-4e26-b937-fa68e26ba626	disk_usage	gauge	45.200000	{}	2025-08-31 00:05:38.432+00
585b2d33-6bdf-440c-aa11-c62900e4b31f	cpu_usage	gauge	8.000000	{}	2025-08-31 00:06:38.432+00
9de3f2eb-ab92-45f8-b4f2-38adc1c477ed	uptime	gauge	5649.291762	{}	2025-08-31 00:07:38.432+00
410a3fdb-1aa8-47b2-ba32-9aca440dbbcd	disk_usage	gauge	45.200000	{}	2025-08-31 00:08:38.434+00
75c3baea-bc51-4cc4-a52a-be3dff013223	memory_usage	gauge	82.880000	{}	2025-08-31 00:09:38.434+00
3ab0f540-a444-4363-bc73-961c53effa80	cpu_usage	gauge	8.000000	{}	2025-08-31 00:54:49.569+00
1c01724e-6280-4912-a4a8-c3497350ccbc	memory_usage	gauge	79.050000	{}	2025-08-31 01:18:47.691+00
4b408b6e-d568-4245-b576-6c039260fc16	memory_usage	gauge	79.330000	{}	2025-08-31 01:19:47.692+00
6f23617b-b991-4f24-8ab0-87c435c5d771	memory_usage	gauge	79.270000	{}	2025-08-31 01:20:47.692+00
6f2d1564-c81a-48bd-9cb6-c11b7f988753	memory_usage	gauge	78.130000	{}	2025-08-31 01:22:47.692+00
552cbe5b-2cbe-4d91-9600-550462147f22	cpu_usage	gauge	8.000000	{}	2025-08-31 01:23:47.692+00
c0ab7025-572f-48dc-aa34-c3339924a28e	cpu_usage	gauge	8.000000	{}	2025-08-31 01:24:47.692+00
5572a171-1591-458b-9cdd-2c3c74f5975e	cpu_usage	gauge	8.000000	{}	2025-08-31 01:25:47.692+00
b035ab05-7e94-49af-a44b-41ca0d6550dd	disk_usage	gauge	45.200000	{}	2025-08-31 01:26:47.693+00
c9f761bc-b99c-41da-b7ea-104f9de684ce	memory_usage	gauge	66.060000	{}	2025-08-30 22:26:22.922+00
d4f70780-f413-41e2-8911-41e2bbcc07d1	memory_usage	gauge	66.190000	{}	2025-08-30 22:27:22.924+00
03e3519c-e2d0-407b-9def-24ae72f9c6e2	memory_usage	gauge	66.240000	{}	2025-08-30 22:28:22.925+00
e22c64d9-3136-485c-beb2-eabd3332e7ef	cpu_usage	gauge	7.000000	{}	2025-08-30 22:29:22.926+00
4c4ad9ef-aba9-46a9-b9cc-451f8b5edb7f	memory_usage	gauge	82.890000	{}	2025-08-30 23:33:38.411+00
6f316cf8-5732-45cc-aa17-0f063d20efc4	disk_usage	gauge	45.200000	{}	2025-08-30 23:34:38.411+00
bb22374a-2cfb-4b20-bcc6-71852c9644dc	disk_usage	gauge	45.200000	{}	2025-08-30 23:35:38.412+00
a186dee5-7e65-4dee-89a4-d6aeaba867b0	memory_usage	gauge	82.690000	{}	2025-08-30 23:36:38.413+00
4acefa66-5884-490b-96db-83a2dca0c242	memory_usage	gauge	82.600000	{}	2025-08-30 23:37:38.413+00
d3824e7e-b687-460d-ad06-732de9478203	cpu_usage	gauge	8.000000	{}	2025-08-30 23:38:38.414+00
0f02a314-12aa-48ef-b851-af00fedb1e0c	cpu_usage	gauge	8.000000	{}	2025-08-30 23:39:38.414+00
d137d2bb-5bf0-43a2-8e4d-e6183acaa0b3	uptime	gauge	4029.273918	{}	2025-08-30 23:40:38.415+00
f852574a-69a8-4c0c-84a6-e818113f4fe9	disk_usage	gauge	45.200000	{}	2025-08-30 23:41:38.415+00
eeb96c35-e6e7-404d-a8f4-c5e6fdf8d950	disk_usage	gauge	45.200000	{}	2025-08-30 23:42:38.416+00
bb3a24c4-9868-48a0-9999-affdf92a5317	cpu_usage	gauge	8.000000	{}	2025-08-30 23:43:38.414+00
a4bb1434-4c9c-4c6a-8e80-2e99221f19f1	uptime	gauge	4269.274977	{}	2025-08-30 23:44:38.416+00
d36b8a4a-74bf-416d-ae93-6a4e604b0c51	disk_usage	gauge	45.200000	{}	2025-08-30 23:45:38.417+00
854ebbf1-796f-4f40-830a-76a1d1c5deed	cpu_usage	gauge	8.000000	{}	2025-08-30 23:46:38.419+00
b1c0362f-2a53-4da2-8c2c-9b1588a75879	uptime	gauge	4449.278281	{}	2025-08-30 23:47:38.419+00
46ded83e-00b8-4ff2-8eaa-57b2a0340b18	cpu_usage	gauge	8.000000	{}	2025-08-30 23:48:38.42+00
a1c45bd0-408b-4c6e-8533-5f86f7b54a08	uptime	gauge	4569.279914	{}	2025-08-30 23:49:38.421+00
9c001da1-e26a-4fbb-8f7a-02936bf56a83	cpu_usage	gauge	8.000000	{}	2025-08-30 23:50:38.42+00
e7a66129-40db-4d07-a78f-d23984a8e28a	cpu_usage	gauge	8.000000	{}	2025-08-30 23:51:38.421+00
5081a540-0473-43a0-a316-08fb327fc863	uptime	gauge	4749.282359	{}	2025-08-30 23:52:38.423+00
79e81372-7ecb-4c63-a801-986f07972e81	disk_usage	gauge	45.200000	{}	2025-08-30 23:53:38.424+00
db6dbde8-b9fe-4c74-8a38-9c36e4d2fd4b	disk_usage	gauge	45.200000	{}	2025-08-30 23:54:38.425+00
6be3a637-857d-4724-b301-a045da24aacb	memory_usage	gauge	82.680000	{}	2025-08-30 23:55:38.426+00
2f9af612-8683-41ce-b4b1-80da250b6ce7	uptime	gauge	4989.286287	{}	2025-08-30 23:56:38.427+00
69249d2a-33aa-4537-8c1c-d0ee65cfacc2	disk_usage	gauge	45.200000	{}	2025-08-30 23:57:38.428+00
ef2c5a17-7f73-4f22-bc9f-b9cec0dac992	memory_usage	gauge	82.380000	{}	2025-08-30 23:58:38.429+00
b4b8284a-8e73-4304-a9da-cdd53f6c2f1b	cpu_usage	gauge	8.000000	{}	2025-08-30 23:59:38.43+00
a960fadd-e524-4c21-a19b-4a73047b0b29	uptime	gauge	5229.290511	{}	2025-08-31 00:00:38.431+00
54258748-bc4c-430b-be57-138d24da40de	cpu_usage	gauge	8.000000	{}	2025-08-31 00:01:38.431+00
fa1f10fe-465e-46b0-ab10-22553eed2db3	uptime	gauge	5349.290608	{}	2025-08-31 00:02:38.431+00
0ed16f52-179c-4f7a-85a3-206ef0fe7ca6	memory_usage	gauge	82.920000	{}	2025-08-31 00:03:38.431+00
279f1933-7df4-4775-be6d-d78a526579dd	disk_usage	gauge	45.200000	{}	2025-08-31 00:04:38.432+00
e2d6afc6-9c00-434e-8ce1-060cc5a4dc7b	memory_usage	gauge	82.820000	{}	2025-08-31 00:05:38.432+00
d97bc68a-f279-4d33-918b-6ea191948f29	memory_usage	gauge	82.910000	{}	2025-08-31 00:06:38.432+00
95f961ff-8ec5-4656-a0bd-e7f2b3d4aea9	memory_usage	gauge	83.110000	{}	2025-08-31 00:07:38.432+00
673e4dfb-f59c-4f73-8331-3ed2bf348a46	memory_usage	gauge	82.940000	{}	2025-08-31 00:08:38.433+00
ff8a7651-b710-4226-8b09-80e182fca356	cpu_usage	gauge	8.000000	{}	2025-08-31 00:09:38.434+00
1b5a9f58-c7c9-4289-ac62-95c62c43116e	disk_usage	gauge	45.200000	{}	2025-08-31 00:54:49.57+00
a3fe4327-cab0-4850-a025-1078cd10244f	memory_usage	gauge	78.340000	{}	2025-08-31 01:27:47.693+00
74339c68-bdc8-4d6a-a575-0df910d54a63	cpu_usage	gauge	8.000000	{}	2025-08-31 01:28:47.693+00
f8ceaa42-c9ae-4e54-a6bd-0ee78ea6a328	disk_usage	gauge	45.200000	{}	2025-08-30 22:26:22.923+00
35d19142-2fed-498c-a492-e87f4dcb5963	cpu_usage	gauge	8.000000	{}	2025-08-30 22:27:22.924+00
71a7852a-8140-42a0-8fa0-6fdebc4f48c7	uptime	gauge	7928.745611	{}	2025-08-30 22:28:22.925+00
74de7ce1-4528-42ea-9e8f-832da75c97ef	memory_usage	gauge	66.290000	{}	2025-08-30 22:29:22.926+00
3ead6fbf-d9ea-47f7-a48b-543a65648a28	memory_usage	gauge	66.830000	{}	2025-08-30 22:30:22.926+00
2be1587f-f5b5-41f7-8dc2-4ca2de4dbd53	uptime	gauge	8108.748290	{}	2025-08-30 22:31:22.928+00
4d0a8423-03a5-4f00-bbca-8d130fc3210e	disk_usage	gauge	45.200000	{}	2025-08-30 23:33:38.411+00
871e5f52-8e7a-4627-921a-1237b168c3f8	cpu_usage	gauge	8.000000	{}	2025-08-30 23:34:38.411+00
b0306f8c-71be-4317-bed6-8c0f6bc2ed19	uptime	gauge	3729.271713	{}	2025-08-30 23:35:38.412+00
20add937-2db0-461b-ae09-5d268f4da68f	cpu_usage	gauge	8.000000	{}	2025-08-30 23:36:38.412+00
75492d0f-b6fa-4487-b3fe-8d56640d9fef	uptime	gauge	3849.271961	{}	2025-08-30 23:37:38.413+00
a2cf5d3d-8e2b-4d5f-acdc-22054a246d0d	disk_usage	gauge	45.200000	{}	2025-08-30 23:38:38.414+00
7b20955e-b765-4d21-aace-d13114f5cd04	memory_usage	gauge	82.750000	{}	2025-08-30 23:39:38.414+00
4643df79-081a-41bf-8d2d-4aed8e1f43bf	cpu_usage	gauge	8.000000	{}	2025-08-30 23:40:38.414+00
75bca8c8-3513-425e-ab96-ef2f830fcc7f	uptime	gauge	4089.274744	{}	2025-08-30 23:41:38.415+00
1d61f70c-1ea0-4d24-999a-81d49c05c537	cpu_usage	gauge	8.000000	{}	2025-08-30 23:42:38.415+00
0f4ab111-4f4d-45ea-a24f-27a556cb0424	uptime	gauge	4209.273858	{}	2025-08-30 23:43:38.415+00
1c7fd492-224c-41dd-913a-a4493e0276db	memory_usage	gauge	82.940000	{}	2025-08-30 23:44:38.416+00
5f2be423-f59b-4988-9825-e1fa84ddb44c	memory_usage	gauge	82.840000	{}	2025-08-30 23:45:38.417+00
480c2c6e-9f16-4d85-bcc0-45552dd35d45	disk_usage	gauge	45.200000	{}	2025-08-30 23:46:38.419+00
3ac428a8-ecae-40b7-a805-1c08c049e300	cpu_usage	gauge	8.000000	{}	2025-08-30 23:47:38.419+00
6eb35967-0f56-4e9f-826f-dea0f0a367a8	uptime	gauge	4509.279550	{}	2025-08-30 23:48:38.42+00
0e1e009a-ee25-47f0-b37f-c5bb3cf59a2f	memory_usage	gauge	82.560000	{}	2025-08-30 23:49:38.421+00
042db9d6-d3b9-4e67-b797-941f154ed1df	disk_usage	gauge	45.200000	{}	2025-08-30 23:50:38.421+00
b1752a3e-6291-4ff7-a524-c517e24d8a60	memory_usage	gauge	82.430000	{}	2025-08-30 23:51:38.421+00
a386fd83-25c0-4f83-aae6-c11563bb4315	cpu_usage	gauge	8.000000	{}	2025-08-30 23:52:38.423+00
4699173b-cfc3-4a35-a254-ca73a1793ff2	uptime	gauge	4809.283442	{}	2025-08-30 23:53:38.424+00
0c1db026-70d6-45af-82fe-0f0c427fada2	cpu_usage	gauge	8.000000	{}	2025-08-30 23:54:38.425+00
c8c926a0-9fbd-479d-a59a-f579645d1c92	uptime	gauge	4929.285071	{}	2025-08-30 23:55:38.426+00
3f814edf-0fd2-46da-ac1a-6c997f11efe5	disk_usage	gauge	45.200000	{}	2025-08-30 23:56:38.427+00
cc5cc2f5-c750-4118-942f-671fcaf62301	cpu_usage	gauge	8.000000	{}	2025-08-30 23:57:38.428+00
a2931526-623f-4a14-b4d6-ec5fc717f250	uptime	gauge	5109.288425	{}	2025-08-30 23:58:38.429+00
744127f4-6d39-45ac-8c3c-de8d5e1f8c1b	disk_usage	gauge	45.200000	{}	2025-08-30 23:59:38.43+00
ceb55864-0e74-4d2a-89a9-47a356f218fa	memory_usage	gauge	83.030000	{}	2025-08-31 00:00:38.431+00
d75b5f00-5917-41e7-a204-0b62e56cbcdc	disk_usage	gauge	45.200000	{}	2025-08-31 00:01:38.431+00
fe3049f6-639c-4558-8523-a2a28fd7c289	cpu_usage	gauge	8.000000	{}	2025-08-31 00:02:38.431+00
0c3aea1d-af5d-4571-963f-23f85cc1e71e	uptime	gauge	5409.290435	{}	2025-08-31 00:03:38.431+00
8f292f9d-b8dd-4224-b481-5591ae747f4a	memory_usage	gauge	82.890000	{}	2025-08-31 00:04:38.431+00
b97f7695-27ab-4333-a669-6d45692c73f5	uptime	gauge	5529.291301	{}	2025-08-31 00:05:38.432+00
dbb0ab30-2702-4e48-b79e-e28d1f574b02	disk_usage	gauge	45.200000	{}	2025-08-31 00:06:38.432+00
8c20a03e-7aa8-4818-8348-88350e6393d9	cpu_usage	gauge	8.000000	{}	2025-08-31 00:07:38.432+00
dc0967e7-24db-4c79-a34d-890577d8f0f6	uptime	gauge	5709.292869	{}	2025-08-31 00:08:38.434+00
9f173b58-6d95-4300-a8de-e9ae5e7e0d52	disk_usage	gauge	45.200000	{}	2025-08-31 00:09:38.434+00
0a62b14c-b090-485e-bbae-8e6ec304802b	memory_usage	gauge	79.590000	{}	2025-08-31 00:55:04.842+00
324904b1-4fa2-4c2b-8d69-8db8ad7dc672	disk_usage	gauge	45.200000	{}	2025-08-31 00:56:04.843+00
1f7c1a86-8c45-4b54-9531-d5e7d5c6781d	uptime	gauge	488.361074	{}	2025-08-31 00:57:04.842+00
1c4210d1-3dc1-499b-9486-3bb889a5e6a3	memory_usage	gauge	80.990000	{}	2025-08-31 00:58:04.842+00
c298b9e6-db6a-4e5f-ae17-9bff82e2ac3a	cpu_usage	gauge	8.000000	{}	2025-08-31 00:59:04.843+00
3fc6e840-577a-484b-aadf-15ee3d8330fe	disk_usage	gauge	45.200000	{}	2025-08-31 01:00:04.844+00
b8f27d4d-c08d-4fea-84b7-a2ae3070e0b8	cpu_usage	gauge	8.000000	{}	2025-08-31 01:31:01.619+00
49d6ba5c-323c-4e2f-8b99-2d4b1af4d064	uptime	gauge	128.237879	{}	2025-08-31 01:32:01.623+00
28ca4adf-d9be-4abd-ad0e-18c9b8923a79	uptime	gauge	188.236029	{}	2025-08-31 01:33:01.621+00
39dfd3d5-6653-4d30-b135-7df9e021f996	disk_usage	gauge	45.200000	{}	2025-08-31 01:34:01.621+00
4e6303b8-fdd7-4dd9-a7f4-06da45deff79	memory_usage	gauge	78.270000	{}	2025-08-31 01:35:01.628+00
3c6cf002-4d40-41aa-84ca-dd4b1d2e28cc	disk_usage	gauge	45.200000	{}	2025-08-31 01:36:01.629+00
108ced32-015f-4eea-9bea-4e5b24ee8b52	disk_usage	gauge	45.200000	{}	2025-08-31 01:37:01.63+00
f66456f0-9279-4624-a6eb-944c134469bf	cpu_usage	gauge	8.000000	{}	2025-08-31 01:38:01.631+00
9ae8e9b7-fe05-43ac-89e5-55600d03b355	uptime	gauge	548.247200	{}	2025-08-31 01:39:01.632+00
4283b2ec-c802-403a-894e-3e184ea09437	uptime	gauge	608.247592	{}	2025-08-31 01:40:01.633+00
2e1efd0f-2e6d-4593-85b1-f0272c3ec310	uptime	gauge	7808.742981	{}	2025-08-30 22:26:22.923+00
89b4a8a1-ac54-4855-bc1b-6260652ea9ca	disk_usage	gauge	45.200000	{}	2025-08-30 22:27:22.924+00
2f2604e5-c61d-4865-85ee-fcadc0083969	disk_usage	gauge	45.200000	{}	2025-08-30 22:28:22.925+00
24cd6d18-1504-4d11-a673-f9a5d1126e1a	disk_usage	gauge	45.200000	{}	2025-08-30 22:29:22.926+00
f74d22c5-f13b-420b-9adb-70611508a730	uptime	gauge	8048.746972	{}	2025-08-30 22:30:22.927+00
57dfa77d-b2fc-4c32-af1f-9a46c761c049	cpu_usage	gauge	8.000000	{}	2025-08-30 22:31:22.928+00
d2300360-1699-490f-99a5-086308d4cc97	uptime	gauge	3609.270046	{}	2025-08-30 23:33:38.411+00
804202dc-56ca-40a5-b399-d3f7d515a1f2	memory_usage	gauge	82.760000	{}	2025-08-30 23:34:38.411+00
fd5826a3-8c4c-40d9-8b0b-c478e2a38136	cpu_usage	gauge	8.000000	{}	2025-08-30 23:35:38.412+00
aa268dc0-9608-402f-a2f9-26b3e18f9e93	uptime	gauge	3789.271904	{}	2025-08-30 23:36:38.413+00
93392dca-53a5-4f61-b84f-c519ebcc137e	disk_usage	gauge	45.200000	{}	2025-08-30 23:37:38.413+00
0ad7312b-847d-4efe-b750-8a6299d78868	memory_usage	gauge	83.010000	{}	2025-08-30 23:38:38.414+00
2750e039-7a5f-419b-b7ac-c8038544eb21	uptime	gauge	3969.273773	{}	2025-08-30 23:39:38.414+00
d9dedd9a-c4be-4ed4-b047-17287481ff8d	memory_usage	gauge	82.980000	{}	2025-08-30 23:40:38.415+00
de2d81cd-862f-46f8-8383-d25c6a7200d7	cpu_usage	gauge	8.000000	{}	2025-08-30 23:41:38.415+00
1d05c8eb-1680-41f0-bdb0-3c17738afd5d	memory_usage	gauge	82.720000	{}	2025-08-30 23:42:38.415+00
f0717897-3096-4647-892f-ca71fc734814	disk_usage	gauge	45.200000	{}	2025-08-30 23:43:38.415+00
5600adac-027f-43dc-96b4-0c310411a258	cpu_usage	gauge	8.000000	{}	2025-08-30 23:44:38.416+00
f5e7442d-a0c7-42d5-998d-f9f0a6f8aeff	uptime	gauge	4329.276405	{}	2025-08-30 23:45:38.417+00
fa0b6b7a-ebc5-441c-9c3f-b2b6cb05491d	memory_usage	gauge	82.790000	{}	2025-08-30 23:46:38.419+00
b84c4b06-937f-4d2e-8946-c07861adfb6f	memory_usage	gauge	82.800000	{}	2025-08-30 23:47:38.419+00
52e1305a-53c5-43a6-bcfc-d241a8d50f97	memory_usage	gauge	82.800000	{}	2025-08-30 23:48:38.42+00
d5a4ed4e-aa9c-4a53-b777-d5c9f1a941e0	cpu_usage	gauge	8.000000	{}	2025-08-30 23:49:38.42+00
119420d0-17c8-40a4-81f5-9dd3e8b0186e	uptime	gauge	4629.280708	{}	2025-08-30 23:50:38.421+00
257a32f3-84b4-48be-9e8a-8a10eb90d6f2	disk_usage	gauge	45.200000	{}	2025-08-30 23:51:38.421+00
d86df6f6-6566-4560-a274-5621bbfe48eb	memory_usage	gauge	82.620000	{}	2025-08-30 23:52:38.423+00
0c22ab5e-e40e-4947-80ff-359c492fe9b2	memory_usage	gauge	82.600000	{}	2025-08-30 23:53:38.424+00
14cf2d20-1f70-4396-b55f-f372eb48e414	memory_usage	gauge	82.730000	{}	2025-08-30 23:54:38.425+00
a8ffe1cf-4f36-4587-8d66-1bd80ddfbb27	cpu_usage	gauge	8.000000	{}	2025-08-30 23:55:38.426+00
6fe2b732-2acf-43be-9631-836c93f9f295	cpu_usage	gauge	8.000000	{}	2025-08-30 23:56:38.427+00
3a8d66f8-4be8-4506-bf11-312d306c43a0	uptime	gauge	5049.287190	{}	2025-08-30 23:57:38.428+00
bf252412-9a3b-437d-9faa-f6212fa206e1	disk_usage	gauge	45.200000	{}	2025-08-30 23:58:38.429+00
8aa1ed36-6990-4720-a25d-5ca336056a82	memory_usage	gauge	82.740000	{}	2025-08-30 23:59:38.43+00
b3e7c855-b50f-444f-879c-7e7f4f3537e6	cpu_usage	gauge	8.000000	{}	2025-08-31 00:00:38.431+00
0df4b26a-a924-4b40-90b7-3a784cdfe7a2	uptime	gauge	5289.290538	{}	2025-08-31 00:01:38.431+00
0bb531fe-ff06-4549-80a6-16916bd42ab2	disk_usage	gauge	45.200000	{}	2025-08-31 00:02:38.431+00
3d298b1d-1672-4758-a4b0-802043c4d275	cpu_usage	gauge	8.000000	{}	2025-08-31 00:03:38.431+00
2d128ea0-9e51-42b3-8952-7b62ed2a56c0	uptime	gauge	5469.290853	{}	2025-08-31 00:04:38.432+00
d17e6869-43d2-4658-9312-6b58936e1369	cpu_usage	gauge	8.000000	{}	2025-08-31 00:05:38.432+00
5a0091e0-0f7d-45fe-b494-b5538bdc8058	uptime	gauge	5589.291270	{}	2025-08-31 00:06:38.432+00
46ac5017-9a64-4225-911d-45941cc5f349	disk_usage	gauge	45.200000	{}	2025-08-31 00:07:38.432+00
69bdab35-cca7-4d6e-8c85-66f2b89a9c9b	cpu_usage	gauge	8.000000	{}	2025-08-31 00:08:38.433+00
ce180565-6df0-490b-aee2-d5e7c2d10d4e	uptime	gauge	5769.293053	{}	2025-08-31 00:09:38.434+00
efbc4939-ab78-4185-8a50-a2691e1e4307	disk_usage	gauge	45.200000	{}	2025-08-31 00:55:04.842+00
3a5b35a7-f2c7-4b1e-ae03-81e718994ff1	cpu_usage	gauge	8.000000	{}	2025-08-31 00:56:04.843+00
a5a7dfe1-e088-46b3-bbb1-0d07579fa059	cpu_usage	gauge	8.000000	{}	2025-08-31 00:57:04.842+00
f13f7019-011d-4bc7-a0a5-1c340ec26e5a	cpu_usage	gauge	8.000000	{}	2025-08-31 00:58:04.842+00
2d7f7432-c073-465a-afbb-a828634bb244	uptime	gauge	608.362277	{}	2025-08-31 00:59:04.843+00
a9574e08-6e8c-48d4-b69e-20d893b582db	cpu_usage	gauge	8.000000	{}	2025-08-31 01:00:04.844+00
491569bb-18f8-46b8-b4d4-e5cba8f5075f	uptime	gauge	68.234502	{}	2025-08-31 01:31:01.619+00
fdca29f8-959a-4ad8-991e-8ec8ed8d3436	memory_usage	gauge	77.840000	{}	2025-08-31 01:32:01.621+00
c734e60b-8b6e-4ae6-aeab-3b34f52c9c4b	memory_usage	gauge	78.140000	{}	2025-08-31 01:33:01.621+00
8ca4c6bd-9c95-438a-8d1c-6e0679ac5db5	uptime	gauge	248.236028	{}	2025-08-31 01:34:01.621+00
1b1c2ee9-1d13-41b1-9dbc-afd6fac15b89	cpu_usage	gauge	8.000000	{}	2025-08-31 01:35:01.628+00
f515b5c1-f18e-47a5-8d68-1e90fe38282b	uptime	gauge	368.243659	{}	2025-08-31 01:36:01.629+00
e986ba66-6577-47ff-80ad-234b6f9b1b05	uptime	gauge	428.244834	{}	2025-08-31 01:37:01.63+00
3478fd03-2ca6-4af2-8573-9e6f9f0a98f4	memory_usage	gauge	78.850000	{}	2025-08-31 01:38:01.631+00
f5eddd52-e1b4-4e8d-84bd-9662e3d2230c	memory_usage	gauge	78.540000	{}	2025-08-31 01:39:01.632+00
36458d99-bb84-4da7-bd38-e087f64c0491	disk_usage	gauge	45.200000	{}	2025-08-31 01:40:01.633+00
6f019771-b6e2-4641-baa1-c4cd12ee0edd	cpu_usage	gauge	7.000000	{}	2025-08-30 22:30:22.926+00
7cb33608-6271-4b94-9c3a-172e53464fa6	disk_usage	gauge	45.200000	{}	2025-08-30 22:31:22.928+00
2e05e02a-f65a-4dea-94a8-3a91ffb6f69e	disk_usage	gauge	45.200000	{}	2025-08-31 00:10:38.434+00
e9f124dc-fcdc-4532-acd4-209956905dd1	uptime	gauge	5829.293238	{}	2025-08-31 00:10:38.434+00
1f4021e5-df23-412f-85b5-c4c7658db534	memory_usage	gauge	82.700000	{}	2025-08-31 00:11:38.436+00
0c006bd7-4df2-4e62-9427-7b11f4680ed7	uptime	gauge	5889.294903	{}	2025-08-31 00:11:38.436+00
04dcfe8c-916e-4563-b520-a21c6d1028ee	cpu_usage	gauge	8.000000	{}	2025-08-31 00:12:38.437+00
ac096413-3bec-4ab9-a6eb-6393f78e0370	uptime	gauge	5949.295968	{}	2025-08-31 00:12:38.437+00
35800df2-dca4-460d-9bce-cecd3e6254bc	disk_usage	gauge	45.200000	{}	2025-08-31 00:13:38.438+00
7ae5b63a-a785-4857-a6ca-451ef006a6fb	uptime	gauge	6009.297498	{}	2025-08-31 00:13:38.438+00
644f2eac-da01-4cc9-8452-7965194131bc	cpu_usage	gauge	8.000000	{}	2025-08-31 00:14:38.439+00
294cea5a-92de-4fc5-a485-20e01e0d94ba	memory_usage	gauge	82.300000	{}	2025-08-31 00:14:38.439+00
ce5c4471-b68b-4a57-b84e-c10c7f23bb3d	memory_usage	gauge	82.910000	{}	2025-08-31 00:15:38.439+00
f4183ecb-60e0-4f49-a545-e9c9d45e3290	uptime	gauge	6129.298812	{}	2025-08-31 00:15:38.439+00
ddbd1f0f-718c-4752-af13-8e50a3851a69	memory_usage	gauge	83.030000	{}	2025-08-31 00:16:38.44+00
82510018-e4ea-4535-841a-6febbb363a57	disk_usage	gauge	45.200000	{}	2025-08-31 00:16:38.44+00
0bd06731-4fea-4987-b2cc-dff29b157406	memory_usage	gauge	83.060000	{}	2025-08-31 00:17:38.44+00
08ffbe6c-d8e8-4cc5-9369-446252015d46	uptime	gauge	6249.299593	{}	2025-08-31 00:17:38.44+00
9a1e8a15-6433-4ddb-b577-4eca200c4e80	disk_usage	gauge	45.200000	{}	2025-08-31 00:18:38.441+00
e67594a9-1b25-4faf-adfe-ab54a5a5aca2	uptime	gauge	6309.299928	{}	2025-08-31 00:18:38.441+00
0cf31924-c637-46a0-880a-2dc5e0fb4b48	cpu_usage	gauge	8.000000	{}	2025-08-31 00:19:38.441+00
7e8d62de-c824-40bb-9768-260de5fc4cca	memory_usage	gauge	83.290000	{}	2025-08-31 00:19:38.441+00
4d4debc1-e645-47bd-90c4-3277bd878dd6	cpu_usage	gauge	8.000000	{}	2025-08-31 00:20:38.442+00
6d16483a-bce2-49e3-a89b-6b7daf4e790c	uptime	gauge	6429.301014	{}	2025-08-31 00:20:38.442+00
f9391d76-02eb-4dc5-9e6c-835919887a9f	disk_usage	gauge	45.200000	{}	2025-08-31 00:21:38.442+00
a2eeecf1-a2be-4765-9179-7dbfa6fe0e80	uptime	gauge	6489.301531	{}	2025-08-31 00:21:38.442+00
dd20f45a-4c9d-49d1-b815-7616f059227a	cpu_usage	gauge	8.000000	{}	2025-08-31 00:22:38.442+00
43112356-ff7d-4e98-86dc-12066f872383	memory_usage	gauge	83.920000	{}	2025-08-31 00:22:38.442+00
23c6f359-0fa2-4452-8c17-99a2a37e991f	disk_usage	gauge	45.200000	{}	2025-08-31 00:23:38.442+00
1c625c30-e8d1-48be-9f10-e1f08abeb545	uptime	gauge	6609.301767	{}	2025-08-31 00:23:38.442+00
874164df-a52e-429a-b3a1-7934b8fbcb99	cpu_usage	gauge	8.000000	{}	2025-08-31 00:24:38.442+00
21e9d949-dc7a-4b74-84c6-2c6241924487	memory_usage	gauge	84.100000	{}	2025-08-31 00:24:38.442+00
8f5012bd-3649-43b6-9b83-abfc43c30b50	disk_usage	gauge	45.200000	{}	2025-08-31 00:25:38.443+00
7092f954-5fa4-4ba3-9014-8cad91147608	uptime	gauge	6729.301850	{}	2025-08-31 00:25:38.443+00
cac4204b-f4ce-4ac1-bd1f-8ff090a98656	uptime	gauge	368.361120	{}	2025-08-31 00:55:04.842+00
a0f288f8-1b8f-4d62-a64e-158c196c9782	memory_usage	gauge	80.540000	{}	2025-08-31 00:56:04.843+00
cd5c160b-68e5-42ed-a62e-91ad0e5fed9c	memory_usage	gauge	80.490000	{}	2025-08-31 00:57:04.842+00
16f1637f-27cb-48df-804d-7ed39444e7b8	uptime	gauge	548.361259	{}	2025-08-31 00:58:04.842+00
0f8d3ff8-27b6-42f2-a8a7-019d8f1ad1fb	disk_usage	gauge	45.200000	{}	2025-08-31 00:59:04.843+00
db3a3a9d-11a4-4721-aa20-e8e4403513dc	memory_usage	gauge	80.630000	{}	2025-08-31 01:00:04.844+00
a4f662aa-3886-41c9-89a7-2448681ee918	memory_usage	gauge	77.330000	{}	2025-08-31 01:31:01.619+00
0c653db3-0a1d-4add-bc20-506df8b561f3	cpu_usage	gauge	8.000000	{}	2025-08-31 01:32:01.621+00
9f8046e7-f1f8-4016-9c10-20b2efc3e431	cpu_usage	gauge	8.000000	{}	2025-08-31 01:33:01.621+00
0f1cd98d-9f90-415f-98b2-b3681d1c88d6	cpu_usage	gauge	8.000000	{}	2025-08-31 01:34:01.621+00
503946f4-5eb6-4ed0-97e5-6b7b8f70617c	uptime	gauge	308.243158	{}	2025-08-31 01:35:01.628+00
9489f966-4285-46f6-bc4d-5a5c61861e37	cpu_usage	gauge	8.000000	{}	2025-08-31 01:36:01.628+00
cecd2d32-d66e-43a2-954e-253aefe6eaf9	memory_usage	gauge	78.320000	{}	2025-08-31 01:37:01.63+00
9c2c535c-d7b6-44c7-b0bf-bb7b9651b7bb	disk_usage	gauge	45.200000	{}	2025-08-31 01:38:01.631+00
4baf8406-ecbd-41ec-8c83-5e934dd66258	disk_usage	gauge	45.200000	{}	2025-08-31 01:39:01.632+00
bdbd2bd6-c035-4252-bb5d-f6760b399e77	disk_usage	gauge	45.200000	{}	2025-08-30 22:30:22.927+00
cc846f04-ab8f-47c2-a5a5-002d59e0b4db	memory_usage	gauge	67.260000	{}	2025-08-30 22:31:22.928+00
65b4850a-ad24-4c4e-b89c-bda2b62eb9f2	cpu_usage	gauge	8.000000	{}	2025-08-31 00:10:38.434+00
8dca4f2e-e3a2-49cc-89dc-fa639a55558c	cpu_usage	gauge	8.000000	{}	2025-08-31 00:11:38.435+00
745f584a-945a-4a73-b71b-7fb888c2a60b	memory_usage	gauge	82.580000	{}	2025-08-31 00:12:38.437+00
dc82b147-032e-4aff-8b61-d7ca40b211b8	cpu_usage	gauge	8.000000	{}	2025-08-31 00:13:38.438+00
c03f4a64-c1e6-4ebb-ad24-1f3e86128ba0	uptime	gauge	6069.298540	{}	2025-08-31 00:14:38.439+00
4a311709-70a1-453e-9bbc-a6d6dbc91f57	disk_usage	gauge	45.200000	{}	2025-08-31 00:15:38.439+00
0d8cabe2-4b30-4259-947b-2a414dabd552	cpu_usage	gauge	8.000000	{}	2025-08-31 00:16:38.44+00
d8133bd7-1994-4f2a-bc27-74ad93ba3505	disk_usage	gauge	45.200000	{}	2025-08-31 00:17:38.44+00
12affc91-d474-426d-92c6-474c26c7e3eb	memory_usage	gauge	83.460000	{}	2025-08-31 00:18:38.441+00
db03f217-5eb8-449c-aa64-3e1dfc9a585e	uptime	gauge	6369.300856	{}	2025-08-31 00:19:38.442+00
f85ee39c-9fa0-4b1d-8745-582dab99b031	disk_usage	gauge	45.200000	{}	2025-08-31 00:20:38.442+00
201ab3f4-2343-47f9-b22d-9cb4c7b57450	memory_usage	gauge	84.090000	{}	2025-08-31 00:21:38.442+00
5a2068c6-3de0-448a-addf-d306a78bb7b9	uptime	gauge	6549.301354	{}	2025-08-31 00:22:38.442+00
858ad859-24eb-48ae-ad0b-15cdf0d70cf8	memory_usage	gauge	83.940000	{}	2025-08-31 00:23:38.442+00
f3259077-7ae1-4cf5-b605-7a031c1844b2	uptime	gauge	6669.300996	{}	2025-08-31 00:24:38.442+00
69c29f57-e770-44c2-94f7-5f7eeafd55ac	memory_usage	gauge	83.350000	{}	2025-08-31 00:25:38.442+00
2e925d15-66b0-45bd-a2a2-1ec981145950	cpu_usage	gauge	8.000000	{}	2025-08-31 00:55:04.842+00
fe79396a-24d5-4899-b8d2-18bfb2c81da8	disk_usage	gauge	45.200000	{}	2025-08-31 01:31:01.619+00
d22e0471-08af-45be-9c3f-ec8630e64d38	disk_usage	gauge	45.200000	{}	2025-08-31 01:32:01.623+00
f02ec4e4-2b51-4f8a-8653-0fb41c5eb5d7	disk_usage	gauge	45.200000	{}	2025-08-31 01:33:01.621+00
ab27dce2-7e17-4a18-aff4-768ead1d8ef1	memory_usage	gauge	77.490000	{}	2025-08-31 01:34:01.621+00
882df8e8-437e-42f8-86dc-079a384de1b3	disk_usage	gauge	45.200000	{}	2025-08-31 01:35:01.628+00
d30be97c-daf0-4d7f-95de-13c910eb88bf	memory_usage	gauge	78.120000	{}	2025-08-31 01:36:01.629+00
dd541706-0bbb-4d01-9e31-1066cb7c3706	cpu_usage	gauge	8.000000	{}	2025-08-31 01:37:01.63+00
d969dbb2-6bd2-45b9-970d-bdcab8b61bc8	uptime	gauge	488.246275	{}	2025-08-31 01:38:01.631+00
bada9b5f-d8a5-4fad-a813-10378eb234bd	cpu_usage	gauge	8.000000	{}	2025-08-31 01:39:01.632+00
98f7baab-c186-4a4b-b4c0-9b6a78344077	uptime	gauge	2108.677746	{}	2025-08-30 20:51:22.857+00
911e960a-2af5-4585-bdfe-b053aaa20eba	cpu_usage	gauge	8.000000	{}	2025-08-30 20:52:22.858+00
6022d4e1-d905-4a16-bece-0f50b71c67e9	uptime	gauge	2228.679194	{}	2025-08-30 20:53:22.859+00
4357e48e-99ec-4f4d-986d-67f3e355b158	memory_usage	gauge	65.950000	{}	2025-08-30 20:54:22.859+00
410430c3-5361-4e6d-893f-bce6e7baf093	disk_usage	gauge	45.200000	{}	2025-08-30 20:55:22.86+00
dea56ef3-df38-425f-8d2f-44c2c6ce8939	disk_usage	gauge	45.200000	{}	2025-08-30 20:56:22.861+00
3ed9a5c8-db61-4b5f-a72d-da037f6a91e3	disk_usage	gauge	45.200000	{}	2025-08-30 20:57:22.86+00
15fe7c3d-6472-4758-9d67-57b8d5e08f9a	disk_usage	gauge	45.200000	{}	2025-08-30 20:58:22.86+00
51b6daf8-f7b9-4a54-b1b2-67c884192e64	cpu_usage	gauge	8.000000	{}	2025-08-30 20:59:22.86+00
2ea70070-2a43-4fad-83d5-ea4438536734	uptime	gauge	2648.681969	{}	2025-08-30 21:00:22.862+00
c9b79686-3a8e-47f9-9d27-9cac9c533fd1	disk_usage	gauge	45.200000	{}	2025-08-30 21:01:22.862+00
9b0825a6-c5e4-427f-be0a-9cb32e2b708e	disk_usage	gauge	45.200000	{}	2025-08-30 21:02:22.864+00
10cc3813-5d7c-4d09-9260-bdafdd28826f	disk_usage	gauge	45.200000	{}	2025-08-30 21:03:22.864+00
6cf9acdc-a132-4343-8686-ff2c79811688	disk_usage	gauge	45.200000	{}	2025-08-30 21:04:22.867+00
f96c8c89-98b2-4a43-a3e1-02607b30778f	memory_usage	gauge	66.460000	{}	2025-08-30 21:05:22.866+00
bf9b172f-048b-4a2e-a7a2-303c0be20a4a	memory_usage	gauge	66.710000	{}	2025-08-30 21:06:22.867+00
89b461df-5128-482c-866c-b170e6864112	disk_usage	gauge	45.200000	{}	2025-08-30 21:07:22.868+00
054246db-140f-46b1-aac4-cacd48bc145b	memory_usage	gauge	65.970000	{}	2025-08-30 21:08:22.869+00
64967897-6a15-4c12-9467-117d75782ad4	cpu_usage	gauge	8.000000	{}	2025-08-30 21:09:22.869+00
c6437e56-0f58-4eb1-a6dc-704f65fcd3a6	cpu_usage	gauge	8.000000	{}	2025-08-31 00:55:49.569+00
1778fbd9-1c5d-41be-ad51-d166eba76008	uptime	gauge	249.955027	{}	2025-08-31 00:56:49.569+00
8035ee34-916a-455e-8e7d-de9f9e76a087	disk_usage	gauge	45.200000	{}	2025-08-31 00:57:49.569+00
2aedf6e4-654f-40e0-9a37-9ac7b1b03169	cpu_usage	gauge	8.000000	{}	2025-08-31 00:58:49.569+00
7025989c-41e1-4112-a536-fbf5ca99a857	uptime	gauge	429.955948	{}	2025-08-31 00:59:49.57+00
ab87732f-2daf-42b5-8d7e-62d92e062c94	cpu_usage	gauge	8.000000	{}	2025-08-31 01:40:01.632+00
\.


--
-- TOC entry 4258 (class 0 OID 18195)
-- Dependencies: 253
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, user_id, user_name, user_avatar, content, rating, is_verified, is_public, is_featured, tags, metadata, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4244 (class 0 OID 17901)
-- Dependencies: 239
-- Data for Name: trend_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trend_analysis (id, product_id, price_trend, availability_trend, demand_score, volatility_score, analyzed_at) FROM stdin;
\.


--
-- TOC entry 4240 (class 0 OID 17810)
-- Dependencies: 235
-- Data for Name: unsubscribe_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unsubscribe_tokens (id, token, user_id, email_type, expires_at, used_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4264 (class 0 OID 18341)
-- Dependencies: 259
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assignment_reason, assigned_at, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4236 (class 0 OID 17751)
-- Dependencies: 231
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, refresh_token, device_info, ip_address, user_agent, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4232 (class 0 OID 17632)
-- Dependencies: 227
-- Data for Name: user_watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_watch_packs (id, user_id, watch_pack_id, customizations, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4221 (class 0 OID 16477)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, subscription_tier, created_at, updated_at, email_verified, verification_token, reset_token, reset_token_expires, failed_login_attempts, locked_until, last_login, shipping_addresses, payment_methods, retailer_credentials, notification_settings, quiet_hours, timezone, zip_code, push_subscriptions, role, last_admin_login, admin_permissions, direct_permissions, role_last_updated, role_updated_by, permission_metadata, first_name, last_name, preferences, newsletter_subscription, terms_accepted) FROM stdin;
2debc72e-0100-4f4d-afeb-efc1c32fb098	test@boosterbeacon.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS	pro	2025-08-29 16:07:22.704238+00	2025-08-29 16:07:22.704238+00	f	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	[]	[]	\N	\N	{}	\N	\N	{}	f	f
b71108f1-fd0f-4103-ac7c-0408564476a5	derek.test2@gmail.com	$2b$12$JICtiBbnidtqt2iGI8grkuu1uu6UiWZc7yYbteY6YF.we0s2Am1o6	free	2025-08-30 19:21:16.644499+00	2025-08-30 19:21:16.65+00	f	c93df61de9ac05f694fc8cc116c7ff71778c771978f8ef12803d7030fa432106	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Derek	Test	{}	f	t
3fade3dd-a982-4f8f-bbd0-00131c53b5fb	test@example.com	$2b$12$bMjZ.LOUdfVvVedm2ewu7es83/Y7LDkXdsebeRqxyLxGys7dST8qC	free	2025-08-30 19:22:38.092033+00	2025-08-30 19:22:38.099+00	f	2d4b05e1f656398cc7fe106dedf8339ed605af24182e76c89f63af9b95755006	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
2bd9fb38-f8fd-4d75-99ab-042e5c5cdc6d	test2@example.com	$2b$12$iw8mspYZnwW05hgcovLvbOp0F34IWPbyHTXnzsGDxHXrSmJeTU14e	free	2025-08-30 19:22:58.239074+00	2025-08-30 19:22:58.244+00	f	d0843334afdb71d8d29c88f8d849549008310b8fafa694bac02821081c79e108	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
d69fbe66-d7ea-4f06-9304-68dda64bb5b0	nunya@example.com	$2b$12$VDES7I64f9UCtqFrvJp1c.mAW2CmO6iXii4FUuCMtcH6R06uvUHG6	free	2025-08-30 19:23:33.794786+00	2025-08-30 19:23:33.802+00	f	102ae037848a0ac86c1f8d6402a515270b660fc4626490955d838267d88b2fd6	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	nunya	bidness	{}	t	t
fffad115-e42f-459d-b659-7e958325affa	test3@example.com	$2b$12$ToN2il0I0y1SBIk7YlU09.OJimR32YnSPS.zTpwdgS1FUREM/z1xq	free	2025-08-30 19:25:55.7163+00	2025-08-30 19:25:55.72+00	f	b3159131a69d188412105841358351372f0592c815a95ee20787adabfa7cbc92	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
e5cd6028-90b4-495d-bb5a-1451b758ee1a	whever@example.com	$2b$12$hjqc7.r5vdEhTF8E7l7SF.dCjcq2zL.f.GIWGo3L3tf68nzWrC3zC	free	2025-08-30 19:27:07.788593+00	2025-08-30 19:27:07.794+00	f	340a67d6fb70f22207a979db32c14f39305de7797956b87d549b7968adb4adf9	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	derek	mihlfeith	{}	t	t
23baf190-793e-46cd-a276-a1c1096e1fb2	asdfsd@asasdfa.com	$2b$12$JCe7PfwOiVF9lqDzOf6X/uKLWEOPyNf6J.hUE6trQpV8eVK2QiKYG	free	2025-08-30 19:28:05.545253+00	2025-08-30 19:28:05.55+00	f	b3581abd056bd2f7fe1758c007720f3bcc448d16043f4d2f0c8b66d139dd1a84	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	asdf	asdf	{}	t	t
42fc3e61-5bea-480b-85af-5dd2f784d145	test4@example.com	$2b$12$XpnyPxP05CpmGXAiNDzCCe5Chf/aAugCiNB1iiJ/VgnX7dq0tJc3C	free	2025-08-30 19:28:18.552613+00	2025-08-30 19:28:18.558+00	f	ad0fcb2de1a4ce846d121afb04576496bdab58c244a79620e90c0ca49753d881	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
b2aff720-8b79-463e-8bca-1f747a857fb6	test5@example.com	$2b$12$az3HiSfwE2a17wt.C7C8He0AzN2nkaBu/0NaFw1y4lw8Tdyqbt8Dq	free	2025-08-30 19:29:24.289836+00	2025-08-30 19:29:24.295+00	f	288600164883edc969c98406eb82dbeeba282b683911ad137e124f349bbf7cd6	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
2c8b7d84-5467-4b6e-ad76-3b09503db363	asdfaaaa@example.com	$2b$12$2BhXSo7kRWk1ErOM2NrHkuiRbA0r62UbfqgYfjZkaKu9gVZz1T72G	free	2025-08-30 19:30:14.53287+00	2025-08-30 19:30:40.296+00	f	2a31e89232a8dea0ec1d0de3f5c17e8608a95db3bdf03e046ad911151e40bb5a	\N	\N	0	\N	2025-08-30 19:30:40.296+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	sadf	asdf	{}	t	t
548e8555-e070-4955-ab61-b0ee2e34526d	test6@example.com	$2b$12$sgyve5HX8DAQvhaiA.B6xekwD/A.vrWbdRA0S7Q.IGHNfBCgygWE.	free	2025-08-30 19:31:36.133669+00	2025-08-30 19:31:36.139+00	f	1e195fb4e6f7e317e2b7c984774d43e27ae393eaf8d3684873926e3a236b89cb	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
3db0198f-d37e-49c6-9cb1-39359de2b7e8	1234@example.com	$2b$12$s7sOvcd3TWGhEtvhkRLh1OLdlZ/2cJuURjrx8kmwZqkSD1cQSgfFy	free	2025-08-30 19:33:08.10551+00	2025-08-30 19:33:08.11+00	f	0b47b39ec95336309338b4cef78aaf8803b398c823a128090ada71c055f0391b	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	asdf	asdf	{}	t	t
43682f79-458f-4278-80d9-cb85205e8d35	test7@example.com	$2b$12$LjvGLfJ3Iw01JDjcaRgOMe7eAAypdMLu/wadPTgoyixH2Mzk62ehO	free	2025-08-30 19:34:38.448269+00	2025-08-30 19:34:38.453+00	f	baa9bdf7fcfef276f39a0d377e8e936dee547d2b917b40efadbfdadc0352f210	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
c45b2111-2343-48ee-9bba-f646d20fc821	aaa@test.com	$2b$12$U609DVYGdiic640XBdmDW.44jBLIGoL1kyg5Ok6HqSaZE1kIGYnIa	free	2025-08-30 19:37:11.273811+00	2025-08-30 19:37:11.279+00	f	709f89feed34247a0e5dfa3fb0cd0c9a738d9b9387afa270e28309173f8e422c	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	aaa	aaaa	{}	t	t
7e06e06a-863c-471c-b3a1-eb017c8d14c1	derekmihlfeith@gmail.com	$2b$12$vIehNBIeGiJNtCj5GXMZ6uhbQJpJ4FXZCJfN7vZ3aCVMRm5UyUdY.	free	2025-08-30 19:18:37.254727+00	2025-08-31 00:51:45.645+00	f	3912095e40bc5c9d81c1d0a62f23269c2fbf260a59e5d933e5e0c2a6bbf20519	\N	\N	1	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Derek	Mihlfeith	{}	f	t
eaf163d1-3d7e-4c70-bb0a-ebd4a82a0736	11111@example.com	$2b$12$czUu62PliG8t35dOoQx7FuHFOX49HeLapiuOPJmXw976THb/nTZt.	free	2025-08-30 19:36:18.245433+00	2025-08-31 01:25:28.668+00	f	010008b82bb952a0758de1b935619a11caf4f3c6ab5f6bbd7ca517a6a80b1a6a	\N	\N	0	\N	2025-08-31 01:25:28.668+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	asdf	asdf	{}	t	t
81558779-18ae-4d23-8327-e293257f4bf2	test8@example.com	$2b$12$az57SJ7eSLvx436Nre/xNedM25XmzKtMD1PHJtc5BfKWUcevU89hO	free	2025-08-30 19:40:35.12014+00	2025-08-30 19:40:35.126+00	f	199ff6163e0895bdaf60ca70d01e79b7c8635f2b4c00811396d4dedb46c050e2	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
9ec7dd45-53dc-4032-b5f2-8a8f751e7ee0	test9@example.com	$2b$12$mG0yV10GTmb9dslgu5vyiuc4tI1th2jMwmoOxCkRvPSrDcoQ3YOa2	free	2025-08-30 19:42:37.64265+00	2025-08-30 19:42:37.649+00	f	e7b35b65177cdb0b6900c950d65f85d07de8ef51ac4768b9981a200bc9e90196	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
ac7d22c1-26d8-49fa-9498-11f81b3f8dec	test10@example.com	$2b$12$drudhAkMPPcxr07AWi2vMuGoV7I0IDMtgF.5ZkqqUu8n2bU/gZYZy	free	2025-08-30 19:49:15.970544+00	2025-08-30 19:49:15.977+00	f	f348f06146c807564d3b23c6bf8d66a0218493f1159ce1ba84dc19b7ff133aa1	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
069ebde1-c50f-41c2-80c6-91cf31bcec64	3333@test.com	$2b$12$VH.vY0oHjaooyhb5ubLiD.ZGENu8ZTtRBMOPr/vT7b17lynVBUFRO	free	2025-08-30 19:50:25.782337+00	2025-08-30 19:50:25.784+00	f	e27330d0d5cf6c8e7e86141a0d008f8113f1a31c51210463cf38b1641ddb55f0	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	adfd	adfwe	{}	t	t
b42c4ee5-0a58-41e3-b5db-195f9604c183	test11@example.com	$2b$12$dHm6UWFH7TWUMEYi9yPkr.5YFOMdPS8DASDVvd.43SPlC9Nk4MvBy	free	2025-08-30 19:54:24.24904+00	2025-08-30 19:54:24.255+00	f	e6440d5457af80263ea9fab8c64d5a7b76228e70e7f3c11d8a1cd0a8847f692f	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	Test	User	{}	f	t
07accd7c-fe74-4b82-a5df-2089fe5dc3c9	admin@boosterbeacon.com	$2b$12$66j3EhvWT2INcBGcJxygmuZWorcKSGcitWkEUcwNN71qbZwNe9PZ2	pro	2025-08-31 01:40:00.100763+00	2025-08-31 01:42:37.401+00	t	\N	\N	\N	0	\N	2025-08-31 01:42:37.401+00	[]	[]	{}	{"sms": true, "email": true, "discord": true, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	super_admin	\N	["user_management", "user_suspend", "user_delete", "ml_model_training", "ml_data_review", "system_monitoring", "analytics_view", "audit_log_view"]	[]	\N	\N	{}	Admin	User	{}	f	f
e7df1c91-05c0-419f-befb-3741c7c4df5f	as12@test.com	$2b$12$LR6nOVleCNVKCk5TdiWgMOallk2hJupl6uHy289w4011F6oPrXYY2	free	2025-08-30 19:59:40.530099+00	2025-08-30 19:59:40.536+00	f	53bf63765269a83e2947140aa13c12b453f488a5799e0d004d4e4c1ec0923fba	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	aaaa	aaaa	{}	t	t
1ff27250-ff36-4aef-87f3-6b3d4fb6407c	nunya1@test.com	$2b$12$oKH5.ZGVCKYCSNleJbFbluehyagrZWDMpPkTsscnS5KxvStdczCSi	free	2025-08-31 00:52:14.448492+00	2025-08-31 00:52:14.454+00	f	ec18a2f0a54a4064aed8dec5cadebefdd8fa7e30a19a3613a3e6726fda63d4cc	\N	\N	0	\N	\N	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	d	d	{}	t	t
290c9264-7ea8-4b1f-a9e6-f13ec4b8bbf4	1122@test.com	$2b$12$Ck/1WOcq0v6dMAwKpYCU/OGsfbPt0.oHAx6At7JQjoWTd9QgXP.Si	free	2025-08-30 19:46:09.507674+00	2025-08-31 01:27:26.044+00	f	020f95e7f8b3c5c1f904752295e98d9f713a7f17bb4cb0126192656995a7425b	\N	\N	0	\N	2025-08-31 01:27:26.044+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	aaa	aaa	{}	t	t
4779a055-ec92-4a2f-98bc-716dc0672ef4	333!@test.com	$2b$12$6bQz2mgHPMiA63B6sIj/IOShVKk9mB.jdzILo8GQenNL/RQ.WCIyS	free	2025-08-30 19:47:41.509811+00	2025-08-31 01:30:35.121+00	f	15cdc3cade0d7af08976c25f4e3a910ac43ad26254cef445194d54cb8147644e	\N	\N	0	\N	2025-08-31 01:30:35.121+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	[]	\N	\N	{}	asdfa	asdfa	{}	t	t
\.


--
-- TOC entry 4231 (class 0 OID 17615)
-- Dependencies: 226
-- Data for Name: watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watch_packs (id, name, slug, description, product_ids, is_active, auto_update, update_criteria, subscriber_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4230 (class 0 OID 17583)
-- Dependencies: 225
-- Data for Name: watches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watches (id, user_id, product_id, retailer_ids, max_price, availability_type, zip_code, radius_miles, is_active, alert_preferences, last_alerted, alert_count, created_at, updated_at) FROM stdin;
6c04ccc2-222d-4cb3-b46c-1ad55906d7aa	07accd7c-fe74-4b82-a5df-2089fe5dc3c9	1f551d14-60b3-4205-97fd-5530a2f94f41	{}	\N	both	\N	\N	t	{}	\N	0	2025-08-31 01:40:36.251342+00	2025-08-31 01:40:36.251342+00
\.


--
-- TOC entry 4255 (class 0 OID 18127)
-- Dependencies: 250
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, user_id, name, url, secret, events, headers, retry_config, filters, is_active, total_calls, successful_calls, failed_calls, last_triggered, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4276 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 22, true);


--
-- TOC entry 4277 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 3935 (class 2606 OID 18035)
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3843 (class 2606 OID 17720)
-- Name: alert_deliveries alert_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_pkey PRIMARY KEY (id);


--
-- TOC entry 3829 (class 2606 OID 17674)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3895 (class 2606 OID 17887)
-- Name: availability_snapshots availability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 3996 (class 2606 OID 18316)
-- Name: comment_likes comment_likes_comment_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_user_id_unique UNIQUE (comment_id, user_id);


--
-- TOC entry 3998 (class 2606 OID 18304)
-- Name: comment_likes comment_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 3980 (class 2606 OID 18240)
-- Name: community_posts community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 3964 (class 2606 OID 18163)
-- Name: csv_operations csv_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_pkey PRIMARY KEY (id);


--
-- TOC entry 3929 (class 2606 OID 18010)
-- Name: data_quality_metrics data_quality_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3955 (class 2606 OID 18118)
-- Name: discord_servers discord_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_pkey PRIMARY KEY (id);


--
-- TOC entry 3958 (class 2606 OID 18125)
-- Name: discord_servers discord_servers_user_id_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_server_id_unique UNIQUE (user_id, server_id);


--
-- TOC entry 3888 (class 2606 OID 17831)
-- Name: email_bounces email_bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_bounces
    ADD CONSTRAINT email_bounces_pkey PRIMARY KEY (id);


--
-- TOC entry 3892 (class 2606 OID 17841)
-- Name: email_complaints email_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_complaints
    ADD CONSTRAINT email_complaints_pkey PRIMARY KEY (id);


--
-- TOC entry 3875 (class 2606 OID 17809)
-- Name: email_delivery_logs email_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3866 (class 2606 OID 17799)
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 3869 (class 2606 OID 17857)
-- Name: email_preferences email_preferences_unsubscribe_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_unsubscribe_token_unique UNIQUE (unsubscribe_token);


--
-- TOC entry 3916 (class 2606 OID 17965)
-- Name: engagement_metrics engagement_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3920 (class 2606 OID 17972)
-- Name: engagement_metrics engagement_metrics_product_id_metrics_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_metrics_date_unique UNIQUE (product_id, metrics_date);


--
-- TOC entry 3774 (class 2606 OID 16504)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3772 (class 2606 OID 16497)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3912 (class 2606 OID 17944)
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3939 (class 2606 OID 18070)
-- Name: ml_models ml_models_name_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_name_version_unique UNIQUE (name, version);


--
-- TOC entry 3941 (class 2606 OID 18060)
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


--
-- TOC entry 3906 (class 2606 OID 17925)
-- Name: ml_predictions ml_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_pkey PRIMARY KEY (id);


--
-- TOC entry 3946 (class 2606 OID 18083)
-- Name: ml_training_data ml_training_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4021 (class 2606 OID 18383)
-- Name: permission_audit_log permission_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3985 (class 2606 OID 18263)
-- Name: post_comments post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_pkey PRIMARY KEY (id);


--
-- TOC entry 3989 (class 2606 OID 18283)
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 3992 (class 2606 OID 18295)
-- Name: post_likes post_likes_post_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_user_id_unique UNIQUE (post_id, user_id);


--
-- TOC entry 3847 (class 2606 OID 17736)
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3802 (class 2606 OID 17566)
-- Name: product_availability product_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_pkey PRIMARY KEY (id);


--
-- TOC entry 3805 (class 2606 OID 17578)
-- Name: product_availability product_availability_product_id_retailer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_retailer_id_unique UNIQUE (product_id, retailer_id);


--
-- TOC entry 3783 (class 2606 OID 17514)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3786 (class 2606 OID 17516)
-- Name: product_categories product_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_slug_unique UNIQUE (slug);


--
-- TOC entry 3790 (class 2606 OID 17537)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3795 (class 2606 OID 17539)
-- Name: products products_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_unique UNIQUE (slug);


--
-- TOC entry 3798 (class 2606 OID 17541)
-- Name: products products_upc_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_upc_unique UNIQUE (upc);


--
-- TOC entry 3777 (class 2606 OID 17499)
-- Name: retailers retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (id);


--
-- TOC entry 3780 (class 2606 OID 17501)
-- Name: retailers retailers_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_slug_unique UNIQUE (slug);


--
-- TOC entry 4004 (class 2606 OID 18335)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 4006 (class 2606 OID 18333)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4008 (class 2606 OID 18337)
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- TOC entry 3924 (class 2606 OID 17986)
-- Name: seasonal_patterns seasonal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 3968 (class 2606 OID 18181)
-- Name: social_shares social_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_pkey PRIMARY KEY (id);


--
-- TOC entry 4024 (class 2606 OID 18430)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 18432)
-- Name: subscription_plans subscription_plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_unique UNIQUE (slug);


--
-- TOC entry 4028 (class 2606 OID 18434)
-- Name: subscription_plans subscription_plans_stripe_price_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_stripe_price_id_unique UNIQUE (stripe_price_id);


--
-- TOC entry 3862 (class 2606 OID 17783)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 3952 (class 2606 OID 18102)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3974 (class 2606 OID 18212)
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- TOC entry 3901 (class 2606 OID 17907)
-- Name: trend_analysis trend_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_pkey PRIMARY KEY (id);


--
-- TOC entry 3880 (class 2606 OID 17820)
-- Name: unsubscribe_tokens unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3883 (class 2606 OID 17853)
-- Name: unsubscribe_tokens unsubscribe_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4012 (class 2606 OID 18352)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4016 (class 2606 OID 18369)
-- Name: user_roles user_roles_user_id_role_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_unique UNIQUE (user_id, role_id);


--
-- TOC entry 3855 (class 2606 OID 17761)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3858 (class 2606 OID 17768)
-- Name: user_sessions user_sessions_refresh_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_unique UNIQUE (refresh_token);


--
-- TOC entry 3822 (class 2606 OID 17643)
-- Name: user_watch_packs user_watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3825 (class 2606 OID 17655)
-- Name: user_watch_packs user_watch_packs_user_id_watch_pack_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique UNIQUE (user_id, watch_pack_id);


--
-- TOC entry 3761 (class 2606 OID 16489)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3763 (class 2606 OID 17469)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3766 (class 2606 OID 16487)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3817 (class 2606 OID 17627)
-- Name: watch_packs watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3820 (class 2606 OID 17629)
-- Name: watch_packs watch_packs_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_slug_unique UNIQUE (slug);


--
-- TOC entry 3809 (class 2606 OID 17598)
-- Name: watches watches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_pkey PRIMARY KEY (id);


--
-- TOC entry 3814 (class 2606 OID 17610)
-- Name: watches watches_user_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_product_id_unique UNIQUE (user_id, product_id);


--
-- TOC entry 3960 (class 2606 OID 18143)
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 3931 (class 1259 OID 18042)
-- Name: admin_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_action_created_at_index ON public.admin_audit_log USING btree (action, created_at);


--
-- TOC entry 3932 (class 1259 OID 18041)
-- Name: admin_audit_log_admin_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_admin_user_id_created_at_index ON public.admin_audit_log USING btree (admin_user_id, created_at);


--
-- TOC entry 3933 (class 1259 OID 18044)
-- Name: admin_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_created_at_index ON public.admin_audit_log USING btree (created_at);


--
-- TOC entry 3936 (class 1259 OID 18043)
-- Name: admin_audit_log_target_type_target_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_target_type_target_id_index ON public.admin_audit_log USING btree (target_type, target_id);


--
-- TOC entry 3840 (class 1259 OID 17726)
-- Name: alert_deliveries_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_alert_id_index ON public.alert_deliveries USING btree (alert_id);


--
-- TOC entry 3841 (class 1259 OID 17727)
-- Name: alert_deliveries_channel_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_channel_index ON public.alert_deliveries USING btree (channel);


--
-- TOC entry 3844 (class 1259 OID 17729)
-- Name: alert_deliveries_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_sent_at_index ON public.alert_deliveries USING btree (sent_at);


--
-- TOC entry 3845 (class 1259 OID 17728)
-- Name: alert_deliveries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_status_index ON public.alert_deliveries USING btree (status);


--
-- TOC entry 3827 (class 1259 OID 17703)
-- Name: alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_index ON public.alerts USING btree (created_at);


--
-- TOC entry 3830 (class 1259 OID 17701)
-- Name: alerts_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_priority_index ON public.alerts USING btree (priority);


--
-- TOC entry 3831 (class 1259 OID 17696)
-- Name: alerts_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_product_id_index ON public.alerts USING btree (product_id);


--
-- TOC entry 3832 (class 1259 OID 17697)
-- Name: alerts_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_retailer_id_index ON public.alerts USING btree (retailer_id);


--
-- TOC entry 3833 (class 1259 OID 17702)
-- Name: alerts_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_scheduled_for_index ON public.alerts USING btree (scheduled_for);


--
-- TOC entry 3834 (class 1259 OID 17699)
-- Name: alerts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_index ON public.alerts USING btree (status);


--
-- TOC entry 3835 (class 1259 OID 17705)
-- Name: alerts_status_priority_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_priority_created_at_index ON public.alerts USING btree (status, priority, created_at);


--
-- TOC entry 3836 (class 1259 OID 17700)
-- Name: alerts_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_index ON public.alerts USING btree (type);


--
-- TOC entry 3837 (class 1259 OID 17695)
-- Name: alerts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_index ON public.alerts USING btree (user_id);


--
-- TOC entry 3838 (class 1259 OID 17704)
-- Name: alerts_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_status_index ON public.alerts USING btree (user_id, status);


--
-- TOC entry 3839 (class 1259 OID 17698)
-- Name: alerts_watch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_watch_id_index ON public.alerts USING btree (watch_id);


--
-- TOC entry 3896 (class 1259 OID 17898)
-- Name: availability_snapshots_product_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_product_id_snapshot_time_index ON public.availability_snapshots USING btree (product_id, snapshot_time);


--
-- TOC entry 3897 (class 1259 OID 17899)
-- Name: availability_snapshots_retailer_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_retailer_id_snapshot_time_index ON public.availability_snapshots USING btree (retailer_id, snapshot_time);


--
-- TOC entry 3898 (class 1259 OID 17900)
-- Name: availability_snapshots_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_snapshot_time_index ON public.availability_snapshots USING btree (snapshot_time);


--
-- TOC entry 3994 (class 1259 OID 18317)
-- Name: comment_likes_comment_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_comment_id_index ON public.comment_likes USING btree (comment_id);


--
-- TOC entry 3999 (class 1259 OID 18318)
-- Name: comment_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_user_id_index ON public.comment_likes USING btree (user_id);


--
-- TOC entry 3977 (class 1259 OID 18249)
-- Name: community_posts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_created_at_index ON public.community_posts USING btree (created_at);


--
-- TOC entry 3978 (class 1259 OID 18248)
-- Name: community_posts_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_is_featured_is_public_index ON public.community_posts USING btree (is_featured, is_public);


--
-- TOC entry 3981 (class 1259 OID 18247)
-- Name: community_posts_type_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_type_moderation_status_index ON public.community_posts USING btree (type, moderation_status);


--
-- TOC entry 3982 (class 1259 OID 18246)
-- Name: community_posts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_user_id_index ON public.community_posts USING btree (user_id);


--
-- TOC entry 3962 (class 1259 OID 18170)
-- Name: csv_operations_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_created_at_index ON public.csv_operations USING btree (created_at);


--
-- TOC entry 3965 (class 1259 OID 18169)
-- Name: csv_operations_user_id_operation_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_user_id_operation_type_index ON public.csv_operations USING btree (user_id, operation_type);


--
-- TOC entry 3926 (class 1259 OID 18017)
-- Name: data_quality_metrics_assessed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_assessed_at_index ON public.data_quality_metrics USING btree (assessed_at);


--
-- TOC entry 3927 (class 1259 OID 18018)
-- Name: data_quality_metrics_overall_quality_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_overall_quality_score_index ON public.data_quality_metrics USING btree (overall_quality_score);


--
-- TOC entry 3930 (class 1259 OID 18016)
-- Name: data_quality_metrics_product_id_data_source_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_product_id_data_source_index ON public.data_quality_metrics USING btree (product_id, data_source);


--
-- TOC entry 3956 (class 1259 OID 18126)
-- Name: discord_servers_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX discord_servers_user_id_is_active_index ON public.discord_servers USING btree (user_id, is_active);


--
-- TOC entry 3885 (class 1259 OID 17868)
-- Name: email_bounces_bounce_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_bounce_type_index ON public.email_bounces USING btree (bounce_type);


--
-- TOC entry 3886 (class 1259 OID 17854)
-- Name: email_bounces_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_message_id_index ON public.email_bounces USING btree (message_id);


--
-- TOC entry 3889 (class 1259 OID 17873)
-- Name: email_bounces_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_timestamp_index ON public.email_bounces USING btree ("timestamp");


--
-- TOC entry 3890 (class 1259 OID 17855)
-- Name: email_complaints_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_message_id_index ON public.email_complaints USING btree (message_id);


--
-- TOC entry 3893 (class 1259 OID 17869)
-- Name: email_complaints_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_timestamp_index ON public.email_complaints USING btree ("timestamp");


--
-- TOC entry 3871 (class 1259 OID 17875)
-- Name: email_delivery_logs_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_alert_id_index ON public.email_delivery_logs USING btree (alert_id);


--
-- TOC entry 3872 (class 1259 OID 17880)
-- Name: email_delivery_logs_email_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_email_type_index ON public.email_delivery_logs USING btree (email_type);


--
-- TOC entry 3873 (class 1259 OID 17877)
-- Name: email_delivery_logs_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_message_id_index ON public.email_delivery_logs USING btree (message_id);


--
-- TOC entry 3876 (class 1259 OID 17879)
-- Name: email_delivery_logs_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_sent_at_index ON public.email_delivery_logs USING btree (sent_at);


--
-- TOC entry 3877 (class 1259 OID 17871)
-- Name: email_delivery_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_user_id_index ON public.email_delivery_logs USING btree (user_id);


--
-- TOC entry 3867 (class 1259 OID 17874)
-- Name: email_preferences_unsubscribe_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_unsubscribe_token_index ON public.email_preferences USING btree (unsubscribe_token);


--
-- TOC entry 3870 (class 1259 OID 17870)
-- Name: email_preferences_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_user_id_index ON public.email_preferences USING btree (user_id);


--
-- TOC entry 3914 (class 1259 OID 17974)
-- Name: engagement_metrics_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_metrics_date_index ON public.engagement_metrics USING btree (metrics_date);


--
-- TOC entry 3917 (class 1259 OID 17973)
-- Name: engagement_metrics_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_index ON public.engagement_metrics USING btree (product_id);


--
-- TOC entry 3918 (class 1259 OID 17975)
-- Name: engagement_metrics_product_id_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_metrics_date_index ON public.engagement_metrics USING btree (product_id, metrics_date);


--
-- TOC entry 3757 (class 1259 OID 16490)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3758 (class 1259 OID 17788)
-- Name: idx_users_push_subscriptions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_push_subscriptions ON public.users USING btree (id);


--
-- TOC entry 3909 (class 1259 OID 17947)
-- Name: ml_model_metrics_last_evaluated_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_last_evaluated_at_index ON public.ml_model_metrics USING btree (last_evaluated_at);


--
-- TOC entry 3910 (class 1259 OID 17945)
-- Name: ml_model_metrics_model_name_model_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_model_name_model_version_index ON public.ml_model_metrics USING btree (model_name, model_version);


--
-- TOC entry 3913 (class 1259 OID 17946)
-- Name: ml_model_metrics_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_prediction_type_index ON public.ml_model_metrics USING btree (prediction_type);


--
-- TOC entry 3937 (class 1259 OID 18066)
-- Name: ml_models_name_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_name_status_created_at_index ON public.ml_models USING btree (name, status, created_at);


--
-- TOC entry 3942 (class 1259 OID 18067)
-- Name: ml_models_status_deployed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_status_deployed_at_index ON public.ml_models USING btree (status, deployed_at);


--
-- TOC entry 3943 (class 1259 OID 18068)
-- Name: ml_models_trained_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_trained_by_index ON public.ml_models USING btree (trained_by);


--
-- TOC entry 3904 (class 1259 OID 17932)
-- Name: ml_predictions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_expires_at_index ON public.ml_predictions USING btree (expires_at);


--
-- TOC entry 3907 (class 1259 OID 17931)
-- Name: ml_predictions_product_id_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_index ON public.ml_predictions USING btree (product_id, prediction_type);


--
-- TOC entry 3908 (class 1259 OID 17933)
-- Name: ml_predictions_product_id_prediction_type_timeframe_days_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_timeframe_days_index ON public.ml_predictions USING btree (product_id, prediction_type, timeframe_days);


--
-- TOC entry 3944 (class 1259 OID 18090)
-- Name: ml_training_data_dataset_name_data_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_dataset_name_data_type_index ON public.ml_training_data USING btree (dataset_name, data_type);


--
-- TOC entry 3947 (class 1259 OID 18091)
-- Name: ml_training_data_reviewed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_reviewed_by_index ON public.ml_training_data USING btree (reviewed_by);


--
-- TOC entry 3948 (class 1259 OID 18089)
-- Name: ml_training_data_status_data_type_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_status_data_type_created_at_index ON public.ml_training_data USING btree (status, data_type, created_at);


--
-- TOC entry 4017 (class 1259 OID 18396)
-- Name: permission_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_action_created_at_index ON public.permission_audit_log USING btree (action, created_at);


--
-- TOC entry 4018 (class 1259 OID 18395)
-- Name: permission_audit_log_actor_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_actor_user_id_created_at_index ON public.permission_audit_log USING btree (actor_user_id, created_at);


--
-- TOC entry 4019 (class 1259 OID 18397)
-- Name: permission_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_created_at_index ON public.permission_audit_log USING btree (created_at);


--
-- TOC entry 4022 (class 1259 OID 18394)
-- Name: permission_audit_log_target_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_target_user_id_created_at_index ON public.permission_audit_log USING btree (target_user_id, created_at);


--
-- TOC entry 3983 (class 1259 OID 18276)
-- Name: post_comments_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_created_at_index ON public.post_comments USING btree (created_at);


--
-- TOC entry 3986 (class 1259 OID 18274)
-- Name: post_comments_post_id_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_post_id_moderation_status_index ON public.post_comments USING btree (post_id, moderation_status);


--
-- TOC entry 3987 (class 1259 OID 18275)
-- Name: post_comments_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_user_id_index ON public.post_comments USING btree (user_id);


--
-- TOC entry 3990 (class 1259 OID 18296)
-- Name: post_likes_post_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_post_id_index ON public.post_likes USING btree (post_id);


--
-- TOC entry 3993 (class 1259 OID 18297)
-- Name: post_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_user_id_index ON public.post_likes USING btree (user_id);


--
-- TOC entry 3848 (class 1259 OID 17747)
-- Name: price_history_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_index ON public.price_history USING btree (product_id);


--
-- TOC entry 3849 (class 1259 OID 17750)
-- Name: price_history_product_id_retailer_id_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_retailer_id_recorded_at_index ON public.price_history USING btree (product_id, retailer_id, recorded_at);


--
-- TOC entry 3850 (class 1259 OID 17749)
-- Name: price_history_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_recorded_at_index ON public.price_history USING btree (recorded_at);


--
-- TOC entry 3851 (class 1259 OID 17748)
-- Name: price_history_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_retailer_id_index ON public.price_history USING btree (retailer_id);


--
-- TOC entry 3799 (class 1259 OID 17581)
-- Name: product_availability_in_stock_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_in_stock_index ON public.product_availability USING btree (in_stock);


--
-- TOC entry 3800 (class 1259 OID 17582)
-- Name: product_availability_last_checked_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_last_checked_index ON public.product_availability USING btree (last_checked);


--
-- TOC entry 3803 (class 1259 OID 17579)
-- Name: product_availability_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_product_id_index ON public.product_availability USING btree (product_id);


--
-- TOC entry 3806 (class 1259 OID 17580)
-- Name: product_availability_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_retailer_id_index ON public.product_availability USING btree (retailer_id);


--
-- TOC entry 3781 (class 1259 OID 17523)
-- Name: product_categories_parent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_parent_id_index ON public.product_categories USING btree (parent_id);


--
-- TOC entry 3784 (class 1259 OID 17522)
-- Name: product_categories_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_slug_index ON public.product_categories USING btree (slug);


--
-- TOC entry 3787 (class 1259 OID 17549)
-- Name: products_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_index ON public.products USING btree (category_id);


--
-- TOC entry 3788 (class 1259 OID 17551)
-- Name: products_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_is_active_index ON public.products USING btree (is_active);


--
-- TOC entry 3791 (class 1259 OID 17552)
-- Name: products_release_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_release_date_index ON public.products USING btree (release_date);


--
-- TOC entry 3792 (class 1259 OID 17550)
-- Name: products_set_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_set_name_index ON public.products USING btree (set_name);


--
-- TOC entry 3793 (class 1259 OID 17547)
-- Name: products_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_index ON public.products USING btree (slug);


--
-- TOC entry 3796 (class 1259 OID 17548)
-- Name: products_upc_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_upc_index ON public.products USING btree (upc);


--
-- TOC entry 3775 (class 1259 OID 17503)
-- Name: retailers_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_is_active_index ON public.retailers USING btree (is_active);


--
-- TOC entry 3778 (class 1259 OID 17502)
-- Name: retailers_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_slug_index ON public.retailers USING btree (slug);


--
-- TOC entry 4000 (class 1259 OID 18340)
-- Name: roles_created_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_created_by_index ON public.roles USING btree (created_by);


--
-- TOC entry 4001 (class 1259 OID 18338)
-- Name: roles_is_system_role_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_is_system_role_is_active_index ON public.roles USING btree (is_system_role, is_active);


--
-- TOC entry 4002 (class 1259 OID 18339)
-- Name: roles_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_level_index ON public.roles USING btree (level);


--
-- TOC entry 3921 (class 1259 OID 17998)
-- Name: seasonal_patterns_category_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_category_id_pattern_type_index ON public.seasonal_patterns USING btree (category_id, pattern_type);


--
-- TOC entry 3922 (class 1259 OID 17999)
-- Name: seasonal_patterns_pattern_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_pattern_name_index ON public.seasonal_patterns USING btree (pattern_name);


--
-- TOC entry 3925 (class 1259 OID 17997)
-- Name: seasonal_patterns_product_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_product_id_pattern_type_index ON public.seasonal_patterns USING btree (product_id, pattern_type);


--
-- TOC entry 3966 (class 1259 OID 18193)
-- Name: social_shares_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_alert_id_index ON public.social_shares USING btree (alert_id);


--
-- TOC entry 3969 (class 1259 OID 18194)
-- Name: social_shares_shared_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_shared_at_index ON public.social_shares USING btree (shared_at);


--
-- TOC entry 3970 (class 1259 OID 18192)
-- Name: social_shares_user_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_user_id_platform_index ON public.social_shares USING btree (user_id, platform);


--
-- TOC entry 3860 (class 1259 OID 17786)
-- Name: system_health_checked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_checked_at_index ON public.system_health USING btree (checked_at);


--
-- TOC entry 3863 (class 1259 OID 17784)
-- Name: system_health_service_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_service_name_index ON public.system_health USING btree (service_name);


--
-- TOC entry 3864 (class 1259 OID 17785)
-- Name: system_health_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_status_index ON public.system_health USING btree (status);


--
-- TOC entry 3949 (class 1259 OID 18103)
-- Name: system_metrics_metric_name_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_name_recorded_at_index ON public.system_metrics USING btree (metric_name, recorded_at);


--
-- TOC entry 3950 (class 1259 OID 18104)
-- Name: system_metrics_metric_type_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_type_recorded_at_index ON public.system_metrics USING btree (metric_type, recorded_at);


--
-- TOC entry 3953 (class 1259 OID 18105)
-- Name: system_metrics_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_recorded_at_index ON public.system_metrics USING btree (recorded_at);


--
-- TOC entry 3971 (class 1259 OID 18220)
-- Name: testimonials_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_is_featured_is_public_index ON public.testimonials USING btree (is_featured, is_public);


--
-- TOC entry 3972 (class 1259 OID 18219)
-- Name: testimonials_moderation_status_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_moderation_status_is_public_index ON public.testimonials USING btree (moderation_status, is_public);


--
-- TOC entry 3975 (class 1259 OID 18221)
-- Name: testimonials_rating_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_rating_index ON public.testimonials USING btree (rating);


--
-- TOC entry 3976 (class 1259 OID 18218)
-- Name: testimonials_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_user_id_index ON public.testimonials USING btree (user_id);


--
-- TOC entry 3899 (class 1259 OID 17914)
-- Name: trend_analysis_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_analyzed_at_index ON public.trend_analysis USING btree (analyzed_at);


--
-- TOC entry 3902 (class 1259 OID 17915)
-- Name: trend_analysis_product_id_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_analyzed_at_index ON public.trend_analysis USING btree (product_id, analyzed_at);


--
-- TOC entry 3903 (class 1259 OID 17913)
-- Name: trend_analysis_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_index ON public.trend_analysis USING btree (product_id);


--
-- TOC entry 3878 (class 1259 OID 17878)
-- Name: unsubscribe_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_expires_at_index ON public.unsubscribe_tokens USING btree (expires_at);


--
-- TOC entry 3881 (class 1259 OID 17872)
-- Name: unsubscribe_tokens_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_token_index ON public.unsubscribe_tokens USING btree (token);


--
-- TOC entry 3884 (class 1259 OID 17876)
-- Name: unsubscribe_tokens_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_user_id_index ON public.unsubscribe_tokens USING btree (user_id);


--
-- TOC entry 4009 (class 1259 OID 18372)
-- Name: user_roles_assigned_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_assigned_by_index ON public.user_roles USING btree (assigned_by);


--
-- TOC entry 4010 (class 1259 OID 18373)
-- Name: user_roles_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_expires_at_index ON public.user_roles USING btree (expires_at);


--
-- TOC entry 4013 (class 1259 OID 18371)
-- Name: user_roles_role_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_role_id_is_active_index ON public.user_roles USING btree (role_id, is_active);


--
-- TOC entry 4014 (class 1259 OID 18370)
-- Name: user_roles_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_user_id_is_active_index ON public.user_roles USING btree (user_id, is_active);


--
-- TOC entry 3852 (class 1259 OID 17771)
-- Name: user_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_expires_at_index ON public.user_sessions USING btree (expires_at);


--
-- TOC entry 3853 (class 1259 OID 17772)
-- Name: user_sessions_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_is_active_index ON public.user_sessions USING btree (is_active);


--
-- TOC entry 3856 (class 1259 OID 17770)
-- Name: user_sessions_refresh_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_refresh_token_index ON public.user_sessions USING btree (refresh_token);


--
-- TOC entry 3859 (class 1259 OID 17769)
-- Name: user_sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_user_id_index ON public.user_sessions USING btree (user_id);


--
-- TOC entry 3823 (class 1259 OID 17656)
-- Name: user_watch_packs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_user_id_index ON public.user_watch_packs USING btree (user_id);


--
-- TOC entry 3826 (class 1259 OID 17657)
-- Name: user_watch_packs_watch_pack_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_watch_pack_id_index ON public.user_watch_packs USING btree (watch_pack_id);


--
-- TOC entry 3759 (class 1259 OID 17470)
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- TOC entry 3764 (class 1259 OID 18023)
-- Name: users_last_admin_login_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_last_admin_login_index ON public.users USING btree (last_admin_login);


--
-- TOC entry 3767 (class 1259 OID 17481)
-- Name: users_reset_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reset_token_index ON public.users USING btree (reset_token);


--
-- TOC entry 3768 (class 1259 OID 18405)
-- Name: users_role_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_created_at_index ON public.users USING btree (role, created_at);


--
-- TOC entry 3769 (class 1259 OID 18022)
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- TOC entry 3770 (class 1259 OID 17480)
-- Name: users_verification_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_verification_token_index ON public.users USING btree (verification_token);


--
-- TOC entry 3815 (class 1259 OID 17631)
-- Name: watch_packs_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_is_active_index ON public.watch_packs USING btree (is_active);


--
-- TOC entry 3818 (class 1259 OID 17630)
-- Name: watch_packs_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_slug_index ON public.watch_packs USING btree (slug);


--
-- TOC entry 3807 (class 1259 OID 17613)
-- Name: watches_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_is_active_index ON public.watches USING btree (is_active);


--
-- TOC entry 3810 (class 1259 OID 17612)
-- Name: watches_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_product_id_index ON public.watches USING btree (product_id);


--
-- TOC entry 3811 (class 1259 OID 17611)
-- Name: watches_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_index ON public.watches USING btree (user_id);


--
-- TOC entry 3812 (class 1259 OID 17614)
-- Name: watches_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_is_active_index ON public.watches USING btree (user_id, is_active);


--
-- TOC entry 3961 (class 1259 OID 18149)
-- Name: webhooks_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_user_id_is_active_index ON public.webhooks USING btree (user_id, is_active);


--
-- TOC entry 4058 (class 2606 OID 18036)
-- Name: admin_audit_log admin_audit_log_admin_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_user_id_foreign FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4042 (class 2606 OID 17721)
-- Name: alert_deliveries alert_deliveries_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4038 (class 2606 OID 17680)
-- Name: alerts alerts_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4039 (class 2606 OID 17685)
-- Name: alerts alerts_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4040 (class 2606 OID 17675)
-- Name: alerts alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4041 (class 2606 OID 17690)
-- Name: alerts alerts_watch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watch_id_foreign FOREIGN KEY (watch_id) REFERENCES public.watches(id) ON DELETE SET NULL;


--
-- TOC entry 4050 (class 2606 OID 17888)
-- Name: availability_snapshots availability_snapshots_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4051 (class 2606 OID 17893)
-- Name: availability_snapshots availability_snapshots_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4072 (class 2606 OID 18305)
-- Name: comment_likes comment_likes_comment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_foreign FOREIGN KEY (comment_id) REFERENCES public.post_comments(id) ON DELETE CASCADE;


--
-- TOC entry 4073 (class 2606 OID 18310)
-- Name: comment_likes comment_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4067 (class 2606 OID 18241)
-- Name: community_posts community_posts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4063 (class 2606 OID 18164)
-- Name: csv_operations csv_operations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4057 (class 2606 OID 18011)
-- Name: data_quality_metrics data_quality_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4061 (class 2606 OID 18119)
-- Name: discord_servers discord_servers_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4047 (class 2606 OID 17858)
-- Name: email_delivery_logs email_delivery_logs_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE SET NULL;


--
-- TOC entry 4048 (class 2606 OID 17847)
-- Name: email_delivery_logs email_delivery_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4046 (class 2606 OID 17842)
-- Name: email_preferences email_preferences_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4054 (class 2606 OID 17966)
-- Name: engagement_metrics engagement_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4059 (class 2606 OID 18061)
-- Name: ml_models ml_models_trained_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_trained_by_foreign FOREIGN KEY (trained_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4053 (class 2606 OID 17926)
-- Name: ml_predictions ml_predictions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4060 (class 2606 OID 18084)
-- Name: ml_training_data ml_training_data_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4077 (class 2606 OID 18384)
-- Name: permission_audit_log permission_audit_log_actor_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_actor_user_id_foreign FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- TOC entry 4078 (class 2606 OID 18389)
-- Name: permission_audit_log permission_audit_log_target_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_target_user_id_foreign FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- TOC entry 4068 (class 2606 OID 18264)
-- Name: post_comments post_comments_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4069 (class 2606 OID 18269)
-- Name: post_comments post_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4070 (class 2606 OID 18284)
-- Name: post_likes post_likes_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4071 (class 2606 OID 18289)
-- Name: post_likes post_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4043 (class 2606 OID 17737)
-- Name: price_history price_history_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4044 (class 2606 OID 17742)
-- Name: price_history price_history_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4032 (class 2606 OID 17567)
-- Name: product_availability product_availability_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4033 (class 2606 OID 17572)
-- Name: product_availability product_availability_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4030 (class 2606 OID 17517)
-- Name: product_categories product_categories_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4031 (class 2606 OID 17542)
-- Name: products products_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4055 (class 2606 OID 17992)
-- Name: seasonal_patterns seasonal_patterns_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE CASCADE;


--
-- TOC entry 4056 (class 2606 OID 17987)
-- Name: seasonal_patterns seasonal_patterns_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4064 (class 2606 OID 18187)
-- Name: social_shares social_shares_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4065 (class 2606 OID 18182)
-- Name: social_shares social_shares_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4066 (class 2606 OID 18213)
-- Name: testimonials testimonials_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4052 (class 2606 OID 17908)
-- Name: trend_analysis trend_analysis_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4049 (class 2606 OID 17863)
-- Name: unsubscribe_tokens unsubscribe_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4074 (class 2606 OID 18363)
-- Name: user_roles user_roles_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- TOC entry 4075 (class 2606 OID 18358)
-- Name: user_roles user_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4076 (class 2606 OID 18353)
-- Name: user_roles user_roles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4045 (class 2606 OID 17762)
-- Name: user_sessions user_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4036 (class 2606 OID 17644)
-- Name: user_watch_packs user_watch_packs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4037 (class 2606 OID 17649)
-- Name: user_watch_packs user_watch_packs_watch_pack_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_watch_pack_id_foreign FOREIGN KEY (watch_pack_id) REFERENCES public.watch_packs(id) ON DELETE CASCADE;


--
-- TOC entry 4029 (class 2606 OID 18400)
-- Name: users users_role_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_updated_by_foreign FOREIGN KEY (role_updated_by) REFERENCES public.users(id);


--
-- TOC entry 4034 (class 2606 OID 17604)
-- Name: watches watches_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4035 (class 2606 OID 17599)
-- Name: watches watches_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4062 (class 2606 OID 18144)
-- Name: webhooks webhooks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-08-31 01:47:13 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict kDUKucF6QhaMcZyTfFUpcQN9CpUGtPLegptnqufDqy5S1kXGxKebO47TEIzMlS3

