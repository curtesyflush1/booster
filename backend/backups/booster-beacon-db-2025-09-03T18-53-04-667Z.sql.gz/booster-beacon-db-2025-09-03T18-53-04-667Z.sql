--
-- PostgreSQL database dump
--

\restrict IQXIUVJzVW1TXhSCJ8EPypBSEd8lDBB3Iadmf8Xm4FaMldZ7NXr4iWySNVvxGxb

-- Dumped from database version 15.14
-- Dumped by pg_dump version 17.6

-- Started on 2025-09-03 18:53:04 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_product_id_foreign;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_role_updated_by_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_watch_pack_id_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_foreign;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_role_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_assigned_by_foreign;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_user_id_foreign;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_product_id_foreign;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_alert_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_product_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_category_id_foreign;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_category_id_foreign;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_parent_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_retailer_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_retailer_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_product_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_user_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_user_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_post_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_target_user_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_actor_user_id_foreign;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_reviewed_by_foreign;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_product_id_foreign;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_trained_by_foreign;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_product_id_foreign;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_foreign;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_alert_id_foreign;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_foreign;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_product_id_foreign;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_user_id_foreign;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_retailer_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_product_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_watch_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_user_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_retailer_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_product_id_foreign;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_alert_id_foreign;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_admin_user_id_foreign;
DROP INDEX public.webhooks_user_id_is_active_index;
DROP INDEX public.watches_user_id_is_active_index;
DROP INDEX public.watches_user_id_index;
DROP INDEX public.watches_product_id_index;
DROP INDEX public.watches_is_active_index;
DROP INDEX public.watch_packs_slug_index;
DROP INDEX public.watch_packs_is_active_index;
DROP INDEX public.users_verification_token_index;
DROP INDEX public.users_subscription_plan_id_index;
DROP INDEX public.users_role_index;
DROP INDEX public.users_role_created_at_index;
DROP INDEX public.users_reset_token_index;
DROP INDEX public.users_last_admin_login_index;
DROP INDEX public.users_email_index;
DROP INDEX public.user_watch_packs_watch_pack_id_index;
DROP INDEX public.user_watch_packs_user_id_index;
DROP INDEX public.user_sessions_user_id_index;
DROP INDEX public.user_sessions_refresh_token_index;
DROP INDEX public.user_sessions_is_active_index;
DROP INDEX public.user_sessions_expires_at_index;
DROP INDEX public.user_roles_user_id_is_active_index;
DROP INDEX public.user_roles_role_id_is_active_index;
DROP INDEX public.user_roles_expires_at_index;
DROP INDEX public.user_roles_assigned_by_index;
DROP INDEX public.unsubscribe_tokens_user_id_index;
DROP INDEX public.unsubscribe_tokens_token_index;
DROP INDEX public.unsubscribe_tokens_expires_at_index;
DROP INDEX public.trend_analysis_product_id_index;
DROP INDEX public.trend_analysis_product_id_analyzed_at_index;
DROP INDEX public.trend_analysis_analyzed_at_index;
DROP INDEX public.testimonials_user_id_index;
DROP INDEX public.testimonials_rating_index;
DROP INDEX public.testimonials_moderation_status_is_public_index;
DROP INDEX public.testimonials_is_featured_is_public_index;
DROP INDEX public.system_metrics_recorded_at_index;
DROP INDEX public.system_metrics_metric_type_recorded_at_index;
DROP INDEX public.system_metrics_metric_name_recorded_at_index;
DROP INDEX public.system_health_status_index;
DROP INDEX public.system_health_service_name_index;
DROP INDEX public.system_health_checked_at_index;
DROP INDEX public.social_shares_user_id_platform_index;
DROP INDEX public.social_shares_shared_at_index;
DROP INDEX public.social_shares_alert_id_index;
DROP INDEX public.seasonal_patterns_product_id_pattern_type_index;
DROP INDEX public.seasonal_patterns_pattern_name_index;
DROP INDEX public.seasonal_patterns_category_id_pattern_type_index;
DROP INDEX public.roles_level_index;
DROP INDEX public.roles_is_system_role_is_active_index;
DROP INDEX public.roles_created_by_index;
DROP INDEX public.retailers_slug_index;
DROP INDEX public.retailers_is_active_index;
DROP INDEX public.products_upc_index;
DROP INDEX public.products_slug_index;
DROP INDEX public.products_set_name_index;
DROP INDEX public.products_release_date_index;
DROP INDEX public.products_is_active_index;
DROP INDEX public.products_category_id_index;
DROP INDEX public.product_categories_slug_index;
DROP INDEX public.product_categories_parent_id_index;
DROP INDEX public.product_availability_retailer_id_index;
DROP INDEX public.product_availability_product_id_index;
DROP INDEX public.product_availability_last_checked_index;
DROP INDEX public.product_availability_in_stock_index;
DROP INDEX public.price_history_retailer_id_index;
DROP INDEX public.price_history_recorded_at_index;
DROP INDEX public.price_history_product_id_retailer_id_recorded_at_index;
DROP INDEX public.price_history_product_id_index;
DROP INDEX public.post_likes_user_id_index;
DROP INDEX public.post_likes_post_id_index;
DROP INDEX public.post_comments_user_id_index;
DROP INDEX public.post_comments_post_id_moderation_status_index;
DROP INDEX public.post_comments_created_at_index;
DROP INDEX public.permission_audit_log_target_user_id_created_at_index;
DROP INDEX public.permission_audit_log_created_at_index;
DROP INDEX public.permission_audit_log_actor_user_id_created_at_index;
DROP INDEX public.permission_audit_log_action_created_at_index;
DROP INDEX public.ml_training_data_status_data_type_created_at_index;
DROP INDEX public.ml_training_data_reviewed_by_index;
DROP INDEX public.ml_training_data_dataset_name_data_type_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_timeframe_days_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_index;
DROP INDEX public.ml_predictions_expires_at_index;
DROP INDEX public.ml_models_trained_by_index;
DROP INDEX public.ml_models_status_deployed_at_index;
DROP INDEX public.ml_models_name_status_created_at_index;
DROP INDEX public.ml_model_metrics_prediction_type_index;
DROP INDEX public.ml_model_metrics_model_name_model_version_index;
DROP INDEX public.ml_model_metrics_last_evaluated_at_index;
DROP INDEX public.idx_users_subscription_status;
DROP INDEX public.idx_users_stripe_customer;
DROP INDEX public.idx_users_push_subscriptions;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_transactions_user_hash;
DROP INDEX public.idx_transactions_status;
DROP INDEX public.idx_transactions_retailer;
DROP INDEX public.idx_transactions_product;
DROP INDEX public.idx_billing_events_type;
DROP INDEX public.idx_billing_events_subscription;
DROP INDEX public.idx_billing_events_invoice;
DROP INDEX public.idx_billing_events_customer;
DROP INDEX public.external_product_map_product_id_index;
DROP INDEX public.engagement_metrics_product_id_metrics_date_index;
DROP INDEX public.engagement_metrics_product_id_index;
DROP INDEX public.engagement_metrics_metrics_date_index;
DROP INDEX public.email_preferences_user_id_index;
DROP INDEX public.email_preferences_unsubscribe_token_index;
DROP INDEX public.email_delivery_logs_user_id_index;
DROP INDEX public.email_delivery_logs_sent_at_index;
DROP INDEX public.email_delivery_logs_message_id_index;
DROP INDEX public.email_delivery_logs_email_type_index;
DROP INDEX public.email_delivery_logs_alert_id_index;
DROP INDEX public.email_complaints_timestamp_index;
DROP INDEX public.email_complaints_message_id_index;
DROP INDEX public.email_bounces_timestamp_index;
DROP INDEX public.email_bounces_message_id_index;
DROP INDEX public.email_bounces_bounce_type_index;
DROP INDEX public.discord_servers_user_id_is_active_index;
DROP INDEX public.data_quality_metrics_product_id_data_source_index;
DROP INDEX public.data_quality_metrics_overall_quality_score_index;
DROP INDEX public.data_quality_metrics_assessed_at_index;
DROP INDEX public.csv_operations_user_id_operation_type_index;
DROP INDEX public.csv_operations_created_at_index;
DROP INDEX public.conversion_analytics_user_id_index;
DROP INDEX public.conversion_analytics_event_type_index;
DROP INDEX public.conversion_analytics_event_date_index;
DROP INDEX public.community_posts_user_id_index;
DROP INDEX public.community_posts_type_moderation_status_index;
DROP INDEX public.community_posts_is_featured_is_public_index;
DROP INDEX public.community_posts_created_at_index;
DROP INDEX public.comment_likes_user_id_index;
DROP INDEX public.comment_likes_comment_id_index;
DROP INDEX public.availability_snapshots_snapshot_time_index;
DROP INDEX public.availability_snapshots_retailer_id_snapshot_time_index;
DROP INDEX public.availability_snapshots_product_id_snapshot_time_index;
DROP INDEX public.alerts_watch_id_index;
DROP INDEX public.alerts_user_id_status_index;
DROP INDEX public.alerts_user_id_index;
DROP INDEX public.alerts_type_index;
DROP INDEX public.alerts_status_priority_created_at_index;
DROP INDEX public.alerts_status_index;
DROP INDEX public.alerts_scheduled_for_index;
DROP INDEX public.alerts_retailer_id_index;
DROP INDEX public.alerts_product_id_index;
DROP INDEX public.alerts_priority_index;
DROP INDEX public.alerts_created_at_index;
DROP INDEX public.alert_deliveries_status_index;
DROP INDEX public.alert_deliveries_sent_at_index;
DROP INDEX public.alert_deliveries_channel_index;
DROP INDEX public.alert_deliveries_alert_id_index;
DROP INDEX public.admin_audit_log_target_type_target_id_index;
DROP INDEX public.admin_audit_log_created_at_index;
DROP INDEX public.admin_audit_log_admin_user_id_created_at_index;
DROP INDEX public.admin_audit_log_action_created_at_index;
ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_pkey;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_product_id_unique;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_pkey;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_slug_unique;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_subscription_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_stripe_customer_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_pkey;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_refresh_token_unique;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_pkey;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_role_id_unique;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_pkey;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_token_unique;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_pkey;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_pkey;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_pkey;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_pkey;
ALTER TABLE ONLY public.system_metrics DROP CONSTRAINT system_metrics_pkey;
ALTER TABLE ONLY public.system_health DROP CONSTRAINT system_health_pkey;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_stripe_price_id_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_slug_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_pkey;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_pkey;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_slug_unique;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_name_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_slug_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_upc_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_slug_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_slug_unique;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_pkey;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_retailer_id_unique;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_pkey;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_pkey;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_user_id_unique;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_pkey;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_pkey;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_pkey;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_pkey;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_name_version_unique;
ALTER TABLE ONLY public.ml_model_metrics DROP CONSTRAINT ml_model_metrics_pkey;
ALTER TABLE ONLY public.knex_migrations DROP CONSTRAINT knex_migrations_pkey;
ALTER TABLE ONLY public.knex_migrations_lock DROP CONSTRAINT knex_migrations_lock_pkey;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_retailer_slug_external_id_unique;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_pkey;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_metrics_date_unique;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_pkey;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_unsubscribe_token_unique;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_pkey;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_pkey;
ALTER TABLE ONLY public.email_complaints DROP CONSTRAINT email_complaints_pkey;
ALTER TABLE ONLY public.email_bounces DROP CONSTRAINT email_bounces_pkey;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_server_id_unique;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_pkey;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_pkey;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_pkey;
ALTER TABLE ONLY public.conversion_analytics DROP CONSTRAINT conversion_analytics_pkey;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_user_id_unique;
ALTER TABLE ONLY public.billing_events DROP CONSTRAINT billing_events_pkey;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_pkey;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_pkey;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_pkey;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_pkey;
ALTER TABLE public.knex_migrations_lock ALTER COLUMN index DROP DEFAULT;
ALTER TABLE public.knex_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.webhooks;
DROP TABLE public.watches;
DROP TABLE public.watch_packs;
DROP TABLE public.users;
DROP TABLE public.user_watch_packs;
DROP TABLE public.user_sessions;
DROP TABLE public.user_roles;
DROP TABLE public.unsubscribe_tokens;
DROP TABLE public.trend_analysis;
DROP TABLE public.transactions;
DROP TABLE public.testimonials;
DROP TABLE public.system_metrics;
DROP TABLE public.system_health;
DROP TABLE public.subscription_plans;
DROP TABLE public.social_shares;
DROP TABLE public.seasonal_patterns;
DROP TABLE public.roles;
DROP TABLE public.retailers;
DROP TABLE public.products;
DROP TABLE public.product_categories;
DROP TABLE public.product_availability;
DROP TABLE public.price_history;
DROP TABLE public.post_likes;
DROP TABLE public.post_comments;
DROP TABLE public.permission_audit_log;
DROP TABLE public.ml_training_data;
DROP TABLE public.ml_predictions;
DROP TABLE public.ml_models;
DROP TABLE public.ml_model_metrics;
DROP SEQUENCE public.knex_migrations_lock_index_seq;
DROP TABLE public.knex_migrations_lock;
DROP SEQUENCE public.knex_migrations_id_seq;
DROP TABLE public.knex_migrations;
DROP TABLE public.external_product_map;
DROP TABLE public.engagement_metrics;
DROP TABLE public.email_preferences;
DROP TABLE public.email_delivery_logs;
DROP TABLE public.email_complaints;
DROP TABLE public.email_bounces;
DROP TABLE public.discord_servers;
DROP TABLE public.data_quality_metrics;
DROP TABLE public.csv_operations;
DROP TABLE public.conversion_analytics;
DROP TABLE public.community_posts;
DROP TABLE public.comment_likes;
DROP TABLE public.billing_events;
DROP TABLE public.availability_snapshots;
DROP TABLE public.alerts;
DROP TABLE public.alert_deliveries;
DROP TABLE public.admin_audit_log;
DROP TYPE public.billing_period_enum;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pg_trgm;
--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4341 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4342 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1061 (class 1247 OID 17451)
-- Name: billing_period_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.billing_period_enum AS ENUM (
    'monthly',
    'yearly'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 17065)
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50),
    target_id character varying(255),
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT admin_audit_log_check CHECK ((((target_type IS NULL) AND (target_id IS NULL)) OR ((target_type IS NOT NULL) AND (target_id IS NOT NULL))))
);


--
-- TOC entry 229 (class 1259 OID 16747)
-- Name: alert_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id uuid NOT NULL,
    channel text NOT NULL,
    status text DEFAULT 'pending'::text,
    external_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alert_deliveries_channel_check CHECK ((channel = ANY (ARRAY['web_push'::text, 'email'::text, 'sms'::text, 'discord'::text]))),
    CONSTRAINT alert_deliveries_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'delivered'::text, 'failed'::text, 'bounced'::text])))
);


--
-- TOC entry 228 (class 1259 OID 16699)
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    watch_id uuid,
    type text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text,
    delivery_channels jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    sent_at timestamp with time zone,
    read_at timestamp with time zone,
    clicked_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alerts_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'urgent'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'failed'::text, 'read'::text]))),
    CONSTRAINT alerts_type_check CHECK ((type = ANY (ARRAY['restock'::text, 'price_drop'::text, 'low_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 238 (class 1259 OID 16922)
-- Name: availability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    stock_level integer,
    last_checked timestamp with time zone,
    snapshot_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 263 (class 1259 OID 17490)
-- Name: billing_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stripe_customer_id character varying(255) NOT NULL,
    subscription_id character varying(255),
    event_type character varying(100) NOT NULL,
    amount_cents integer,
    currency character varying(10),
    status character varying(50),
    invoice_id character varying(255),
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    raw_event jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 17342)
-- Name: comment_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 254 (class 1259 OID 17266)
-- Name: community_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.community_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    type text NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    images jsonb DEFAULT '[]'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    likes integer DEFAULT 0,
    comments_count integer DEFAULT 0,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT community_posts_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT community_posts_type_check CHECK ((type = ANY (ARRAY['success_story'::text, 'tip'::text, 'collection_showcase'::text, 'deal_share'::text, 'question'::text])))
);


--
-- TOC entry 264 (class 1259 OID 17505)
-- Name: conversion_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversion_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type character varying(255) NOT NULL,
    source character varying(255) DEFAULT 'direct'::character varying,
    medium character varying(255) DEFAULT 'organic'::character varying,
    campaign character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    event_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 251 (class 1259 OID 17194)
-- Name: csv_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csv_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    operation_type text NOT NULL,
    filename character varying(255),
    total_rows integer,
    successful_rows integer,
    failed_rows integer,
    errors jsonb DEFAULT '[]'::jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT csv_operations_operation_type_check CHECK ((operation_type = ANY (ARRAY['import'::text, 'export'::text]))),
    CONSTRAINT csv_operations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text])))
);


--
-- TOC entry 244 (class 1259 OID 17041)
-- Name: data_quality_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_quality_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    data_source character varying(255) NOT NULL,
    completeness_score numeric(5,2),
    freshness_hours numeric(8,2),
    accuracy_score numeric(5,2),
    missing_fields jsonb DEFAULT '[]'::jsonb,
    overall_quality_score numeric(5,2),
    recommendations jsonb DEFAULT '[]'::jsonb,
    assessed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 249 (class 1259 OID 17150)
-- Name: discord_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discord_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    server_id character varying(255) NOT NULL,
    channel_id character varying(255) NOT NULL,
    token text,
    alert_filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_alerts_sent integer DEFAULT 0,
    last_alert_sent timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 16862)
-- Name: email_bounces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_bounces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    bounce_type text NOT NULL,
    bounce_sub_type character varying(255) NOT NULL,
    bounced_recipients jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_bounces_bounce_type_check CHECK ((bounce_type = ANY (ARRAY['permanent'::text, 'transient'::text])))
);


--
-- TOC entry 237 (class 1259 OID 16873)
-- Name: email_complaints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_complaints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    complained_recipients jsonb NOT NULL,
    feedback_type character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16841)
-- Name: email_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_delivery_logs (
    id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    alert_id uuid,
    email_type text NOT NULL,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message_id character varying(255),
    sent_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    bounced_at timestamp with time zone,
    complained_at timestamp with time zone,
    bounce_reason text,
    complaint_reason text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_delivery_logs_email_type_check CHECK ((email_type = ANY (ARRAY['alert'::text, 'welcome'::text, 'marketing'::text, 'digest'::text, 'system'::text])))
);


--
-- TOC entry 233 (class 1259 OID 16830)
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    alert_emails boolean DEFAULT true,
    marketing_emails boolean DEFAULT true,
    weekly_digest boolean DEFAULT true,
    unsubscribe_token character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 16989)
-- Name: engagement_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    watch_count integer DEFAULT 0,
    alert_count integer DEFAULT 0,
    click_count integer DEFAULT 0,
    click_through_rate numeric(5,2) DEFAULT '0'::numeric,
    search_volume integer DEFAULT 0,
    social_mentions integer DEFAULT 0,
    engagement_score numeric(5,2) DEFAULT '0'::numeric,
    trend_direction text DEFAULT 'stable'::text,
    metrics_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT engagement_metrics_trend_direction_check CHECK ((trend_direction = ANY (ARRAY['rising'::text, 'falling'::text, 'stable'::text])))
);


--
-- TOC entry 265 (class 1259 OID 17532)
-- Name: external_product_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_product_map (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    retailer_slug character varying(255) NOT NULL,
    external_id character varying(255) NOT NULL,
    product_id uuid NOT NULL,
    product_url character varying(255) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 16496)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- TOC entry 217 (class 1259 OID 16495)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4343 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 220 (class 1259 OID 16503)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- TOC entry 219 (class 1259 OID 16502)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4344 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 241 (class 1259 OID 16975)
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_model_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(255) NOT NULL,
    prediction_type text NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    mean_absolute_error numeric(10,4),
    root_mean_square_error numeric(10,4),
    training_data_size integer,
    prediction_count integer DEFAULT 0,
    avg_processing_time numeric(8,2),
    last_trained_at timestamp with time zone,
    last_evaluated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_model_metrics_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 246 (class 1259 OID 17086)
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    status text DEFAULT 'training'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    model_path character varying(500),
    training_started_at timestamp with time zone,
    training_completed_at timestamp with time zone,
    deployed_at timestamp with time zone,
    trained_by uuid,
    training_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_models_check CHECK (((status <> 'active'::text) OR (deployed_at IS NOT NULL))),
    CONSTRAINT ml_models_check1 CHECK (((status <> 'training'::text) OR (training_started_at IS NOT NULL))),
    CONSTRAINT ml_models_status_check CHECK ((status = ANY (ARRAY['training'::text, 'active'::text, 'deprecated'::text, 'failed'::text])))
);


--
-- TOC entry 240 (class 1259 OID 16957)
-- Name: ml_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_predictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    prediction_type text NOT NULL,
    prediction_data jsonb NOT NULL,
    timeframe_days integer,
    input_price numeric(10,2),
    confidence_score numeric(5,2),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_predictions_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 247 (class 1259 OID 17112)
-- Name: ml_training_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_training_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dataset_name character varying(200) NOT NULL,
    data_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_training_data_check CHECK (((status = 'pending'::text) OR ((reviewed_by IS NOT NULL) AND (reviewed_at IS NOT NULL)))),
    CONSTRAINT ml_training_data_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 260 (class 1259 OID 17418)
-- Name: permission_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid NOT NULL,
    target_user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    permission_or_role character varying(100),
    old_value json,
    new_value json,
    reason text,
    ip_address character varying(45),
    user_agent text,
    metadata json DEFAULT '{}'::json,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 255 (class 1259 OID 17294)
-- Name: post_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    likes integer DEFAULT 0,
    is_public boolean DEFAULT true,
    moderation_status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT post_comments_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 256 (class 1259 OID 17321)
-- Name: post_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 16771)
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 224 (class 1259 OID 16594)
-- Name: product_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_availability (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean DEFAULT false,
    price numeric(10,2),
    original_price numeric(10,2),
    availability_status text,
    product_url character varying(255) NOT NULL,
    cart_url character varying(255),
    stock_level integer,
    store_locations jsonb DEFAULT '[]'::jsonb,
    last_checked timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_in_stock timestamp with time zone,
    last_price_change timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_availability_availability_status_check CHECK ((availability_status = ANY (ARRAY['in_stock'::text, 'low_stock'::text, 'out_of_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 222 (class 1259 OID 16545)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    parent_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16565)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    sku character varying(255),
    upc character varying(255),
    category_id uuid,
    set_name character varying(255),
    series character varying(255),
    release_date date,
    msrp numeric(10,2),
    image_url character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    popularity_score integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT products_popularity_score_check CHECK (((popularity_score >= 0) AND (popularity_score <= 1000)))
);


--
-- TOC entry 221 (class 1259 OID 16523)
-- Name: retailers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retailers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    website_url character varying(255) NOT NULL,
    api_type text NOT NULL,
    api_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    rate_limit_per_minute integer DEFAULT 60,
    health_score integer DEFAULT 100,
    last_health_check timestamp with time zone,
    supported_features jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT retailers_api_type_check CHECK ((api_type = ANY (ARRAY['official'::text, 'affiliate'::text, 'scraping'::text]))),
    CONSTRAINT retailers_health_score_check CHECK (((health_score >= 0) AND (health_score <= 100))),
    CONSTRAINT retailers_rate_limit_per_minute_check CHECK (((rate_limit_per_minute >= 1) AND (rate_limit_per_minute <= 10000)))
);


--
-- TOC entry 258 (class 1259 OID 17363)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    permissions json DEFAULT '[]'::json,
    is_system_role boolean DEFAULT false,
    categories json DEFAULT '[]'::json,
    level integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 17017)
-- Name: seasonal_patterns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasonal_patterns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    category_id uuid,
    pattern_type character varying(255) NOT NULL,
    pattern_name character varying(255) NOT NULL,
    avg_price_change numeric(5,2),
    availability_change numeric(5,2),
    demand_multiplier numeric(4,2) DEFAULT '1'::numeric,
    historical_occurrences integer DEFAULT 1,
    confidence numeric(5,2),
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 252 (class 1259 OID 17215)
-- Name: social_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    alert_id uuid,
    platform character varying(255) NOT NULL,
    share_type character varying(255) DEFAULT 'manual'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    shared_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 261 (class 1259 OID 17455)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    billing_period public.billing_period_enum NOT NULL,
    stripe_price_id character varying(255),
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    limits jsonb DEFAULT '{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT name_not_empty CHECK ((length(TRIM(BOTH FROM name)) > 0)),
    CONSTRAINT price_non_negative CHECK ((price >= (0)::numeric))
);


--
-- TOC entry 232 (class 1259 OID 16814)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    status text NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    message text,
    checked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_health_status_check CHECK ((status = ANY (ARRAY['healthy'::text, 'degraded'::text, 'down'::text])))
);


--
-- TOC entry 248 (class 1259 OID 17133)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type text NOT NULL,
    value numeric(15,6) NOT NULL,
    labels jsonb DEFAULT '{}'::jsonb NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['gauge'::text, 'counter'::text, 'histogram'::text, 'summary'::text])))
);


--
-- TOC entry 253 (class 1259 OID 17239)
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    rating integer NOT NULL,
    is_verified boolean DEFAULT false,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT testimonials_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- TOC entry 262 (class 1259 OID 17475)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_slug character varying(100) NOT NULL,
    rule_id uuid,
    user_id_hash character varying(200) NOT NULL,
    status character varying(32) NOT NULL,
    price_paid numeric(10,2),
    msrp numeric(10,2),
    qty integer DEFAULT 1 NOT NULL,
    alert_at timestamp with time zone,
    added_to_cart_at timestamp with time zone,
    purchased_at timestamp with time zone,
    lead_time_ms integer,
    failure_reason text,
    region character varying(64),
    session_fingerprint character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 16942)
-- Name: trend_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trend_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    price_trend numeric(10,6),
    availability_trend numeric(10,6),
    demand_score numeric(5,2),
    volatility_score numeric(5,2),
    analyzed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 16851)
-- Name: unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unsubscribe_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    email_type text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT unsubscribe_tokens_email_type_check CHECK ((email_type = ANY (ARRAY['all'::text, 'alerts'::text, 'marketing'::text, 'digest'::text])))
);


--
-- TOC entry 259 (class 1259 OID 17385)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assignment_reason text,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 16792)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    refresh_token character varying(255) NOT NULL,
    device_info character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 16673)
-- Name: user_watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    watch_pack_id uuid NOT NULL,
    customizations jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16477)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    subscription_tier character varying(20) DEFAULT 'free'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_verified boolean DEFAULT false,
    verification_token character varying(255),
    reset_token character varying(255),
    reset_token_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login timestamp with time zone,
    shipping_addresses jsonb DEFAULT '[]'::jsonb,
    payment_methods jsonb DEFAULT '[]'::jsonb,
    retailer_credentials jsonb DEFAULT '{}'::jsonb,
    notification_settings jsonb DEFAULT '{"sms": false, "email": true, "discord": false, "web_push": true}'::jsonb,
    quiet_hours jsonb DEFAULT '{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}'::jsonb,
    timezone character varying(255) DEFAULT 'UTC'::character varying,
    zip_code character varying(255),
    push_subscriptions jsonb DEFAULT '[]'::jsonb,
    role text DEFAULT 'user'::text NOT NULL,
    last_admin_login timestamp with time zone,
    admin_permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    preferences jsonb DEFAULT '{}'::jsonb,
    newsletter_subscription boolean DEFAULT false,
    terms_accepted boolean DEFAULT false,
    direct_permissions json DEFAULT '[]'::json,
    role_last_updated timestamp with time zone,
    role_updated_by uuid,
    permission_metadata json DEFAULT '{}'::json,
    stripe_customer_id character varying(255),
    subscription_id character varying(255),
    subscription_status character varying(50),
    subscription_start_date timestamp with time zone,
    subscription_end_date timestamp with time zone,
    trial_end_date timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    subscription_plan_id character varying(255),
    CONSTRAINT users_failed_login_attempts_check CHECK (((failed_login_attempts >= 0) AND (failed_login_attempts <= 10))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['user'::text, 'admin'::text, 'super_admin'::text])))
);


--
-- TOC entry 226 (class 1259 OID 16656)
-- Name: watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    product_ids jsonb NOT NULL,
    is_active boolean DEFAULT true,
    auto_update boolean DEFAULT true,
    update_criteria character varying(255),
    subscriber_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 16624)
-- Name: watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_ids jsonb DEFAULT '[]'::jsonb,
    max_price numeric(10,2),
    availability_type text DEFAULT 'both'::text,
    zip_code character varying(255),
    radius_miles integer,
    is_active boolean DEFAULT true,
    alert_preferences jsonb DEFAULT '{}'::jsonb,
    last_alerted timestamp with time zone,
    alert_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    auto_purchase jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT watches_availability_type_check CHECK ((availability_type = ANY (ARRAY['online'::text, 'in_store'::text, 'both'::text])))
);


--
-- TOC entry 250 (class 1259 OID 17171)
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret text,
    events jsonb NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb,
    retry_config jsonb DEFAULT '{"maxRetries": 3, "retryDelay": 1000, "backoffMultiplier": 2}'::jsonb,
    filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_calls integer DEFAULT 0,
    successful_calls integer DEFAULT 0,
    failed_calls integer DEFAULT 0,
    last_triggered timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3533 (class 2604 OID 16499)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3534 (class 2604 OID 16506)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 4315 (class 0 OID 17065)
-- Dependencies: 245
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, details, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4299 (class 0 OID 16747)
-- Dependencies: 229
-- Data for Name: alert_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_deliveries (id, alert_id, channel, status, external_id, metadata, sent_at, delivered_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4298 (class 0 OID 16699)
-- Dependencies: 228
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, product_id, retailer_id, watch_id, type, priority, data, status, delivery_channels, scheduled_for, sent_at, read_at, clicked_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4308 (class 0 OID 16922)
-- Dependencies: 238
-- Data for Name: availability_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_snapshots (id, product_id, retailer_id, in_stock, availability_status, stock_level, last_checked, snapshot_time) FROM stdin;
fd658cca-5980-4efc-9898-9c920038bfed	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	2	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
77dc7c74-f029-479e-9471-ca5e6e1e936c	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
a7787e6f-ef44-4028-acd6-5cc1263f52e7	418e4d95-5e24-45ab-9d82-9f8fc0410132	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
9058ba0b-088a-4df1-a041-e7efdd412eed	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
f9892853-756b-4795-9c66-d4f48c74472b	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
5dbcee3e-8126-49b2-b1ac-e150735fb043	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
29bf7182-8377-4cac-9b94-56356ba73678	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
c9ff58e2-bc77-4ad2-bfa7-3be670f5559e	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
3c37a69b-768a-4ed6-8d6a-5a787594311a	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	t	low_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
fc8b5159-90f1-43b8-b504-b34d228f0f4f	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
ebd00fff-8dfc-41ae-9772-908a8b5952fe	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
97323a6d-cf90-4237-9d77-c7180ff94210	b4dfaf4f-ce1b-4386-ae65-65512832d284	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
5cb3fc67-d054-4e1d-a73b-90210d01e3f8	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
9f23a93d-1221-4523-8f1a-bebd6cd917c0	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
cc78ecf7-1d38-40be-b9d3-2547178a767f	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
2a6da9dc-a7c9-451a-9705-cbffc98cb0e3	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
4a388ebe-890a-4b70-b67b-cf36eda0b234	669e93c6-5846-4046-8d40-d94bfd34b780	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
c41a60b3-ab6f-4296-b241-d8912356b396	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
4faf612b-1889-4196-b821-1c21cbe2bdcd	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
fafa949e-455e-489e-99a6-10fd651d1203	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
41b4348a-1747-4209-a257-e2c29579cd9f	e07633f1-7182-4567-a6c5-60456b332f0c	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
018e172a-0959-4d6f-9c72-13b066edcb51	e07633f1-7182-4567-a6c5-60456b332f0c	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
db5d08b6-cb98-4eba-a5fb-367a73a8c669	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	30	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
73107f34-6ea6-4b32-bf2a-c8fbbf390c98	e07633f1-7182-4567-a6c5-60456b332f0c	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
8d8dcf07-493d-4482-a52c-c22dca02596c	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
53929e1f-6e4a-497b-8ebe-38e7199a12a7	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
c99aa6d0-16fd-44fe-81b6-af1c097371d3	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
4f3a7bd9-a45a-473c-87fa-6098a1b57c61	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
567b52c8-b1a9-4498-b5a0-24f16c097f6f	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
0c016fee-652d-48a8-8b56-c696585674a0	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	36	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
57e10fa7-afca-41e7-ac5c-ccd7f3cfffa4	345a6e90-30bb-49d2-bf67-7b4377955cfa	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
cdd24cc5-89e9-4aa8-bf2d-2ec23f9ff4a7	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
331a68d6-2a22-4579-b3a1-2d439fe1b9fd	345a6e90-30bb-49d2-bf67-7b4377955cfa	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
7c3edd5e-6a90-49d2-81ad-918f6c02c6e1	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
a77c390d-f67a-4135-9e3c-bdd47c1cb3bc	345a6e90-30bb-49d2-bf67-7b4377955cfa	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
347abd29-0d63-4934-b831-5349907be80b	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	3	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
37929053-8199-4034-98c3-641f6badfe81	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
750e631b-3308-433b-a962-40d6ce2bb55d	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
2655f224-1bf6-4d70-bf1e-68d785408525	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
9dc03454-3500-4c1b-b26b-ea66f66d4735	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
94a451e6-964d-441a-ba43-9cdacc95788d	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	43	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
7925bb03-c1c5-4405-b292-54cfaf2a1359	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
9112bc16-6d2a-4e99-86b1-a2a7f53b70e1	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	9	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
9b91f6a5-e9b7-4bd3-921e-86edec5ce3f4	afccfd8f-9743-44a5-ba87-0f2ab1048f97	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
99afaf5a-4e5c-4456-80eb-22ee3a301666	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
d1ad1d64-84d3-4115-bb80-9b066c8ef7fa	afccfd8f-9743-44a5-ba87-0f2ab1048f97	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
1a064dde-27af-4bd6-99bd-bc52d15e0e12	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
de442c1f-34c3-4395-bc45-d01d1f0a5e41	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	1	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
6bb51d8d-cb88-4c14-b616-e59785cf7c25	d6ca80c9-732a-49c7-ab46-2a4c71a86110	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
1df8c3bf-e573-4c3e-9ba3-40298851de49	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	16	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
7d4b3da6-4f09-488a-b356-8e997e32f104	d6ca80c9-732a-49c7-ab46-2a4c71a86110	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
04afedf2-9315-40d8-9440-557c9e3a87a2	d6ca80c9-732a-49c7-ab46-2a4c71a86110	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
9e515659-a284-4fa7-9363-bf83079eb6db	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
de7360f4-3380-4622-918f-f9e871b11915	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	11	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
6357932b-9f90-435a-8c83-9b2baf79b5ce	69e556c3-ee7f-4ac8-85da-35345a52cf5a	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
b496635b-3691-43fb-9c1d-b7bde1e071a0	69e556c3-ee7f-4ac8-85da-35345a52cf5a	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
b1462390-0885-4a85-a65e-029fedfb7797	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
f018bcb3-94f6-4e4c-83b4-6795769d901a	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
5be6c37c-8ebf-4b1d-9fa6-d68fc915dfdf	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
b4d71dde-79f8-4bf1-8b2e-77c5b0b29320	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
36d3ff3a-7fac-49e6-8f28-23db321e4b6c	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
61d302db-a8e7-4ff4-a8d0-f3946b7ade94	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
c4e808ce-6c37-4138-ac6c-1a44aab1c54c	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
ddb5a702-8617-427d-bacb-83dbacc0ab0a	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
8008d559-e41c-4d0a-80dd-252f8f30a9b3	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
aa161d15-48b0-408c-963c-48995a8a3b89	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
a5afa81d-fb35-4425-8601-3e544583c4ef	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	15	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
fd71291b-c1f4-4d2a-bf18-4e9939a1902b	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
8fa24d7f-5071-4cad-9500-9c69ea119f4d	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
c61b5459-232f-4763-90b7-84341f99de13	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
c984bb5b-fef4-48c8-870a-481bf00ae92b	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
42f04b87-7ac3-424b-a534-b6381ca055e2	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	48	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
62479ba4-e75e-44dc-a705-6af7a7a8f934	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	6	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
b2831756-e562-4b88-b9ad-a4db23e20254	5b266066-2106-40ae-b282-949dc23491a9	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
dcab048b-0ffa-4395-b574-c072d3b755e9	5b266066-2106-40ae-b282-949dc23491a9	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
ea053b1a-8b1c-487e-b80c-7d8b89f6e77c	5b266066-2106-40ae-b282-949dc23491a9	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
42fb62d7-f040-43bc-94db-b07c15ab2c12	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
e8d07ead-a56a-485f-ab27-fe7e0759e087	5b266066-2106-40ae-b282-949dc23491a9	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
014c5771-e34a-4c6f-90c6-9b87f8255cc9	7cbb19fa-f7bd-49f8-84f8-07f983c84132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
17fdf2e2-d0fd-4b59-8b7d-0d0b8a8af103	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
f6407f34-9a75-4891-8ec4-c9aad9557ea3	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
be703c4f-1500-4e64-8562-8391b464e04f	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
def97a76-28b2-44f4-b6ef-8dae50de2238	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
3f412ed5-e05f-4b3b-9e77-3e29171c2b48	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
cc8ca043-d7d6-4b1c-a3ad-c1caba04f6d3	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
669364b2-90dd-4d6f-a6b1-c60c771224bb	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	4	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
4e59499e-ff44-44bb-a548-2b8593d7c1e4	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
12906ca2-d3d7-478c-9510-53cd81ad2421	9975f314-970f-4dda-9c8f-61a36558666f	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
0bb2e609-5298-4bf7-8543-a6756f6945d0	9975f314-970f-4dda-9c8f-61a36558666f	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
6f40a5ff-3b57-4bd7-babd-d6f330704fc2	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
fd83d97c-bc35-4b54-a597-cee9e9f0df9e	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
17323347-6cae-4737-a97f-71fb90dec854	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
efa69313-53e5-42c6-962f-a1fc8667f0a8	f1f9a969-2c82-453c-a6a3-775d3bf365ca	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
69433ab7-7531-421a-a4b8-b710080abf0a	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
a3de1002-3343-4b4e-9c0c-f20b7d1bf82f	f1f9a969-2c82-453c-a6a3-775d3bf365ca	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
974bd467-7589-408f-b00e-749ae7581d63	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
61274c2a-0ea0-4081-8a76-652004ede7cd	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
4212e309-22f4-4597-ac6e-92a7c57a293e	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	21	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
6f232718-97da-4891-91c3-0052f7e1f072	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
5fe77f13-e8d5-494d-a516-3a78067a3263	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
16434514-828a-4368-bbc6-438b024f14a4	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
2d284560-7778-4b79-94a8-58ab9cc5a75f	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
161a70fc-9dd8-4566-aad6-a0e959060e35	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
ef9e639b-0f81-4d51-b67a-853f3692403d	464f5a27-cbb5-4107-8ebd-f1a6fe286487	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
5f03122e-3b69-412f-97d6-e39e09d4810d	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
8d16e6b3-dc9e-43c7-97dd-a1ac9c01fa1b	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	34	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
8fc327fd-a15b-418e-9e72-710f8380abe4	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
4f91b940-47bd-4a54-b619-d80258b84d2c	464f5a27-cbb5-4107-8ebd-f1a6fe286487	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
e50535b8-6f98-4fd6-8b58-15e4a2c40bee	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
f5b9115b-b01b-4ff5-ac19-4a98d8ddc355	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
49bfc951-de97-43c3-ace6-aa8f3f859b65	210293d2-cc9d-4fca-be6e-41df29fdd537	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
fa05ebb1-ccbd-4065-8cc5-77e9236789e8	210293d2-cc9d-4fca-be6e-41df29fdd537	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
bbf6b047-92c4-44c2-b7a2-3363ab36c493	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
a41702d7-53bb-4f4a-8103-632d3d6f4251	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	31	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.404+00
e3b3dc93-3086-4f24-8b4a-cbed9446e4dd	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	2	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
00b76233-5100-432c-bcb0-2ac65bee9023	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
757d8270-0253-4f8c-b917-b8112d68666b	418e4d95-5e24-45ab-9d82-9f8fc0410132	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
3ab4b206-c307-4d44-bcdd-6e5c81bdea7a	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
72d711c6-9806-4f1c-b538-e369d837fb30	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
4cfed637-1b71-416d-ac27-2b5075620157	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
1bc0b381-3876-4ffa-a8ee-f35f77c08a55	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
22b6996a-2115-46d9-a7da-69d637b848bc	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
954a0c36-44d7-4386-a255-1cb7fe355889	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	t	low_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
a00c1f8f-2655-4dca-99e3-6ed4e5b85548	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
5f73eec0-0d7d-4989-affa-f7c04c690965	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b0c747fe-691f-4e8e-8eff-1204cecb0091	b4dfaf4f-ce1b-4386-ae65-65512832d284	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
9b1304a5-d6f3-4284-84b3-71827c0e3523	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
156927cd-b1f6-46f5-8d8a-60f2481cd47f	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
9675ee33-2da0-49d4-99f3-a731df7dd674	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
90a9e6e6-caa0-4402-a7c0-f90d32cdcf4c	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
a44bb2b2-c4da-4337-8044-576ba1b79e73	669e93c6-5846-4046-8d40-d94bfd34b780	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
71818c8b-985f-4d8e-baa0-16fe1ea7bc31	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
8eccc4df-8187-41ad-9f15-719c720dd195	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
54f74f65-e0c2-4f2d-b72c-350a73958dbf	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
42f4870a-29c5-45aa-8308-264b9967b44b	e07633f1-7182-4567-a6c5-60456b332f0c	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
4e0f8102-54b4-40ac-870b-61d9fdaf443a	e07633f1-7182-4567-a6c5-60456b332f0c	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
f4e14ca6-148f-4db6-86ed-17a975a427dd	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	30	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
d41d809d-2f1e-4871-99a8-fb2617197e58	e07633f1-7182-4567-a6c5-60456b332f0c	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
6969f91b-a239-4b3a-8e8e-da2c10edb2f6	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
6f3396d2-fbff-47ce-8559-0dc4f4b4e58d	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
19ac1453-592b-42a3-97f7-23a45f906a93	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
6e57de67-e3dd-41b4-9aed-b8ba091c8302	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
6cd79a63-9e71-4d9d-a594-eb014ff7e667	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
22c013fe-dc08-46c4-8a92-a21cbdbd1030	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	36	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
955c3222-d452-4040-aad9-ae1754e8d16c	345a6e90-30bb-49d2-bf67-7b4377955cfa	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
0799d6e2-43f8-42b4-8738-0583c6c48419	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
846552c8-5fa9-41a5-954c-d12605cf5144	345a6e90-30bb-49d2-bf67-7b4377955cfa	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
889c66af-654a-4241-8044-b7e13ac2ee29	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
91588157-f40b-4da8-b1f5-cea459fdccb3	345a6e90-30bb-49d2-bf67-7b4377955cfa	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
fb9b3d5e-5799-426f-beee-d45862db663b	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	3	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b533a280-648c-4534-b2ae-a68d51ceb498	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
9278314a-9cb7-40e2-ac38-17dfb7e32b2a	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
6ea74f05-f318-410b-b341-a1c0522ab69f	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b755d14b-0ae6-48aa-9853-b0d5537f2201	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
c1c73a35-e15a-4355-9af8-c2ea66288329	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	43	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
7d758ab9-fca6-42f7-aa43-20f5255be085	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
54a37510-0f4a-4dcb-bde9-51bdb6c6954a	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	9	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
98864f98-4e38-45b6-a332-604e4e64a813	afccfd8f-9743-44a5-ba87-0f2ab1048f97	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
2bd0997a-8164-4bf3-8657-e4f6f5b92fcb	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
47bc7ecc-0397-4e95-b4a6-ce5922e52770	afccfd8f-9743-44a5-ba87-0f2ab1048f97	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
cfa4a3fe-65d1-4185-90ce-e815d2a3af1c	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
49310f22-c5cf-4935-a81f-b2e4cc6630ea	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	1	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
02bd9239-b42c-46a9-8f7a-be9c51a8ae4c	d6ca80c9-732a-49c7-ab46-2a4c71a86110	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
350355ce-49b7-4812-ade8-809dd665e75c	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	16	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
f1822000-445a-4163-9a6d-31b29d0987d9	d6ca80c9-732a-49c7-ab46-2a4c71a86110	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
c2ab418e-e2f8-4ed5-9f86-95f8db2a097b	d6ca80c9-732a-49c7-ab46-2a4c71a86110	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
5f6f59f0-6097-412b-9e69-16b325e07655	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
9410f909-56ff-4856-8c8c-0ff77905d355	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	11	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
484ebcc1-c7cc-4b9b-a5f6-03d8d5014317	69e556c3-ee7f-4ac8-85da-35345a52cf5a	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
f0c4532c-591f-414a-923c-c941d5f9ea4d	69e556c3-ee7f-4ac8-85da-35345a52cf5a	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
4d03af97-7571-416e-af8a-968d578c4235	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
e51b44f6-feee-4d45-a87f-d5f8f7caa1da	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
545a06f7-de74-4587-ac6a-bc83f2bd1cfc	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
a2a5ce0d-ae52-4214-b93a-dac18c759f75	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
a939aca8-7298-4390-840f-511e5e6af534	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
771b296f-677e-4045-9cf0-0b39a19259f9	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
ae7c6f3e-a5d5-4546-9bdf-e9f004ed5a6e	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
1964fdbe-51e1-4bba-b69b-b5d2f4112dc5	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
cb672215-d4b3-433e-8580-fb23b1a87f24	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
f2f71992-561f-4356-9979-2bd7ffa557ac	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
e789de28-ed0e-4229-add6-d2361d9c43e4	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	15	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
c1010954-eb85-44e8-a68b-47f66c83ce2e	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
01f65aa9-b8a2-41ba-bdfc-bdeb19aabba3	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
accaa1c7-598b-4ec2-8a4b-439cca8a3aaf	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
cbb2a853-463a-44e9-85ce-bc1cb0035aa9	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
2c77a1fc-8823-44c1-ad73-5ced0380e752	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	48	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
9a19754f-cb16-484b-b476-7f49362ceda9	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	6	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
d8b59b3a-9610-4e23-8fa5-79040b0605a7	5b266066-2106-40ae-b282-949dc23491a9	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
65b7bcc2-ddac-48d0-9b30-75cc8b9524fb	5b266066-2106-40ae-b282-949dc23491a9	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
46d34def-cb83-4121-94c6-8e0ac22e102c	5b266066-2106-40ae-b282-949dc23491a9	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
f53e35bf-42eb-452e-9b36-7ae0f595c65a	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
28ae0bb3-8a68-40d6-8688-d63a459da4ad	5b266066-2106-40ae-b282-949dc23491a9	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
9e24bf98-823d-4f10-8fba-2fa1fd641a84	7cbb19fa-f7bd-49f8-84f8-07f983c84132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b07bc241-761c-440d-bd19-e25ee589e138	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b69ccfa4-a4fc-4159-a60d-60a8cf47e485	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
426f7c78-fc5b-43d0-9892-79a35c6c7fc4	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
824e502e-5b8f-47b7-bb6a-1c8090207747	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
d2a8aad0-6bf7-4de0-862d-7a837b73d0a9	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b6e296e4-9174-435e-a07e-f57f13a2476f	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
8d7f17ad-45b2-4103-824e-925342a1960a	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	4	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
3771849f-2faa-46ec-a31f-a2caf17829c9	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
bc2645db-45ca-4bc7-83f8-1b88a5d0cef2	9975f314-970f-4dda-9c8f-61a36558666f	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
1ab19518-b6b5-4815-a636-469ceda06f2f	9975f314-970f-4dda-9c8f-61a36558666f	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
d28acc5b-7a35-4b89-80b2-5bf5ac5232e8	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
eeef59d5-355d-4042-8900-0b71df963dad	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
e40b901a-9307-486c-87f0-747f371f2082	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
ff613d4d-3cc6-4097-a54a-2195194924db	f1f9a969-2c82-453c-a6a3-775d3bf365ca	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
3136ff70-bb78-498a-ba72-b5f5ec833759	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
25736ff9-d402-46da-a86c-fc64c8bba8dd	f1f9a969-2c82-453c-a6a3-775d3bf365ca	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
859a2ec2-1eb5-404d-af67-0940c30240fe	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
a3aa4185-9b04-48fc-9add-865e04148799	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
6ba3f7b9-3d70-4623-ba01-be2a19b8a9c9	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	21	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
bfdf95eb-38ce-458a-a94c-9000bb13daa1	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
b0ebda91-0395-4ec4-9107-947c4748837c	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
7be2014f-794f-459d-b88a-3b24e4626b67	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
3c2edef1-4b8d-4694-a990-80715f3a69a3	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
7f2ae237-c36a-47c4-8853-c41f40d40002	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
aa5e0292-6bf3-44e6-8ccf-e8db044b09be	464f5a27-cbb5-4107-8ebd-f1a6fe286487	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
037202d1-05a4-468c-9849-1b862ae43551	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
bdf0a9b8-f65f-4050-9db4-08693c1180cb	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	34	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
a482bb63-f516-4f27-8a8d-0e3d770a27f9	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
bd54757f-fa39-475a-ae38-72241d4caa93	464f5a27-cbb5-4107-8ebd-f1a6fe286487	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
77b1a6a6-e810-41ca-99e6-6fd5f3371eaa	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
14d8be32-f7e3-43c5-8706-d7c7cd713bb9	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
afbf6df5-982a-4d77-877c-da2e829207e1	210293d2-cc9d-4fca-be6e-41df29fdd537	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
c3d4c7dc-15a2-4254-9508-816194bc5b82	210293d2-cc9d-4fca-be6e-41df29fdd537	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
ee099b41-b8ad-499d-9b7c-1685fc3304a6	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
2224cf33-b016-4dc6-beee-9a3ccb1235b2	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	31	2025-09-03 16:53:58.124+00	2025-09-03 17:00:00.568+00
54ba69ad-5644-421c-a70d-a980736bf8bf	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	2	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
2607e5e6-c6c9-4b2c-89fa-73a24e753bf2	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
7cbba125-b3e1-454b-9b89-9c4cbbd2a065	418e4d95-5e24-45ab-9d82-9f8fc0410132	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
94b9eaeb-e77f-48ec-8d91-903e73ccb222	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
0f82d18d-8621-4033-8cee-f9db30fef34b	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a2973e22-babe-4fd4-86b7-c35b9cec3a9a	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
aba958fb-0a57-4ac7-91f0-0e7a1f19f3ef	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
9406013f-74ae-424d-baa0-a2db80d0e29a	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
b4f70bdb-6310-4252-a595-8fad71d33778	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	t	low_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ba2edd5f-46de-468d-952b-cb5bbc696452	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
df5e4c1c-738d-4972-b26d-2233bf2ac813	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
1cafcac6-c497-43dd-bb52-d99b9edc8270	b4dfaf4f-ce1b-4386-ae65-65512832d284	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ada5f81c-3158-4ace-b870-64e82e8130a3	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
b9692797-5d2b-4f26-b646-ba6c7e6837fa	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a44be91d-a252-4a92-94ca-72db3974aa09	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
87207317-8145-4433-8bac-1e5e8736ea65	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f5d30bc2-88da-4f63-8cd7-670367632fec	669e93c6-5846-4046-8d40-d94bfd34b780	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
df1360c7-2fb1-4e04-bbfd-ad630c45295e	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
03600884-b33d-4c1a-9ae6-b537d8f83e95	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
4c376a8d-e199-489e-9ba9-505b6b123d71	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ab9daa88-4e26-432e-892c-40ae888c8687	e07633f1-7182-4567-a6c5-60456b332f0c	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
70e7903c-d351-407b-9fbb-949f7bb396b9	e07633f1-7182-4567-a6c5-60456b332f0c	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
784b038f-de68-4743-98ab-d938f2b26f4b	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	30	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
9406c6af-3eff-4620-8a59-366be1cf2844	e07633f1-7182-4567-a6c5-60456b332f0c	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
68d51cc0-289e-48ab-a5da-f9b2d3810bcd	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
57a44ec1-e5de-4e87-a90e-9f44b676774e	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
5b6a0bee-cfdc-49c1-80e8-61370a542a86	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c53de80e-d93d-43e7-998b-511a16823715	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
9b9c1099-a4a7-4fb1-b432-9fb45495f21f	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
fdde95a4-1d8b-41d4-b9bd-b4688ad48b4b	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	36	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
1565ce99-3ab5-4793-b612-f1ad2feefdb5	345a6e90-30bb-49d2-bf67-7b4377955cfa	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
42716daa-7492-470f-bdab-788f2665624e	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
88fb66a5-1450-4fdf-83a0-dbe5ee66f401	345a6e90-30bb-49d2-bf67-7b4377955cfa	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
188d2354-476a-4e69-b9b6-228cb43db890	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
b2a0a3e5-7dc4-4b73-b4e6-e0389bf5f47c	345a6e90-30bb-49d2-bf67-7b4377955cfa	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
2edbf49e-c2c9-4338-8b06-a0a0bcc41061	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	3	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e5a1bff8-8688-41a1-829f-739eb72dc865	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a4152434-8e18-4331-8935-68d8b7355b6a	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
982bb9ad-065e-4af3-92c8-dc3ab70effc9	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
459d84e9-4306-433a-b1b7-be351babd1a5	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c2f0135b-83ed-4f4a-923e-eb8bc200646b	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	43	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f53dc216-d8e4-4d7b-9679-9c797a75f6e4	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
51af631d-2cf0-46db-9cea-bcd3438f19b0	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	9	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
74d41fca-7abb-4eb8-b469-262ccae7c615	afccfd8f-9743-44a5-ba87-0f2ab1048f97	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
6d93bd1f-f8e1-48f4-99f8-3fbac0240236	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f3983a1c-53f5-4f75-806a-3bad7e580c0f	afccfd8f-9743-44a5-ba87-0f2ab1048f97	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
240559a7-4088-4f26-b3d8-b36a75db0608	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
b38d7609-0b4c-4795-a3a0-d3b08d2ced77	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	1	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
3efbfd46-840c-4bc8-9673-247df92a1ce0	d6ca80c9-732a-49c7-ab46-2a4c71a86110	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
1eebc035-bfc1-4d39-a716-0f35e335cf0f	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	16	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f91b7dbc-03ee-495f-b1dc-215ecde990bc	d6ca80c9-732a-49c7-ab46-2a4c71a86110	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
8e049351-5f97-4ec7-aee8-f80ac63a5832	d6ca80c9-732a-49c7-ab46-2a4c71a86110	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a393b7f7-f6d9-4665-a716-1a5a0261c078	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f872a8ea-e1d2-40e4-a79b-54ef28edb8e9	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	11	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c1b48410-b345-440b-ac0c-98fe9b176f8b	69e556c3-ee7f-4ac8-85da-35345a52cf5a	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a7f6f8e8-2802-4c6b-b755-33777c72a473	69e556c3-ee7f-4ac8-85da-35345a52cf5a	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
8f560fa7-f7d7-492e-86b0-16f75cb52213	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ac7dd879-0120-481a-8e3b-f2b19dffa76f	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e09f7cb3-23af-49e9-906c-8ac4f732c949	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
6ddde2a3-c91a-4f7e-b601-6d3e1e0cea52	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
6ef5ef67-c06e-4c93-95ee-c491b030e94a	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
9e77eb70-dc56-40a7-9f5c-e12ead804bd4	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
387f7ac3-4a86-4e11-b1f6-efdbeacdbf48	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
152f063a-70ca-41fb-89f9-9ccacccfa865	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
99011222-0338-442d-a9bc-13604c139651	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
5b499d22-4f58-4c95-9f96-10b6e3719314	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
4b061c8a-2889-4aaa-afb6-cb3feaa41e2a	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	15	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c8253ea5-88b8-459a-a0ba-b5f5d1537123	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
0f39c770-e9da-4f85-a3b4-7e8d0c5678e5	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
0adc98ee-c41b-426c-b499-710dc6dbfbca	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
7160b0f2-4a33-4ccc-8b09-8166498ad16a	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
2f2d3771-57e9-40fd-86c2-74e9f3eaf4e4	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	48	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a2daa5f9-fb5d-4662-9779-25bf5c255c33	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	6	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
7dcdf1b7-98b1-4beb-9557-02720958d57c	5b266066-2106-40ae-b282-949dc23491a9	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
42a415d9-5663-403c-b971-284c1d0c29ca	5b266066-2106-40ae-b282-949dc23491a9	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e4051dd6-02ce-4394-8d42-8f8c02d300c2	5b266066-2106-40ae-b282-949dc23491a9	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c017bb3d-0839-4ef8-b7a7-e256f461121d	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
72cdaba9-d9b0-41a8-9e53-a8d80c90d572	5b266066-2106-40ae-b282-949dc23491a9	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c1d74293-f2ce-4f54-a1d9-78b6e464c07f	7cbb19fa-f7bd-49f8-84f8-07f983c84132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
12daeffd-8713-4e7e-a8dc-3c75c5a25acb	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a73acc93-cf65-4dff-899f-49eee3ca8a88	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
c12dcedb-7a67-4d03-b3cc-7e7f3f7e7b5b	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
8095c57c-6816-4deb-a7d1-5875437848cf	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ed1b1161-64eb-4cd0-9241-04c72c365db8	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
d0e69dcf-555d-464b-96e9-cdd728414f11	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e0558de7-31ee-465a-81ac-ce06b3521ac6	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	4	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
84a67725-7ae9-401d-b069-4b97f2f35ee2	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e5aee8ea-dd6e-4dc1-88bf-00f37fe2a1e4	9975f314-970f-4dda-9c8f-61a36558666f	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e62381a6-f960-4afc-9aa3-7db6f757cec9	9975f314-970f-4dda-9c8f-61a36558666f	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
0b80b74f-d8c1-4b76-ad2c-3157bd44f896	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
e94d4b0d-5f90-4e9c-97fa-803fb12a2b31	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
764ad5fd-e981-4fee-806e-a8ec3a48259e	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
911ecdd1-a877-421b-9f95-4cce274a2517	f1f9a969-2c82-453c-a6a3-775d3bf365ca	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
7df4a62b-8f36-4aff-87d4-7280fd2f55e5	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
de3a8a92-d9ef-40e9-9b70-d92c453cc3a3	f1f9a969-2c82-453c-a6a3-775d3bf365ca	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f986ab92-53f0-475f-ac10-3dc8a290e4ca	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
76b18921-d01d-4b62-a11b-05a1f8fbb048	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
de501450-ae4a-4982-8e21-d55d0226e209	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	21	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ec264626-b278-453e-8e60-9ba41f9606d6	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
b3e9ff62-1578-42fa-bb6d-a9e281d89130	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f12e8047-09d2-4e09-a24f-ccf80e4e64de	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
2ca832a7-a6fb-430a-b905-3c67ccc7d555	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
f1549e59-4571-40ba-83dd-8571b47ad8f1	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ec46e571-4e84-4617-b6ca-f2750d20ef06	464f5a27-cbb5-4107-8ebd-f1a6fe286487	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a497c7b3-b07b-4064-bdaa-25a421be37bf	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
601b1655-d863-4136-86a5-1a87a5ef988c	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	34	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
a9483b7d-c830-4f3d-959e-f276b85b8d1e	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
b9f27ae1-16c1-44f4-a00e-1840e183ce39	464f5a27-cbb5-4107-8ebd-f1a6fe286487	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
087079d9-afad-4886-9b3c-85dfbb97e41f	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
8d67508e-a185-4fd8-9758-617410db13e1	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
23c3a80d-54d1-4113-be84-30e6df812476	210293d2-cc9d-4fca-be6e-41df29fdd537	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
14d03ca7-73e2-4734-94fa-99e13c679568	210293d2-cc9d-4fca-be6e-41df29fdd537	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
29f94758-b9e0-4751-a069-80ca00f32299	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
80bdb585-d312-49a3-bef2-972868796863	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	31	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.936+00
ca2f47f3-ff11-41cf-8dba-dc65d3b04716	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	2	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
d84f0a88-a039-4868-be31-bd2e9b33a31d	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
ef915933-e8ec-4daf-85f3-ee89cffa20b3	418e4d95-5e24-45ab-9d82-9f8fc0410132	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
3bf57396-b895-4263-93c6-7ee899453d8e	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
b995847a-0f30-4b6d-9325-f872a2185697	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
7fa83346-a9c9-4271-889a-e5c53e89e0c6	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
d9f3e620-9ab1-4998-b892-771938f38bca	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
09ba5c6e-5ae2-40dc-a21a-138b6f4f409d	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
c11f47ee-7d59-45d3-a4ed-de4357cdc592	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	t	low_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
9d9093f5-79c5-489a-b534-4a75000a1135	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
618dd6a4-1be5-4c54-8fe5-242e557acce3	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
dff94ba6-e243-4942-8303-388fca8c19ac	b4dfaf4f-ce1b-4386-ae65-65512832d284	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
96b988b9-f829-4325-8b99-5080ae9c2f7b	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
bb6d2c1c-356c-47a4-9d6f-5a309b435c9e	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
34be95d6-ba1b-4096-b23a-c846223212a1	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
822aeea3-6a34-4cd4-ac1a-8b1a79e32d10	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	23	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
86ab2edc-de92-42b8-abde-5cf974e26906	669e93c6-5846-4046-8d40-d94bfd34b780	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
4b100b96-0a4e-4690-9547-6ad53173f7f2	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
a7446406-b07e-46dd-aa8e-55f533da75ee	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
d86446fc-1422-4a9e-9c4a-9ea90d670df4	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
7b05941a-2521-45ac-b26f-839591b8035f	e07633f1-7182-4567-a6c5-60456b332f0c	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
809ba08a-4f1e-41b6-bc15-53d230ef605a	e07633f1-7182-4567-a6c5-60456b332f0c	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
b5cbda33-a449-493a-abc1-0f027e7fe0b0	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	30	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
dddf527f-d3d0-41ea-9006-32c26303b1c6	e07633f1-7182-4567-a6c5-60456b332f0c	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
d8822a05-3ca9-422b-9479-367ce1aea734	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
a84e4eee-3ba4-4425-af7f-77d25c678eb4	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
bd39ceea-ad56-41d2-9cd0-2614c9cbec36	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
f77eaf89-d535-4f8e-9686-6cd3b8ededec	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
7d440ba4-194c-4d59-a446-58cb9994c138	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
18dc9ce5-0fc4-44e0-9a4c-f998b0f34ffa	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	36	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
63ad0f64-b3cf-4a3c-a5cd-981ad129c253	345a6e90-30bb-49d2-bf67-7b4377955cfa	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
4abbad71-93b1-4b17-b6c9-28ec050479cd	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
1ddea43e-b36e-49b2-93f2-d501185379a5	345a6e90-30bb-49d2-bf67-7b4377955cfa	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
1fa39205-c9bb-4740-ab1b-813ac2e9dc5d	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
0b663bd0-8680-4326-8c26-c90c6ed31df2	345a6e90-30bb-49d2-bf67-7b4377955cfa	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
b72d36ea-3f89-4993-a93a-3452c5226946	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	3	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
ad37e7bc-7bb5-409a-802e-411a3435dc67	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
163bea74-b655-4e21-a98a-8347fba17030	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
42e92c3c-12c1-45dd-8b87-2556753fa79f	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
a046d0ee-11e0-434e-b337-5a7c135911d1	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
1f1ddfb8-4636-46d0-9846-d0223d02542e	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	43	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
80b6f950-bc15-4c03-9c71-d839c4061b32	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
c65c9d1d-10ea-4642-b391-7612f0556369	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	9	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
04c7b021-d205-48a8-8ec7-94da1115d5f9	afccfd8f-9743-44a5-ba87-0f2ab1048f97	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
55546b08-5fc6-431d-b070-98bc08da0716	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
dd92974e-39d6-41d9-b6d6-f784f1fe94d2	afccfd8f-9743-44a5-ba87-0f2ab1048f97	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
6b9b30c6-f7f5-474e-ba79-0fc45a921b0c	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	8	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
e9bf6a53-618b-4c3e-be4a-75c1739d2302	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	1	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
79ec8ebc-2d33-42a1-9322-62f665949d75	d6ca80c9-732a-49c7-ab46-2a4c71a86110	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
0bf6af60-d3a3-4705-9282-b60bcebff47d	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	16	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
b4e0fe84-d018-4be7-bdc1-33bb0545c928	d6ca80c9-732a-49c7-ab46-2a4c71a86110	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
748912d4-3be1-45ed-bea2-b8324478ca67	d6ca80c9-732a-49c7-ab46-2a4c71a86110	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
a124fb25-df86-4576-9c74-16b9c72d2f7a	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	44	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
b5f7539a-fd95-4305-b71d-baa88f6b4fa5	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	11	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
159d4402-0ada-4dc7-be8e-8f93da0fc3f1	69e556c3-ee7f-4ac8-85da-35345a52cf5a	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
32fb5434-8c13-4dfc-babf-428981e41041	69e556c3-ee7f-4ac8-85da-35345a52cf5a	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
d595477f-f373-4a0c-acf5-416813968086	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
1a2fd76a-7a39-435e-9edb-2474c3591c3d	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
ff1e0c3c-2634-476d-bd1a-cf541ae731e9	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
6b9df2ee-e9a8-44aa-bbbb-d935b77b51e6	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	12	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
bf44d67a-e5ba-4ae9-9a5f-8e5fa16022da	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
ce88d42d-52cc-4c18-b03a-569105146534	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
3b836051-fc2c-4708-943f-6919fb16c0b5	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
87b7e5ac-94f3-45b0-a1ec-0ba27bc90d7a	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
da9bd172-307d-4057-93f0-11b3db3b84df	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
f36a92b9-3da1-48a1-81f9-906599de4ff4	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	29	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.978+00
123c9a4b-9c44-41f5-84e5-4fa6693d354e	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	15	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
99e3d8bd-29a0-4598-9e87-4687f3c60e5d	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
4827f49e-f07f-461c-a06b-a7096a9e4298	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	45	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
6e037bff-cfe2-4f4d-b96e-f21e57ff45fe	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
6207ab49-8fd6-44ce-9d3f-4299255fc44a	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	41	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
2f61f0a0-c151-41e5-ab31-74e382c00d6a	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	48	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
f2e8e231-7900-4082-b980-9eae4cb3e9bc	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	6	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
4586efcc-e48e-4901-8275-f2b261accb98	5b266066-2106-40ae-b282-949dc23491a9	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
31dda68c-0ceb-4a1c-9923-9da4c09fbaed	5b266066-2106-40ae-b282-949dc23491a9	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
e5673377-2df6-4d8e-a411-ece50f1c4e63	5b266066-2106-40ae-b282-949dc23491a9	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
24cfb86f-9e8e-45e5-8378-ead562b524d0	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
7cd95163-085c-4367-be2e-f149c2ee9335	5b266066-2106-40ae-b282-949dc23491a9	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
34ceffd9-660a-4c65-aca2-bca36209745e	7cbb19fa-f7bd-49f8-84f8-07f983c84132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
e2c8ea14-9e7f-44d8-b007-f4b663550549	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
f5675f04-166b-4f6e-891e-bd30ad29aa06	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	24	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
e82917be-1953-45f0-b1c3-f6b35ebd6cbd	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	39	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
071a1b59-4d5c-4207-9df8-f7cfcdee3cab	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	low_stock	13	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
a6e37a89-ac70-4972-876d-f69c9c1d2b3e	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	28	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
f758f231-9ecd-4619-a10c-698807f9cb36	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	35	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
3350b4fe-bd80-4bd4-b3ec-62205fe2cdea	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	4	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
7f760e34-5281-4e73-a5cb-006482ceeb9d	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	14	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
8901409a-8d37-4204-b237-066c6e6f21f1	9975f314-970f-4dda-9c8f-61a36558666f	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
5dcc394e-b90d-46c1-9a4c-8811fc23fc33	9975f314-970f-4dda-9c8f-61a36558666f	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
33f1ec7f-d0d5-46f4-91e9-c550ab0c7e86	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
3cde0949-c96f-4c16-b67d-7faee0d7892d	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
50a18adb-ae4c-41f1-b792-03c1cb0e7bf9	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	t	low_stock	40	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
11c86d08-f3c5-4e32-9173-9d90f9f7f6ac	f1f9a969-2c82-453c-a6a3-775d3bf365ca	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
32576010-3f82-4baa-b550-e3552dcd8fab	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	17	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
99f7fcde-bb99-4e2c-b776-2f1c2d9cad2d	f1f9a969-2c82-453c-a6a3-775d3bf365ca	b7b3c125-fa4e-40ec-813a-db76c0430127	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
83eff971-e1ed-4080-9279-907355877108	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
0110a164-696d-4098-a422-12d61ca54d41	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
ab37c2d5-5a37-44a1-9506-47ced0101204	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	21	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
f6da6cd7-6890-49f7-bbf2-5169197710eb	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
41ab6bbb-1e37-4bca-aecd-a7e1a5beeae3	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	26	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
25f6a5db-d9f9-4b26-86f6-1b01aaf87b54	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
c476876a-14ae-46df-a2e5-a830974a691c	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	in_stock	19	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
17b31fa9-c252-44e8-aec6-79340340a3aa	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	low_stock	42	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
8c6372c5-3831-4313-89fd-7b2b4216b506	464f5a27-cbb5-4107-8ebd-f1a6fe286487	e99e80ff-9412-47d3-b965-1d864a148a0b	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
d61c453e-9bd2-4f96-9e26-5d996bddaee0	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	t	in_stock	10	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
9cbe7f48-fb30-4d35-bbcf-4c0adf8f4926	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	t	in_stock	34	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
9b3e30d8-d969-45fe-887b-75a8ffdd8ba9	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	50	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
40af74b7-8e6c-4d8c-bc8f-6a36df638d3e	464f5a27-cbb5-4107-8ebd-f1a6fe286487	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
40c0291a-f463-40c3-8db5-73666a0b88f7	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	in_stock	33	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
11a2f2fc-5e14-4269-bb68-e44024cdba0d	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	t	in_stock	38	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
6294fffa-47a9-437b-8fee-500ef55bb7ab	210293d2-cc9d-4fca-be6e-41df29fdd537	5be78519-dba9-4be6-a909-2fa6c802d38e	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
b9794727-0465-4b8a-9392-9a1a057b6f77	210293d2-cc9d-4fca-be6e-41df29fdd537	ed369918-9011-441a-8f69-30847fe469f4	f	out_of_stock	0	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
d3ab21d9-0022-4500-b9fb-a9082e445fe6	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	t	in_stock	18	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
4889b5df-10c3-4df8-b718-988341f94785	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	low_stock	31	2025-09-03 16:53:58.124+00	2025-09-03 18:00:00.979+00
\.


--
-- TOC entry 4333 (class 0 OID 17490)
-- Dependencies: 263
-- Data for Name: billing_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_events (id, stripe_customer_id, subscription_id, event_type, amount_cents, currency, status, invoice_id, occurred_at, raw_event, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4327 (class 0 OID 17342)
-- Dependencies: 257
-- Data for Name: comment_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_likes (id, comment_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4324 (class 0 OID 17266)
-- Dependencies: 254
-- Data for Name: community_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.community_posts (id, user_id, user_name, user_avatar, type, title, content, images, tags, likes, comments_count, is_public, is_featured, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4334 (class 0 OID 17505)
-- Dependencies: 264
-- Data for Name: conversion_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversion_analytics (id, user_id, event_type, source, medium, campaign, metadata, event_date) FROM stdin;
\.


--
-- TOC entry 4321 (class 0 OID 17194)
-- Dependencies: 251
-- Data for Name: csv_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.csv_operations (id, user_id, operation_type, filename, total_rows, successful_rows, failed_rows, errors, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4314 (class 0 OID 17041)
-- Dependencies: 244
-- Data for Name: data_quality_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_quality_metrics (id, product_id, data_source, completeness_score, freshness_hours, accuracy_score, missing_fields, overall_quality_score, recommendations, assessed_at) FROM stdin;
\.


--
-- TOC entry 4319 (class 0 OID 17150)
-- Dependencies: 249
-- Data for Name: discord_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discord_servers (id, user_id, server_id, channel_id, token, alert_filters, is_active, total_alerts_sent, last_alert_sent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4306 (class 0 OID 16862)
-- Dependencies: 236
-- Data for Name: email_bounces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_bounces (id, message_id, bounce_type, bounce_sub_type, bounced_recipients, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4307 (class 0 OID 16873)
-- Dependencies: 237
-- Data for Name: email_complaints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_complaints (id, message_id, complained_recipients, feedback_type, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4304 (class 0 OID 16841)
-- Dependencies: 234
-- Data for Name: email_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_delivery_logs (id, user_id, alert_id, email_type, recipient_email, subject, message_id, sent_at, delivered_at, bounced_at, complained_at, bounce_reason, complaint_reason, metadata, created_at, updated_at) FROM stdin;
email_1756919173617_bv7v21nkg	0b5d6a4f-8fd8-439b-9d75-6e0933be5b7e	\N	system	derekmihlfeith@gmail.com	Verify your email for BoosterBeacon	<8dfd01f4-f9d6-446a-c6fb-c6c23dc24dad@boosterbeacon.com>	2025-09-03 17:06:13.617+00	\N	\N	\N	\N	\N	{"category": "verification"}	2025-09-03 17:06:13.617743+00	2025-09-03 17:06:13.617743+00
\.


--
-- TOC entry 4303 (class 0 OID 16830)
-- Dependencies: 233
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_preferences (id, user_id, alert_emails, marketing_emails, weekly_digest, unsubscribe_token, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4312 (class 0 OID 16989)
-- Dependencies: 242
-- Data for Name: engagement_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.engagement_metrics (id, product_id, watch_count, alert_count, click_count, click_through_rate, search_volume, social_mentions, engagement_score, trend_direction, metrics_date, calculated_at) FROM stdin;
\.


--
-- TOC entry 4335 (class 0 OID 17532)
-- Dependencies: 265
-- Data for Name: external_product_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_product_map (id, retailer_slug, external_id, product_id, product_url, last_seen_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4288 (class 0 OID 16496)
-- Dependencies: 218
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	001_initial_schema.js	1	2025-09-03 16:36:02.672+00
2	20250826174814_expand_core_schema.js	1	2025-09-03 16:36:02.826+00
3	20250826180000_add_push_subscriptions.js	1	2025-09-03 16:36:02.828+00
4	20250827000001_email_system.js	1	2025-09-03 16:36:02.876+00
5	20250827130000_add_ml_tables.js	1	2025-09-03 16:36:02.937+00
6	20250827140000_add_user_roles.js	1	2025-09-03 16:36:02.98+00
7	20250827140001_add_missing_user_fields.js	1	2025-09-03 16:36:02.981+00
8	20250827140005_validate_admin_setup.js	1	2025-09-03 16:36:02.997+00
9	20250827140006_add_registration_fields.js	1	2025-09-03 16:36:02.998+00
10	20250827150000_add_community_integration_tables.js	1	2025-09-03 16:36:03.08+00
11	20250827160000_implement_granular_rbac.js	1	2025-09-03 16:36:03.122+00
12	20250829151931_create_subscription_plans_table.js	1	2025-09-03 16:36:03.132+00
13	20250901090000_create_transactions_and_billing_events.js	1	2025-09-03 16:36:03.15+00
14	20250901151600_add_conversion_analytics.js	1	2025-09-03 16:36:03.158+00
15	20250901152000_add_user_subscription_columns.js	1	2025-09-03 16:36:03.166+00
16	20250901154000_add_user_subscription_plan_id.js	1	2025-09-03 16:36:03.168+00
17	20250902140000_add_watch_auto_purchase.js	1	2025-09-03 16:36:03.174+00
\.


--
-- TOC entry 4290 (class 0 OID 16503)
-- Dependencies: 220
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- TOC entry 4311 (class 0 OID 16975)
-- Dependencies: 241
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_model_metrics (id, model_name, model_version, prediction_type, accuracy, "precision", recall, f1_score, mean_absolute_error, root_mean_square_error, training_data_size, prediction_count, avg_processing_time, last_trained_at, last_evaluated_at, created_at) FROM stdin;
\.


--
-- TOC entry 4316 (class 0 OID 17086)
-- Dependencies: 246
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, version, status, config, metrics, model_path, training_started_at, training_completed_at, deployed_at, trained_by, training_notes, created_at, updated_at) FROM stdin;
a139aaf0-9ce6-43d5-a308-130a64588316	price_prediction	v1.0	active	{"algorithm": "ARIMA", "forecast_days": 7, "lookback_days": 30}	{"mae": 2.34, "rmse": 3.12, "accuracy": 0.85}	\N	2025-08-27 16:53:58.369+00	2025-08-28 16:53:58.369+00	2025-08-28 16:53:58.369+00	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
b9f29bf2-92a8-4efe-8ed8-026c5fa19350	sellout_risk	v1.2	active	{"features": ["price_history", "availability_patterns", "user_engagement"], "algorithm": "Random Forest"}	{"recall": 0.94, "accuracy": 0.92, "precision": 0.89}	\N	2025-08-31 16:53:58.369+00	2025-09-01 16:53:58.369+00	2025-09-01 16:53:58.369+00	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
8a5afdf6-05e7-43e8-b368-a0840f42265f	roi_estimation	v0.8	training	{"algorithm": "LSTM", "hidden_units": 128, "sequence_length": 14}	{}	\N	2025-09-02 16:53:58.369+00	\N	\N	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
\.


--
-- TOC entry 4310 (class 0 OID 16957)
-- Dependencies: 240
-- Data for Name: ml_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_predictions (id, product_id, prediction_type, prediction_data, timeframe_days, input_price, confidence_score, expires_at, created_at) FROM stdin;
\.


--
-- TOC entry 4317 (class 0 OID 17112)
-- Dependencies: 247
-- Data for Name: ml_training_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_training_data (id, dataset_name, data_type, data, status, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
7dd8a9cc-9dc5-4404-91a5-c04bf1de9a6f	pokemon_tcg_prices_q4_2024	price_history	{"products": ["charizard_151", "pikachu_promo"], "date_range": "2024-10-01 to 2024-12-31", "price_points": 1250}	pending	\N	\N	\N	2025-09-03 16:53:58.374142+00	2025-09-03 16:53:58.374142+00
9ac0295c-1d42-455c-8436-e5d2097b0e45	availability_patterns_holiday_2024	availability_patterns	{"retailers": ["best_buy", "walmart", "costco"], "pattern_count": 890, "seasonal_factor": "holiday_rush"}	approved	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	2025-09-03 16:53:58.374142+00	\N	2025-09-03 16:53:58.374142+00	2025-09-03 16:53:58.374142+00
\.


--
-- TOC entry 4330 (class 0 OID 17418)
-- Dependencies: 260
-- Data for Name: permission_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_audit_log (id, actor_user_id, target_user_id, action, permission_or_role, old_value, new_value, reason, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4325 (class 0 OID 17294)
-- Dependencies: 255
-- Data for Name: post_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_comments (id, post_id, user_id, user_name, user_avatar, content, likes, is_public, moderation_status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4326 (class 0 OID 17321)
-- Dependencies: 256
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_likes (id, post_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4300 (class 0 OID 16771)
-- Dependencies: 230
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, product_id, retailer_id, price, original_price, in_stock, availability_status, recorded_at) FROM stdin;
711efa03-1bbf-41ad-8892-749cc1334d03	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	140.25	143.64	t	in_stock	2025-08-04 16:53:58.134+00
ab3b7e06-30cd-471b-8129-171344d8ba33	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	132.91	143.64	t	in_stock	2025-08-05 16:53:58.134+00
3a761c3c-f76e-40e3-9afc-68c5bcf34edf	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	146.81	143.64	t	in_stock	2025-08-06 16:53:58.134+00
fed23fbd-cb3f-490d-8035-7f016d57cce3	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	150.00	143.64	t	in_stock	2025-08-07 16:53:58.134+00
422c0aed-81fe-43e2-bfa9-d1ea22999742	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	133.08	143.64	t	in_stock	2025-08-08 16:53:58.134+00
1809f8cd-1492-4df1-8b0a-b36490298a74	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.39	143.64	t	in_stock	2025-08-09 16:53:58.134+00
4bf76b4e-aae6-4b20-9ecc-975025d6bf74	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	146.34	143.64	t	in_stock	2025-08-10 16:53:58.134+00
c238238f-cb90-4b75-823d-e4231ecd47b3	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	135.59	143.64	f	out_of_stock	2025-08-11 16:53:58.134+00
fb7acf45-07d9-48fe-be77-06125164899d	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.72	143.64	t	in_stock	2025-08-12 16:53:58.134+00
88ccec36-a533-49d4-9959-b495bf63cf82	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	147.02	143.64	f	out_of_stock	2025-08-13 16:53:58.134+00
be6cb88e-588e-4201-94db-99df3ec54705	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.51	143.64	t	in_stock	2025-08-14 16:53:58.134+00
ce1a3db4-d3ff-4f6c-a6c6-35d4a1a3d22c	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.35	143.64	t	in_stock	2025-08-15 16:53:58.134+00
3f734313-6865-4960-9d91-745579552625	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	145.21	143.64	t	in_stock	2025-08-16 16:53:58.134+00
821c14bd-33fb-4452-8c7e-1cf67d561934	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	140.54	143.64	t	in_stock	2025-08-17 16:53:58.134+00
f5de7041-862f-46ec-9027-23a15435400b	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	149.08	143.64	t	in_stock	2025-08-18 16:53:58.134+00
6d9e8a8f-4063-430a-af6d-32221cee84c6	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	147.54	143.64	t	in_stock	2025-08-19 16:53:58.134+00
7d22b6e2-700c-4b54-bed8-633711e16d40	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.91	143.64	f	out_of_stock	2025-08-20 16:53:58.134+00
9782bf5d-a8f7-4afe-aa3e-6b3d84d5529e	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	144.14	143.64	t	in_stock	2025-08-21 16:53:58.134+00
b40ff72f-244c-468e-a55a-81c14d1be7a2	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	136.36	143.64	f	out_of_stock	2025-08-22 16:53:58.134+00
c82993c4-03f6-4e07-8c45-49cab79bf934	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	140.22	143.64	t	in_stock	2025-08-23 16:53:58.134+00
932c5729-481a-4788-9fa8-d7773133523b	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.57	143.64	t	in_stock	2025-08-24 16:53:58.134+00
9df023bf-e344-4152-9fb9-c3100f7af5ca	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.24	143.64	t	in_stock	2025-08-25 16:53:58.134+00
f76e1491-6200-4859-9ff2-9d29ef08c412	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	149.78	143.64	t	in_stock	2025-08-26 16:53:58.134+00
c7793573-f099-4ffe-a550-608452403f07	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	152.37	143.64	t	in_stock	2025-08-27 16:53:58.134+00
90370fa7-fbf3-4897-8a63-bceea04ab358	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	145.50	143.64	f	out_of_stock	2025-08-28 16:53:58.134+00
5b52d2ea-ba0f-491e-bf37-2969167858db	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.06	143.64	f	out_of_stock	2025-08-29 16:53:58.134+00
e9dcedb8-9b44-4cab-b25b-2e3b7c03ac77	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.59	143.64	t	in_stock	2025-08-30 16:53:58.134+00
3cf429ba-01b1-4d61-841d-26021ed6ae3f	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	148.84	143.64	t	in_stock	2025-08-31 16:53:58.134+00
8086fbd1-9bd7-46da-b8c7-f7c33a319a13	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	149.49	143.64	t	in_stock	2025-09-01 16:53:58.134+00
408d233d-b8b3-4225-b907-fffb37f6955d	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	138.05	143.64	t	in_stock	2025-09-02 16:53:58.134+00
dcf310a7-9abc-45e7-8800-1b4190acae09	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	145.08	143.64	t	in_stock	2025-09-03 16:53:58.134+00
82e9178a-0189-4994-a2e2-a9f5dbade673	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	150.49	143.64	t	in_stock	2025-08-04 16:53:58.134+00
217538eb-b76e-48e7-b578-c0bad5d54f11	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	134.32	143.64	t	in_stock	2025-08-05 16:53:58.134+00
444cb627-5914-41bb-8786-f79579fd9da6	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	135.54	143.64	t	in_stock	2025-08-06 16:53:58.134+00
cc317d33-1241-4e66-961f-0e3c31193746	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	140.12	143.64	t	in_stock	2025-08-07 16:53:58.134+00
9f626405-e314-403e-ad46-5b7eeb8e988a	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.22	143.64	t	in_stock	2025-08-08 16:53:58.134+00
5c8a83a8-eea7-40d2-bd15-2c6669beaf41	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	139.95	143.64	t	in_stock	2025-08-09 16:53:58.134+00
7eeea16e-d016-4f3b-8285-65d05ea88529	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	136.19	143.64	t	in_stock	2025-08-10 16:53:58.134+00
a3c4240b-96a7-41cb-a491-34a8031d62f5	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	145.37	143.64	f	out_of_stock	2025-08-11 16:53:58.134+00
5ab619d2-4d6d-4f2e-b473-6e6b97fcad28	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	150.30	143.64	t	in_stock	2025-08-12 16:53:58.134+00
83e38ec9-1a43-434e-8d9d-dab3c7b90df1	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	151.91	143.64	t	in_stock	2025-08-13 16:53:58.134+00
89eeb5d9-f254-474f-8e02-063ebf62884d	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	148.40	143.64	t	in_stock	2025-08-14 16:53:58.134+00
fd403b2b-79ad-44ac-94c5-2059fb112e1b	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	152.25	143.64	t	in_stock	2025-08-15 16:53:58.134+00
73fa15a5-dcf9-400b-8497-0e4e222facac	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	140.76	143.64	t	in_stock	2025-08-16 16:53:58.134+00
fc41d34f-8071-443c-bfa3-0eec22e5beaf	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	138.69	143.64	t	in_stock	2025-08-17 16:53:58.134+00
bd8043e8-b16d-4abb-bd66-77a1f3726459	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	139.25	143.64	t	in_stock	2025-08-18 16:53:58.134+00
2cace224-07eb-47d4-8c49-1ea8d8c78a4b	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	145.82	143.64	t	in_stock	2025-08-19 16:53:58.134+00
f403dc36-648a-471d-ae7d-28f2e90668a2	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	136.81	143.64	t	in_stock	2025-08-20 16:53:58.134+00
5f2a8ad3-de1d-4a1f-b409-5b85e1f4a438	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	134.91	143.64	f	out_of_stock	2025-08-21 16:53:58.134+00
bd05ba18-0db7-40d5-a172-cb0a2ea72799	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	132.87	143.64	t	in_stock	2025-08-22 16:53:58.134+00
83c0d545-fa06-456d-bac9-de3c003bea18	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	144.18	143.64	t	in_stock	2025-08-23 16:53:58.134+00
42e61a6b-f980-465f-a171-ae7140958dab	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	137.25	143.64	t	in_stock	2025-08-24 16:53:58.134+00
62d07deb-7f4b-4cdb-a646-c4f3b6cd8df0	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	151.01	143.64	t	in_stock	2025-08-25 16:53:58.134+00
1a692f55-4d98-4417-8a00-370e0b4f5f09	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	146.19	143.64	t	in_stock	2025-08-26 16:53:58.134+00
e12f2b2b-a304-41e0-a50d-e68fd6f5f568	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	140.20	143.64	f	out_of_stock	2025-08-27 16:53:58.134+00
1ea33cb3-9faa-4897-bfe1-0e3e48eaef05	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	139.09	143.64	t	in_stock	2025-08-28 16:53:58.134+00
f9523993-9b5d-467b-a87d-2b3e52cb1b46	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	135.08	143.64	f	out_of_stock	2025-08-29 16:53:58.134+00
fe3d8f84-5d43-4931-8d1b-97c343c42ad0	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.73	143.64	t	in_stock	2025-08-30 16:53:58.134+00
dde2f2ca-3d4e-4186-b56e-13ff8ba9e893	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.17	143.64	f	out_of_stock	2025-08-31 16:53:58.134+00
bfc74e85-7363-4939-8906-ea3a38e820d5	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	139.69	143.64	t	in_stock	2025-09-01 16:53:58.134+00
9e3a6528-61a1-4726-aecb-56a3ed04ff06	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	152.97	143.64	t	in_stock	2025-09-02 16:53:58.134+00
63b93abd-11aa-4037-9e8c-afd475625427	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	143.45	143.64	t	in_stock	2025-09-03 16:53:58.134+00
f163b217-5ea8-4d2b-9bf4-e678c65b0d08	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	148.27	143.64	f	out_of_stock	2025-08-04 16:53:58.134+00
c786c65c-ca5f-4cb1-bafc-82f38006aeb2	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.28	143.64	t	in_stock	2025-08-05 16:53:58.134+00
334ff599-7777-4ed3-a693-ff56ea92657d	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	134.11	143.64	t	in_stock	2025-08-06 16:53:58.134+00
5f136f35-9322-41fa-b195-0dbaad449ab4	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	141.25	143.64	t	in_stock	2025-08-07 16:53:58.134+00
e4435cf5-7e57-4c23-9188-0fa9f2f6bb53	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	148.95	143.64	f	out_of_stock	2025-08-08 16:53:58.134+00
66b21c41-1565-4a0a-9e49-48522546e299	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	146.44	143.64	f	out_of_stock	2025-08-09 16:53:58.134+00
6b3fb601-8518-4211-946c-2bc5f6691c10	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.06	143.64	t	in_stock	2025-08-10 16:53:58.134+00
32942211-efc1-47bb-abbc-99a8d1037b62	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.97	143.64	f	out_of_stock	2025-08-11 16:53:58.134+00
565c83ef-1a7c-47c6-b1ba-02e3c28db721	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	153.01	143.64	t	in_stock	2025-08-12 16:53:58.134+00
9906f96c-6d61-4b3d-a145-c06da057c6ce	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	138.32	143.64	t	in_stock	2025-08-13 16:53:58.134+00
5639cc58-733e-4088-8664-8764e440e7d6	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	140.96	143.64	t	in_stock	2025-08-14 16:53:58.134+00
5eaace57-ea60-4707-8ef2-030ac82e1ed4	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	141.53	143.64	f	out_of_stock	2025-08-15 16:53:58.134+00
19965d8c-b409-4d63-815c-6fe92cb02553	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	150.56	143.64	f	out_of_stock	2025-08-16 16:53:58.134+00
8ddd8774-fa2f-4560-aee7-062a30ec2df7	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	148.15	143.64	f	out_of_stock	2025-08-17 16:53:58.134+00
c95c859d-24cc-4039-8464-876e94bd17dd	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	146.83	143.64	t	in_stock	2025-08-18 16:53:58.134+00
dbc9d993-b1d0-4bd9-869a-618180f6f8c0	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	146.53	143.64	t	in_stock	2025-08-19 16:53:58.134+00
7b78ac27-f520-4c38-9c93-397b2cbf2823	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.09	143.64	t	in_stock	2025-08-20 16:53:58.134+00
bb36073e-6413-4509-90b5-419456b7ecdb	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.14	143.64	t	in_stock	2025-08-21 16:53:58.134+00
b2c4b491-e823-427b-a99b-88443475d2bc	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	153.79	143.64	t	in_stock	2025-08-22 16:53:58.134+00
fe8558d4-e9c2-411e-94ed-050a04d40671	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.90	143.64	t	in_stock	2025-08-23 16:53:58.134+00
3d4ac0de-1289-4fb9-9c9d-19602619541c	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	133.74	143.64	f	out_of_stock	2025-08-24 16:53:58.134+00
4af0ec02-a183-4aa8-8abd-53509ac57b10	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	145.99	143.64	t	in_stock	2025-08-25 16:53:58.134+00
86d86c8b-c96e-4407-a96a-c736aa28769d	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.68	143.64	t	in_stock	2025-08-26 16:53:58.134+00
2c5fbe28-7849-4ed9-a20a-c1e5eb7671de	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	150.58	143.64	t	in_stock	2025-08-27 16:53:58.134+00
3da5da41-59c2-4ff4-885b-8becb7215f08	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	136.18	143.64	f	out_of_stock	2025-08-28 16:53:58.134+00
0a8bbf17-1bbe-40c0-90ab-125b0e85e3f4	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	141.73	143.64	t	in_stock	2025-08-29 16:53:58.134+00
0d70d736-f554-49ae-81ce-58376f145cc0	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	136.24	143.64	f	out_of_stock	2025-08-30 16:53:58.134+00
7d0a3fb4-eaf1-4ab2-ab45-c0ea0cdacee9	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	138.43	143.64	f	out_of_stock	2025-08-31 16:53:58.134+00
3f742808-3dff-4bdb-99fa-bbcaf9f684b2	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	134.46	143.64	t	in_stock	2025-09-01 16:53:58.134+00
e6392b51-a26a-4881-aa68-8e39b8f0a888	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	134.10	143.64	t	in_stock	2025-09-02 16:53:58.134+00
5bad27af-0931-4c10-a0d4-9eb3443e3da5	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	149.43	143.64	t	in_stock	2025-09-03 16:53:58.134+00
10a1719a-b747-4926-9f96-e985f120b55f	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	143.79	143.64	t	in_stock	2025-08-04 16:53:58.134+00
adb2a3ac-4be6-49ef-b28e-255d9e9b8c4b	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	149.84	143.64	t	in_stock	2025-08-05 16:53:58.134+00
c4a689c0-fd85-431a-a128-420486fbedbe	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	154.41	143.64	t	in_stock	2025-08-06 16:53:58.134+00
8ca10858-9858-4eb1-a1e7-9511d27b1f38	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	138.81	143.64	t	in_stock	2025-08-07 16:53:58.134+00
18ffcb51-5253-42a4-b753-d3eddc362330	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	139.56	143.64	f	out_of_stock	2025-08-08 16:53:58.134+00
ca15d51b-4d65-41a4-b5f4-c57b02095105	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	152.43	143.64	t	in_stock	2025-08-09 16:53:58.134+00
15e7b7c6-d06d-47ab-8b67-ab42d2115a2a	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	137.21	143.64	t	in_stock	2025-08-10 16:53:58.134+00
6fd267ab-7175-4251-aeb9-c86e3cef4f0a	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	135.54	143.64	t	in_stock	2025-08-11 16:53:58.134+00
cba6bcd2-1a2c-42ba-b7a3-951a31f4833f	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	138.98	143.64	t	in_stock	2025-08-12 16:53:58.134+00
247492f1-99e4-4765-a9ae-3275c586d0a0	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	144.26	143.64	t	in_stock	2025-08-13 16:53:58.134+00
aab36bf4-1362-4fb9-99fd-c8425111644f	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	141.24	143.64	f	out_of_stock	2025-08-14 16:53:58.134+00
b1c45b60-f9d1-48bd-aeb6-c87806795bbe	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	144.53	143.64	t	in_stock	2025-08-15 16:53:58.134+00
d5f163df-461f-4aa0-ac2f-43354a235dde	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	143.98	143.64	t	in_stock	2025-08-16 16:53:58.134+00
d6a5b8a2-e34a-4500-aef2-5440ad905324	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	136.40	143.64	t	in_stock	2025-08-17 16:53:58.134+00
4cc25a87-6d1a-4ddb-b1ac-51f814e78b7b	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	152.89	143.64	t	in_stock	2025-08-18 16:53:58.134+00
4d00b64c-26ce-40e2-8b67-4754271041ff	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	138.07	143.64	t	in_stock	2025-08-19 16:53:58.134+00
4b4b0533-0d0c-45e7-b8f5-55d6aa0976e7	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	134.48	143.64	t	in_stock	2025-08-20 16:53:58.134+00
17921b29-8c59-43fe-b645-6025733c9b11	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	136.41	143.64	t	in_stock	2025-08-21 16:53:58.134+00
cae7862e-7654-465a-bbdd-daef9f77a673	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	134.48	143.64	t	in_stock	2025-08-22 16:53:58.134+00
394302f1-abe9-414a-9e6c-cff9e04d50ef	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	151.88	143.64	t	in_stock	2025-08-23 16:53:58.134+00
c5fbb488-99ae-4082-8952-354eaa057142	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	153.66	143.64	t	in_stock	2025-08-24 16:53:58.134+00
8319b4e2-5b11-4f33-a65f-918fd862498f	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	153.23	143.64	t	in_stock	2025-08-25 16:53:58.134+00
fcdb37fe-be36-439d-80cb-f6a4e9583341	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	150.10	143.64	t	in_stock	2025-08-26 16:53:58.134+00
caa8e880-411e-4dd2-bea2-eb22498dee7b	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	149.29	143.64	t	in_stock	2025-08-27 16:53:58.134+00
9b341499-79b9-44c5-8cf6-37e5d22d2bcc	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	133.16	143.64	f	out_of_stock	2025-08-28 16:53:58.134+00
99f0aeab-3019-420e-8587-49d32fcbd99c	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	136.57	143.64	t	in_stock	2025-08-29 16:53:58.134+00
2abc71a9-9d17-4a65-b92c-79d97d853bbb	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	138.46	143.64	f	out_of_stock	2025-08-30 16:53:58.134+00
a727da00-196c-441e-873f-bc6cdd4046fc	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	148.35	143.64	f	out_of_stock	2025-08-31 16:53:58.134+00
2838bfc6-0a80-4938-8262-f33b25064682	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	149.14	143.64	t	in_stock	2025-09-01 16:53:58.134+00
9ac9228a-1d17-4bc2-9d4e-be9bdf55842f	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	140.86	143.64	t	in_stock	2025-09-02 16:53:58.134+00
8ba8c39e-58d1-4388-bf01-83b588f8829a	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	147.80	143.64	f	out_of_stock	2025-09-03 16:53:58.134+00
ade45c7f-f1d7-4697-9b77-903cf910f4c7	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.62	49.99	t	in_stock	2025-08-04 16:53:58.134+00
fa39b02a-10d6-4945-912f-e41871745960	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.81	49.99	t	in_stock	2025-08-05 16:53:58.134+00
9944495c-4262-4fb1-87a5-7a44ee2fa8ef	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.13	49.99	t	in_stock	2025-08-06 16:53:58.134+00
cb7a6a8c-41c5-4895-8a47-5145c1dfd06a	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	48.26	49.99	t	in_stock	2025-08-07 16:53:58.134+00
c172992c-270d-4ac8-83a4-7f6466303ca5	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	51.79	49.99	t	in_stock	2025-08-08 16:53:58.134+00
06e2bd07-2552-452d-ab56-a47085e38c2b	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.10	49.99	f	out_of_stock	2025-08-09 16:53:58.134+00
fa17b2e0-1374-4b75-b49c-fd3ce803b20d	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.25	49.99	f	out_of_stock	2025-08-10 16:53:58.134+00
67ca0eb6-b406-4aed-8f67-eb9e7cc94928	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.15	49.99	t	in_stock	2025-08-11 16:53:58.134+00
610b0c81-fb1c-4f3c-b93b-0ecd41b45cba	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.39	49.99	t	in_stock	2025-08-12 16:53:58.134+00
d9eb42fe-4b67-4a92-8823-3fd5e09d86e5	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	53.41	49.99	f	out_of_stock	2025-08-13 16:53:58.134+00
f5970abb-1312-4bcf-bd67-7c5afcf4b1b1	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.89	49.99	t	in_stock	2025-08-14 16:53:58.134+00
afebf905-2f0c-4fc7-8aed-7277db0a53bb	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.66	49.99	t	in_stock	2025-08-15 16:53:58.134+00
d30fa992-3899-461e-accc-18f9e6a9a97d	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.89	49.99	t	in_stock	2025-08-16 16:53:58.134+00
6ac3560d-7120-46ae-901f-10fd5b74e2f3	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	53.07	49.99	t	in_stock	2025-08-17 16:53:58.134+00
795d5886-460b-4431-aed8-bd4af64fac6a	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	49.66	49.99	f	out_of_stock	2025-08-18 16:53:58.134+00
180a5cab-9740-4093-95e6-e602a294e9c4	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	49.79	49.99	t	in_stock	2025-08-19 16:53:58.134+00
c044589c-1d53-4ecd-a960-65ed45fa7294	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.20	49.99	f	out_of_stock	2025-08-20 16:53:58.134+00
46d7d49f-76f4-4a1c-9f14-bbc5bfb61193	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	52.91	49.99	t	in_stock	2025-08-21 16:53:58.134+00
58933021-578e-44b2-b951-a93a625b241e	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	52.88	49.99	t	in_stock	2025-08-22 16:53:58.134+00
b0fe7c72-4f50-4cdc-bb07-2bc60cc28e3d	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	51.26	49.99	t	in_stock	2025-08-23 16:53:58.134+00
2422c067-5e79-42fb-a23e-e40ded3ef127	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	48.04	49.99	t	in_stock	2025-08-24 16:53:58.134+00
74d21ed1-046b-4b7d-a795-1f53004e54e3	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.34	49.99	f	out_of_stock	2025-08-25 16:53:58.134+00
4bc1bc43-f00e-4fc0-9f41-6570a467a112	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	48.68	49.99	f	out_of_stock	2025-08-26 16:53:58.134+00
c6e2bd1a-5c38-4fe0-bf3e-799f4ab16142	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.33	49.99	f	out_of_stock	2025-08-27 16:53:58.134+00
3c15b354-f173-43ad-9a85-fd2db99d904d	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.55	49.99	f	out_of_stock	2025-08-28 16:53:58.134+00
12fd265f-4124-44c3-8f50-33d0d714a586	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	48.95	49.99	t	in_stock	2025-08-29 16:53:58.134+00
e9fdba58-9511-4fb8-935e-13c5a9a5f33d	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	47.34	49.99	t	in_stock	2025-08-30 16:53:58.134+00
9a13b114-7c5a-4781-80bb-071cc9bf18a5	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	46.88	49.99	f	out_of_stock	2025-08-31 16:53:58.134+00
2ef94a71-652a-48ae-9f57-3f13237b92e1	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	52.89	49.99	t	in_stock	2025-09-01 16:53:58.134+00
3c447fbb-e73b-4c71-9210-629f653ec940	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	52.34	49.99	t	in_stock	2025-09-02 16:53:58.134+00
85aaf508-a3cd-49e1-8e6e-9fe012a0576e	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	51.35	49.99	t	in_stock	2025-09-03 16:53:58.134+00
59ad1419-b000-4c1f-84cd-e1101971ec18	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	48.62	49.99	t	in_stock	2025-08-04 16:53:58.134+00
3c535df3-beaa-452c-8a9f-31015dd2670f	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	48.44	49.99	t	in_stock	2025-08-05 16:53:58.134+00
c01c0bd7-86c7-4813-9091-15b6f7be4073	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	50.54	49.99	t	in_stock	2025-08-06 16:53:58.134+00
7f24da00-69b8-4f8a-92b6-cf341df73643	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	53.38	49.99	t	in_stock	2025-08-07 16:53:58.134+00
6db043fa-7079-4582-a30a-218ec664c608	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	53.42	49.99	t	in_stock	2025-08-08 16:53:58.134+00
ab78140d-e02f-43af-bf94-2529de433b3e	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	50.04	49.99	t	in_stock	2025-08-09 16:53:58.134+00
50c684fe-de9e-496a-b062-0adbedd4eef2	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.41	49.99	t	in_stock	2025-08-10 16:53:58.134+00
983fd139-6dfc-4207-81f0-dad676dedc7c	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	52.16	49.99	t	in_stock	2025-08-11 16:53:58.134+00
920957dd-72ad-4454-84ac-53026940f378	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	50.26	49.99	t	in_stock	2025-08-12 16:53:58.134+00
adf3548f-3f30-49f1-b604-d970abd352a2	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	48.03	49.99	t	in_stock	2025-08-13 16:53:58.134+00
4ca93ac2-ec35-4e6b-8c19-84e69f3609bf	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	51.07	49.99	t	in_stock	2025-08-14 16:53:58.134+00
712a9bb0-a9c5-4f0e-8a81-f273aa0ac153	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.37	49.99	t	in_stock	2025-08-15 16:53:58.134+00
8815086f-efef-4c2c-8933-59cb2d5547b0	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	49.60	49.99	t	in_stock	2025-08-16 16:53:58.134+00
7febc8b9-535a-49be-8efc-7b2a22b21dd4	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	51.45	49.99	t	in_stock	2025-08-17 16:53:58.134+00
99022812-d53a-4ae3-bdab-b8f2865edd84	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	51.73	49.99	t	in_stock	2025-08-18 16:53:58.134+00
04064172-d44b-4987-b96f-5cdcfee114ca	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	50.09	49.99	t	in_stock	2025-08-19 16:53:58.134+00
fdec1c95-5a55-48b4-9b33-c44417430752	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	53.39	49.99	t	in_stock	2025-08-20 16:53:58.134+00
2ed6d996-9ae2-41e3-8ac1-428df7c92e8e	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.10	49.99	t	in_stock	2025-08-21 16:53:58.134+00
ae9beec4-1899-4ffa-a931-07cc30101796	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	48.86	49.99	t	in_stock	2025-08-22 16:53:58.134+00
1af81fb9-88e8-4eda-bda3-6c6a7c689a1c	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	48.73	49.99	t	in_stock	2025-08-23 16:53:58.134+00
8b2e8aba-1660-49e1-90fb-f3597b3387a3	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	52.80	49.99	f	out_of_stock	2025-08-24 16:53:58.134+00
a963e78d-cd2f-406d-80a6-98bc308bf2a9	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	51.61	49.99	t	in_stock	2025-08-25 16:53:58.134+00
f1c71e1c-c29c-4f54-950f-e833fe08a19f	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.35	49.99	t	in_stock	2025-08-26 16:53:58.134+00
5dd7ba18-8343-40cb-bdf9-9241cda1f44f	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	53.42	49.99	t	in_stock	2025-08-27 16:53:58.134+00
46f6b7e1-3651-415b-877e-2bd7e86d296e	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	48.49	49.99	t	in_stock	2025-08-28 16:53:58.134+00
11086f0e-7464-442c-beb1-bb27a1298221	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.50	49.99	t	in_stock	2025-08-29 16:53:58.134+00
7427efb5-161a-4962-aa2b-2e3e84626230	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	49.92	49.99	t	in_stock	2025-08-30 16:53:58.134+00
77ee6db3-1b72-4ef7-9cec-7ab963549828	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	50.18	49.99	t	in_stock	2025-08-31 16:53:58.134+00
177e00b0-b26f-488c-8814-0429430d1fad	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.32	49.99	t	in_stock	2025-09-01 16:53:58.134+00
1a2ff846-e284-49d8-9305-95a4b991016c	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	46.25	49.99	f	out_of_stock	2025-09-02 16:53:58.134+00
45a7e79e-4dd2-4f33-896d-37439e953dff	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	51.85	49.99	t	in_stock	2025-09-03 16:53:58.134+00
3ca1c0aa-817b-4002-9a44-d14f24ff7e28	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.42	143.64	t	in_stock	2025-09-03 17:00:00.381+00
04a3c6c3-8201-43a1-bd91-f7010f0b1bed	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.00	143.64	t	in_stock	2025-09-03 17:00:00.381+00
24aa8a77-ec13-451b-b3be-db87fda1a767	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	139.49	143.64	t	in_stock	2025-09-03 17:00:00.381+00
a5220c54-cc15-4ca5-ba36-eef620704972	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	134.19	143.64	t	in_stock	2025-09-03 17:00:00.381+00
824179bd-5e25-427f-b052-c1decab98034	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.52	143.64	t	in_stock	2025-09-03 17:00:00.381+00
b2aaabe5-b91a-43c7-9acb-2ed4e6c6707b	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	153.29	143.64	t	low_stock	2025-09-03 17:00:00.381+00
3e3f865f-f066-445a-8a8c-31b4b17936dc	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	144.05	143.64	t	low_stock	2025-09-03 17:00:00.381+00
6fedc122-2a7b-4e88-bb4d-9ba16e4e5095	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	138.00	143.64	t	in_stock	2025-09-03 17:00:00.381+00
758d277a-c1d4-4791-934c-2d2e62fa58ee	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	141.46	143.64	t	in_stock	2025-09-03 17:00:00.381+00
b51a6b9f-5989-4079-8cb6-d21bcdeba66c	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	46.65	49.99	t	in_stock	2025-09-03 17:00:00.381+00
010af520-d5ad-42c0-a578-e846d3ecf04a	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.99	49.99	t	in_stock	2025-09-03 17:00:00.381+00
e33a4385-0b3d-4f1e-bba5-c0ee15927719	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	47.82	49.99	t	in_stock	2025-09-03 17:00:00.381+00
5dbac468-eba0-418f-8d1b-5a29792c184c	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	45.20	49.99	t	in_stock	2025-09-03 17:00:00.381+00
b1e5c657-5964-4ab9-84bb-379637d797e2	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	50.48	49.99	t	in_stock	2025-09-03 17:00:00.381+00
4a0c02c6-a239-4f62-b4ed-7b1c4b464920	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	117.30	119.99	t	in_stock	2025-09-03 17:00:00.381+00
11d79859-f88b-43d8-82c4-a264194fd9d2	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	112.13	119.99	t	low_stock	2025-09-03 17:00:00.381+00
38fb4df3-d8c9-4ffa-933d-ed61e081eaa4	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	119.27	119.99	t	in_stock	2025-09-03 17:00:00.381+00
988ff364-c4ec-4a00-aeb9-efd4388bdca9	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	4.38	3.99	t	in_stock	2025-09-03 17:00:00.381+00
a1f01967-7a72-491e-8eb6-d30b1febf15e	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	4.23	3.99	t	in_stock	2025-09-03 17:00:00.381+00
53caff01-4338-4d6d-bb58-21c0907b239d	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	3.76	3.99	t	in_stock	2025-09-03 17:00:00.381+00
e7bc621d-4119-4940-a568-3a99a024f16a	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	4.27	3.99	t	in_stock	2025-09-03 17:00:00.381+00
39268ce0-5f01-4ca4-95fb-ac7e9aa9a857	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	146.69	143.64	t	in_stock	2025-09-03 17:00:00.381+00
c8182c07-0027-489b-9f5e-a33d36d8df33	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	144.90	143.64	t	in_stock	2025-09-03 17:00:00.381+00
37dada24-6b5f-491b-97e7-7fe1d103d2c1	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	131.28	143.64	t	in_stock	2025-09-03 17:00:00.381+00
f8d8e2ad-e04a-4516-814a-7b2494de7f80	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	155.50	143.64	t	in_stock	2025-09-03 17:00:00.381+00
4a28aa25-e102-44a6-899e-61a1953643a7	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	134.21	143.64	t	in_stock	2025-09-03 17:00:00.381+00
8793b780-0fb7-473f-8c06-c1e57363af70	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	148.53	143.64	t	in_stock	2025-09-03 17:00:00.381+00
bdbc38d1-907e-48cf-93b3-f5a7fcf43f55	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	143.26	143.64	t	in_stock	2025-09-03 17:00:00.381+00
b5dd458f-da46-40a8-bfc1-77ad5fa3430b	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.20	49.99	t	in_stock	2025-09-03 17:00:00.381+00
00062cec-600c-440e-bfb1-57bc984721ad	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	49.80	49.99	t	in_stock	2025-09-03 17:00:00.381+00
dfcf93ef-bcf4-40c9-9f4b-2b9a049a0a8e	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	47.31	49.99	t	in_stock	2025-09-03 17:00:00.381+00
925dcd80-615a-4e9c-8e97-3f3bd815854c	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	54.50	49.99	t	in_stock	2025-09-03 17:00:00.381+00
492eaf2e-3eed-4331-84ea-f28415541714	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	138.30	143.64	t	in_stock	2025-09-03 17:00:00.381+00
e39d9fbd-4834-4374-9b88-aa8fca94e901	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	145.73	143.64	t	in_stock	2025-09-03 17:00:00.381+00
f7a1a810-fd3e-4782-9152-eeb6137f6597	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	152.57	143.64	t	in_stock	2025-09-03 17:00:00.381+00
f8d80f96-7248-4a08-bcb8-d94da22585cb	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	54.25	49.99	t	in_stock	2025-09-03 17:00:00.381+00
b0b62da9-d81c-4222-920a-319690827cc0	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	46.66	49.99	t	in_stock	2025-09-03 17:00:00.381+00
9c731230-a922-43f1-bd46-e88eaafc9f7b	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	53.09	49.99	t	in_stock	2025-09-03 17:00:00.381+00
734dd492-433b-4fd3-a0f7-e51e1933d46d	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	47.54	49.99	t	in_stock	2025-09-03 17:00:00.381+00
f779fecd-26ec-4139-8434-57a5d1ab200a	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.30	143.64	t	in_stock	2025-09-03 17:00:00.381+00
f769a031-956b-4126-91e1-6e335cd7e7c6	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	130.73	143.64	t	in_stock	2025-09-03 17:00:00.381+00
33a865fd-5214-4aad-93c8-d4d112514e7d	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	135.33	143.64	t	in_stock	2025-09-03 17:00:00.381+00
1efb8a48-4c79-499c-a474-d1da45934b64	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	150.39	143.64	t	low_stock	2025-09-03 17:00:00.381+00
c1256df7-ea1e-4be0-90a9-1ff2e650f900	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.79	143.64	t	low_stock	2025-09-03 17:00:00.381+00
9be349f7-3c82-4694-9f10-faba72fb8e8f	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	130.49	143.64	t	in_stock	2025-09-03 17:00:00.381+00
cdacd966-d3d2-4f9e-bfca-9c06aca37ab5	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	137.25	143.64	t	in_stock	2025-09-03 17:00:00.381+00
2f8b4ab6-1ded-4b0a-8a2f-05ed47300839	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	152.49	143.64	t	in_stock	2025-09-03 17:00:00.381+00
96733b59-7043-47a9-b339-9eb5ad3fed3a	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	129.84	143.64	t	in_stock	2025-09-03 17:00:00.381+00
256ac241-b0b0-4547-b744-665c44cdd255	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.54	143.64	t	in_stock	2025-09-03 17:00:00.381+00
38ecde0f-a01c-4aa1-9789-78b06bf8801e	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.72	143.64	t	in_stock	2025-09-03 17:00:00.381+00
efb14671-5256-466e-936c-50b19b66a01b	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	152.14	143.64	t	low_stock	2025-09-03 17:00:00.381+00
ad46bc7e-7937-4612-af22-f25c5ca8f8ca	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	132.42	143.64	t	in_stock	2025-09-03 17:00:00.381+00
4cd9a682-522e-42ea-9a1f-1081e521309f	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	135.01	143.64	t	in_stock	2025-09-03 17:00:00.381+00
cc66f219-a268-4cad-886a-d89900e1dfe9	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	146.34	143.64	t	in_stock	2025-09-03 17:00:00.381+00
f8965664-9389-4720-bff7-fc43388a5122	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	148.23	143.64	t	low_stock	2025-09-03 17:00:00.381+00
13dd0d81-89bd-41df-be8b-96e16611638b	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	146.26	143.64	t	in_stock	2025-09-03 17:00:00.381+00
3fbe9f44-2b3f-4f3d-8543-56354ea4156a	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	130.73	143.64	t	in_stock	2025-09-03 17:00:00.381+00
4213ce91-c084-4fe8-a805-cd4923305b34	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	143.97	143.64	t	in_stock	2025-09-03 17:00:00.381+00
346853bd-eced-4bf7-9c4a-ff56023f710b	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	133.69	143.64	t	in_stock	2025-09-03 17:00:00.381+00
a23df5c0-d9c3-4b60-a17b-850e72245cd8	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	140.67	143.64	t	in_stock	2025-09-03 17:00:00.381+00
4dcb85bf-75d5-489f-ad13-99ccaa0a9df1	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	54.67	49.99	t	in_stock	2025-09-03 17:00:00.381+00
a1076fe7-75a2-4895-af3d-2878c12bfd93	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	45.54	49.99	t	low_stock	2025-09-03 17:00:00.381+00
bdb1ba68-b867-4022-97e7-4dbe365d7c43	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	46.40	49.99	t	in_stock	2025-09-03 17:00:00.381+00
aa302355-78c9-43c7-87a0-abd0897d7903	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	49.09	49.99	t	in_stock	2025-09-03 17:00:00.381+00
97361bf5-81a2-40e2-9d39-4a22144580b4	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	45.16	49.99	t	in_stock	2025-09-03 17:00:00.381+00
b3148d67-48cc-4f46-8fbe-1c2bedf5fe60	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	48.92	49.99	t	in_stock	2025-09-03 17:00:00.381+00
7c337c2b-1bbf-411d-b8ad-5f1a78cd4aa4	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	52.56	49.99	t	in_stock	2025-09-03 17:00:00.381+00
9064231b-03e3-4fdd-a610-5e0ce10f987c	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	51.23	49.99	t	in_stock	2025-09-03 17:00:00.381+00
76283d0b-476b-47ae-91dd-ea3babacd981	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.08	49.99	t	low_stock	2025-09-03 17:00:00.381+00
496e1ad2-9c6f-4aa0-8e52-50aa821f5cd2	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	54.98	49.99	t	in_stock	2025-09-03 17:00:00.381+00
0974f72a-ad81-45ac-9778-9a3394db5c82	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	54.66	49.99	t	in_stock	2025-09-03 17:00:00.381+00
f1f4fc0e-e3ee-4eea-918e-6f0461c85a31	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	51.16	49.99	t	in_stock	2025-09-03 17:00:00.381+00
072a2089-d8b0-434b-85b6-ab27ee88a3db	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	132.90	143.64	t	in_stock	2025-09-03 17:00:00.381+00
3b42b628-99a2-40c7-8b26-8307cd2e9328	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	155.11	143.64	t	in_stock	2025-09-03 17:00:00.381+00
01cadaab-b83a-44ff-975c-b9ccf40390f9	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	129.60	143.64	t	in_stock	2025-09-03 17:00:00.381+00
629ae907-6c45-4e9c-9666-d7d90d242c9c	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	154.33	143.64	t	low_stock	2025-09-03 17:00:00.381+00
0b8b9d23-f608-4745-8229-6f3ec26f95cc	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.42	143.64	t	in_stock	2025-09-03 17:00:00.55+00
52b14c54-1deb-48eb-9ff9-0e0282a09718	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.00	143.64	t	in_stock	2025-09-03 17:00:00.55+00
7952b6d3-ff27-4c4f-a7c8-4c38762ee1a3	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	139.49	143.64	t	in_stock	2025-09-03 17:00:00.55+00
f08de480-3f4d-4105-9020-5cf2b120326b	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	134.19	143.64	t	in_stock	2025-09-03 17:00:00.55+00
6e48a8c3-560d-4d56-acb3-04d6f915790b	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.52	143.64	t	in_stock	2025-09-03 17:00:00.55+00
036ceb1c-10cd-456a-a7e3-d39749b9d796	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	153.29	143.64	t	low_stock	2025-09-03 17:00:00.55+00
30834f56-27b2-4e52-bfe6-139a10dab0c7	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	144.05	143.64	t	low_stock	2025-09-03 17:00:00.55+00
60c06290-8d1b-47d3-ae2d-63d3f524e453	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	138.00	143.64	t	in_stock	2025-09-03 17:00:00.55+00
12166592-98a1-4af1-9652-ed844633c3a8	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	141.46	143.64	t	in_stock	2025-09-03 17:00:00.55+00
6e143052-460c-449b-a9c7-38345151c1e2	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	46.65	49.99	t	in_stock	2025-09-03 17:00:00.55+00
9214fd83-51d3-4f0d-82e3-c1e27f3a31e6	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.99	49.99	t	in_stock	2025-09-03 17:00:00.55+00
0329d7aa-9023-45cc-8ba5-b05e5ba99032	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	47.82	49.99	t	in_stock	2025-09-03 17:00:00.55+00
2407bf57-6475-48bb-9051-dac714c5c73b	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	45.20	49.99	t	in_stock	2025-09-03 17:00:00.55+00
4f3310c3-94a0-494b-ad3d-0c0e0c8bbb5e	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	50.48	49.99	t	in_stock	2025-09-03 17:00:00.55+00
28bc7430-ae1f-42f6-8e0c-9bb3ebc7b598	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	117.30	119.99	t	in_stock	2025-09-03 17:00:00.55+00
0b678c79-cfec-4702-bd7e-1bc343e3fbc6	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	112.13	119.99	t	low_stock	2025-09-03 17:00:00.55+00
1240783d-7b64-47d8-8bfa-4151afb1c51c	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	119.27	119.99	t	in_stock	2025-09-03 17:00:00.55+00
f771fb80-b8ce-4fae-8677-88f7fc87bdcb	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	4.38	3.99	t	in_stock	2025-09-03 17:00:00.55+00
8800299b-f92e-4f06-96d9-edf1a5eb8946	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	4.23	3.99	t	in_stock	2025-09-03 17:00:00.55+00
c2ace7aa-b641-4d70-8c21-90e31bac3f7a	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	3.76	3.99	t	in_stock	2025-09-03 17:00:00.55+00
bfd7cbe4-adbb-4cce-8673-7c87f247cf23	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	4.27	3.99	t	in_stock	2025-09-03 17:00:00.55+00
4c505467-269f-457e-b7d9-25ebd4a26224	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	146.69	143.64	t	in_stock	2025-09-03 17:00:00.55+00
3ab9f104-f231-4e8b-82be-6f6874ccbd5b	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	144.90	143.64	t	in_stock	2025-09-03 17:00:00.55+00
4f097355-7d85-4120-b946-64499bb0dc0f	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	131.28	143.64	t	in_stock	2025-09-03 17:00:00.55+00
ca02c0c1-cd7e-4b25-bcfb-2b81afbfc78a	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	155.50	143.64	t	in_stock	2025-09-03 17:00:00.55+00
079c0f20-2f94-46c8-8bc0-d758492ac6ff	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	134.21	143.64	t	in_stock	2025-09-03 17:00:00.55+00
b6ae7716-b0c9-4ded-b2f7-1968ee2082e9	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	148.53	143.64	t	in_stock	2025-09-03 17:00:00.55+00
ab78010e-a40a-4527-b3b3-91bbb5e8bff6	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	143.26	143.64	t	in_stock	2025-09-03 17:00:00.55+00
bd2212b6-f6b4-47a2-aaf0-9b9001b3acaf	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.20	49.99	t	in_stock	2025-09-03 17:00:00.55+00
b8d9aaab-838e-42a3-b191-ec4ceb0dfc9c	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	49.80	49.99	t	in_stock	2025-09-03 17:00:00.55+00
41a8fe34-cb1e-40ea-a9e6-db40c3914995	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	47.31	49.99	t	in_stock	2025-09-03 17:00:00.55+00
3400715c-fb8a-4df3-a61c-5528fd633938	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	54.50	49.99	t	in_stock	2025-09-03 17:00:00.55+00
3df97b6b-cb1f-409a-b967-837ac1a131fe	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	138.30	143.64	t	in_stock	2025-09-03 17:00:00.55+00
ace9a862-026b-4222-bcd9-c8c938b22bf6	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	145.73	143.64	t	in_stock	2025-09-03 17:00:00.55+00
f0a5e548-fa82-40b2-9bf3-562a1e0aca65	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	152.57	143.64	t	in_stock	2025-09-03 17:00:00.55+00
14521be3-f6a7-442a-8e62-6749db7c9f62	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	54.25	49.99	t	in_stock	2025-09-03 17:00:00.55+00
5b973bd6-4a24-4734-8d38-f5bd2a43c03c	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	46.66	49.99	t	in_stock	2025-09-03 17:00:00.55+00
baaa7e04-9a10-442b-ad0b-d7aa501a1b48	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	53.09	49.99	t	in_stock	2025-09-03 17:00:00.55+00
5798f14f-f7b2-4b4d-9aba-70128c120744	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	47.54	49.99	t	in_stock	2025-09-03 17:00:00.55+00
e0931751-4654-4d4d-8272-2b34ea3355e0	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.30	143.64	t	in_stock	2025-09-03 17:00:00.55+00
6c28cc3c-b5c2-4d10-92a4-374bedaa2a4b	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	130.73	143.64	t	in_stock	2025-09-03 17:00:00.55+00
96b0e068-6fae-4850-929e-052bd099fdc3	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	135.33	143.64	t	in_stock	2025-09-03 17:00:00.55+00
6d976540-63f6-4fcc-86a2-8e1e61465de6	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	150.39	143.64	t	low_stock	2025-09-03 17:00:00.55+00
a2abca74-017d-4ff5-9a11-906227d5f09a	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.79	143.64	t	low_stock	2025-09-03 17:00:00.55+00
81fd5553-f145-42d7-9a7a-0ffe60a10757	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	130.49	143.64	t	in_stock	2025-09-03 17:00:00.55+00
06462e83-b7a4-4f06-ba64-82ba7ceb6007	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	137.25	143.64	t	in_stock	2025-09-03 17:00:00.55+00
31ddd38e-775f-404f-b68c-7fb1bd6de3be	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	152.49	143.64	t	in_stock	2025-09-03 17:00:00.55+00
a5c0d2de-a843-457c-9655-864636bf9ae2	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	129.84	143.64	t	in_stock	2025-09-03 17:00:00.55+00
2050444e-5d51-40ea-9c93-be8c1f2d8d11	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.54	143.64	t	in_stock	2025-09-03 17:00:00.55+00
c934c005-ca7d-4b4a-a50a-967c811a17ab	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.72	143.64	t	in_stock	2025-09-03 17:00:00.55+00
9b245e6e-b774-4c9f-9221-2c469bc11518	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	152.14	143.64	t	low_stock	2025-09-03 17:00:00.55+00
c09def11-ff3f-4683-a3ad-db2991d19609	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	132.42	143.64	t	in_stock	2025-09-03 17:00:00.55+00
8f941c8f-a1d8-457c-bc18-84166c3f2166	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	135.01	143.64	t	in_stock	2025-09-03 17:00:00.55+00
5acaae9b-04d7-4f86-be58-8e52e8c14087	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	146.34	143.64	t	in_stock	2025-09-03 17:00:00.55+00
7666eee0-aa65-4ed4-bbb7-55879dbc90c8	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	148.23	143.64	t	low_stock	2025-09-03 17:00:00.55+00
59cc891a-4ec4-4d16-b096-3341d8eab34e	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	146.26	143.64	t	in_stock	2025-09-03 17:00:00.55+00
80862e0a-77ed-4d71-a474-05ae711102b3	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	130.73	143.64	t	in_stock	2025-09-03 17:00:00.55+00
d305c052-60b4-4511-bef2-ad3898499eb0	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	143.97	143.64	t	in_stock	2025-09-03 17:00:00.55+00
50275b31-2504-4d98-81e4-cd167433782d	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	133.69	143.64	t	in_stock	2025-09-03 17:00:00.55+00
3703e840-7a80-4bfa-96de-80ef2726d42e	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	140.67	143.64	t	in_stock	2025-09-03 17:00:00.55+00
28ee5f41-32c3-450c-8839-97fa4750ad47	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	54.67	49.99	t	in_stock	2025-09-03 17:00:00.55+00
d83a0c34-d866-4c04-a3f0-6868b2f879a3	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	45.54	49.99	t	low_stock	2025-09-03 17:00:00.55+00
45cefa86-01ea-42b0-8e57-7b78b559f423	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	46.40	49.99	t	in_stock	2025-09-03 17:00:00.55+00
c114ac03-4085-4bad-9590-a79e7261e224	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	49.09	49.99	t	in_stock	2025-09-03 17:00:00.55+00
4b858366-5128-4ec7-b3e3-df66124955b6	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	45.16	49.99	t	in_stock	2025-09-03 17:00:00.55+00
2d68d89e-e83a-4aff-b376-2cb676b5ae5f	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	48.92	49.99	t	in_stock	2025-09-03 17:00:00.55+00
eaad1a44-3140-4292-befb-fc4e2cc6c401	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	52.56	49.99	t	in_stock	2025-09-03 17:00:00.55+00
65847e46-88d5-4123-b424-b4ae137d649f	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	51.23	49.99	t	in_stock	2025-09-03 17:00:00.55+00
74bd411a-8bed-4aa9-b26a-b0a891be2cc7	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.08	49.99	t	low_stock	2025-09-03 17:00:00.55+00
7885ae7c-10cf-4fa0-859b-a72af6b595bb	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	54.98	49.99	t	in_stock	2025-09-03 17:00:00.55+00
11a21f48-945d-42ce-93d5-60955a14d127	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	54.66	49.99	t	in_stock	2025-09-03 17:00:00.55+00
d981503f-b212-4851-86bd-18e4645653b6	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	51.16	49.99	t	in_stock	2025-09-03 17:00:00.55+00
c7aa6d36-e545-44d3-8f0f-a6215a404e5a	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	132.90	143.64	t	in_stock	2025-09-03 17:00:00.55+00
a2f2eea8-8256-4d43-8511-2f542c8970d8	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	155.11	143.64	t	in_stock	2025-09-03 17:00:00.55+00
695397ac-8150-4bb1-a59a-dfe8b62d256f	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	129.60	143.64	t	in_stock	2025-09-03 17:00:00.55+00
1df2f00b-1d27-4096-96db-fa452841d7c3	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	154.33	143.64	t	low_stock	2025-09-03 17:00:00.55+00
246a9ce0-3c7f-4a92-a382-fca8d29de197	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.42	143.64	t	in_stock	2025-09-03 18:00:00.918+00
7d959ab1-c115-47cd-92de-558005e7aab8	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.00	143.64	t	in_stock	2025-09-03 18:00:00.918+00
8e02f611-9b56-460f-862b-0b5f38d7be33	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	139.49	143.64	t	in_stock	2025-09-03 18:00:00.918+00
9ac35a6e-44b6-4d81-bbe7-d0a693f5d196	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	134.19	143.64	t	in_stock	2025-09-03 18:00:00.918+00
4a8751c8-93e7-4b05-b92e-72a6071874b0	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.52	143.64	t	in_stock	2025-09-03 18:00:00.918+00
9d7bec69-a674-47f1-af69-b139f1cfa6dc	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	153.29	143.64	t	low_stock	2025-09-03 18:00:00.918+00
0aa5dcab-51f2-4921-866f-499730390c79	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	144.05	143.64	t	low_stock	2025-09-03 18:00:00.918+00
4bd7a20e-b2d1-4568-9dd0-15f0bfc64309	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	138.00	143.64	t	in_stock	2025-09-03 18:00:00.918+00
8f81f341-4e7b-4dd1-b156-540f1c572173	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	141.46	143.64	t	in_stock	2025-09-03 18:00:00.918+00
a24f86e7-2a3d-469f-8a5f-40eaeb34ea21	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	46.65	49.99	t	in_stock	2025-09-03 18:00:00.918+00
4bfc09f0-24f3-4428-b246-53878c1463e3	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.99	49.99	t	in_stock	2025-09-03 18:00:00.918+00
93f22978-93b6-4e61-a62a-02a3d38f4f14	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	47.82	49.99	t	in_stock	2025-09-03 18:00:00.918+00
69d953af-9e71-4716-b855-b7f18b7a3d8b	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	45.20	49.99	t	in_stock	2025-09-03 18:00:00.918+00
866a3015-ffd8-418f-8f46-346c7f9eebf4	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	50.48	49.99	t	in_stock	2025-09-03 18:00:00.918+00
a6fdfb39-1912-4330-99b6-b73dccf2343f	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	117.30	119.99	t	in_stock	2025-09-03 18:00:00.918+00
0cdc1c11-06f8-463e-bc5a-db8cd06809a7	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	112.13	119.99	t	low_stock	2025-09-03 18:00:00.918+00
58b9b907-d24a-4934-b48b-ad05c9643e00	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	119.27	119.99	t	in_stock	2025-09-03 18:00:00.918+00
1c55f9e4-92dd-4731-a9ef-15ba0aac02aa	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	4.38	3.99	t	in_stock	2025-09-03 18:00:00.918+00
662f4dee-727f-419f-b17e-e3237ca55e26	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	4.23	3.99	t	in_stock	2025-09-03 18:00:00.918+00
217b7102-03b3-4cc2-86fb-6c1f63a3e84c	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	3.76	3.99	t	in_stock	2025-09-03 18:00:00.918+00
e66f2bb5-b68e-40ac-92b9-56e83455494a	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	4.27	3.99	t	in_stock	2025-09-03 18:00:00.918+00
c074a56e-8e24-4a8c-8014-c6d804c4ab96	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	146.69	143.64	t	in_stock	2025-09-03 18:00:00.918+00
b0ca5dac-985d-47b7-a527-1351f1af674f	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	144.90	143.64	t	in_stock	2025-09-03 18:00:00.918+00
52cdc4da-824d-4a38-9642-30b8cbfc5243	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	131.28	143.64	t	in_stock	2025-09-03 18:00:00.918+00
32358b3b-0f7e-4232-a401-186fa4a4e942	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	155.50	143.64	t	in_stock	2025-09-03 18:00:00.918+00
f16eda94-d6e0-4253-ac22-d0bf789fe3fd	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	134.21	143.64	t	in_stock	2025-09-03 18:00:00.918+00
a79497bd-a9ce-4fdd-b954-9066a931202b	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	148.53	143.64	t	in_stock	2025-09-03 18:00:00.918+00
20ccac31-0388-4f5d-94e1-c7a929242c97	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	143.26	143.64	t	in_stock	2025-09-03 18:00:00.918+00
4ffce3fa-dd09-497a-90ec-188bed375169	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.20	49.99	t	in_stock	2025-09-03 18:00:00.918+00
01c75bc1-fcf1-4f20-92d2-1f8a4018c8cb	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	49.80	49.99	t	in_stock	2025-09-03 18:00:00.918+00
0bee7ab0-1204-4e0e-abac-c3dc2e1e1899	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	47.31	49.99	t	in_stock	2025-09-03 18:00:00.918+00
33676e8b-ada5-483f-ac9b-0771f91e24bd	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	54.50	49.99	t	in_stock	2025-09-03 18:00:00.918+00
13021116-be43-472b-b12e-7260cd7246dc	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	138.30	143.64	t	in_stock	2025-09-03 18:00:00.918+00
539a1ee2-cc21-4bee-a2fb-c4736a16e8c3	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	145.73	143.64	t	in_stock	2025-09-03 18:00:00.918+00
620fde7a-7684-41c9-837a-714d13f027ed	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	152.57	143.64	t	in_stock	2025-09-03 18:00:00.918+00
27f4d524-4af2-4417-91cc-98658f08f2de	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	54.25	49.99	t	in_stock	2025-09-03 18:00:00.918+00
02d7620c-b8e0-450c-a0a6-3b09f51ebf96	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	46.66	49.99	t	in_stock	2025-09-03 18:00:00.918+00
80de8edd-87b3-42d3-8252-1d3b2d892584	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	53.09	49.99	t	in_stock	2025-09-03 18:00:00.918+00
181c325c-72f2-41ad-a0fb-37a30aaad054	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	47.54	49.99	t	in_stock	2025-09-03 18:00:00.918+00
121115f4-f055-4924-b63a-7366a8132ccd	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.30	143.64	t	in_stock	2025-09-03 18:00:00.918+00
778c9932-1c0d-4c93-93df-2003c455e25a	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	130.73	143.64	t	in_stock	2025-09-03 18:00:00.918+00
bf3ebca5-ad83-4e52-a747-1d3fa273f544	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	135.33	143.64	t	in_stock	2025-09-03 18:00:00.918+00
7a877b17-6188-4fb6-aa05-35d52eb52516	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	150.39	143.64	t	low_stock	2025-09-03 18:00:00.918+00
6301a7e6-bb76-4a49-9caa-e33ff9c516f4	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.79	143.64	t	low_stock	2025-09-03 18:00:00.918+00
3db85820-3c09-4897-9f1b-4a98a81ea0ea	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	130.49	143.64	t	in_stock	2025-09-03 18:00:00.918+00
42a95af3-b470-47e2-a5a0-341289c38ae5	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	137.25	143.64	t	in_stock	2025-09-03 18:00:00.918+00
90278aed-59f6-4494-ab5a-23ecc99f05a3	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	152.49	143.64	t	in_stock	2025-09-03 18:00:00.918+00
895f03a7-16e1-43f5-90b3-2b94e0998f3e	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	129.84	143.64	t	in_stock	2025-09-03 18:00:00.918+00
5df932b9-b3ee-43f2-bd30-3e9e921cea68	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.54	143.64	t	in_stock	2025-09-03 18:00:00.918+00
5681af80-e938-4f1f-88fb-cf90268fcf6f	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.72	143.64	t	in_stock	2025-09-03 18:00:00.918+00
b74c6744-7b8f-41a5-9a2c-f09758b9dcd0	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	152.14	143.64	t	low_stock	2025-09-03 18:00:00.918+00
b679d7df-71ba-4a24-998a-ce66908550c3	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	132.42	143.64	t	in_stock	2025-09-03 18:00:00.918+00
c343e1eb-8843-4c9c-9aea-6daabf281bcb	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	135.01	143.64	t	in_stock	2025-09-03 18:00:00.918+00
0acbc301-f136-4cc1-ba9a-5599f58b96e3	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	146.34	143.64	t	in_stock	2025-09-03 18:00:00.918+00
12dc0683-090b-4932-8dc3-f2506f2136f6	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	148.23	143.64	t	low_stock	2025-09-03 18:00:00.918+00
85df2413-3ee7-40ca-a37f-96eb0cdbb0f6	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	146.26	143.64	t	in_stock	2025-09-03 18:00:00.918+00
fe5cbfd8-b391-43a4-84e1-6cf729be05bc	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	130.73	143.64	t	in_stock	2025-09-03 18:00:00.918+00
9e13d9d9-e2a5-4966-8e80-7980efdb4ab1	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	143.97	143.64	t	in_stock	2025-09-03 18:00:00.918+00
d3180115-2918-4aaa-8431-7c715af181da	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	133.69	143.64	t	in_stock	2025-09-03 18:00:00.918+00
bcda0427-471a-442c-98e7-097dc11b46d9	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	140.67	143.64	t	in_stock	2025-09-03 18:00:00.918+00
35f43a24-ec09-4721-b108-3309f61bcdb2	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	54.67	49.99	t	in_stock	2025-09-03 18:00:00.918+00
1c8b04df-bdb0-4272-bc85-a3aae4d62579	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	45.54	49.99	t	low_stock	2025-09-03 18:00:00.918+00
763ac7a6-aa1b-406b-adab-e23abe6e5335	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	46.40	49.99	t	in_stock	2025-09-03 18:00:00.918+00
35d6128e-9aa4-49d4-9b4c-920dcda39036	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	49.09	49.99	t	in_stock	2025-09-03 18:00:00.918+00
f0f04e25-2f4e-457b-8e79-3dba3ada48f7	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	45.16	49.99	t	in_stock	2025-09-03 18:00:00.918+00
91717415-79da-4ed8-9d8a-56568eb8bcca	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	48.92	49.99	t	in_stock	2025-09-03 18:00:00.918+00
8195753b-64f2-4469-9781-43fe2c5fc362	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	52.56	49.99	t	in_stock	2025-09-03 18:00:00.918+00
97ee5382-c381-4517-8201-698bb85241ce	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	51.23	49.99	t	in_stock	2025-09-03 18:00:00.918+00
11fccf1f-35ff-49bd-911c-9a5025077651	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.08	49.99	t	low_stock	2025-09-03 18:00:00.918+00
df7fa683-c234-404e-8ff7-28c564d1fdeb	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	54.98	49.99	t	in_stock	2025-09-03 18:00:00.918+00
ba18ca64-b3ef-417f-82b5-5b926045ce46	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	54.66	49.99	t	in_stock	2025-09-03 18:00:00.918+00
38091487-f292-48d4-b142-c13f5f0f1bca	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	51.16	49.99	t	in_stock	2025-09-03 18:00:00.918+00
d0f4742f-2ba1-4020-b32e-e869eb505744	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	132.90	143.64	t	in_stock	2025-09-03 18:00:00.918+00
fe61a300-c472-4245-a7b4-f759832762ab	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	155.11	143.64	t	in_stock	2025-09-03 18:00:00.918+00
416f757a-fbd1-4b75-8936-395f18943632	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	129.60	143.64	t	in_stock	2025-09-03 18:00:00.918+00
fa17e643-cce3-4acf-8c6d-089c2a5bc871	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	154.33	143.64	t	low_stock	2025-09-03 18:00:00.918+00
3123d7af-7ebf-40e5-9f70-216bfaaffeda	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.42	143.64	t	in_stock	2025-09-03 18:00:00.945+00
a853c173-3284-4e1d-a286-7df5b01b44f5	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	147.00	143.64	t	in_stock	2025-09-03 18:00:00.945+00
1a64843b-ecce-4951-a5f8-aa2db453dae9	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	139.49	143.64	t	in_stock	2025-09-03 18:00:00.945+00
4e027990-6909-4c3f-96db-c248218ac26a	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	134.19	143.64	t	in_stock	2025-09-03 18:00:00.945+00
75bad697-9f66-42e2-b785-2ec388499848	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.52	143.64	t	in_stock	2025-09-03 18:00:00.945+00
3b1c21b2-6642-464f-88e5-ac120a9723e7	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	153.29	143.64	t	low_stock	2025-09-03 18:00:00.945+00
5effa6e9-6538-4d8f-88b1-dbee0264dc76	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	144.05	143.64	t	low_stock	2025-09-03 18:00:00.945+00
ece605a8-88ef-4d4d-8cf9-41e84b68ee53	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	138.00	143.64	t	in_stock	2025-09-03 18:00:00.945+00
24682eed-01a4-41a8-a629-1d121fd46b16	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	141.46	143.64	t	in_stock	2025-09-03 18:00:00.945+00
4b800107-2f32-41a7-81d1-9239d0797e74	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	46.65	49.99	t	in_stock	2025-09-03 18:00:00.945+00
afdf6db4-0a23-4314-9e47-5b959d73fb14	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	47.99	49.99	t	in_stock	2025-09-03 18:00:00.945+00
943b3ce6-b997-43a4-9ac7-f82b3f022174	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	47.82	49.99	t	in_stock	2025-09-03 18:00:00.945+00
e03ffec8-285f-47b7-a63f-6d792d04b430	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	45.20	49.99	t	in_stock	2025-09-03 18:00:00.945+00
c3b426aa-ab3a-46af-97d5-f81e6a5c424f	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	50.48	49.99	t	in_stock	2025-09-03 18:00:00.945+00
76b5f93d-fc4a-4f1c-9773-a59ef95b5cf9	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	117.30	119.99	t	in_stock	2025-09-03 18:00:00.945+00
0673e8d1-0a90-4ced-aa8e-bb5aa7f7b371	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	112.13	119.99	t	low_stock	2025-09-03 18:00:00.945+00
06d77d33-959c-4cb5-b71f-0a734ceb912f	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	119.27	119.99	t	in_stock	2025-09-03 18:00:00.945+00
40829226-8ac5-40b0-8490-32848f2abd47	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	4.38	3.99	t	in_stock	2025-09-03 18:00:00.945+00
173d55d1-d002-4c67-83f1-72f96dd5fa6b	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	4.23	3.99	t	in_stock	2025-09-03 18:00:00.945+00
f38521f8-8b63-45c2-b76d-3e7c17be60d6	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	3.76	3.99	t	in_stock	2025-09-03 18:00:00.945+00
2f2abae8-9707-4134-888f-272a97c04642	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	4.27	3.99	t	in_stock	2025-09-03 18:00:00.945+00
467bd5de-d6b0-48d2-8665-6d1caf6f721c	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	146.69	143.64	t	in_stock	2025-09-03 18:00:00.945+00
881e13cf-4d74-4967-a139-c77c689acbba	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	144.90	143.64	t	in_stock	2025-09-03 18:00:00.945+00
08871d0e-f3cb-4115-92f2-bc94e9e0439c	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	131.28	143.64	t	in_stock	2025-09-03 18:00:00.945+00
add6f53e-f490-470a-adb4-6f67404558fc	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	155.50	143.64	t	in_stock	2025-09-03 18:00:00.945+00
141cc2aa-34e9-4d7c-8d07-1e790b0d0660	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	134.21	143.64	t	in_stock	2025-09-03 18:00:00.945+00
602818a6-1c83-411a-a661-a95037199824	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	148.53	143.64	t	in_stock	2025-09-03 18:00:00.945+00
64d633d4-f785-4087-b178-c00420310330	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	143.26	143.64	t	in_stock	2025-09-03 18:00:00.945+00
9544bb04-f4f5-44bf-9999-6e52eddf2245	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.20	49.99	t	in_stock	2025-09-03 18:00:00.945+00
2b70af83-cb84-4b79-99d5-d814042859f1	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	49.80	49.99	t	in_stock	2025-09-03 18:00:00.945+00
7aa19b1a-7185-4408-96f8-2e6aa70f5872	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	47.31	49.99	t	in_stock	2025-09-03 18:00:00.945+00
ddcb67f8-413a-428d-b481-c510e86b53df	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	54.50	49.99	t	in_stock	2025-09-03 18:00:00.945+00
e945bb98-96c8-4500-a215-c6156504ddd3	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	138.30	143.64	t	in_stock	2025-09-03 18:00:00.945+00
052a568a-f6cc-4621-9e1b-9749ebd55c4d	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	145.73	143.64	t	in_stock	2025-09-03 18:00:00.945+00
e59b094b-8024-409f-b5fd-479394bdfead	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	152.57	143.64	t	in_stock	2025-09-03 18:00:00.945+00
71c1233f-9d71-4403-86db-b1f0e16c187c	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	54.25	49.99	t	in_stock	2025-09-03 18:00:00.945+00
5dace8b0-4f74-4a1f-a329-f3e296a0030d	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	46.66	49.99	t	in_stock	2025-09-03 18:00:00.945+00
6c614535-7e6b-42d5-9bef-887df33781b1	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	53.09	49.99	t	in_stock	2025-09-03 18:00:00.945+00
e1b68f7b-39bc-4c54-9038-1fc8915fcdf9	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	47.54	49.99	t	in_stock	2025-09-03 18:00:00.945+00
5a1d9392-6397-4d03-a1fc-e3093242efeb	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	151.30	143.64	t	in_stock	2025-09-03 18:00:00.945+00
f80204d8-754e-4eea-b30e-db7dda06b6cd	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	130.73	143.64	t	in_stock	2025-09-03 18:00:00.945+00
237d6567-2574-4102-8a23-a6a6a270279b	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	135.33	143.64	t	in_stock	2025-09-03 18:00:00.945+00
460a9534-9ad4-4fad-834f-844228533056	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	150.39	143.64	t	low_stock	2025-09-03 18:00:00.945+00
574a1fca-7fe2-4b1e-a395-3c397fb0d39a	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	139.79	143.64	t	low_stock	2025-09-03 18:00:00.945+00
73bbd6bb-88e5-4e4f-b1a2-6739ef3fd1ec	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	130.49	143.64	t	in_stock	2025-09-03 18:00:00.945+00
fdd7fa74-50ff-4d72-a344-d874ecc1ac52	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	137.25	143.64	t	in_stock	2025-09-03 18:00:00.945+00
d31598ad-ebf7-4861-b88c-d0acb67c5aa4	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	152.49	143.64	t	in_stock	2025-09-03 18:00:00.945+00
836fa5d2-95fe-4e6f-b6ff-4d87fba68aab	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	129.84	143.64	t	in_stock	2025-09-03 18:00:00.945+00
3491026a-7cde-4ad7-b7d1-057c10e07b58	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	132.54	143.64	t	in_stock	2025-09-03 18:00:00.945+00
edd1fdfa-173c-47d0-9c58-6069c1d6a423	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	142.72	143.64	t	in_stock	2025-09-03 18:00:00.945+00
fa719de7-faad-4c54-814d-f43e6280b0e7	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	152.14	143.64	t	low_stock	2025-09-03 18:00:00.945+00
ca58bd11-7976-4c56-ba31-84b8ea0e9ae7	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	132.42	143.64	t	in_stock	2025-09-03 18:00:00.945+00
8ae90803-f214-4a39-b4ad-8dec87914bc7	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	135.01	143.64	t	in_stock	2025-09-03 18:00:00.945+00
e3127bdc-5729-4d51-90f6-1fee96dcf4a0	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	146.34	143.64	t	in_stock	2025-09-03 18:00:00.945+00
70140744-b8cb-498d-80a4-10a6ffed8c31	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	148.23	143.64	t	low_stock	2025-09-03 18:00:00.945+00
8b5e1119-68a5-4569-9339-60b8c18c201a	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	146.26	143.64	t	in_stock	2025-09-03 18:00:00.945+00
beb2e2b4-9464-4d85-8c64-ea651b7ae56d	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	130.73	143.64	t	in_stock	2025-09-03 18:00:00.945+00
798cf3c4-bdb5-4173-9d0f-813365be149a	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	143.97	143.64	t	in_stock	2025-09-03 18:00:00.945+00
3b5ddc7a-f353-4f71-96a9-5b0b73375f37	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	133.69	143.64	t	in_stock	2025-09-03 18:00:00.945+00
38931a0d-84ab-41ea-910c-a9249e3472d3	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	140.67	143.64	t	in_stock	2025-09-03 18:00:00.945+00
e56147fa-c435-4635-86be-90cca88ebeac	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	54.67	49.99	t	in_stock	2025-09-03 18:00:00.945+00
de41b77c-e1e4-4b5a-876f-ad282e956ce9	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	45.54	49.99	t	low_stock	2025-09-03 18:00:00.945+00
d353a816-42ba-4b30-ba63-84afbfcf54ae	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	46.40	49.99	t	in_stock	2025-09-03 18:00:00.945+00
c57fdb2f-a270-4e54-b372-1b7627d06a30	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	49.09	49.99	t	in_stock	2025-09-03 18:00:00.945+00
50501856-3953-4209-aade-300853fbc286	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	45.16	49.99	t	in_stock	2025-09-03 18:00:00.945+00
f299b450-fa72-4cf0-8f5c-e012345f4764	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	48.92	49.99	t	in_stock	2025-09-03 18:00:00.945+00
7f8ce568-2b40-4ace-bcdc-57e519b4dc40	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	52.56	49.99	t	in_stock	2025-09-03 18:00:00.945+00
d078a161-1195-413a-b3d5-18edff93cb77	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	51.23	49.99	t	in_stock	2025-09-03 18:00:00.945+00
18401441-7bf9-46b7-bd98-3b5757b5e23a	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	50.08	49.99	t	low_stock	2025-09-03 18:00:00.945+00
efe53f01-0df7-4653-8325-969227b66bb7	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	54.98	49.99	t	in_stock	2025-09-03 18:00:00.945+00
76aa95cb-5bf8-421d-aee2-37d8fdf1902f	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	54.66	49.99	t	in_stock	2025-09-03 18:00:00.945+00
ff4bbe4b-69f9-4ec6-8121-590403094050	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	51.16	49.99	t	in_stock	2025-09-03 18:00:00.945+00
936522d5-c15a-4b22-b6fa-eefa36d04598	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	132.90	143.64	t	in_stock	2025-09-03 18:00:00.945+00
3923d856-988d-4269-af9d-e7d204324e5e	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	155.11	143.64	t	in_stock	2025-09-03 18:00:00.945+00
90e47f15-52d0-4e02-89f9-3cbf965ab439	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	129.60	143.64	t	in_stock	2025-09-03 18:00:00.945+00
4cccec79-7a4f-4ee6-a7ac-31b17dd690af	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	154.33	143.64	t	low_stock	2025-09-03 18:00:00.945+00
\.


--
-- TOC entry 4294 (class 0 OID 16594)
-- Dependencies: 224
-- Data for Name: product_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_availability (id, product_id, retailer_id, in_stock, price, original_price, availability_status, product_url, cart_url, stock_level, store_locations, last_checked, last_in_stock, last_price_change, created_at, updated_at) FROM stdin;
8d93148d-3f6f-4253-a924-4e3b260dc27d	418e4d95-5e24-45ab-9d82-9f8fc0410132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	151.42	143.64	in_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-base-booster-box	https://www.bestbuy.com/cart/add/SV01-BB-EN	2	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
eff56e26-4c28-4090-8ad6-7822a0ec1eb1	418e4d95-5e24-45ab-9d82-9f8fc0410132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	147.00	143.64	in_stock	https://www.walmart.com/products/pokemon-scarlet-violet-base-booster-box	\N	29	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
19b7a386-8990-4abf-8652-23d35b58d254	418e4d95-5e24-45ab-9d82-9f8fc0410132	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8f578286-a20e-43d7-b35e-29b533092577	418e4d95-5e24-45ab-9d82-9f8fc0410132	ed369918-9011-441a-8f69-30847fe469f4	t	139.49	143.64	in_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-base-booster-box	\N	44	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
4ff37583-c6fe-4d5e-a293-2e1025192c2f	418e4d95-5e24-45ab-9d82-9f8fc0410132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	134.19	143.64	in_stock	https://www.gamestop.com/products/pokemon-scarlet-violet-base-booster-box	\N	14	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
2f4654e7-afec-4e8b-b761-c0ac7522dbb1	418e4d95-5e24-45ab-9d82-9f8fc0410132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	132.52	143.64	in_stock	https://www.target.com/products/pokemon-scarlet-violet-base-booster-box	\N	42	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
76a7dc74-328c-4b1c-bc7e-ffd9af1e3d72	b4dfaf4f-ce1b-4386-ae65-65512832d284	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-paldea-evolved-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a79c01e3-89c0-4699-947b-71f2c5980292	b4dfaf4f-ce1b-4386-ae65-65512832d284	e99e80ff-9412-47d3-b965-1d864a148a0b	t	153.29	143.64	low_stock	https://www.walmart.com/products/pokemon-paldea-evolved-booster-box	\N	26	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
5a1195a8-c858-442f-a327-6a8abf425eea	b4dfaf4f-ce1b-4386-ae65-65512832d284	5be78519-dba9-4be6-a909-2fa6c802d38e	t	144.05	143.64	low_stock	https://www.costco.com/products/pokemon-paldea-evolved-booster-box	\N	38	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
ec54bcc6-58e4-4dde-9e29-66fdbef8809d	b4dfaf4f-ce1b-4386-ae65-65512832d284	ed369918-9011-441a-8f69-30847fe469f4	t	138.00	143.64	in_stock	https://www.samsclub.com/products/pokemon-paldea-evolved-booster-box	\N	26	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
b1c60607-66f0-4d13-876b-cd043e5cc975	b4dfaf4f-ce1b-4386-ae65-65512832d284	b7b3c125-fa4e-40ec-813a-db76c0430127	t	141.46	143.64	in_stock	https://www.gamestop.com/products/pokemon-paldea-evolved-booster-box	\N	41	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
2bbb2150-e138-4aa9-b9e0-6d851c8c1e74	b4dfaf4f-ce1b-4386-ae65-65512832d284	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-paldea-evolved-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8bf6d62e-3358-46d0-803d-38d3cba1b1a2	669e93c6-5846-4046-8d40-d94bfd34b780	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	46.65	49.99	in_stock	https://www.bestbuy.com/products/pokemon-151-elite-trainer-box	https://www.bestbuy.com/cart/add/SV3.5-ETB-EN	23	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
65fa91df-9efc-4035-aaf8-d70cd7934110	669e93c6-5846-4046-8d40-d94bfd34b780	e99e80ff-9412-47d3-b965-1d864a148a0b	t	47.99	49.99	in_stock	https://www.walmart.com/products/pokemon-151-elite-trainer-box	\N	38	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
4ad11bfd-b11f-4486-b310-3258e3ae5224	669e93c6-5846-4046-8d40-d94bfd34b780	5be78519-dba9-4be6-a909-2fa6c802d38e	t	47.82	49.99	in_stock	https://www.costco.com/products/pokemon-151-elite-trainer-box	\N	24	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
4ed533e1-3272-4b6b-9d0e-99b339e7abd7	669e93c6-5846-4046-8d40-d94bfd34b780	ed369918-9011-441a-8f69-30847fe469f4	t	45.20	49.99	in_stock	https://www.samsclub.com/products/pokemon-151-elite-trainer-box	\N	23	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a545c372-907a-43ea-96f7-a800c077fe95	669e93c6-5846-4046-8d40-d94bfd34b780	b7b3c125-fa4e-40ec-813a-db76c0430127	f	\N	49.99	out_of_stock	https://www.gamestop.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
dcbdd21a-ea05-4df5-bba5-72c0eaec78f8	669e93c6-5846-4046-8d40-d94bfd34b780	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	50.48	49.99	in_stock	https://www.target.com/products/pokemon-151-elite-trainer-box	\N	18	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
e47823cb-22a2-469e-a5c7-85ac53e47fa3	e07633f1-7182-4567-a6c5-60456b332f0c	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	117.30	119.99	in_stock	https://www.bestbuy.com/products/charizard-ex-super-premium-collection	https://www.bestbuy.com/cart/add/SV-CHAR-SPC	12	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
7bab030e-6f93-4930-8d36-bb529be42140	e07633f1-7182-4567-a6c5-60456b332f0c	e99e80ff-9412-47d3-b965-1d864a148a0b	t	112.13	119.99	low_stock	https://www.walmart.com/products/charizard-ex-super-premium-collection	\N	10	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
2ab67968-07f5-4d01-ae1e-fb7fd586f305	e07633f1-7182-4567-a6c5-60456b332f0c	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	119.99	out_of_stock	https://www.costco.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
2cad3f03-3169-4637-973d-648f3481d437	e07633f1-7182-4567-a6c5-60456b332f0c	ed369918-9011-441a-8f69-30847fe469f4	f	\N	119.99	out_of_stock	https://www.samsclub.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
1e82bcd8-1074-418f-933e-a4bed4ab973c	e07633f1-7182-4567-a6c5-60456b332f0c	b7b3c125-fa4e-40ec-813a-db76c0430127	t	119.27	119.99	in_stock	https://www.gamestop.com/products/charizard-ex-super-premium-collection	\N	30	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
229ab1d9-be06-4720-856d-f71a627b927f	e07633f1-7182-4567-a6c5-60456b332f0c	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	\N	119.99	out_of_stock	https://www.target.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
92d41989-1592-4897-b278-e35604b9eda7	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	4.38	3.99	in_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-booster-pack	https://www.bestbuy.com/cart/add/SV01-BP-EN	19	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
adfbed14-9807-4486-946b-2b322619c18a	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	\N	3.99	out_of_stock	https://www.walmart.com/products/pokemon-scarlet-violet-booster-pack	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
f39a08d8-8466-4f4a-bca0-4b1fe666929e	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	4.23	3.99	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-booster-pack	\N	33	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
99390353-5c3b-41f4-ae36-66f080432695	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	ed369918-9011-441a-8f69-30847fe469f4	t	3.76	3.99	in_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-booster-pack	\N	13	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
88bea78e-c18d-4428-8e3d-cf9d4c2e6daf	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	b7b3c125-fa4e-40ec-813a-db76c0430127	f	\N	3.99	out_of_stock	https://www.gamestop.com/products/pokemon-scarlet-violet-booster-pack	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
2640426f-c595-4f63-b731-fe479df477c7	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	4.27	3.99	in_stock	https://www.target.com/products/pokemon-scarlet-violet-booster-pack	\N	36	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
7697b08e-859b-4652-8e01-2bbf501b1f54	345a6e90-30bb-49d2-bf67-7b4377955cfa	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
5191d004-61c4-4355-bae9-6af64edeed08	345a6e90-30bb-49d2-bf67-7b4377955cfa	e99e80ff-9412-47d3-b965-1d864a148a0b	t	146.69	143.64	in_stock	https://www.walmart.com/products/pokemon-obsidian-flames-booster-box	\N	28	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
ded827f8-b534-4fdf-a767-551dcc6a09f8	345a6e90-30bb-49d2-bf67-7b4377955cfa	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
18569c80-e156-43e0-a442-c8079c37c4e2	345a6e90-30bb-49d2-bf67-7b4377955cfa	ed369918-9011-441a-8f69-30847fe469f4	t	144.90	143.64	in_stock	https://www.samsclub.com/products/pokemon-obsidian-flames-booster-box	\N	8	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
68ec5167-3f8f-489a-8df6-57f6e1c22088	345a6e90-30bb-49d2-bf67-7b4377955cfa	b7b3c125-fa4e-40ec-813a-db76c0430127	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
ba6f60a5-574f-44fa-8ce3-ae866f376679	345a6e90-30bb-49d2-bf67-7b4377955cfa	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	131.28	143.64	in_stock	https://www.target.com/products/pokemon-obsidian-flames-booster-box	\N	3	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8bb46921-6705-42ee-b595-a0a4ededad23	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
d8c98a30-c644-4d6c-bc06-1a39843b2275	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	e99e80ff-9412-47d3-b965-1d864a148a0b	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
5a7ff014-1bff-4738-9adb-900de5ec3f53	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	5be78519-dba9-4be6-a909-2fa6c802d38e	t	155.50	143.64	in_stock	https://www.costco.com/products/pokemon-paradox-rift-booster-box	\N	41	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
50147bf2-0a9b-4be2-9d16-8c5d9be9dd15	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	ed369918-9011-441a-8f69-30847fe469f4	t	134.21	143.64	in_stock	https://www.samsclub.com/products/pokemon-paradox-rift-booster-box	\N	41	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
7e2bfea5-2979-4ea6-acda-76e7d41b0f75	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	148.53	143.64	in_stock	https://www.gamestop.com/products/pokemon-paradox-rift-booster-box	\N	43	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8a6e5273-f93d-4cd7-a58a-b29175ce24bb	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	143.26	143.64	in_stock	https://www.target.com/products/pokemon-paradox-rift-booster-box	\N	35	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
d76ee6cb-9aa7-406d-9ca4-643a8d8e3511	afccfd8f-9743-44a5-ba87-0f2ab1048f97	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	50.20	49.99	in_stock	https://www.bestbuy.com/products/pokemon-paldean-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SV4.5-ETB-EN	9	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
edecd044-7a92-4ebe-a7f5-c19ac875b266	afccfd8f-9743-44a5-ba87-0f2ab1048f97	e99e80ff-9412-47d3-b965-1d864a148a0b	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-paldean-fates-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a4a05055-3cfc-4770-9dbf-c20845510474	afccfd8f-9743-44a5-ba87-0f2ab1048f97	5be78519-dba9-4be6-a909-2fa6c802d38e	t	49.80	49.99	in_stock	https://www.costco.com/products/pokemon-paldean-fates-elite-trainer-box	\N	33	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
55ae254b-ff2f-461d-89c1-a34dfcbe5836	afccfd8f-9743-44a5-ba87-0f2ab1048f97	ed369918-9011-441a-8f69-30847fe469f4	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-paldean-fates-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
6de1eb96-ab56-4048-906b-f144c73631a6	afccfd8f-9743-44a5-ba87-0f2ab1048f97	b7b3c125-fa4e-40ec-813a-db76c0430127	t	47.31	49.99	in_stock	https://www.gamestop.com/products/pokemon-paldean-fates-elite-trainer-box	\N	8	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
c1d6d334-c91f-4fa9-aacd-795f9284fda1	afccfd8f-9743-44a5-ba87-0f2ab1048f97	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	54.50	49.99	in_stock	https://www.target.com/products/pokemon-paldean-fates-elite-trainer-box	\N	1	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
dd90b23c-88a2-473d-aa03-72f908982a3d	d6ca80c9-732a-49c7-ab46-2a4c71a86110	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
dd79c95a-19c8-49b9-aad2-56d21d7ceaaa	d6ca80c9-732a-49c7-ab46-2a4c71a86110	e99e80ff-9412-47d3-b965-1d864a148a0b	t	138.30	143.64	in_stock	https://www.walmart.com/products/pokemon-temporal-forces-booster-box	\N	16	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
3a4d06dd-a6b1-4412-aaf1-bfd079467823	d6ca80c9-732a-49c7-ab46-2a4c71a86110	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
3950cc34-78e0-4414-86f7-c327249b22e1	d6ca80c9-732a-49c7-ab46-2a4c71a86110	ed369918-9011-441a-8f69-30847fe469f4	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
90548036-c830-4a44-8260-4ecf7b996d0f	d6ca80c9-732a-49c7-ab46-2a4c71a86110	b7b3c125-fa4e-40ec-813a-db76c0430127	t	145.73	143.64	in_stock	https://www.gamestop.com/products/pokemon-temporal-forces-booster-box	\N	44	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
e2e6db3a-37bb-403d-8db3-17d340c10fff	d6ca80c9-732a-49c7-ab46-2a4c71a86110	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	152.57	143.64	in_stock	https://www.target.com/products/pokemon-temporal-forces-booster-box	\N	11	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
74a56f5c-094b-4573-9a9b-c1281e9bc058	69e556c3-ee7f-4ac8-85da-35345a52cf5a	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
d032b9dd-d058-4b56-b081-60b13a570c9b	69e556c3-ee7f-4ac8-85da-35345a52cf5a	e99e80ff-9412-47d3-b965-1d864a148a0b	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
7878e1df-4c29-4950-82ee-fac882800d98	69e556c3-ee7f-4ac8-85da-35345a52cf5a	5be78519-dba9-4be6-a909-2fa6c802d38e	t	54.25	49.99	in_stock	https://www.costco.com/products/pokemon-crown-zenith-elite-trainer-box	\N	24	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
63ce5fd3-f96b-4eda-9b57-94982d349fbe	69e556c3-ee7f-4ac8-85da-35345a52cf5a	ed369918-9011-441a-8f69-30847fe469f4	t	46.66	49.99	in_stock	https://www.samsclub.com/products/pokemon-crown-zenith-elite-trainer-box	\N	45	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
226a6563-732f-4fc1-8a6d-a8fdcf26c058	69e556c3-ee7f-4ac8-85da-35345a52cf5a	b7b3c125-fa4e-40ec-813a-db76c0430127	t	53.09	49.99	in_stock	https://www.gamestop.com/products/pokemon-crown-zenith-elite-trainer-box	\N	39	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
5c66fbb4-30eb-45c7-ae8f-2777799fb952	69e556c3-ee7f-4ac8-85da-35345a52cf5a	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	47.54	49.99	in_stock	https://www.target.com/products/pokemon-crown-zenith-elite-trainer-box	\N	12	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
97a58c62-2371-4320-8f04-34741b3801b1	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	151.30	143.64	in_stock	https://www.bestbuy.com/products/pokemon-evolving-skies-booster-box	https://www.bestbuy.com/cart/add/SWSH07-BB-EN	42	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
839ef003-8c40-4cdb-ac3e-834760f58dfb	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	e99e80ff-9412-47d3-b965-1d864a148a0b	t	130.73	143.64	in_stock	https://www.walmart.com/products/pokemon-evolving-skies-booster-box	\N	17	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a333b8be-aa1e-44a8-853f-4959c19a7482	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-evolving-skies-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
c6691336-262d-4e55-bd5c-4875d12c8a19	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	ed369918-9011-441a-8f69-30847fe469f4	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-evolving-skies-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
c66ba891-f773-40d7-b48a-26b151faaead	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	b7b3c125-fa4e-40ec-813a-db76c0430127	t	135.33	143.64	in_stock	https://www.gamestop.com/products/pokemon-evolving-skies-booster-box	\N	35	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
bdeb4d8b-8ec5-4045-a194-6382619ede2b	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	150.39	143.64	low_stock	https://www.target.com/products/pokemon-evolving-skies-booster-box	\N	29	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
f10095f1-0cbd-4cd9-b3f2-6cf2a95fff5c	325f8360-7200-4d59-b46e-4134bd6bacc3	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	139.79	143.64	low_stock	https://www.bestbuy.com/products/pokemon-brilliant-stars-booster-box	https://www.bestbuy.com/cart/add/SWSH09-BB-EN	15	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
6a1dbc3f-50ac-4741-b23b-c8c6fb3306ad	325f8360-7200-4d59-b46e-4134bd6bacc3	e99e80ff-9412-47d3-b965-1d864a148a0b	t	130.49	143.64	in_stock	https://www.walmart.com/products/pokemon-brilliant-stars-booster-box	\N	14	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
37f08132-f30d-45b8-bc1b-bfb8640d4342	325f8360-7200-4d59-b46e-4134bd6bacc3	5be78519-dba9-4be6-a909-2fa6c802d38e	t	137.25	143.64	in_stock	https://www.costco.com/products/pokemon-brilliant-stars-booster-box	\N	45	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
aa889254-98dc-4730-8cd6-320396fc5aec	325f8360-7200-4d59-b46e-4134bd6bacc3	ed369918-9011-441a-8f69-30847fe469f4	t	152.49	143.64	in_stock	https://www.samsclub.com/products/pokemon-brilliant-stars-booster-box	\N	41	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
3d57fafe-0fbf-4cd3-b925-deec12d99ac5	325f8360-7200-4d59-b46e-4134bd6bacc3	b7b3c125-fa4e-40ec-813a-db76c0430127	t	129.84	143.64	in_stock	https://www.gamestop.com/products/pokemon-brilliant-stars-booster-box	\N	41	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
440c359d-09cb-4462-bc46-fe1723053b20	325f8360-7200-4d59-b46e-4134bd6bacc3	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	132.54	143.64	in_stock	https://www.target.com/products/pokemon-brilliant-stars-booster-box	\N	48	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a420c9db-2f90-46f3-85da-cf88feb4cee0	5b266066-2106-40ae-b282-949dc23491a9	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	142.72	143.64	in_stock	https://www.bestbuy.com/products/pokemon-lost-origin-booster-box	https://www.bestbuy.com/cart/add/SWSH11-BB-EN	6	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
cdc02ed9-035c-4780-afaa-3eb473099be6	5b266066-2106-40ae-b282-949dc23491a9	e99e80ff-9412-47d3-b965-1d864a148a0b	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-lost-origin-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
97cbf707-ceab-41ba-81d6-d0bcdaba84cf	5b266066-2106-40ae-b282-949dc23491a9	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-lost-origin-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
e9453c3f-f5a6-49bb-81c8-266e8ffde4a9	5b266066-2106-40ae-b282-949dc23491a9	ed369918-9011-441a-8f69-30847fe469f4	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-lost-origin-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
5384cfbd-4740-48ac-9653-c6c928a3ffb6	5b266066-2106-40ae-b282-949dc23491a9	b7b3c125-fa4e-40ec-813a-db76c0430127	t	152.14	143.64	low_stock	https://www.gamestop.com/products/pokemon-lost-origin-booster-box	\N	40	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
56d210ab-84e4-47c0-9687-4e2e636d1b61	5b266066-2106-40ae-b282-949dc23491a9	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-lost-origin-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
da59161d-c43f-42af-98d0-93d171ec6865	7cbb19fa-f7bd-49f8-84f8-07f983c84132	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-astral-radiance-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
d01a1c7d-e106-47dc-a01d-2345724d1785	7cbb19fa-f7bd-49f8-84f8-07f983c84132	e99e80ff-9412-47d3-b965-1d864a148a0b	t	132.42	143.64	in_stock	https://www.walmart.com/products/pokemon-astral-radiance-booster-box	\N	40	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
0e5c7615-0478-4cbf-a1c4-084cd83d2b49	7cbb19fa-f7bd-49f8-84f8-07f983c84132	5be78519-dba9-4be6-a909-2fa6c802d38e	t	135.01	143.64	in_stock	https://www.costco.com/products/pokemon-astral-radiance-booster-box	\N	24	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
44e598b5-57eb-4787-ab60-f2de91cc12f7	7cbb19fa-f7bd-49f8-84f8-07f983c84132	ed369918-9011-441a-8f69-30847fe469f4	t	146.34	143.64	in_stock	https://www.samsclub.com/products/pokemon-astral-radiance-booster-box	\N	39	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a62c3339-32c8-4444-80c7-76d64b73225e	7cbb19fa-f7bd-49f8-84f8-07f983c84132	b7b3c125-fa4e-40ec-813a-db76c0430127	t	148.23	143.64	low_stock	https://www.gamestop.com/products/pokemon-astral-radiance-booster-box	\N	13	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
ddabb5a5-a8f9-410c-ae58-fc74b8717d21	7cbb19fa-f7bd-49f8-84f8-07f983c84132	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	146.26	143.64	in_stock	https://www.target.com/products/pokemon-astral-radiance-booster-box	\N	28	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
7b6e8602-0ce0-408c-9d3d-81695a91a070	9975f314-970f-4dda-9c8f-61a36558666f	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	130.73	143.64	in_stock	https://www.bestbuy.com/products/pokemon-fusion-strike-booster-box	https://www.bestbuy.com/cart/add/SWSH08-BB-EN	35	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
bae0e0ae-2292-4366-95c8-3a4383d1342b	9975f314-970f-4dda-9c8f-61a36558666f	e99e80ff-9412-47d3-b965-1d864a148a0b	t	143.97	143.64	in_stock	https://www.walmart.com/products/pokemon-fusion-strike-booster-box	\N	4	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
39b8c44c-dd1f-445f-b319-269d39fa82ef	9975f314-970f-4dda-9c8f-61a36558666f	5be78519-dba9-4be6-a909-2fa6c802d38e	t	133.69	143.64	in_stock	https://www.costco.com/products/pokemon-fusion-strike-booster-box	\N	14	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8725f9a2-f43d-4e2c-b707-e767b5e09fb2	9975f314-970f-4dda-9c8f-61a36558666f	ed369918-9011-441a-8f69-30847fe469f4	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
3a579825-408c-4019-b8ab-24eeb043a245	9975f314-970f-4dda-9c8f-61a36558666f	b7b3c125-fa4e-40ec-813a-db76c0430127	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
abe083ba-0bb3-4437-8868-4b8662dca1cb	9975f314-970f-4dda-9c8f-61a36558666f	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	140.67	143.64	in_stock	https://www.target.com/products/pokemon-fusion-strike-booster-box	\N	50	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
b3ae73c1-5b33-4f24-a64c-27f489e485af	f1f9a969-2c82-453c-a6a3-775d3bf365ca	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	54.67	49.99	in_stock	https://www.bestbuy.com/products/pokemon-celebrations-elite-trainer-box	https://www.bestbuy.com/cart/add/SWSH25-ETB-EN	50	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
1dcb087d-d039-4196-b0d6-ee01a2ffa4f0	f1f9a969-2c82-453c-a6a3-775d3bf365ca	e99e80ff-9412-47d3-b965-1d864a148a0b	t	45.54	49.99	low_stock	https://www.walmart.com/products/pokemon-celebrations-elite-trainer-box	\N	40	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
d0a9f2ae-ba61-4d33-817c-a068e3e16d6f	f1f9a969-2c82-453c-a6a3-775d3bf365ca	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	49.99	out_of_stock	https://www.costco.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
31a94d46-cda1-43ed-8064-2b5f7bd8ead2	f1f9a969-2c82-453c-a6a3-775d3bf365ca	ed369918-9011-441a-8f69-30847fe469f4	t	46.40	49.99	in_stock	https://www.samsclub.com/products/pokemon-celebrations-elite-trainer-box	\N	17	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
9d3f7125-7495-4522-a193-d8a170063aef	f1f9a969-2c82-453c-a6a3-775d3bf365ca	b7b3c125-fa4e-40ec-813a-db76c0430127	f	\N	49.99	out_of_stock	https://www.gamestop.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
b63a5820-438a-41f6-bcc2-e33247e0fa01	f1f9a969-2c82-453c-a6a3-775d3bf365ca	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	49.09	49.99	in_stock	https://www.target.com/products/pokemon-celebrations-elite-trainer-box	\N	38	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
27ee6d10-d04d-4ffa-bd90-1ce85adee2fb	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	c886c6ad-9155-460f-8cce-57c7fb39aaa3	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-shining-fates-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8a40232b-eb3a-4022-b08c-34f4693119ca	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	e99e80ff-9412-47d3-b965-1d864a148a0b	t	45.16	49.99	in_stock	https://www.walmart.com/products/pokemon-shining-fates-elite-trainer-box	\N	21	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
520fbbbc-a090-4c50-9d1c-f2dc4316deda	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	49.99	out_of_stock	https://www.costco.com/products/pokemon-shining-fates-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
9b12d3e1-bf30-4552-b357-6f99f7275011	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	ed369918-9011-441a-8f69-30847fe469f4	t	48.92	49.99	in_stock	https://www.samsclub.com/products/pokemon-shining-fates-elite-trainer-box	\N	26	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
b18647aa-e13a-4e07-8580-09082ca2dd41	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	b7b3c125-fa4e-40ec-813a-db76c0430127	t	52.56	49.99	in_stock	https://www.gamestop.com/products/pokemon-shining-fates-elite-trainer-box	\N	10	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
fe40ff12-154f-41b1-8713-23faf1a4077e	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	51.23	49.99	in_stock	https://www.target.com/products/pokemon-shining-fates-elite-trainer-box	\N	19	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
6ad36e1a-1c34-49f0-b59b-76e26ac3b75f	464f5a27-cbb5-4107-8ebd-f1a6fe286487	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	50.08	49.99	low_stock	https://www.bestbuy.com/products/pokemon-hidden-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SM11.5-ETB-EN	42	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
8906c034-af30-4f1b-9808-93c945c7524d	464f5a27-cbb5-4107-8ebd-f1a6fe286487	e99e80ff-9412-47d3-b965-1d864a148a0b	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
cb40984c-110d-4fff-b150-2db31f47e6cf	464f5a27-cbb5-4107-8ebd-f1a6fe286487	5be78519-dba9-4be6-a909-2fa6c802d38e	t	54.98	49.99	in_stock	https://www.costco.com/products/pokemon-hidden-fates-elite-trainer-box	\N	10	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
71e4a2b7-e8e1-4923-8cb3-c10a00a2ab98	464f5a27-cbb5-4107-8ebd-f1a6fe286487	ed369918-9011-441a-8f69-30847fe469f4	t	54.66	49.99	in_stock	https://www.samsclub.com/products/pokemon-hidden-fates-elite-trainer-box	\N	34	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
d710f840-6f82-4181-860e-9ba5a9a0c8ee	464f5a27-cbb5-4107-8ebd-f1a6fe286487	b7b3c125-fa4e-40ec-813a-db76c0430127	t	51.16	49.99	in_stock	https://www.gamestop.com/products/pokemon-hidden-fates-elite-trainer-box	\N	50	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
82f17a20-ba86-4c37-9083-a53b6b1b89e9	464f5a27-cbb5-4107-8ebd-f1a6fe286487	4e909cc9-547a-4540-ad93-2a8aec9a91f3	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
b59a43ff-2532-4c8a-9686-8b869c5b2d72	210293d2-cc9d-4fca-be6e-41df29fdd537	c886c6ad-9155-460f-8cce-57c7fb39aaa3	t	132.90	143.64	in_stock	https://www.bestbuy.com/products/pokemon-chilling-reign-booster-box	https://www.bestbuy.com/cart/add/SWSH06-BB-EN	33	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
23b015d5-2e55-4fd9-bcce-092fbd825893	210293d2-cc9d-4fca-be6e-41df29fdd537	e99e80ff-9412-47d3-b965-1d864a148a0b	t	155.11	143.64	in_stock	https://www.walmart.com/products/pokemon-chilling-reign-booster-box	\N	38	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
32a31c11-4c1c-4511-bdb5-e45081099d98	210293d2-cc9d-4fca-be6e-41df29fdd537	5be78519-dba9-4be6-a909-2fa6c802d38e	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-chilling-reign-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
be867b08-f455-4ed5-b595-5c47b3bc58d9	210293d2-cc9d-4fca-be6e-41df29fdd537	ed369918-9011-441a-8f69-30847fe469f4	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-chilling-reign-booster-box	\N	0	[]	2025-09-03 16:53:58.12434+00	\N	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
7fa3107d-1574-4cc5-b4bf-4d5f074f2d12	210293d2-cc9d-4fca-be6e-41df29fdd537	b7b3c125-fa4e-40ec-813a-db76c0430127	t	129.60	143.64	in_stock	https://www.gamestop.com/products/pokemon-chilling-reign-booster-box	\N	18	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
a8f64db5-0af3-411f-92be-9777c63f62a0	210293d2-cc9d-4fca-be6e-41df29fdd537	4e909cc9-547a-4540-ad93-2a8aec9a91f3	t	154.33	143.64	low_stock	https://www.target.com/products/pokemon-chilling-reign-booster-box	\N	31	[]	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00	2025-09-03 16:53:58.12434+00
\.


--
-- TOC entry 4292 (class 0 OID 16545)
-- Dependencies: 222
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name, slug, description, parent_id, sort_order, created_at, updated_at) FROM stdin;
36a3d14d-c952-4789-8def-f9c4a170325e	Booster Boxes	booster-boxes	Complete booster boxes containing multiple booster packs	\N	1	2025-09-03 16:53:58.109595+00	2025-09-03 16:53:58.109595+00
970bd13b-49fc-4e6b-afc7-f5ccab2005b0	Booster Packs	booster-packs	Individual booster packs	\N	2	2025-09-03 16:53:58.109595+00	2025-09-03 16:53:58.109595+00
8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Elite Trainer Boxes	elite-trainer-boxes	Elite Trainer Boxes with booster packs and accessories	\N	3	2025-09-03 16:53:58.109595+00	2025-09-03 16:53:58.109595+00
183f9830-cc27-4fa2-87f1-545750bd7106	Collection Boxes	collection-boxes	Special collection boxes and premium products	\N	4	2025-09-03 16:53:58.109595+00	2025-09-03 16:53:58.109595+00
29e2a24a-bd51-46fa-abf1-59907320befd	Starter Decks	starter-decks	Theme decks and starter products	\N	5	2025-09-03 16:53:58.109595+00	2025-09-03 16:53:58.109595+00
\.


--
-- TOC entry 4293 (class 0 OID 16565)
-- Dependencies: 223
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, slug, sku, upc, category_id, set_name, series, release_date, msrp, image_url, description, metadata, is_active, popularity_score, created_at, updated_at) FROM stdin;
210293d2-cc9d-4fca-be6e-41df29fdd537	Pokémon Chilling Reign Booster Box	pokemon-chilling-reign-booster-box	SWSH06-BB-EN	0820650458858	36a3d14d-c952-4789-8def-f9c4a170325e	Chilling Reign	Sword & Shield	2021-06-18	143.64	https://images.pokemontcg.io/swsh6/logo.png	Chilling Reign Booster Box featuring the Calyrex forms	{"language": "English", "set_code": "SWSH06", "pack_count": 36, "cards_per_pack": 10}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.977+00
2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	Pokémon Shining Fates Elite Trainer Box	pokemon-shining-fates-elite-trainer-box	SWSH4.5-ETB-EN	0820650457448	8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Shining Fates	Sword & Shield	2021-02-19	49.99	https://images.pokemontcg.io/swsh45/logo.png	Shining Fates Elite Trainer Box featuring shiny vault cards	{"language": "English", "pack_count": 10}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.981+00
325f8360-7200-4d59-b46e-4134bd6bacc3	Pokémon Brilliant Stars Booster Box	pokemon-brilliant-stars-booster-box	SWSH09-BB-EN	0820650459541	36a3d14d-c952-4789-8def-f9c4a170325e	Brilliant Stars	Sword & Shield	2022-02-25	143.64	https://images.pokemontcg.io/swsh9/logo.png	Brilliant Stars Booster Box featuring the Trainer Gallery subset	{"language": "English", "set_code": "SWSH09", "pack_count": 36, "cards_per_pack": 10}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.984+00
345a6e90-30bb-49d2-bf67-7b4377955cfa	Pokémon Obsidian Flames Booster Box	pokemon-obsidian-flames-booster-box	SV03-BB-EN	820650850059	36a3d14d-c952-4789-8def-f9c4a170325e	Obsidian Flames	Scarlet & Violet	2023-08-11	143.64	https://images.pokemontcg.io/sv3/logo.png	Obsidian Flames Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV03", "pack_count": 36, "cards_per_pack": 11}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.985+00
418e4d95-5e24-45ab-9d82-9f8fc0410132	Pokémon Scarlet & Violet Base Set Booster Box	pokemon-scarlet-violet-base-booster-box	SV01-BB-EN	820650850011	36a3d14d-c952-4789-8def-f9c4a170325e	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	143.64	https://images.pokemontcg.io/sv1/logo.png	Scarlet & Violet Base Set Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV01", "pack_count": 36, "cards_per_pack": 11, "rarity_distribution": {"common": 7, "uncommon": 3, "rare_or_higher": 1}}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.985+00
464f5a27-cbb5-4107-8ebd-f1a6fe286487	Pokémon Hidden Fates Elite Trainer Box	pokemon-hidden-fates-elite-trainer-box	SM11.5-ETB-EN	0820650451491	8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Hidden Fates	Sun & Moon	2019-09-20	49.99	https://images.pokemontcg.io/sm115/logo.png	Hidden Fates Elite Trainer Box with the iconic shiny vault	{"language": "English", "pack_count": 10}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.986+00
485c2cb8-71b4-4da7-aa48-72a06a2a6da2	Pokémon Paradox Rift Booster Box	pokemon-paradox-rift-booster-box	SV04-BB-EN	820650850066	36a3d14d-c952-4789-8def-f9c4a170325e	Paradox Rift	Scarlet & Violet	2023-11-03	143.64	https://images.pokemontcg.io/sv4/logo.png	Paradox Rift Booster Box with 36 booster packs	{"language": "English", "set_code": "SV04", "pack_count": 36, "cards_per_pack": 11}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.986+00
5b266066-2106-40ae-b282-949dc23491a9	Pokémon Lost Origin Booster Box	pokemon-lost-origin-booster-box	SWSH11-BB-EN	0820650460233	36a3d14d-c952-4789-8def-f9c4a170325e	Lost Origin	Sword & Shield	2022-09-09	143.64	https://images.pokemontcg.io/swsh11/logo.png	Lost Origin Booster Box featuring the Lost Zone mechanic	{"language": "English", "set_code": "SWSH11", "pack_count": 36, "cards_per_pack": 10}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.987+00
669e93c6-5846-4046-8d40-d94bfd34b780	Pokémon 151 Elite Trainer Box	pokemon-151-elite-trainer-box	SV3.5-ETB-EN	820650851001	8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Pokémon 151	Scarlet & Violet	2023-09-22	49.99	https://images.pokemontcg.io/sv3pt5/logo.png	Pokémon 151 Elite Trainer Box with 9 booster packs and accessories	{"includes": ["9 Pokémon 151 booster packs", "65 card sleeves", "45 Energy cards", "Player's guide", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "Collector's box"], "language": "English", "set_code": "SV3.5", "pack_count": 9, "cards_per_pack": 11}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.987+00
69e556c3-ee7f-4ac8-85da-35345a52cf5a	Pokémon Crown Zenith Elite Trainer Box	pokemon-crown-zenith-elite-trainer-box	SWSH12.5-ETB-EN	0820650852625	8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Crown Zenith	Sword & Shield	2023-01-20	49.99	https://images.pokemontcg.io/swsh12pt5/logo.png	Crown Zenith Elite Trainer Box featuring special Galarian Gallery cards	{"language": "English", "set_code": "SWSH12.5", "pack_count": 10}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.988+00
70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	Pokémon Scarlet & Violet Booster Pack	pokemon-scarlet-violet-booster-pack	SV01-BP-EN	820650850035	970bd13b-49fc-4e6b-afc7-f5ccab2005b0	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	3.99	https://images.pokemontcg.io/sv1/pack.png	Single Scarlet & Violet Base Set booster pack	{"language": "English", "set_code": "SV01", "cards_per_pack": 11}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.988+00
7cbb19fa-f7bd-49f8-84f8-07f983c84132	Pokémon Astral Radiance Booster Box	pokemon-astral-radiance-booster-box	SWSH10-BB-EN	0820650460134	36a3d14d-c952-4789-8def-f9c4a170325e	Astral Radiance	Sword & Shield	2022-05-27	143.64	https://images.pokemontcg.io/swsh10/logo.png	Astral Radiance Booster Box featuring Hisuian Pokémon	{"language": "English", "set_code": "SWSH10", "pack_count": 36, "cards_per_pack": 10}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.989+00
9975f314-970f-4dda-9c8f-61a36558666f	Pokémon Fusion Strike Booster Box	pokemon-fusion-strike-booster-box	SWSH08-BB-EN	0820650459275	36a3d14d-c952-4789-8def-f9c4a170325e	Fusion Strike	Sword & Shield	2021-11-12	143.64	https://images.pokemontcg.io/swsh8/logo.png	Fusion Strike Booster Box featuring Mew VMAX and Gengar VMAX	{"language": "English", "set_code": "SWSH08", "pack_count": 36, "cards_per_pack": 10}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.99+00
9ac1687e-3ccb-420c-8b08-c84e856bfaf2	Pokémon Evolving Skies Booster Box	pokemon-evolving-skies-booster-box	SWSH07-BB-EN	0820650453693	36a3d14d-c952-4789-8def-f9c4a170325e	Evolving Skies	Sword & Shield	2021-08-27	143.64	https://images.pokemontcg.io/swsh7/logo.png	Evolving Skies Booster Box featuring Eeveelutions and Dragon-type Pokémon	{"language": "English", "set_code": "SWSH07", "pack_count": 36, "cards_per_pack": 10}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.991+00
afccfd8f-9743-44a5-ba87-0f2ab1048f97	Pokémon Paldean Fates Elite Trainer Box	pokemon-paldean-fates-elite-trainer-box	SV4.5-ETB-EN	0820650852441	8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Paldean Fates	Scarlet & Violet	2024-01-26	49.99	https://images.pokemontcg.io/sv4pt5/logo.png	Paldean Fates Elite Trainer Box including 9 booster packs and accessories	{"includes": ["9 Paldean Fates booster packs", "Card sleeves", "Energy cards", "Dice", "Markers"], "language": "English", "set_code": "SV4.5", "pack_count": 9}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.991+00
b4dfaf4f-ce1b-4386-ae65-65512832d284	Pokémon Paldea Evolved Booster Box	pokemon-paldea-evolved-booster-box	SV02-BB-EN	820650850028	36a3d14d-c952-4789-8def-f9c4a170325e	Paldea Evolved	Scarlet & Violet	2023-06-09	143.64	https://images.pokemontcg.io/sv2/logo.png	Paldea Evolved Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV02", "pack_count": 36, "cards_per_pack": 11}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.992+00
d6ca80c9-732a-49c7-ab46-2a4c71a86110	Pokémon Temporal Forces Booster Box	pokemon-temporal-forces-booster-box	SV05-BB-EN	0820650852519	36a3d14d-c952-4789-8def-f9c4a170325e	Temporal Forces	Scarlet & Violet	2024-03-22	143.64	https://images.pokemontcg.io/sv5/logo.png	Temporal Forces Booster Box with 36 booster packs	{"language": "English", "set_code": "SV05", "pack_count": 36, "cards_per_pack": 11}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.993+00
e07633f1-7182-4567-a6c5-60456b332f0c	Charizard ex Super Premium Collection	charizard-ex-super-premium-collection	SV-CHAR-SPC	820650852001	183f9830-cc27-4fa2-87f1-545750bd7106	Special Collection	Scarlet & Violet	2023-12-01	119.99	https://images.pokemontcg.io/sv-promo/charizard-ex.png	Charizard ex Super Premium Collection with exclusive cards and accessories	{"includes": ["1 foil promo card featuring Charizard ex", "1 foil promo card featuring Charmander", "1 foil promo card featuring Charmeleon", "16 Pokémon TCG booster packs", "1 playmat featuring Charizard ex", "65 card sleeves featuring Charizard ex", "1 metal coin featuring Charizard ex", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "1 collector's box"], "language": "English", "set_code": "SV-PROMO", "pack_count": 16}	t	2	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.994+00
f1f9a969-2c82-453c-a6a3-775d3bf365ca	Pokémon Celebrations Elite Trainer Box	pokemon-celebrations-elite-trainer-box	SWSH25-ETB-EN	0820650459299	8dad9d7c-d05b-4413-b2ba-63607c8c7a7a	Celebrations	Sword & Shield	2021-10-08	49.99	https://images.pokemontcg.io/swsh45/logo.png	25th Anniversary Celebrations Elite Trainer Box with special mini-packs	{"language": "English", "pack_count": 10}	t	3	2025-09-03 16:53:58.112619+00	2025-09-03 18:00:00.994+00
\.


--
-- TOC entry 4291 (class 0 OID 16523)
-- Dependencies: 221
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retailers (id, name, slug, website_url, api_type, api_config, is_active, rate_limit_per_minute, health_score, last_health_check, supported_features, created_at, updated_at) FROM stdin;
c886c6ad-9155-460f-8cce-57c7fb39aaa3	Best Buy	best-buy	https://www.bestbuy.com	official	{"api_key": "placeholder", "base_url": "https://api.bestbuy.com/v1"}	t	60	95	\N	["cart_links", "inventory_check", "price_tracking"]	2025-09-03 16:53:58.102669+00	2025-09-03 16:53:58.102669+00
e99e80ff-9412-47d3-b965-1d864a148a0b	Walmart	walmart	https://www.walmart.com	affiliate	{"api_key": "placeholder", "affiliate_id": "placeholder"}	t	100	90	\N	["affiliate_links", "price_tracking"]	2025-09-03 16:53:58.102669+00	2025-09-03 16:53:58.102669+00
5be78519-dba9-4be6-a909-2fa6c802d38e	Costco	costco	https://www.costco.com	scraping	{"base_url": "https://www.costco.com", "user_agent": "BoosterBeacon/1.0"}	t	30	85	\N	["price_tracking"]	2025-09-03 16:53:58.102669+00	2025-09-03 16:53:58.102669+00
ed369918-9011-441a-8f69-30847fe469f4	Sam's Club	sams-club	https://www.samsclub.com	scraping	{"base_url": "https://www.samsclub.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 16:53:58.102669+00	2025-09-03 16:53:58.102669+00
b7b3c125-fa4e-40ec-813a-db76c0430127	GameStop	gamestop	https://www.gamestop.com	scraping	{"base_url": "https://www.gamestop.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 16:53:58.102669+00	2025-09-03 16:53:58.102669+00
4e909cc9-547a-4540-ad93-2a8aec9a91f3	Target	target	https://www.target.com	scraping	{"base_url": "https://www.target.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 16:53:58.102669+00	2025-09-03 16:53:58.102669+00
\.


--
-- TOC entry 4328 (class 0 OID 17363)
-- Dependencies: 258
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, slug, description, permissions, is_system_role, categories, level, is_active, created_by, created_at, updated_at) FROM stdin;
9425e23e-c63c-434e-a688-0e786cd19608	Super Administrator	super_admin	Full system access with all permissions	[]	t	["user_management","system_administration","ml_operations","analytics","content_management","security","billing","monitoring"]	100	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6fc7d6b5-cde0-4c33-9206-d20f107f1906	Administrator	admin	Administrative access with most permissions	[]	t	["user_management","system_administration","analytics","content_management","security","monitoring"]	80	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
96520317-38af-41b0-b46e-3890d4d99f25	User Manager	user_manager	Manage users and basic administrative tasks	[]	t	["user_management","analytics"]	60	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
8c185a4e-5962-4d59-af7f-56b68fda06df	Content Manager	content_manager	Manage products, retailers, and content	[]	t	["content_management","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6814f358-63ad-4530-a185-9c5cd7dbf0c2	ML Engineer	ml_engineer	Manage machine learning models and data	[]	t	["ml_operations","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
7dff1611-3ec6-4d08-bc90-2d5db769de78	Analyst	analyst	View and analyze system data and metrics	[]	t	["analytics"]	40	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
58b9d7f9-b295-4b7a-8abc-9e650d4586b2	Support Agent	support_agent	Provide customer support and basic user management	[]	t	["user_management"]	30	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
cf9919c8-4c2f-4768-8c0c-3bc770a34e5b	Billing Manager	billing_manager	Manage billing, subscriptions, and financial data	[]	t	["billing","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
4c762ab2-3f74-43ec-906b-bfdb46b58b21	Security Officer	security_officer	Manage security, audit logs, and compliance	[]	t	["security","monitoring"]	70	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
2d0c24b1-6468-4cd9-833e-fc310409aea1	User	user	Standard user with no administrative permissions	[]	t	[]	0	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
\.


--
-- TOC entry 4313 (class 0 OID 17017)
-- Dependencies: 243
-- Data for Name: seasonal_patterns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasonal_patterns (id, product_id, category_id, pattern_type, pattern_name, avg_price_change, availability_change, demand_multiplier, historical_occurrences, confidence, last_updated) FROM stdin;
\.


--
-- TOC entry 4322 (class 0 OID 17215)
-- Dependencies: 252
-- Data for Name: social_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_shares (id, user_id, alert_id, platform, share_type, metadata, shared_at) FROM stdin;
\.


--
-- TOC entry 4331 (class 0 OID 17455)
-- Dependencies: 261
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, slug, description, price, billing_period, stripe_price_id, features, limits, is_active, trial_days, created_at, updated_at) FROM stdin;
42837560-04ff-489d-80a5-e3239ec373c5	Free	free	Basic alerts for casual collectors	0.00	monthly	\N	["Up to 2 product watches", "Basic email alerts", "Web push notifications", "Community support"]	{"max_watches": 2, "api_rate_limit": 1000, "max_alerts_per_day": 50}	t	0	2025-09-03 16:53:58.157967+00	2025-09-03 16:53:58.157967+00
e18d5a5a-29c9-49f1-9336-4878d1c9b59d	Pro	pro-monthly	Advanced features with limited auto-purchase and ML insights	40.00	monthly	price_your_pro_monthly_price_id	["Up to 10 product watches", "Higher alert priority", "SMS & Discord notifications", "Auto-purchase (limited capacity)", "ML insights (limited: basic price trend + risk)", "Extended price history (12 months)", "Advanced filtering", "Browser extension access"]	{"max_watches": 10, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-09-03 16:53:58.157967+00	2025-09-03 16:53:58.157967+00
03ad3916-a1ca-4e6e-bf3c-e1d4acd5a9f5	Premium	premium-monthly	Full auto-purchase, full ML, and highest queue priority	100.00	monthly	price_your_premium_monthly_price_id	["Unlimited product watches", "Fastest alert delivery and queue priority", "SMS & Discord notifications", "Auto-purchase (full capacity & priority)", "Full ML: price predictions, sellout risk, ROI", "Full price history access", "Advanced filtering", "Browser extension access", "Premium support", "One-time $300 setup fee"]	{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-09-03 16:53:58.157967+00	2025-09-03 16:53:58.157967+00
\.


--
-- TOC entry 4302 (class 0 OID 16814)
-- Dependencies: 232
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, service_name, status, metrics, message, checked_at) FROM stdin;
1980b98b-f183-45aa-ae57-8b4025e3e0d7	api_server	healthy	{"error_rate": 0.02, "response_time": 45, "uptime_percentage": 99.8}	\N	2025-09-03 16:53:58.37726+00
d19c69f7-49b0-40da-bead-8047cd9d2350	database	healthy	{"query_time": 12, "connection_pool": 8, "uptime_percentage": 99.9}	\N	2025-09-03 16:53:58.37726+00
b541cf95-9c8a-4394-8df5-b5d30cbb0958	retailer_monitoring	healthy	{"success_rate": 98.5, "avg_check_time": 2.3, "active_monitors": 4}	\N	2025-09-03 16:53:58.37726+00
\.


--
-- TOC entry 4318 (class 0 OID 17133)
-- Dependencies: 248
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_metrics (id, metric_name, metric_type, value, labels, recorded_at) FROM stdin;
3c802948-0f8e-492d-88c0-dff25cdf27e4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:36.212+00
1695bdb1-2765-4c19-a26e-084c4d42b365	uptime	gauge	309.459464	{}	2025-09-03 16:36:36.212+00
0d1258c5-8d93-468e-a339-4b355ed35026	memory_usage	gauge	75.570000	{}	2025-09-03 16:36:36.212+00
9a2765b6-8abb-4553-84e9-8869a040d12b	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:36.212+00
4e3a89f2-6edb-4eed-a9ad-e7cadac60073	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:58.34+00
d2c8d491-5e7f-48fc-922f-0ee7ca343eb7	uptime	gauge	248.100242	{}	2025-09-03 16:36:58.341+00
4de06082-95a8-4707-9774-4ee6b4bf76fd	memory_usage	gauge	75.680000	{}	2025-09-03 16:36:58.34+00
efe07c33-9f0c-405b-9cd3-a904a9d646fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:58.341+00
31fe1c93-cb08-4c5f-9d97-5d675f8a84af	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:36.212+00
65f93504-e136-41de-b03c-b19121f38d51	memory_usage	gauge	75.830000	{}	2025-09-03 16:37:36.212+00
b0af6be9-90c2-43f0-b255-6ef5f650c0de	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:36.212+00
8d116f32-15ae-4daf-847f-b4d379c6ba64	uptime	gauge	369.458978	{}	2025-09-03 16:37:36.212+00
0f03de57-b8e4-400e-a640-1501056f4f1b	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:58.346+00
4605f34f-cf0b-44ed-b844-bc8e987d994f	memory_usage	gauge	75.730000	{}	2025-09-03 16:37:58.346+00
19f45d60-ddb5-4ed0-9807-26a7668c7571	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:58.346+00
733ca3c5-1cfc-4bc9-bf30-dd81e206c078	uptime	gauge	308.106181	{}	2025-09-03 16:37:58.346+00
958dd4cc-7532-44e4-ba8d-838bd699454b	memory_usage	gauge	75.930000	{}	2025-09-03 16:38:36.213+00
738e7053-9eb8-491b-b6a2-1535a9e381cd	cpu_usage	gauge	6.000000	{}	2025-09-03 16:38:36.213+00
5a32f3df-c841-456b-a22d-0c72a9bec3e4	disk_usage	gauge	45.200000	{}	2025-09-03 16:38:36.213+00
3f609f44-0d80-45fb-81f7-d4f7f2485ce7	uptime	gauge	429.459813	{}	2025-09-03 16:38:36.213+00
629e4293-0840-4cec-8c5e-79d45cc5adb7	memory_usage	gauge	75.930000	{}	2025-09-03 16:38:58.346+00
4df21ba8-6dd4-49dd-a86c-f3c81dd84201	cpu_usage	gauge	6.000000	{}	2025-09-03 16:38:58.346+00
12aa3cc5-432f-4469-a8a0-31e38175a772	disk_usage	gauge	45.200000	{}	2025-09-03 16:38:58.346+00
b0ed47cc-8c9f-45c8-a501-98293f4638f3	uptime	gauge	368.105434	{}	2025-09-03 16:38:58.346+00
71d54afb-aac6-4432-8cd0-71b9c4982fb1	cpu_usage	gauge	6.000000	{}	2025-09-03 16:39:36.213+00
ae2d401b-1291-4057-aa2b-3a67f13fb897	memory_usage	gauge	75.900000	{}	2025-09-03 16:39:36.213+00
13c332bc-38e6-4e89-819e-04020f0e47c5	disk_usage	gauge	45.200000	{}	2025-09-03 16:39:36.213+00
b65a6867-ae3b-49e8-9390-b270da074d94	uptime	gauge	489.460450	{}	2025-09-03 16:39:36.213+00
52842366-5165-4db4-ad63-b1a94130c9fc	cpu_usage	gauge	6.000000	{}	2025-09-03 16:39:58.346+00
02c0af50-cfee-413e-a1fe-bc06ee7e1340	memory_usage	gauge	75.830000	{}	2025-09-03 16:39:58.346+00
47d5cbd7-c46d-4fa5-82da-c8b24ea758a8	disk_usage	gauge	45.200000	{}	2025-09-03 16:39:58.346+00
16e09ad7-92b4-460d-bafe-9da2e98615a0	uptime	gauge	428.105690	{}	2025-09-03 16:39:58.346+00
5e16855a-b10b-4afc-809d-15877c8ffaaf	cpu_usage	gauge	6.000000	{}	2025-09-03 16:40:36.213+00
bfc21ada-d92e-4ef9-af68-a06a7fa569d6	memory_usage	gauge	75.990000	{}	2025-09-03 16:40:36.213+00
b93f937c-72e6-4ec2-8fc2-c5bfec91ae32	disk_usage	gauge	45.200000	{}	2025-09-03 16:40:36.213+00
d1dd662c-78a9-4d84-af8e-cc17c7b140f2	uptime	gauge	549.460244	{}	2025-09-03 16:40:36.213+00
7badb281-dae4-49e2-955d-ef3c67f158f1	cpu_usage	gauge	6.000000	{}	2025-09-03 16:40:58.346+00
2df7574f-ce2f-4ea7-931b-8056f102f90e	memory_usage	gauge	76.020000	{}	2025-09-03 16:40:58.346+00
94674ee2-bfcb-42bb-b3b0-828a8ec51737	disk_usage	gauge	45.200000	{}	2025-09-03 16:40:58.346+00
870d6935-e945-4049-989d-5b636d9b2d74	uptime	gauge	488.105702	{}	2025-09-03 16:40:58.346+00
44735896-2136-437b-bf84-411ddd6d46d3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:41:36.213+00
a3ac4b27-dada-4bd7-b96f-a13d79d532dc	memory_usage	gauge	75.880000	{}	2025-09-03 16:41:36.213+00
17aeab3b-688f-4154-9c21-6e04d2959ec3	disk_usage	gauge	45.200000	{}	2025-09-03 16:41:36.213+00
817d2778-a9b1-4b9b-9870-8ca825a8fb62	uptime	gauge	609.460277	{}	2025-09-03 16:41:36.213+00
4038caa6-ca99-4948-8017-dd6ae2f543b9	cpu_usage	gauge	6.000000	{}	2025-09-03 16:41:58.346+00
02810cab-8f02-4a7d-a786-d729238f29df	memory_usage	gauge	75.910000	{}	2025-09-03 16:41:58.347+00
e84ac495-6a7c-43b2-860e-7cdc8379178d	disk_usage	gauge	45.200000	{}	2025-09-03 16:41:58.347+00
1b637501-a490-46ad-90da-e754be0f073c	uptime	gauge	548.106349	{}	2025-09-03 16:41:58.347+00
dd6b7556-51c4-48d8-98e2-8a71f68db110	cpu_usage	gauge	6.000000	{}	2025-09-03 16:42:36.213+00
4391b6c3-769a-4c2e-9d49-9fac9464ed21	memory_usage	gauge	75.910000	{}	2025-09-03 16:42:36.213+00
21b3f84e-8814-4e4f-a2d2-c62d1eef7db0	disk_usage	gauge	45.200000	{}	2025-09-03 16:42:36.213+00
7329560b-4969-4bf3-975e-8b0ea63c3a95	uptime	gauge	669.459834	{}	2025-09-03 16:42:36.213+00
1856b91f-77f7-439f-bdfb-cad6c82778aa	cpu_usage	gauge	6.000000	{}	2025-09-03 16:42:58.347+00
42fac545-50c7-4494-9212-52c57bbcffe7	memory_usage	gauge	75.820000	{}	2025-09-03 16:42:58.347+00
0b5b211a-1beb-4f85-9446-a7b9ddbd51a6	disk_usage	gauge	45.200000	{}	2025-09-03 16:42:58.347+00
72b4e205-7f2b-4753-9e75-34da9755cbbc	uptime	gauge	608.106409	{}	2025-09-03 16:42:58.347+00
395d88e8-bf58-44bb-bbc0-343919cfcd53	memory_usage	gauge	75.880000	{}	2025-09-03 16:43:36.213+00
796d50e7-9a0f-4677-b6ab-cacf2b1fc3ae	disk_usage	gauge	45.200000	{}	2025-09-03 16:43:36.214+00
fd7a9466-6660-46fa-8228-4c35986f5f1b	uptime	gauge	729.460647	{}	2025-09-03 16:43:36.214+00
b9ebe36f-8f5a-4ccb-819d-172c839bdd23	cpu_usage	gauge	6.000000	{}	2025-09-03 16:43:36.213+00
84d7944e-c9c9-48b2-8511-5232c7b13bd4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:43:58.347+00
b22138ba-261c-46a8-a771-7622db63083e	memory_usage	gauge	75.810000	{}	2025-09-03 16:43:58.347+00
d2ee125c-534b-4090-9a1b-d59c62af5be4	disk_usage	gauge	45.200000	{}	2025-09-03 16:43:58.347+00
b35f23a8-9e5c-43b5-9e1b-15148ae5d822	uptime	gauge	668.107077	{}	2025-09-03 16:43:58.347+00
29b31041-a25a-4f93-a0db-2e410bd0af3a	cpu_usage	gauge	6.000000	{}	2025-09-03 16:44:36.213+00
f147b249-208b-4b70-9698-eb928b5a3959	memory_usage	gauge	76.420000	{}	2025-09-03 16:44:36.213+00
ac034995-408a-43f7-a2de-360e97bc1f54	disk_usage	gauge	45.200000	{}	2025-09-03 16:44:36.213+00
911970f2-e565-4605-8944-6bb280464432	uptime	gauge	789.460514	{}	2025-09-03 16:44:36.213+00
d4efed9c-0fca-4a01-bea4-e5798bb20fce	cpu_usage	gauge	6.000000	{}	2025-09-03 16:44:58.347+00
8948a660-8d0f-418d-9fd3-99564d799fcc	memory_usage	gauge	76.340000	{}	2025-09-03 16:44:58.347+00
f71e7e15-8ea2-4972-9048-ff53638c7c73	disk_usage	gauge	45.200000	{}	2025-09-03 16:44:58.348+00
dd6ced7e-cafc-4022-94bd-3a4515aecf3d	uptime	gauge	728.107637	{}	2025-09-03 16:44:58.348+00
8202453b-2d7b-4785-b8dd-1dab0cb72740	cpu_usage	gauge	6.000000	{}	2025-09-03 16:45:36.213+00
6904bba2-bde0-41c3-b463-062551afb48e	memory_usage	gauge	76.750000	{}	2025-09-03 16:45:36.214+00
4791b2b1-1709-4832-93ff-5410e43236c6	disk_usage	gauge	45.200000	{}	2025-09-03 16:45:36.214+00
c6cb4161-8ad5-4d12-8906-ec5a15bcccbe	uptime	gauge	849.460687	{}	2025-09-03 16:45:36.214+00
ba1fc3b6-1977-4b52-b9a4-d128fbf82f24	cpu_usage	gauge	6.000000	{}	2025-09-03 16:45:58.348+00
246b0eba-4de4-4288-bbf2-2362cf4f0755	memory_usage	gauge	76.770000	{}	2025-09-03 16:45:58.348+00
5806108c-f82d-4c73-bcf7-f7e124dbc6bb	disk_usage	gauge	45.200000	{}	2025-09-03 16:45:58.348+00
2a12fb66-40f5-4906-8101-8ab0c709a108	uptime	gauge	788.107618	{}	2025-09-03 16:45:58.348+00
461c6d90-136b-4671-a6f5-b51f36d960a3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:46:36.213+00
6de51c31-0838-44fd-bfdb-28fd6da88786	memory_usage	gauge	76.910000	{}	2025-09-03 16:46:36.214+00
fa9bd97d-8f76-4f6e-8114-53b782254989	disk_usage	gauge	45.200000	{}	2025-09-03 16:46:36.214+00
4d0b1ece-6414-4ec9-9cae-afe51b4a6c98	uptime	gauge	909.460662	{}	2025-09-03 16:46:36.214+00
9567752d-07f4-4187-8d28-693de7089523	cpu_usage	gauge	6.000000	{}	2025-09-03 16:46:58.349+00
e7cbfe09-784e-4722-8cad-98359f589fd3	memory_usage	gauge	76.460000	{}	2025-09-03 16:46:58.349+00
978e6634-96d8-4b8e-b945-c613587ab0b4	disk_usage	gauge	45.200000	{}	2025-09-03 16:46:58.349+00
41f4f5ce-6cb4-4b4d-99d2-69e17078e6d0	uptime	gauge	848.109197	{}	2025-09-03 16:46:58.349+00
f53cfbfb-fef5-428f-b50e-cb4d623c5a28	cpu_usage	gauge	6.000000	{}	2025-09-03 16:47:36.214+00
d815f760-115e-4ee4-a8a8-af9da4689875	memory_usage	gauge	76.440000	{}	2025-09-03 16:47:36.214+00
98ebeb56-883d-4e3d-ac52-6d892d2c500a	disk_usage	gauge	45.200000	{}	2025-09-03 16:47:36.214+00
df8c3123-2107-40bf-a47c-22c0464cea5d	uptime	gauge	969.461411	{}	2025-09-03 16:47:36.214+00
35ba4a98-3e2d-4859-9c92-e9a8a38efa94	cpu_usage	gauge	6.000000	{}	2025-09-03 16:47:58.35+00
0924aa26-7132-4ed5-ad06-5f9f40d321f5	memory_usage	gauge	76.460000	{}	2025-09-03 16:47:58.35+00
07069f3e-b973-4ab7-adb6-5519a0a5cbd3	disk_usage	gauge	45.200000	{}	2025-09-03 16:47:58.35+00
d5caac0f-f079-4b79-8ed4-54264ec1cc93	uptime	gauge	908.109400	{}	2025-09-03 16:47:58.35+00
90ef54f5-0826-4a8f-88f9-4258454b64ec	cpu_usage	gauge	6.000000	{}	2025-09-03 16:48:36.215+00
d97f9450-a425-4e38-b7d3-fcc68a953625	disk_usage	gauge	45.200000	{}	2025-09-03 16:48:36.215+00
44678f0b-2356-4d5b-bcbc-556f09e5bca4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:49:36.215+00
b15578a9-8163-445d-b130-0a0c47ac902d	uptime	gauge	1029.461810	{}	2025-09-03 16:48:36.215+00
cb56c4d0-2cf1-4324-8130-5902f5b7c7ca	disk_usage	gauge	45.200000	{}	2025-09-03 16:49:36.215+00
df1d8c40-4523-4497-ae6c-063e714d1e1e	memory_usage	gauge	76.390000	{}	2025-09-03 16:48:58.35+00
5fba1d39-3646-4dc2-a6bc-c3965b1e422f	uptime	gauge	1028.112035	{}	2025-09-03 16:49:58.352+00
93452c38-6d2e-4eb1-96c6-c16f02ffaf97	cpu_usage	gauge	6.000000	{}	2025-09-03 16:48:58.35+00
d0f3533d-a10c-4251-aa94-371a5f43313c	cpu_usage	gauge	6.000000	{}	2025-09-03 16:49:58.352+00
ae03ce59-9cfd-4156-b98f-f8eab42fb501	disk_usage	gauge	45.200000	{}	2025-09-03 16:48:58.35+00
38dde6f2-ce08-4e2e-aecf-d168642a33fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:49:58.352+00
7636af42-9b87-4ba6-bd1b-2b370cbeb310	uptime	gauge	968.110089	{}	2025-09-03 16:48:58.35+00
1a66b0ac-854e-401b-8d46-7d4d0f116d38	memory_usage	gauge	76.500000	{}	2025-09-03 16:49:58.352+00
fc53b25d-4ece-4f30-9c29-abe646c8db60	uptime	gauge	1089.462308	{}	2025-09-03 16:49:36.215+00
85254410-25a7-4fd6-ab62-f79ed59ddf34	memory_usage	gauge	76.890000	{}	2025-09-03 16:50:36.215+00
88939c22-aaa8-4a6a-8ea3-3e25c5b1722f	uptime	gauge	1209.461963	{}	2025-09-03 16:51:36.215+00
a5b2626f-92ae-4086-8a73-1c1d051c350d	memory_usage	gauge	76.490000	{}	2025-09-03 16:52:36.215+00
f5732cd5-1ae0-49c7-9d21-71e7c67a7705	memory_usage	gauge	76.390000	{}	2025-09-03 16:53:36.216+00
8e92afaa-5774-461a-b0f9-b0cfa3ba738a	memory_usage	gauge	76.400000	{}	2025-09-03 16:54:36.216+00
1ef2969e-b51f-4677-9f7a-f09479accb9f	memory_usage	gauge	77.340000	{}	2025-09-03 16:55:36.217+00
9ea5703c-811b-4687-861c-7d852eb2310f	memory_usage	gauge	77.550000	{}	2025-09-03 16:56:36.217+00
aaf04adb-ea06-4a89-b227-187bb57bb3f2	cpu_usage	gauge	6.000000	{}	2025-09-03 16:57:36.217+00
c583016d-c1c3-42eb-bfeb-6a806b1b00d0	disk_usage	gauge	45.200000	{}	2025-09-03 16:50:36.215+00
25f41f13-2bea-40e9-827f-d05b2bb7d752	memory_usage	gauge	76.830000	{}	2025-09-03 16:51:36.215+00
c0c54375-df58-4fdc-94f0-04f88e23f92a	uptime	gauge	1269.462529	{}	2025-09-03 16:52:36.215+00
6958620c-4a77-4fd8-97b4-6482400dfb89	disk_usage	gauge	45.200000	{}	2025-09-03 16:53:36.216+00
47fbbd27-43fa-4f04-a934-884e230e892a	cpu_usage	gauge	6.000000	{}	2025-09-03 16:54:36.216+00
bab548c8-3025-4574-8659-1bbff5e377d7	uptime	gauge	1449.463962	{}	2025-09-03 16:55:36.217+00
9dce3151-544f-4020-ac28-a279a607a486	cpu_usage	gauge	6.000000	{}	2025-09-03 16:56:36.217+00
5a969cb1-206e-4251-b82d-6a6a9f0dffcf	uptime	gauge	1569.463926	{}	2025-09-03 16:57:36.217+00
1618c1d2-2938-4e08-81a5-75f0ae3bbdaa	cpu_usage	gauge	6.000000	{}	2025-09-03 16:50:36.215+00
c768e98c-9aaa-4052-b77c-6483ef4fc628	cpu_usage	gauge	6.000000	{}	2025-09-03 16:51:36.215+00
c0d9e31f-366a-453a-bee2-ea27ece5c16c	disk_usage	gauge	45.200000	{}	2025-09-03 16:52:36.215+00
87b60b73-fcd7-4807-9a3a-9a20688c0876	cpu_usage	gauge	6.000000	{}	2025-09-03 16:53:36.216+00
4e0b7007-57a7-4c14-ae4f-b26e34bfd25a	uptime	gauge	1389.463555	{}	2025-09-03 16:54:36.216+00
9524cd9f-0a77-49d1-a18f-df6cae49511f	disk_usage	gauge	45.200000	{}	2025-09-03 16:55:36.217+00
94679b9b-c52c-416f-9ad2-877a6b55d995	disk_usage	gauge	45.200000	{}	2025-09-03 16:56:36.217+00
9af066df-8321-46bf-9a12-08e38df63fd6	memory_usage	gauge	77.620000	{}	2025-09-03 16:57:36.217+00
f6e014d5-7fd5-4806-aa3d-792eea380086	uptime	gauge	1149.462075	{}	2025-09-03 16:50:36.215+00
a84c2895-11c7-472d-ba73-b4c532d2aeda	disk_usage	gauge	45.200000	{}	2025-09-03 16:51:36.215+00
7ccb0354-b4c3-4427-9a26-0a85e70753b7	cpu_usage	gauge	6.000000	{}	2025-09-03 16:52:36.215+00
99fd1d87-b7af-4604-802d-23c61189a6cf	uptime	gauge	1329.463145	{}	2025-09-03 16:53:36.216+00
0d4fe496-8d6d-481d-9cb5-77af0b227b88	disk_usage	gauge	45.200000	{}	2025-09-03 16:54:36.216+00
af14e1d7-d5e4-4a09-8ffc-b9d26d88a61d	cpu_usage	gauge	6.000000	{}	2025-09-03 16:55:36.217+00
d55b816e-541a-46c7-af33-2c9f7176481c	uptime	gauge	1509.463941	{}	2025-09-03 16:56:36.217+00
66f772f5-4ae4-43a7-aa1f-226538e40f59	disk_usage	gauge	45.200000	{}	2025-09-03 16:57:36.217+00
dc2cd04a-852c-4984-956b-39993ed2e6a9	memory_usage	gauge	76.910000	{}	2025-09-03 16:50:58.352+00
7c9e0c03-9af5-4754-bfc5-732216a618b1	uptime	gauge	1148.113165	{}	2025-09-03 16:51:58.353+00
e14bbee6-5894-49c7-b77c-10e862f5dc30	memory_usage	gauge	76.510000	{}	2025-09-03 16:52:58.354+00
e99bbe07-bb25-4f7e-a96d-96a886510c43	uptime	gauge	1268.113535	{}	2025-09-03 16:53:58.354+00
34024502-6841-4696-be4a-d9152356073d	memory_usage	gauge	76.370000	{}	2025-09-03 16:54:58.354+00
35ddd4af-b6b5-4c24-bc70-07b145fb9525	uptime	gauge	1388.114307	{}	2025-09-03 16:55:58.355+00
738ff6ac-17b4-423f-b18a-c1ab93396dbd	disk_usage	gauge	45.200000	{}	2025-09-03 16:56:58.355+00
6b8e51b9-c72a-42d6-aa3c-fdfe2a093eac	uptime	gauge	1508.115367	{}	2025-09-03 16:57:58.356+00
91cc7563-40bc-4ed3-a0ad-72cfcd324084	uptime	gauge	1088.112187	{}	2025-09-03 16:50:58.352+00
ad4ca451-4298-471d-82e7-be176b75d0a4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:51:58.353+00
e9379543-6c19-4e2b-bf8f-10e806de848b	disk_usage	gauge	45.200000	{}	2025-09-03 16:52:58.354+00
cd61ce44-004a-4be7-aa6e-7a697f77bf47	disk_usage	gauge	45.200000	{}	2025-09-03 16:53:58.354+00
10617a79-e2a3-48b7-b798-02c3aa343483	cpu_usage	gauge	6.000000	{}	2025-09-03 16:54:58.354+00
5c4dbafc-9872-4fb2-a9b8-9222baf77c71	disk_usage	gauge	45.200000	{}	2025-09-03 16:55:58.355+00
5cc5b36f-b160-4d57-9538-1aacb0d63207	cpu_usage	gauge	6.000000	{}	2025-09-03 16:56:58.355+00
1fd04c1f-6c63-4b7e-84ba-53fd3c1a424d	disk_usage	gauge	45.200000	{}	2025-09-03 16:57:58.356+00
7a94d813-5996-4d91-a62e-aa5573b74951	cpu_usage	gauge	6.000000	{}	2025-09-03 16:50:58.352+00
5623e58e-0559-4a44-9fca-ff2138d060a0	disk_usage	gauge	45.200000	{}	2025-09-03 16:51:58.353+00
c30fe19d-4b51-44a1-aa73-85ec8b8851c8	cpu_usage	gauge	6.000000	{}	2025-09-03 16:52:58.354+00
b345020d-42d0-4043-b17b-7e19ce9019d5	memory_usage	gauge	76.840000	{}	2025-09-03 16:53:58.354+00
d8b9c807-9254-4806-b8ff-8e2da1f9433c	disk_usage	gauge	45.200000	{}	2025-09-03 16:54:58.354+00
a8d91430-c233-470d-a60f-94fd99383671	memory_usage	gauge	77.750000	{}	2025-09-03 16:55:58.355+00
ed71f53b-e8db-4594-a221-97862189597c	memory_usage	gauge	77.660000	{}	2025-09-03 16:56:58.355+00
4e03288c-cfd4-49b9-a175-b39393efefec	memory_usage	gauge	77.410000	{}	2025-09-03 16:57:58.356+00
57a94809-32c6-42d3-a322-ae81e16973a6	disk_usage	gauge	45.200000	{}	2025-09-03 16:50:58.352+00
2bf194e7-76cd-46fc-a691-498931d6d6d3	memory_usage	gauge	76.510000	{}	2025-09-03 16:51:58.353+00
50a4c9e5-7af4-4249-b1c4-0e10bc4ba707	uptime	gauge	1208.113528	{}	2025-09-03 16:52:58.354+00
9b09020c-c369-4ecd-aa69-60f9f67a7f77	cpu_usage	gauge	6.000000	{}	2025-09-03 16:53:58.354+00
77f2a215-bcdc-46d0-b4c9-a115788e72f0	uptime	gauge	1328.114132	{}	2025-09-03 16:54:58.354+00
8a5b5b54-db6b-4a81-b3e8-2eec3f18c9c3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:55:58.354+00
ae4c1a07-7b87-43ac-aed0-2e8e9c01af12	uptime	gauge	1448.114582	{}	2025-09-03 16:56:58.355+00
90e1245b-8dda-4c99-87b6-46f3fc0b46c2	cpu_usage	gauge	6.000000	{}	2025-09-03 16:57:58.356+00
ed01d5ab-a889-41b6-94f1-41970b068823	cpu_usage	gauge	6.000000	{}	2025-09-03 16:58:36.218+00
2875c1da-aa02-49fc-81b0-e041cb12b878	uptime	gauge	1689.466714	{}	2025-09-03 16:59:36.22+00
1d230758-7692-4039-ae50-b1ea5a269269	cpu_usage	gauge	6.000000	{}	2025-09-03 17:00:36.219+00
8109c091-71a4-457e-8559-4819c73bdb14	uptime	gauge	1809.465741	{}	2025-09-03 17:01:36.219+00
f53f34be-6bc6-4ecb-b862-7bce2f975874	disk_usage	gauge	45.200000	{}	2025-09-03 17:02:36.219+00
91d1845a-5fe5-4b5d-bfee-87d9267b3cdc	memory_usage	gauge	77.130000	{}	2025-09-03 17:03:36.22+00
e613a6a4-7482-4074-833c-7020d7dc067c	memory_usage	gauge	76.730000	{}	2025-09-03 17:04:36.22+00
71cd9b27-3d96-4018-a5f5-a156ae03fb86	cpu_usage	gauge	6.000000	{}	2025-09-03 17:05:36.221+00
d25d4831-5e09-4169-b488-746399a097f7	uptime	gauge	2109.467788	{}	2025-09-03 17:06:36.221+00
3371205f-c7b5-4d6c-b1e3-d79c1695d750	cpu_usage	gauge	6.000000	{}	2025-09-03 17:49:13.549+00
45f56c25-749c-4c3d-91ec-5c0822f51f62	memory_usage	gauge	74.380000	{}	2025-09-03 17:49:13.549+00
eefea8a0-a3e6-4725-8eb0-164000123a83	disk_usage	gauge	45.200000	{}	2025-09-03 17:49:13.549+00
1700a00c-3d54-42ce-b8ce-9ff3bcb1e395	uptime	gauge	69.351909	{}	2025-09-03 17:49:13.549+00
05bed622-ca87-486a-8ce3-d8920ba57c8c	uptime	gauge	129.352361	{}	2025-09-03 17:50:13.55+00
2ed66c06-c2d1-40f0-a757-a976ef764c06	uptime	gauge	189.353844	{}	2025-09-03 17:51:13.551+00
d8af877f-dd9b-4a60-9654-16495a995c44	disk_usage	gauge	45.200000	{}	2025-09-03 17:52:13.55+00
37648ab8-e0cb-4f9d-8928-649b70e9806f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:53:13.555+00
adc6e688-a32b-45a7-ae8b-cbb7687d037b	cpu_usage	gauge	6.000000	{}	2025-09-03 18:25:38.088+00
91704d68-4297-45b3-be58-e6d6646f1027	memory_usage	gauge	69.490000	{}	2025-09-03 18:25:38.089+00
9c63ec59-9bed-4261-a54d-c3253eb117b7	disk_usage	gauge	45.200000	{}	2025-09-03 18:25:38.089+00
8e1dc14b-d12f-4f03-a4bc-dc1c51fd730e	uptime	gauge	69.232184	{}	2025-09-03 18:25:38.089+00
b0a363d2-b265-46df-868b-a4ed489d7358	uptime	gauge	129.231973	{}	2025-09-03 18:26:38.088+00
50e31809-7d08-4931-aa19-18745ca09d2d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:27:38.089+00
63f0832c-730a-4c0b-80f6-d125dda49223	uptime	gauge	249.234122	{}	2025-09-03 18:28:38.091+00
52621e95-2cfc-4d17-85fc-43a843773565	cpu_usage	gauge	6.000000	{}	2025-09-03 18:29:38.096+00
e3f55673-1768-4898-adc5-38717a4c8bd7	uptime	gauge	369.239983	{}	2025-09-03 18:30:38.096+00
9c0cad8c-5136-49e6-872c-9847e5c4a24f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:34:38.098+00
0b7b76b9-23ca-461d-9d2d-22e786f5e95a	memory_usage	gauge	64.770000	{}	2025-09-03 18:34:38.098+00
44a79de9-55e6-4b1d-9cd0-521a44a5ef44	disk_usage	gauge	45.200000	{}	2025-09-03 18:34:38.098+00
4f5a04bc-6db1-4bf0-a62d-3fd62ec86fa4	uptime	gauge	609.241256	{}	2025-09-03 18:34:38.098+00
228492a9-36c6-4b3e-8019-c5215cebcf93	uptime	gauge	669.243544	{}	2025-09-03 18:35:38.1+00
4abca9a5-b301-41f8-8cdb-a4b99554ddc6	cpu_usage	gauge	6.000000	{}	2025-09-03 18:46:36.591+00
dbf8a728-a41b-475e-a9c2-8fe296f98fab	memory_usage	gauge	69.510000	{}	2025-09-03 18:46:36.591+00
fed8bfdd-4d42-4b15-b5b4-49043d47966b	disk_usage	gauge	45.200000	{}	2025-09-03 18:46:36.591+00
32cd1a40-1a36-4b5d-aac0-a14a0f12d001	uptime	gauge	68.948844	{}	2025-09-03 18:46:36.591+00
19624da4-9cb5-40ef-ba5a-5e0446786399	cpu_usage	gauge	6.000000	{}	2025-09-03 18:49:04.666+00
c097a3bd-3c6f-4c87-a5dd-f3e613772222	memory_usage	gauge	64.330000	{}	2025-09-03 18:49:04.666+00
a8913fe1-69c0-41eb-8802-b19dacd67c29	disk_usage	gauge	45.200000	{}	2025-09-03 18:49:04.666+00
4e567f05-9134-463b-879b-2c3f3c160e43	uptime	gauge	69.196963	{}	2025-09-03 18:49:04.667+00
39c5c6fa-6011-4157-8068-dffc260e092a	uptime	gauge	129.196145	{}	2025-09-03 18:50:04.666+00
8616dd93-0945-4ee0-8296-18a7d1b8b123	uptime	gauge	189.195945	{}	2025-09-03 18:51:04.665+00
b37fdd36-e97a-41f5-a63a-527a61980b11	disk_usage	gauge	45.200000	{}	2025-09-03 18:52:04.667+00
a0673e67-9c5a-4b61-a53d-9efbf1af7c23	cpu_usage	gauge	6.000000	{}	2025-09-03 18:53:04.667+00
162a8336-ba7e-4b6c-998a-f8a9ba17bf6b	disk_usage	gauge	45.200000	{}	2025-09-03 16:58:36.218+00
12a4a02e-da43-46f9-aa27-fa7872c6ab19	disk_usage	gauge	45.200000	{}	2025-09-03 16:59:36.22+00
baea5735-735e-43e1-8e6f-8468b8a710d9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:49:27.515+00
f399410a-2ee3-4477-80db-66e59c228057	memory_usage	gauge	74.350000	{}	2025-09-03 17:49:27.515+00
40985f3f-1879-4a96-8216-355e9fce3e39	disk_usage	gauge	45.200000	{}	2025-09-03 17:49:27.515+00
b409d95f-4967-45ff-8758-402d95ca6ac4	memory_usage	gauge	74.980000	{}	2025-09-03 17:50:27.515+00
551762e7-85a6-4a67-898b-2892c3013b99	cpu_usage	gauge	6.000000	{}	2025-09-03 17:51:27.516+00
a6a84e9e-af5b-4ca4-9bee-87416df919c5	uptime	gauge	248.008572	{}	2025-09-03 17:52:27.517+00
ac7d293f-d2ed-442f-b602-e2edd9b02090	cpu_usage	gauge	6.000000	{}	2025-09-03 17:53:27.524+00
805d2158-6f59-4674-ad28-8cb6be55f15f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:26:38.088+00
0cd936e6-f756-4f7a-b48a-63f386ef78d4	uptime	gauge	189.232937	{}	2025-09-03 18:27:38.089+00
89c0b5a3-e12d-4f92-beb1-10415134671e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:28:38.091+00
760449ca-1102-488c-8ae5-1c1ce8e80453	uptime	gauge	309.239843	{}	2025-09-03 18:29:38.096+00
dcb80716-27da-4b25-8119-f48778a4b929	disk_usage	gauge	45.200000	{}	2025-09-03 18:30:38.096+00
f58ead89-ea45-47ae-ada1-2e33960fb97f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:35:38.1+00
88988fbf-a1c3-434c-bb06-5514905e744a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:50:04.666+00
8cfe7c57-cfa5-4981-b8e5-1c5c5e246755	cpu_usage	gauge	6.000000	{}	2025-09-03 18:51:04.665+00
19070a34-3048-47f7-bf17-ec0691a68417	uptime	gauge	249.197199	{}	2025-09-03 18:52:04.667+00
91283943-1552-4d08-afe3-9f077c69a0fd	disk_usage	gauge	45.200000	{}	2025-09-03 18:53:04.667+00
439f3083-b641-4e87-a0a0-b5065f9c5bf2	memory_usage	gauge	77.580000	{}	2025-09-03 16:58:36.218+00
8ecb4883-a8fe-442c-a0d8-b2a07ea834ff	memory_usage	gauge	77.730000	{}	2025-09-03 16:59:36.22+00
a3f17fe1-dbb4-4f13-978d-e4114c3ce481	disk_usage	gauge	45.200000	{}	2025-09-03 17:00:36.219+00
45ac46ad-29be-4c75-8a4d-74ba339b005f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:01:36.219+00
6a1d6916-0bb5-4b07-baac-a599679fb84c	uptime	gauge	1869.466244	{}	2025-09-03 17:02:36.219+00
bbe61130-6afb-47d6-b10e-02c64df7313e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:03:36.22+00
2675a6a9-232b-4c26-81c6-f8361ba6f41c	uptime	gauge	1989.467490	{}	2025-09-03 17:04:36.22+00
cdcbdc96-208c-4ffa-b9ba-80e20085a2c1	disk_usage	gauge	45.200000	{}	2025-09-03 17:05:36.221+00
ac414b67-ed77-4266-9f24-6519e86b7853	disk_usage	gauge	45.200000	{}	2025-09-03 17:06:36.221+00
f3824755-58a4-4161-b6ca-c608acb75275	uptime	gauge	68.007429	{}	2025-09-03 17:49:27.515+00
77d96717-83af-442d-83f2-4b262bb313b0	cpu_usage	gauge	6.000000	{}	2025-09-03 17:50:27.515+00
3ff221c7-8d31-49ea-a606-ab0d242d123d	uptime	gauge	188.008019	{}	2025-09-03 17:51:27.516+00
b7b9d5b5-eff4-4d78-a8b8-cd00f8a9a27e	disk_usage	gauge	45.200000	{}	2025-09-03 17:52:27.517+00
98849cb2-b66b-48c9-9784-e7dad72363af	memory_usage	gauge	75.230000	{}	2025-09-03 17:53:27.524+00
3178b127-82b7-4f67-9cfa-eb679b46680d	memory_usage	gauge	74.920000	{}	2025-09-03 18:26:38.088+00
293ee845-fb5e-48c6-9d32-95609eec0781	disk_usage	gauge	45.200000	{}	2025-09-03 18:27:38.089+00
e448ba2c-4cb2-4003-9d05-a2e34436db10	disk_usage	gauge	45.200000	{}	2025-09-03 18:28:38.091+00
2d74987b-0c33-4720-b19a-269d9678875c	disk_usage	gauge	45.200000	{}	2025-09-03 18:29:38.096+00
61825128-71ad-4e91-912a-3041b3d3de0e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:30:38.096+00
c2af9ddc-3516-49b7-99fe-48c155238e9a	memory_usage	gauge	70.470000	{}	2025-09-03 18:35:38.1+00
63bba86d-6df4-4807-ba75-ed23cd574cab	memory_usage	gauge	64.540000	{}	2025-09-03 18:50:04.666+00
a8f7e67e-5af1-4db8-96b2-e56ff61d49b8	memory_usage	gauge	64.810000	{}	2025-09-03 18:51:04.665+00
49aa1b8a-35c1-4aab-bbb0-caf0de611ada	memory_usage	gauge	65.030000	{}	2025-09-03 18:52:04.667+00
9f41496f-9f98-4cf1-85eb-b92984582bc2	memory_usage	gauge	65.010000	{}	2025-09-03 18:53:04.667+00
7b1fbe62-88f2-4d78-842f-0b243c7bdf52	uptime	gauge	1629.465376	{}	2025-09-03 16:58:36.218+00
5bd3af0e-b2d3-435f-844f-65cec0138f70	cpu_usage	gauge	6.000000	{}	2025-09-03 16:59:36.22+00
207ac82f-c59c-479b-ac5d-aa6ae59b5b35	uptime	gauge	1749.466056	{}	2025-09-03 17:00:36.219+00
bc1e715f-20bc-48ce-873b-c9095097b76f	disk_usage	gauge	45.200000	{}	2025-09-03 17:01:36.219+00
fb61be77-8dbd-452c-b9ee-2c782c585fd7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:02:36.219+00
a0f2de85-a417-43d4-84e6-3dfe257fc901	uptime	gauge	1929.466925	{}	2025-09-03 17:03:36.22+00
af67a2cb-e226-4883-a73d-3d11943b839f	disk_usage	gauge	45.200000	{}	2025-09-03 17:04:36.22+00
23a101f4-fe28-4379-b700-4b61acd95d3c	memory_usage	gauge	77.160000	{}	2025-09-03 17:05:36.221+00
15e906d6-275b-4c5b-a3d0-6321e068ded4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:06:36.221+00
b215b67b-3e39-4ccf-826b-04f7fbfafa2c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:50:13.55+00
2536f46a-cc35-484c-aa69-0607fe438371	cpu_usage	gauge	6.000000	{}	2025-09-03 17:51:13.55+00
61f60293-2c24-459d-a1c0-2ca2eb605639	uptime	gauge	249.352346	{}	2025-09-03 17:52:13.55+00
99032f33-6b8a-4516-bb70-b7b71d71c1be	disk_usage	gauge	45.200000	{}	2025-09-03 17:53:13.555+00
bb06498d-accd-4fc4-9276-8e1b39439826	disk_usage	gauge	45.200000	{}	2025-09-03 18:26:38.088+00
22e71650-2fc8-4b76-9457-234d9cd4f89f	memory_usage	gauge	74.930000	{}	2025-09-03 18:27:38.089+00
afcfc18a-bd27-446d-8f95-8844f910180a	memory_usage	gauge	74.870000	{}	2025-09-03 18:28:38.091+00
5e53d09c-1600-4a12-80e2-0bdd8e38d5a1	memory_usage	gauge	74.720000	{}	2025-09-03 18:29:38.096+00
40c224c1-df94-4dd4-adf2-7e452f82f83d	memory_usage	gauge	75.300000	{}	2025-09-03 18:30:38.096+00
84e7722c-e02c-4f35-a91d-8e7dd363c599	disk_usage	gauge	45.200000	{}	2025-09-03 18:35:38.1+00
08f750a2-5b68-4b28-8bca-1d71409b3398	disk_usage	gauge	45.200000	{}	2025-09-03 18:50:04.666+00
096adcb1-a3c5-4786-899a-bdeb9e41af1b	disk_usage	gauge	45.200000	{}	2025-09-03 18:51:04.665+00
05823d57-4cab-41a9-8cc4-fed1921ad000	cpu_usage	gauge	6.000000	{}	2025-09-03 18:52:04.667+00
c95d10f1-9eed-4ae6-9702-d5591b53d012	uptime	gauge	309.197155	{}	2025-09-03 18:53:04.667+00
152115f4-80f8-4cd9-911d-375138467e7b	memory_usage	gauge	77.560000	{}	2025-09-03 16:58:58.356+00
a62d7691-d332-49d1-9006-1cc557e11e3b	disk_usage	gauge	45.200000	{}	2025-09-03 16:59:58.358+00
bc2d2e45-7c84-45d2-ac21-7910b2e0d98c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:00:58.359+00
63faf7cb-e4ab-4097-86ef-db8a5f5121f2	uptime	gauge	1748.119501	{}	2025-09-03 17:01:58.36+00
bccec84f-896b-4847-8306-497405880f03	disk_usage	gauge	45.200000	{}	2025-09-03 17:02:58.36+00
47916e18-56d2-40bb-b974-a863b8781cb7	memory_usage	gauge	77.120000	{}	2025-09-03 17:03:58.36+00
895118b3-51c8-4f5b-a81f-ef7c0784c537	uptime	gauge	1928.121136	{}	2025-09-03 17:04:58.361+00
0ec7f319-e0d6-4965-8c9d-7d667df21849	cpu_usage	gauge	6.000000	{}	2025-09-03 17:05:58.362+00
ba20a386-0580-4c97-9186-63aa7ba46e1c	memory_usage	gauge	75.120000	{}	2025-09-03 17:50:13.55+00
addd5a0c-ae31-43bf-8d89-209cf5fbc993	memory_usage	gauge	75.460000	{}	2025-09-03 17:51:13.55+00
d41f882e-3ff4-4b4a-ab61-3b4d92884bf7	memory_usage	gauge	75.400000	{}	2025-09-03 17:52:13.55+00
e160e128-2b2c-4112-9ee1-1c0631734fac	memory_usage	gauge	75.510000	{}	2025-09-03 17:53:13.555+00
dad9eca1-d07f-418b-a60d-c5077b1e2741	cpu_usage	gauge	6.000000	{}	2025-09-03 18:26:50.187+00
efb4d334-1d0b-404d-b478-86a8aa654469	memory_usage	gauge	74.850000	{}	2025-09-03 18:26:50.187+00
45bf2e44-07df-4272-9440-6d8a01e70d04	uptime	gauge	68.198442	{}	2025-09-03 18:26:50.187+00
9399d6b0-e5c0-4c24-b144-75bc1776037d	memory_usage	gauge	74.890000	{}	2025-09-03 18:27:50.188+00
6c0aa62c-4b63-4fa8-9ec3-6be1bdbeb121	memory_usage	gauge	74.840000	{}	2025-09-03 18:28:50.188+00
f3d1c175-c18e-4bea-a9db-b09f1d535cea	memory_usage	gauge	75.120000	{}	2025-09-03 18:29:50.188+00
a724e335-3db6-46ae-aa92-98e1c052b7d6	memory_usage	gauge	75.360000	{}	2025-09-03 18:30:50.195+00
fe7291c8-6e35-470c-ac20-46e7526774e7	cpu_usage	gauge	6.000000	{}	2025-09-03 18:36:05.743+00
9bdfde73-d891-4f5a-9d10-a8fddbcfafe3	memory_usage	gauge	70.100000	{}	2025-09-03 18:36:05.743+00
fe2136f1-3dc4-4220-9b7d-ea04ceeb6380	cpu_usage	gauge	6.000000	{}	2025-09-03 16:58:58.356+00
a67ea2c4-9d46-44e7-bd8f-831a2c5cbebe	uptime	gauge	1628.117564	{}	2025-09-03 16:59:58.358+00
1abc87ba-1ca9-407e-b3dc-6e06782864e8	memory_usage	gauge	77.010000	{}	2025-09-03 17:00:58.359+00
8856a57c-67fa-4394-bc81-827fa8eef3bc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:01:58.36+00
928e94c1-9a63-4a45-8ceb-1fa1a0ba10d8	uptime	gauge	1808.119512	{}	2025-09-03 17:02:58.36+00
d6b864d1-8849-4f3f-b9cd-4776e7e16d4e	disk_usage	gauge	45.200000	{}	2025-09-03 17:03:58.36+00
b6b275f6-e553-468e-9ab1-7c1402d16336	disk_usage	gauge	45.200000	{}	2025-09-03 17:04:58.361+00
e7a09ccb-040f-4381-b746-a6083b62f5fa	disk_usage	gauge	45.200000	{}	2025-09-03 17:05:58.362+00
d39967be-0cf0-4e4d-ac72-e01a0b1cd39d	disk_usage	gauge	45.200000	{}	2025-09-03 17:50:13.55+00
c122c76f-4189-4faf-b315-ea9b4cd11dd5	disk_usage	gauge	45.200000	{}	2025-09-03 17:51:13.55+00
9aab627e-5e90-41a3-aee8-b5a09fbdb8d1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:52:13.55+00
aaeff1ba-7593-4afc-85f8-a9e3459c1392	uptime	gauge	309.357754	{}	2025-09-03 17:53:13.555+00
0fc7ccd5-bcb9-482b-955c-5bc1d14e055d	disk_usage	gauge	45.200000	{}	2025-09-03 18:26:50.187+00
0e6e720b-c06c-4e35-8959-e803f0928b83	cpu_usage	gauge	6.000000	{}	2025-09-03 18:27:50.187+00
cbb8de96-ce5e-4e5f-918e-10bc8e89bdc7	uptime	gauge	188.198657	{}	2025-09-03 18:28:50.188+00
707669dd-4b30-4100-9b8b-a1420c9d8c34	disk_usage	gauge	45.200000	{}	2025-09-03 18:29:50.189+00
82b0aec0-ef2b-40c6-8e64-a1d871afd8d6	disk_usage	gauge	45.200000	{}	2025-09-03 18:30:50.195+00
d7969dff-9d85-4e14-994e-82194ff9d068	disk_usage	gauge	45.200000	{}	2025-09-03 18:36:05.743+00
31c8575c-c899-4a79-bda2-9f0b7d248227	uptime	gauge	1568.116239	{}	2025-09-03 16:58:58.357+00
90901a37-320a-4a07-8db4-7414275ab946	memory_usage	gauge	77.400000	{}	2025-09-03 16:59:58.358+00
13184740-621d-4183-93b6-07b0c09a6c94	disk_usage	gauge	45.200000	{}	2025-09-03 17:50:27.515+00
b1193f65-cfda-4bfc-a02d-9ad986e4d7c0	disk_usage	gauge	45.200000	{}	2025-09-03 17:51:27.516+00
7aace998-5ccc-4e3d-9acd-8d38649cbaea	cpu_usage	gauge	6.000000	{}	2025-09-03 17:52:27.517+00
8ac794b9-87ed-49e0-aa2d-fb00a272fe49	uptime	gauge	308.016112	{}	2025-09-03 17:53:27.524+00
ecffc8aa-87fa-4b74-88ac-e004d2455ff2	disk_usage	gauge	45.200000	{}	2025-09-03 18:27:50.188+00
3454be98-668b-4652-ad6f-bbc5bd191c33	cpu_usage	gauge	6.000000	{}	2025-09-03 18:28:50.187+00
a291221b-8240-4167-9624-15f4cd1c3eda	uptime	gauge	248.199536	{}	2025-09-03 18:29:50.189+00
37a0572d-8d1f-4e98-bb65-8f3dfeb4ec80	cpu_usage	gauge	6.000000	{}	2025-09-03 18:30:50.195+00
881c31cb-627e-44e5-b35b-8b0d04778335	uptime	gauge	68.374480	{}	2025-09-03 18:36:05.743+00
30d0f38d-4f29-4361-bdd1-4f052d927d28	disk_usage	gauge	45.200000	{}	2025-09-03 16:58:58.357+00
0f731d25-3b61-4dbc-add0-791689711995	cpu_usage	gauge	6.000000	{}	2025-09-03 16:59:58.358+00
e46a2a11-9276-449b-83b2-57ce3280aa12	uptime	gauge	1688.118572	{}	2025-09-03 17:00:58.359+00
ff5a4ed8-0a45-4452-b3cc-d51dd694a45f	disk_usage	gauge	45.200000	{}	2025-09-03 17:01:58.36+00
3ad5eb8a-7df3-45bb-ad03-279f8c3e5903	cpu_usage	gauge	6.000000	{}	2025-09-03 17:02:58.36+00
97a65b23-1de0-45a5-98ab-b95ccec215f4	uptime	gauge	1868.120054	{}	2025-09-03 17:03:58.36+00
544aa8ff-8fb9-4245-91ac-8d0ab06a91a7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:04:58.361+00
85b74caf-cb01-4e1d-91b8-9e854842db8b	uptime	gauge	1988.121847	{}	2025-09-03 17:05:58.362+00
b59a4e71-9f0e-4e5e-a74e-399751a73add	memory_usage	gauge	80.520000	{}	2025-09-03 17:06:58.363+00
5f08c24c-398e-41b7-9aba-1dddf4d185c4	uptime	gauge	128.006954	{}	2025-09-03 17:50:27.515+00
7207918c-efe0-4404-8ae8-7ad150ac7b5f	memory_usage	gauge	75.390000	{}	2025-09-03 17:51:27.516+00
8c715a76-93bf-4660-9f32-dc1544f495a2	memory_usage	gauge	75.400000	{}	2025-09-03 17:52:27.517+00
9cc1ab8c-fbcd-45f6-a632-361eaca89b83	disk_usage	gauge	45.200000	{}	2025-09-03 17:53:27.524+00
2d0ccc6a-d4dc-4d47-8658-987b9b49686e	uptime	gauge	128.198785	{}	2025-09-03 18:27:50.188+00
f3f36932-75bf-4076-adf7-13ab1895d462	disk_usage	gauge	45.200000	{}	2025-09-03 18:28:50.188+00
9d7c852b-b9ad-488c-9e75-1157f4f8f573	cpu_usage	gauge	6.000000	{}	2025-09-03 18:29:50.188+00
ce2fc85e-2331-4049-a7b1-67cfaa738b70	uptime	gauge	308.206194	{}	2025-09-03 18:30:50.195+00
02cfdbd7-ad8e-4752-8133-ee62d75f09c8	memory_usage	gauge	70.040000	{}	2025-09-03 18:36:38.101+00
483488c5-5132-4634-8a09-9844787f34ec	disk_usage	gauge	45.200000	{}	2025-09-03 18:36:38.101+00
4ad4cf3a-3b58-4512-b027-484bc8d02755	disk_usage	gauge	45.200000	{}	2025-09-03 18:37:38.102+00
4f364891-41e5-4fdb-a1b0-d31548feeda0	uptime	gauge	789.245064	{}	2025-09-03 18:37:38.102+00
da3c0a8d-eeaa-4292-9592-f845dc5673e0	cpu_usage	gauge	6.000000	{}	2025-09-03 18:38:38.102+00
18a80aaa-30cf-498d-a85e-6e82b0f6032e	memory_usage	gauge	70.050000	{}	2025-09-03 18:38:38.102+00
f9b6aad6-2583-4e60-992c-f8fb2f505c6d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:39:38.102+00
58c5a80b-3762-4104-9d77-dbeef12cd12b	uptime	gauge	909.245526	{}	2025-09-03 18:39:38.102+00
9427ba04-02cf-48e1-bff2-507294eaa325	cpu_usage	gauge	6.000000	{}	2025-09-03 18:40:38.102+00
a93ffe8e-e198-4e92-b0a6-bd0c58545021	uptime	gauge	969.245579	{}	2025-09-03 18:40:38.102+00
9398429d-b675-42c9-88a9-d58657b82f30	disk_usage	gauge	45.200000	{}	2025-09-03 18:41:38.103+00
17b2d0d4-9549-4fc7-9ca1-7808e4bb23d7	uptime	gauge	1029.246470	{}	2025-09-03 18:41:38.103+00
9f5225dd-9348-4df0-bab6-9da067c8090a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:42:38.104+00
bc88fca3-1511-4a01-8721-d7c30f405aa6	memory_usage	gauge	65.450000	{}	2025-09-03 18:42:38.104+00
dd91f8ce-a967-49b3-804f-22e02e17726c	disk_usage	gauge	45.200000	{}	2025-09-03 18:43:38.105+00
0ef23ac7-40a2-4232-852b-f44bcf4f2dcb	uptime	gauge	1149.248413	{}	2025-09-03 18:43:38.105+00
900acc49-254b-468a-83b8-fcd20c259607	cpu_usage	gauge	6.000000	{}	2025-09-03 18:44:38.105+00
a2d3f4af-8838-44b5-8a1d-a647c200a32e	disk_usage	gauge	45.200000	{}	2025-09-03 18:44:38.105+00
52a782fd-2941-4082-b835-60e282fd0e3c	memory_usage	gauge	76.800000	{}	2025-09-03 17:00:36.219+00
178ea446-acec-4fc8-a9a2-9140478c700e	memory_usage	gauge	77.040000	{}	2025-09-03 17:01:36.219+00
df99fccb-5466-4c2d-ab78-16ccbc7398fa	memory_usage	gauge	77.140000	{}	2025-09-03 17:02:36.219+00
5d667bb4-bc58-4bea-bacf-81f6ba1cd584	disk_usage	gauge	45.200000	{}	2025-09-03 17:03:36.22+00
7b45de76-7205-471a-95d9-a10cb12fe6d8	cpu_usage	gauge	6.000000	{}	2025-09-03 17:04:36.22+00
8c684642-e481-451a-9eeb-4c7053104c0e	uptime	gauge	2049.468047	{}	2025-09-03 17:05:36.221+00
2bcb2492-124e-46e4-b30c-e36cea4a9f62	memory_usage	gauge	77.130000	{}	2025-09-03 17:06:36.221+00
b0831fff-964b-4493-b564-4e29fd384219	memory_usage	gauge	75.280000	{}	2025-09-03 17:54:13.555+00
950b8b99-bd74-4930-9943-6a88b54090e8	uptime	gauge	429.358211	{}	2025-09-03 17:55:13.556+00
1b2b0779-5c17-4929-bc5b-3608908b8581	disk_usage	gauge	45.200000	{}	2025-09-03 17:56:13.556+00
9c6b56cf-595d-431f-bc5b-a5b180607d60	cpu_usage	gauge	6.000000	{}	2025-09-03 17:57:13.556+00
ef6cc8f9-0a8c-4686-9f78-3760e6e2c0ef	uptime	gauge	609.358561	{}	2025-09-03 17:58:13.556+00
ccc98f65-da37-49c7-9775-8aa62fa85d41	memory_usage	gauge	75.100000	{}	2025-09-03 17:59:13.556+00
c413f8ba-450c-420a-8830-37980b92ab14	cpu_usage	gauge	6.000000	{}	2025-09-03 18:00:13.557+00
b6546104-ac49-4c0b-a3a6-2633af0d30d3	uptime	gauge	789.359829	{}	2025-09-03 18:01:13.557+00
75f78142-de3b-4a3e-8177-1b2d4d91ff31	disk_usage	gauge	45.200000	{}	2025-09-03 18:02:13.557+00
76796ee3-8964-45b4-9fa3-3c894edfe888	memory_usage	gauge	74.790000	{}	2025-09-03 18:03:13.558+00
fd1959c8-5f5b-4125-a379-3e84dee6f978	cpu_usage	gauge	6.000000	{}	2025-09-03 18:04:13.558+00
5818e9b5-8620-4e7b-8d64-08bcea6c70b5	uptime	gauge	1029.360547	{}	2025-09-03 18:05:13.558+00
cf9834d3-c878-44c6-b93e-664a67fd0872	memory_usage	gauge	75.260000	{}	2025-09-03 18:06:13.559+00
8a12a203-1630-48cb-8950-c68b128643eb	cpu_usage	gauge	6.000000	{}	2025-09-03 18:36:38.101+00
3c548717-767e-4b83-83ef-a5d8e044b65c	cpu_usage	gauge	6.000000	{}	2025-09-03 18:37:38.101+00
7513f06c-d0a5-4817-98f4-bf76361b2d03	uptime	gauge	849.245132	{}	2025-09-03 18:38:38.102+00
1330e200-eac0-45ed-aede-9a44e6e5a8d6	disk_usage	gauge	45.200000	{}	2025-09-03 18:39:38.102+00
7059cc98-190c-49d7-80e3-d4c5e332338a	disk_usage	gauge	45.200000	{}	2025-09-03 18:40:38.102+00
e89da9cb-55e5-4f10-a18b-27b2fed42740	cpu_usage	gauge	6.000000	{}	2025-09-03 18:41:38.103+00
89f0b838-43e0-46be-a9bc-c1527845501d	uptime	gauge	1089.247237	{}	2025-09-03 18:42:38.104+00
228da3d5-0ce2-4d79-8cdf-37cb12cb2646	memory_usage	gauge	65.350000	{}	2025-09-03 18:43:38.105+00
b06c0f85-8534-402a-84e0-3a20e0bcae1f	memory_usage	gauge	65.270000	{}	2025-09-03 18:44:38.105+00
06e9bca4-edf1-410f-9199-30e57e30a590	disk_usage	gauge	45.200000	{}	2025-09-03 17:00:58.359+00
db39f074-72a3-48bb-b91e-640b1551e416	memory_usage	gauge	77.150000	{}	2025-09-03 17:01:58.36+00
7bbd9e4c-3bb4-439b-b3da-265143332c72	memory_usage	gauge	76.840000	{}	2025-09-03 17:02:58.36+00
93a8abbf-b19b-4d1c-8a09-fb7213b2b751	cpu_usage	gauge	6.000000	{}	2025-09-03 17:03:58.36+00
7a561ff9-8447-41bb-b4c7-3b3b38c9b745	memory_usage	gauge	76.740000	{}	2025-09-03 17:04:58.361+00
c3dfecc4-92a5-4e0d-80e7-4b55241547b0	memory_usage	gauge	77.790000	{}	2025-09-03 17:05:58.362+00
a968738e-0c3a-4927-815e-df16aa4e8564	cpu_usage	gauge	6.000000	{}	2025-09-03 17:54:13.555+00
32ff6cf6-65ed-41fc-a8cb-2a19eeec6e15	cpu_usage	gauge	6.000000	{}	2025-09-03 17:55:13.555+00
f8b746f0-d5d9-4bec-ac97-419e7691b316	uptime	gauge	489.358895	{}	2025-09-03 17:56:13.556+00
d4146555-29b5-4848-90fe-7daa8eba3280	disk_usage	gauge	45.200000	{}	2025-09-03 17:57:13.557+00
b0dbefb4-3655-4ca4-9167-7e79de54780e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:58:13.556+00
04e2f48e-4f63-40e9-88d7-305d073752fb	uptime	gauge	669.359033	{}	2025-09-03 17:59:13.556+00
4da21533-d76d-4fae-a4fa-a338905f60da	disk_usage	gauge	45.200000	{}	2025-09-03 18:00:13.557+00
25043142-358b-4fd7-9d87-a3ae94ed9ed6	memory_usage	gauge	74.820000	{}	2025-09-03 18:01:13.557+00
ae8dd4ca-282c-439b-9aa5-c0e6d3b531de	cpu_usage	gauge	6.000000	{}	2025-09-03 18:02:13.557+00
29b963ea-78f1-460d-a990-0cd9875897a9	uptime	gauge	909.360392	{}	2025-09-03 18:03:13.558+00
d1310a79-8e02-43a3-a67c-f088e951feed	memory_usage	gauge	74.810000	{}	2025-09-03 18:04:13.558+00
958a6791-2c96-45bc-819d-a601067a9368	memory_usage	gauge	75.710000	{}	2025-09-03 18:05:13.558+00
8df9e310-d96c-4a2a-af34-8186ee5951d5	disk_usage	gauge	45.200000	{}	2025-09-03 18:06:13.559+00
8678cb01-ddd8-4f11-b7ae-e3924a8f0345	uptime	gauge	729.244554	{}	2025-09-03 18:36:38.101+00
d73306ea-b709-42f4-94a1-29457d4b5818	memory_usage	gauge	70.120000	{}	2025-09-03 18:37:38.102+00
bf388ede-bfe2-451a-ab1d-d85058f0f26c	disk_usage	gauge	45.200000	{}	2025-09-03 18:38:38.102+00
da6c7dee-62f6-41d7-8860-8ac77b916cb6	memory_usage	gauge	69.960000	{}	2025-09-03 18:39:38.102+00
39e4a285-63f7-498e-b2a7-175395c03648	memory_usage	gauge	70.420000	{}	2025-09-03 18:40:38.102+00
d521346a-0d45-4554-8d65-28e4e59aeba4	memory_usage	gauge	65.510000	{}	2025-09-03 18:41:38.103+00
e0f56d77-322b-4e74-9332-4fc116ebb431	disk_usage	gauge	45.200000	{}	2025-09-03 18:42:38.104+00
573c1167-864a-4f8f-bd09-aea905a8145d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:43:38.105+00
295d6581-bbea-47aa-9fca-5cc4474cd589	uptime	gauge	1209.248664	{}	2025-09-03 18:44:38.105+00
593d72dd-c3c3-4bcf-8c96-7b0aedac84cd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:06:58.363+00
0893102a-0363-4391-a7d1-34eeb64d6325	disk_usage	gauge	45.200000	{}	2025-09-03 17:54:13.555+00
fa43c723-4aba-42f7-a486-8b4bfd41d3fa	disk_usage	gauge	45.200000	{}	2025-09-03 17:55:13.556+00
50e1b3c4-a8ad-41b8-8955-2fdad02d73c6	memory_usage	gauge	75.230000	{}	2025-09-03 17:56:13.556+00
a55d2163-2da1-4907-b52a-dea522662699	memory_usage	gauge	75.210000	{}	2025-09-03 17:57:13.556+00
38fd8e2b-5a24-43c7-b847-4859659c685f	memory_usage	gauge	75.190000	{}	2025-09-03 17:58:13.556+00
115af0da-7dc1-4667-9ba8-aa8a54e7fc42	cpu_usage	gauge	6.000000	{}	2025-09-03 17:59:13.556+00
13a45bac-62d8-4fca-9c90-56718fc2c79a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:37:05.744+00
0677e501-c2f6-4b2d-9db9-2b1352f1b645	uptime	gauge	188.376412	{}	2025-09-03 18:38:05.745+00
6abfbccb-b0cf-4405-90e9-68d7e469bc11	cpu_usage	gauge	6.000000	{}	2025-09-03 18:39:05.746+00
dbc428a1-b101-4682-9624-a28c53baafc5	memory_usage	gauge	70.700000	{}	2025-09-03 18:40:05.751+00
7a416cc0-395a-42e0-bbdd-a160b7fff21a	disk_usage	gauge	45.200000	{}	2025-09-03 17:06:58.363+00
a6ec7fef-6afe-452c-b9ea-f37824eadda1	uptime	gauge	369.357701	{}	2025-09-03 17:54:13.555+00
a3a83037-b16d-4c7e-80dc-6922a2c2b917	memory_usage	gauge	75.740000	{}	2025-09-03 17:55:13.555+00
33626b8c-4a44-435a-a570-ce9c80bbd2d9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:56:13.556+00
bdc3104b-55c6-4c75-9106-67250c87f3ba	uptime	gauge	549.359220	{}	2025-09-03 17:57:13.557+00
3eed3566-5372-4b88-9ab1-39d83a411812	disk_usage	gauge	45.200000	{}	2025-09-03 17:58:13.556+00
96a50edf-4a1d-469b-aec7-25cdfd261f7b	disk_usage	gauge	45.200000	{}	2025-09-03 17:59:13.556+00
125b0a8a-f8d0-41c7-a25c-908c6f4b61f2	memory_usage	gauge	70.110000	{}	2025-09-03 18:37:05.744+00
398c8e92-55ff-4546-85eb-1b7f57084993	disk_usage	gauge	45.200000	{}	2025-09-03 18:38:05.745+00
e85d4367-266e-4d27-8688-14cb3831e21a	disk_usage	gauge	45.200000	{}	2025-09-03 18:39:05.746+00
57d02880-7bfc-4b0c-9aa3-253fd06b9ba4	disk_usage	gauge	45.200000	{}	2025-09-03 18:40:05.751+00
d3999f84-bc63-4d6a-becd-106f2b9d3eb0	uptime	gauge	2048.122778	{}	2025-09-03 17:06:58.363+00
4896ae26-f6ff-4088-9c84-cddda7ec4eaa	cpu_usage	gauge	6.000000	{}	2025-09-03 17:54:27.524+00
ac87095f-210a-428d-bac4-16ace962d72b	disk_usage	gauge	45.200000	{}	2025-09-03 17:55:27.525+00
85019642-0b78-4a91-a122-8b80b1d7261d	memory_usage	gauge	75.210000	{}	2025-09-03 17:56:27.526+00
e2e46ab7-d5b6-4e8e-b8ad-def8d83b8914	uptime	gauge	548.019306	{}	2025-09-03 17:57:27.527+00
8576239a-8cfc-490f-b0b6-455df384d31b	disk_usage	gauge	45.200000	{}	2025-09-03 17:58:27.529+00
885d2ac0-b8f3-4ad5-899f-3aff2a091a81	memory_usage	gauge	75.050000	{}	2025-09-03 17:59:27.53+00
abd0bc4c-9dc6-470f-8bf6-1ea7d9af2ad0	uptime	gauge	128.375530	{}	2025-09-03 18:37:05.744+00
c2e27a77-cfcd-43c2-9095-1614ed4f6eb2	cpu_usage	gauge	6.000000	{}	2025-09-03 18:38:05.745+00
1397ff4a-987d-4f15-95b1-5a8819cf5feb	uptime	gauge	248.377534	{}	2025-09-03 18:39:05.746+00
701cbdd9-7c31-42d7-918b-77139c98ab18	cpu_usage	gauge	6.000000	{}	2025-09-03 18:40:05.751+00
74fef9b4-1be9-4e69-a355-b76fdfeb4bb3	memory_usage	gauge	80.120000	{}	2025-09-03 17:07:36.221+00
8be7605b-b5c1-4198-a78c-5f058ea11eae	uptime	gauge	2229.467882	{}	2025-09-03 17:08:36.221+00
bdd8e51d-eae5-4007-8db1-09774b775f44	cpu_usage	gauge	6.000000	{}	2025-09-03 17:09:36.221+00
ead6c676-13b4-47fa-b818-1e3256c7cf4b	uptime	gauge	2349.468163	{}	2025-09-03 17:10:36.221+00
36297ecd-83c5-466c-b470-db98989be65d	disk_usage	gauge	45.200000	{}	2025-09-03 17:11:36.221+00
8ea22fe9-785c-44a5-b04a-4a6ae7c0003f	memory_usage	gauge	73.530000	{}	2025-09-03 17:12:36.22+00
e740de99-d085-4022-9a0c-cc0bbcdbed85	cpu_usage	gauge	6.000000	{}	2025-09-03 17:13:36.221+00
0a31e880-087e-4274-9cca-d3c360c26d59	uptime	gauge	2589.468058	{}	2025-09-03 17:14:36.221+00
86ff9aeb-b5d1-4b0b-b805-847567172cf2	memory_usage	gauge	75.220000	{}	2025-09-03 17:54:27.524+00
6a17db26-03fa-4475-9c54-a80ad217e97a	uptime	gauge	428.016571	{}	2025-09-03 17:55:27.525+00
7e65e53f-f303-4c72-a1b2-254f62df01fc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:56:27.526+00
60f1de7c-bac0-4478-bd0e-328448e4958b	disk_usage	gauge	45.200000	{}	2025-09-03 17:57:27.527+00
54635bcd-af81-42fd-bb1c-3bfda26eca10	memory_usage	gauge	75.050000	{}	2025-09-03 17:58:27.529+00
6f8a6cd2-445d-49ea-85c1-85ec63e9bdf0	uptime	gauge	668.021710	{}	2025-09-03 17:59:27.53+00
169970be-9766-41a7-8bc7-62811826f851	cpu_usage	gauge	6.000000	{}	2025-09-03 18:00:27.53+00
3ad2eeb5-4454-497a-860b-935a1452b03b	disk_usage	gauge	45.200000	{}	2025-09-03 18:01:27.53+00
2ece1b96-db65-40c6-81cb-3fc62b8e9b94	cpu_usage	gauge	6.000000	{}	2025-09-03 18:02:27.531+00
212618b7-d799-42fe-b841-2af6f0f66282	cpu_usage	gauge	6.000000	{}	2025-09-03 18:03:27.532+00
f1dbb1de-ada8-49f6-bdf6-ebeb520bce7f	uptime	gauge	968.023437	{}	2025-09-03 18:04:27.531+00
8c86c25d-b27f-48cd-9282-074de256f897	disk_usage	gauge	45.200000	{}	2025-09-03 18:05:27.532+00
81c16fd1-0399-41db-9d83-aaef8118b9dd	cpu_usage	gauge	6.000000	{}	2025-09-03 18:06:27.532+00
9fd4feb2-a7dc-4a58-b653-aa569c80dca2	disk_usage	gauge	45.200000	{}	2025-09-03 18:37:05.744+00
ef331e35-59ab-4a4d-9623-d7e5974f82ba	memory_usage	gauge	70.110000	{}	2025-09-03 18:38:05.745+00
20395fed-ee74-478d-95ee-36930dcacc80	memory_usage	gauge	70.040000	{}	2025-09-03 18:39:05.746+00
25f47245-208e-460b-818d-08ce3fe9b30c	uptime	gauge	308.382555	{}	2025-09-03 18:40:05.751+00
236d6964-7a71-41df-84f4-04d97e2d7ec1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:07:36.221+00
d114cdd1-0aeb-4d4a-8dfe-f99df59c2820	disk_usage	gauge	45.200000	{}	2025-09-03 17:08:36.221+00
292611b6-3a52-41f3-93e5-ae4a8545ef9a	memory_usage	gauge	79.950000	{}	2025-09-03 17:09:36.221+00
813b7d5c-fc08-49bd-890b-9343774339a6	disk_usage	gauge	45.200000	{}	2025-09-03 17:10:36.221+00
3d97f592-5fe2-4964-9aea-0f79f71f4b2d	memory_usage	gauge	73.880000	{}	2025-09-03 17:11:36.22+00
69497139-d446-4fd7-aeab-af3ff8afcf78	disk_usage	gauge	45.200000	{}	2025-09-03 17:12:36.22+00
98e35d0f-ac4d-40b7-abc2-e32e7efaed0d	memory_usage	gauge	73.490000	{}	2025-09-03 17:13:36.221+00
e6d3ccf4-3408-4e3c-853a-330d6c8ea879	memory_usage	gauge	73.510000	{}	2025-09-03 17:14:36.221+00
0d8f4e92-c80e-459a-a4d1-b86de4072424	disk_usage	gauge	45.200000	{}	2025-09-03 17:54:27.524+00
6ce9b273-3a82-4d04-87dc-c327a69b28b1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:55:27.525+00
526b7d07-448a-4336-84d2-c79b15a5e949	disk_usage	gauge	45.200000	{}	2025-09-03 17:56:27.526+00
851ce068-7cf3-423a-9d41-2e5146c489e0	memory_usage	gauge	75.230000	{}	2025-09-03 17:57:27.527+00
b8d910d9-671c-4b10-bd92-9853637e37f1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:58:27.529+00
b08304d6-07f6-4a6f-9ac1-03c39742dcde	cpu_usage	gauge	6.000000	{}	2025-09-03 17:59:27.53+00
5a198919-d6fb-47e4-9706-66f6780519c7	disk_usage	gauge	45.200000	{}	2025-09-03 18:00:27.53+00
d2cb15c8-30f8-4667-bf9d-d1b3edf9bea6	cpu_usage	gauge	6.000000	{}	2025-09-03 18:01:27.53+00
f13bcd40-4af8-482f-a5df-33b7165630f3	uptime	gauge	848.022909	{}	2025-09-03 18:02:27.531+00
1529c2ee-1f90-42d0-b515-a9cf056960fb	memory_usage	gauge	74.840000	{}	2025-09-03 18:03:27.532+00
edb9b1b8-0673-4b62-b85c-779b362f3235	memory_usage	gauge	74.800000	{}	2025-09-03 18:04:27.531+00
60c19e2b-1dca-45d2-9894-322ee288abf6	memory_usage	gauge	75.230000	{}	2025-09-03 18:05:27.532+00
9c220060-78ad-42cc-a9d6-f97c03b9de6e	uptime	gauge	1088.024047	{}	2025-09-03 18:06:27.532+00
0572fab4-6e27-4e80-bf20-c22f0c62f588	uptime	gauge	2169.468543	{}	2025-09-03 17:07:36.221+00
892718eb-007f-467b-88c5-84694281ccfc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:08:36.221+00
5ae5424b-e5d1-4772-b993-350f5474d5e7	uptime	gauge	2289.467913	{}	2025-09-03 17:09:36.221+00
e3bc98e5-7418-45d1-af6b-75134fe34cd7	memory_usage	gauge	73.680000	{}	2025-09-03 17:10:36.221+00
4b74e76b-ff21-4f16-aea2-4170c19cd4e2	cpu_usage	gauge	6.000000	{}	2025-09-03 17:11:36.22+00
2f4ca8af-026f-46cb-9a33-276c2f3af12a	uptime	gauge	2469.467082	{}	2025-09-03 17:12:36.22+00
3cfcabcd-fb43-45b9-932c-d4c18a25b750	disk_usage	gauge	45.200000	{}	2025-09-03 17:13:36.221+00
1db7fbcb-7b7d-4949-bfb9-231314cac727	cpu_usage	gauge	6.000000	{}	2025-09-03 17:14:36.221+00
d0b96b46-fcfa-49ab-8a87-063861a82ce8	uptime	gauge	368.016447	{}	2025-09-03 17:54:27.525+00
68359b1d-23a6-4341-b633-c4de9f4186e6	memory_usage	gauge	75.670000	{}	2025-09-03 17:55:27.525+00
50ec496b-9d12-4292-ab2f-c23a392181d5	uptime	gauge	488.018111	{}	2025-09-03 17:56:27.526+00
c14682bb-fed2-4419-a995-71d87faa0766	cpu_usage	gauge	6.000000	{}	2025-09-03 17:57:27.527+00
2c82278f-526f-40d8-858e-70db204dc8c2	uptime	gauge	608.020676	{}	2025-09-03 17:58:27.529+00
70133665-f38a-4c47-a9b3-80910be059e3	disk_usage	gauge	45.200000	{}	2025-09-03 17:59:27.53+00
e9ef07f0-d62b-4c28-97e0-cddb07d4ba2d	memory_usage	gauge	75.200000	{}	2025-09-03 18:00:27.53+00
62ec8bff-59f3-40fe-b06d-5d5485cbc3d7	uptime	gauge	788.022343	{}	2025-09-03 18:01:27.53+00
3d73aba9-d330-4482-aa57-a6e97a80ed52	disk_usage	gauge	45.200000	{}	2025-09-03 18:02:27.531+00
cb7012f1-0c7b-47c0-aaf2-1c7ebd5cc162	disk_usage	gauge	45.200000	{}	2025-09-03 18:03:27.532+00
3a2d122d-8f25-4bf5-b2dd-31098714b5ae	cpu_usage	gauge	6.000000	{}	2025-09-03 18:04:27.531+00
71dbc44c-ed20-46ca-8a74-8813dceea871	uptime	gauge	1028.023922	{}	2025-09-03 18:05:27.532+00
8ce09bc1-7386-41cc-97f3-bf0a8c7140bc	disk_usage	gauge	45.200000	{}	2025-09-03 18:06:27.532+00
a353fc5e-ad96-4f7a-b9e0-7930d387ab31	disk_usage	gauge	45.200000	{}	2025-09-03 17:07:36.221+00
20878942-e971-4f6a-9e0c-25bfc121064c	memory_usage	gauge	79.960000	{}	2025-09-03 17:08:36.221+00
9fb905e0-2c97-4a3d-9835-ec786020e6a4	disk_usage	gauge	45.200000	{}	2025-09-03 17:09:36.221+00
8068179f-2ea6-4804-a6f1-72a128807ecd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:10:36.221+00
ad4e9379-1e1f-458e-b32d-e0124a2af3c3	uptime	gauge	2409.467594	{}	2025-09-03 17:11:36.221+00
ce1347b7-0c85-45fc-9bb5-f9c6c02ac00c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:12:36.22+00
dd1ad1c9-89e4-4b81-823c-71a4f2f54920	uptime	gauge	2529.467712	{}	2025-09-03 17:13:36.221+00
d9a22324-15f5-4c71-bfeb-3aad0adae1d8	disk_usage	gauge	45.200000	{}	2025-09-03 17:14:36.221+00
fc93079c-382a-4c59-9f72-64bbe08ca364	memory_usage	gauge	76.080000	{}	2025-09-03 18:00:13.557+00
e3596281-30f4-4886-af1a-1760834382ed	cpu_usage	gauge	6.000000	{}	2025-09-03 18:01:13.557+00
f202489c-42df-4761-8eaa-2f4634322372	uptime	gauge	849.360087	{}	2025-09-03 18:02:13.557+00
42aed1aa-d076-4d8d-8d15-218d67339e2a	disk_usage	gauge	45.200000	{}	2025-09-03 18:03:13.558+00
e7a6074a-9845-4bad-8e32-fe4f2404d45b	disk_usage	gauge	45.200000	{}	2025-09-03 18:04:13.558+00
3b90f3b6-37a2-4edf-b275-d0120b877000	cpu_usage	gauge	6.000000	{}	2025-09-03 18:05:13.558+00
23ee16e0-ffbe-4b5f-abaf-2cdaf43a4379	uptime	gauge	1089.361612	{}	2025-09-03 18:06:13.559+00
faabcc97-3093-44fd-a9f0-551bc9db0faa	memory_usage	gauge	79.840000	{}	2025-09-03 17:07:58.362+00
100b15e2-7979-48ab-a55c-6d834cad30e0	uptime	gauge	2168.122447	{}	2025-09-03 17:08:58.363+00
06645b6d-55c6-4c45-a13f-8fa524da5cb5	disk_usage	gauge	45.200000	{}	2025-09-03 17:09:58.363+00
8953881f-413d-427e-a474-6dc9e4c9bf4b	uptime	gauge	729.359537	{}	2025-09-03 18:00:13.557+00
01aa07e1-c2db-484a-8fde-e31ca4469ac5	disk_usage	gauge	45.200000	{}	2025-09-03 18:01:13.557+00
93063b9f-8e4a-4acb-bbea-8928c2805bd1	memory_usage	gauge	74.820000	{}	2025-09-03 18:02:13.557+00
42c7211c-4aeb-4ec4-90a0-f0f01e983c39	cpu_usage	gauge	6.000000	{}	2025-09-03 18:03:13.558+00
1125b234-e8b1-421e-bbb6-925d306a4214	uptime	gauge	969.360463	{}	2025-09-03 18:04:13.558+00
09ac95d2-d741-4412-bdbc-97820384c5b1	disk_usage	gauge	45.200000	{}	2025-09-03 18:05:13.558+00
627bcda1-0afa-4d8a-8fc5-512ba932cec5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:06:13.559+00
c32b9313-5f40-408f-a9f9-6117feb5096b	uptime	gauge	2108.121918	{}	2025-09-03 17:07:58.362+00
eb8f84c0-d3c2-4764-ad09-80c3d2cc2025	cpu_usage	gauge	6.000000	{}	2025-09-03 17:08:58.363+00
2f6d05e1-a0e0-4eee-90d8-7567dcff1880	memory_usage	gauge	79.980000	{}	2025-09-03 17:09:58.363+00
ee012111-4d0b-4ecc-b476-6c1e0f403da8	uptime	gauge	728.021665	{}	2025-09-03 18:00:27.53+00
44084259-0841-40bf-b10f-04defe4ab2c8	memory_usage	gauge	74.890000	{}	2025-09-03 18:01:27.53+00
989b8f45-487c-4818-a82e-a3e9d4ac5b66	memory_usage	gauge	74.780000	{}	2025-09-03 18:02:27.531+00
1fb291ec-32ad-4415-8c86-832adf081570	uptime	gauge	908.023937	{}	2025-09-03 18:03:27.532+00
6d497e94-d0ff-4592-b1a7-06407e2a9fea	disk_usage	gauge	45.200000	{}	2025-09-03 18:04:27.531+00
6e211289-0593-4e6b-b9b6-6428d8869743	cpu_usage	gauge	6.000000	{}	2025-09-03 18:05:27.532+00
0d660b70-dd23-4bcb-8d08-d721ae844da3	memory_usage	gauge	75.290000	{}	2025-09-03 18:06:27.532+00
e796b422-8602-40d3-8994-98cfadf97156	disk_usage	gauge	45.200000	{}	2025-09-03 17:07:58.362+00
221edaa3-1fab-483c-a59b-6715a102f5bf	memory_usage	gauge	79.950000	{}	2025-09-03 17:08:58.363+00
4aa10899-41f9-428f-aed8-e1c4d22776d9	uptime	gauge	2228.122903	{}	2025-09-03 17:09:58.363+00
b579e2ce-342a-44f1-afce-1358d1e93d05	cpu_usage	gauge	6.000000	{}	2025-09-03 18:07:13.56+00
9069e2f9-8ce7-4e5e-89ba-bea4eda65476	uptime	gauge	1209.363598	{}	2025-09-03 18:08:13.561+00
dbeed448-46a0-445f-aca7-e0895608e47b	disk_usage	gauge	45.200000	{}	2025-09-03 18:09:13.562+00
e0f5f6eb-c30a-41c0-9cab-2962221d2275	memory_usage	gauge	69.650000	{}	2025-09-03 18:10:13.563+00
1db6f0b9-3c25-4474-b222-8fc3f225ded5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:11:13.564+00
25bbf5d2-1419-4996-9d20-74254d9f4a3c	uptime	gauge	1449.368303	{}	2025-09-03 18:12:13.566+00
7a1df8c0-e8c2-4fa4-bbb5-b9cf2b3be5ee	memory_usage	gauge	69.540000	{}	2025-09-03 18:13:13.567+00
86fd848e-0449-4f71-9650-73937cd831f5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:14:13.568+00
925d0922-01cb-4816-96b2-1cd1f87aaaf2	uptime	gauge	1629.371522	{}	2025-09-03 18:15:13.569+00
f610c3b6-2594-492a-9c8f-c5e95243d658	memory_usage	gauge	69.550000	{}	2025-09-03 18:16:13.57+00
a8746a0c-84f5-4799-8f06-2481f5f3f327	memory_usage	gauge	69.460000	{}	2025-09-03 18:17:13.571+00
c3966036-c66d-411e-afbc-6a66ea0acc63	cpu_usage	gauge	6.000000	{}	2025-09-03 18:18:13.571+00
fbe849bb-c3cb-40d1-af5c-0daaca723782	cpu_usage	gauge	6.000000	{}	2025-09-03 17:07:58.362+00
5746d62b-e513-42c6-9d2e-8f99393d5a0d	disk_usage	gauge	45.200000	{}	2025-09-03 17:08:58.363+00
2a5edd04-1659-4a0e-a511-f444de268fd5	cpu_usage	gauge	6.000000	{}	2025-09-03 17:09:58.363+00
5cc6504b-3c58-4df5-b176-456986305ea0	memory_usage	gauge	75.270000	{}	2025-09-03 18:07:13.56+00
57d7667b-7ae3-4be9-8c1f-8541e2db0897	memory_usage	gauge	69.430000	{}	2025-09-03 18:08:13.561+00
b3ac7986-6a5d-4a9a-9978-a2892580c9f6	memory_usage	gauge	69.380000	{}	2025-09-03 18:09:13.562+00
aeae42ec-000e-46d5-9cc5-8ca7617c465f	uptime	gauge	1329.365581	{}	2025-09-03 18:10:13.563+00
979dd128-6120-4e7e-818e-7ac7e0203241	disk_usage	gauge	45.200000	{}	2025-09-03 18:11:13.564+00
a7d68c6d-943a-4c3f-9f02-6a0105a5ae24	memory_usage	gauge	69.710000	{}	2025-09-03 18:12:13.566+00
3d7912a7-7d36-4657-b01c-7a31d83b8236	uptime	gauge	1509.369883	{}	2025-09-03 18:13:13.567+00
4ab32e1d-537a-40e8-a4f8-d58c05457756	disk_usage	gauge	45.200000	{}	2025-09-03 18:14:13.568+00
0c9dc365-8d0a-4f73-8665-4e68ce7dad80	memory_usage	gauge	69.690000	{}	2025-09-03 18:15:13.569+00
ab1aa279-b17a-43af-af7e-48ac6febcabb	cpu_usage	gauge	6.000000	{}	2025-09-03 18:16:13.57+00
96774761-f531-41b7-ac8c-bc652b25b637	uptime	gauge	1749.373588	{}	2025-09-03 18:17:13.571+00
b9980662-4a56-4205-b318-b241da9fbf07	disk_usage	gauge	45.200000	{}	2025-09-03 18:18:13.571+00
cc6d240b-a188-4589-b90a-3012f781eeae	cpu_usage	gauge	6.000000	{}	2025-09-03 17:15:57.652+00
eb3a530a-1d2b-415f-89c2-c61d666102df	memory_usage	gauge	73.550000	{}	2025-09-03 17:15:57.652+00
aaa1b317-20a7-42c6-9ef5-3af8e4cb4c37	disk_usage	gauge	45.200000	{}	2025-09-03 17:15:57.652+00
2c048d53-fac5-4e5e-9906-0901f44557fb	uptime	gauge	69.177471	{}	2025-09-03 17:15:57.652+00
d567945e-f155-485f-8811-f2ef3dcb49e6	uptime	gauge	129.178474	{}	2025-09-03 17:16:57.653+00
abbb9092-bf91-43dc-8dc3-a77db7b1fd1c	memory_usage	gauge	73.390000	{}	2025-09-03 17:17:57.654+00
4f0f973c-2f4b-4eff-a256-8ad0b0589b89	memory_usage	gauge	73.430000	{}	2025-09-03 17:18:57.655+00
60177094-40fa-4e45-8b4c-3a4ab972d8bb	disk_usage	gauge	45.200000	{}	2025-09-03 17:19:57.659+00
ef850883-0710-4e8b-92e2-be42553211f7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:20:57.659+00
2373de2e-cdc7-42c5-bd67-6e68a244d78b	uptime	gauge	429.185337	{}	2025-09-03 17:21:57.66+00
bcbc7b93-e38c-43fc-8e06-535c3c30ccd0	disk_usage	gauge	45.200000	{}	2025-09-03 17:22:57.661+00
6510877d-0324-4ef4-b84f-0677456b9a63	disk_usage	gauge	45.200000	{}	2025-09-03 18:07:13.56+00
b833150c-09db-4e3e-8e57-6aad22b67afe	cpu_usage	gauge	6.000000	{}	2025-09-03 18:08:13.561+00
38b3192c-e1aa-40af-ae75-fa98af0c3483	uptime	gauge	1269.365035	{}	2025-09-03 18:09:13.562+00
53c7cfb3-ffe7-4dec-b2dd-e2e0824007ee	disk_usage	gauge	45.200000	{}	2025-09-03 18:10:13.563+00
a93b57ef-8071-4359-9490-3deab54afd05	memory_usage	gauge	69.730000	{}	2025-09-03 18:11:13.564+00
334bdbf0-98f3-4535-b662-b591e06ac283	cpu_usage	gauge	6.000000	{}	2025-09-03 18:12:13.566+00
4e1d3d51-f6b5-4697-be2e-b013e68a879e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:13:13.567+00
6a0c80b0-3831-48ad-9d75-0412ab2f673c	uptime	gauge	1569.371083	{}	2025-09-03 18:14:13.568+00
56c887b1-84ef-4044-bf8f-c50301dd974e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:15:13.569+00
63fd6f7e-e80d-4ca3-b5e8-aca5e2fc1a69	uptime	gauge	1689.373051	{}	2025-09-03 18:16:13.57+00
e872e324-4cff-48b9-9a38-b684a5b0572a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:17:13.571+00
a0f562ca-5450-4962-b777-654721a53be2	uptime	gauge	1809.373791	{}	2025-09-03 18:18:13.571+00
be334deb-a194-4e03-ab51-ba8398200c94	cpu_usage	gauge	6.000000	{}	2025-09-03 17:16:57.653+00
8d7cfbec-fdd6-4b08-8dea-965d13cdbfb8	uptime	gauge	189.179006	{}	2025-09-03 17:17:57.654+00
f00f1e09-74ff-4b06-8797-59b66346324f	disk_usage	gauge	45.200000	{}	2025-09-03 17:18:57.655+00
6d36a95e-93e2-4ac5-99df-6a603ab2f11d	memory_usage	gauge	73.340000	{}	2025-09-03 17:19:57.659+00
96c5dfd1-f696-4a8c-86e2-7ee3c465599e	memory_usage	gauge	73.480000	{}	2025-09-03 17:20:57.66+00
080b7989-3817-4ba6-86f3-c035eb6feaf5	memory_usage	gauge	73.480000	{}	2025-09-03 17:21:57.66+00
07e93c27-27ea-43de-9db8-60ca815dd2f4	uptime	gauge	489.186048	{}	2025-09-03 17:22:57.661+00
dfa54aeb-b5e8-4204-92c1-332c8444374b	uptime	gauge	1149.362512	{}	2025-09-03 18:07:13.56+00
4ecdbff2-dc03-4ecb-a7c8-9b632f86c73f	disk_usage	gauge	45.200000	{}	2025-09-03 18:08:13.561+00
972d3d3a-b6e9-4f98-9672-6e42f49597c7	cpu_usage	gauge	6.000000	{}	2025-09-03 18:09:13.562+00
b3c16b68-f711-45b5-a94b-f5ab82285848	cpu_usage	gauge	6.000000	{}	2025-09-03 18:10:13.563+00
ac1cf103-1f0a-4558-873e-44622d7375a3	uptime	gauge	1389.366537	{}	2025-09-03 18:11:13.564+00
8a0d0905-ec9d-4538-b555-01bad9bb7ed8	disk_usage	gauge	45.200000	{}	2025-09-03 18:12:13.566+00
4ff1200d-6ce5-4f0c-9d34-eab3c972f03c	disk_usage	gauge	45.200000	{}	2025-09-03 18:13:13.567+00
9539ea33-6d2a-455a-b582-8b988b1589d7	memory_usage	gauge	69.450000	{}	2025-09-03 18:14:13.568+00
910ba5f6-b593-451a-9d23-f5750e45b5f0	disk_usage	gauge	45.200000	{}	2025-09-03 18:15:13.569+00
ea393711-2455-4652-bfb0-f67e1825b695	disk_usage	gauge	45.200000	{}	2025-09-03 18:16:13.57+00
9a5413e9-af5d-44e5-964c-0786a1a8c451	disk_usage	gauge	45.200000	{}	2025-09-03 18:17:13.571+00
288c21bc-bb4d-4fdb-ba19-c07dba87e187	memory_usage	gauge	69.450000	{}	2025-09-03 18:18:13.571+00
eabdfb0a-1b4e-4568-ba12-e881a470cf38	memory_usage	gauge	73.550000	{}	2025-09-03 17:16:57.653+00
5ace40fe-84c6-42ae-86e5-39df46b4d595	cpu_usage	gauge	6.000000	{}	2025-09-03 17:17:57.654+00
81e133a1-7a1a-40c7-80f9-a728802a4afa	uptime	gauge	249.180038	{}	2025-09-03 17:18:57.655+00
eb687907-f990-4a2b-904b-10e92a4a58c4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:19:57.659+00
2a385943-0f33-4274-8c36-d0228dcc15c0	uptime	gauge	369.184574	{}	2025-09-03 17:20:57.66+00
a8dbddb4-a7f4-4e77-9cac-ae7f50953432	disk_usage	gauge	45.200000	{}	2025-09-03 17:21:57.66+00
25997b9d-8821-406b-b9cb-ab82f45997a1	memory_usage	gauge	73.510000	{}	2025-09-03 17:22:57.661+00
85cb48eb-bf53-41df-a5f2-cd2d67b808a0	cpu_usage	gauge	6.000000	{}	2025-09-03 18:19:55.008+00
2cf6d1c1-13c7-4e31-87e0-2fc6198a0a78	memory_usage	gauge	70.240000	{}	2025-09-03 18:19:55.008+00
27d15cea-8017-43ce-ae19-2bddf3353f48	uptime	gauge	67.944511	{}	2025-09-03 18:19:55.009+00
5001f8ec-c1bb-4c03-ad7f-e240fb893a8d	disk_usage	gauge	45.200000	{}	2025-09-03 17:16:57.653+00
2471561c-cbe9-474e-9646-4acf1ff126df	disk_usage	gauge	45.200000	{}	2025-09-03 17:17:57.654+00
ba021b83-7ab8-4d02-833f-2fb82658f2ee	cpu_usage	gauge	6.000000	{}	2025-09-03 17:18:57.655+00
10c265b0-4c9d-41d2-bed2-fbd69b8b0881	uptime	gauge	309.184296	{}	2025-09-03 17:19:57.659+00
8e84707d-e378-41d5-b39a-406acea47f78	disk_usage	gauge	45.200000	{}	2025-09-03 17:20:57.66+00
a20131f7-4c47-44ba-be21-d448dc9aff0f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:21:57.66+00
5851af99-3611-4bf5-a7a8-456c0dfc3c39	cpu_usage	gauge	6.000000	{}	2025-09-03 17:22:57.661+00
c994aac7-3388-4bb6-8ab7-2f5a42bd0c9d	disk_usage	gauge	45.200000	{}	2025-09-03 18:19:55.009+00
1bbf7112-8d46-48d7-8236-e8008ce89630	memory_usage	gauge	73.510000	{}	2025-09-03 17:23:57.661+00
2f6a5f2c-3b75-4bbd-88b0-66d1ed2c5e30	uptime	gauge	609.186876	{}	2025-09-03 17:24:57.662+00
2cd23b75-439d-474c-a15f-ea6988075648	disk_usage	gauge	45.200000	{}	2025-09-03 17:25:57.663+00
44e3c031-099d-491e-98ac-ae4f49d9cfe0	disk_usage	gauge	45.200000	{}	2025-09-03 17:26:57.663+00
fcbe8b10-4ad9-40d2-8d3e-db032ddefee9	disk_usage	gauge	45.200000	{}	2025-09-03 17:27:57.665+00
062a51cf-cd46-4c29-9bdf-9f3c9f015428	cpu_usage	gauge	6.000000	{}	2025-09-03 17:28:57.666+00
fcf14e4f-cd2a-494e-96ba-ae778bd37e55	uptime	gauge	909.190355	{}	2025-09-03 17:29:57.665+00
daa2ca23-89d4-4685-8344-833313fd17fd	disk_usage	gauge	45.200000	{}	2025-09-03 17:30:57.666+00
1744df53-1cd0-4a74-a459-f5a91dc99b8b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:31:57.667+00
24cd93d5-9348-4f8f-8f60-d80f8dce486c	uptime	gauge	1089.192565	{}	2025-09-03 17:32:57.668+00
72e0fd3f-aa1b-4762-98fb-b53086f40f7c	memory_usage	gauge	79.000000	{}	2025-09-03 17:33:57.668+00
3b9ec0a2-c04d-4b91-a3c3-73b1ff6e6a48	cpu_usage	gauge	6.000000	{}	2025-09-03 17:34:57.669+00
def2efb6-fb4a-456e-b82e-0040be90cb58	uptime	gauge	1269.194585	{}	2025-09-03 17:35:57.67+00
889c4765-2c3f-4a0d-adfa-56f789e8e0eb	memory_usage	gauge	79.230000	{}	2025-09-03 17:36:57.67+00
58f22014-c053-4966-939f-07b511774886	cpu_usage	gauge	6.000000	{}	2025-09-03 17:37:57.671+00
c91735ee-6ba6-48bb-9c46-3cf1b9512c7e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:21:49.691+00
483cbeed-1dd7-4d34-bf18-c44dd8d66553	memory_usage	gauge	70.280000	{}	2025-09-03 18:21:49.691+00
88af6154-594c-4d2f-a827-b2933fe388dc	uptime	gauge	68.127091	{}	2025-09-03 18:21:49.691+00
f4d96af7-641a-49fb-ac5f-541c27d3f709	cpu_usage	gauge	6.000000	{}	2025-09-03 17:23:57.661+00
f68bf990-baf5-4780-8e28-fd818489f36d	disk_usage	gauge	45.200000	{}	2025-09-03 17:24:57.662+00
88cd1712-20cb-4f58-80ba-4936c6d5ec63	cpu_usage	gauge	6.000000	{}	2025-09-03 17:25:57.663+00
e4819dce-e111-4483-ae3f-db3008fa2239	cpu_usage	gauge	6.000000	{}	2025-09-03 17:26:57.663+00
03399bde-61ab-4162-8872-61e261812f8d	uptime	gauge	789.189898	{}	2025-09-03 17:27:57.665+00
31fbd92e-a5bc-4d7a-b616-c01dc82be3dc	disk_usage	gauge	45.200000	{}	2025-09-03 17:28:57.666+00
9e314934-1998-4ef9-b02e-2182b7da2b46	memory_usage	gauge	73.270000	{}	2025-09-03 17:29:57.665+00
1714a085-a281-46e8-98ea-007a39126866	memory_usage	gauge	79.090000	{}	2025-09-03 17:30:57.666+00
9b6165b7-9f79-4a2a-9581-1079720bbe05	disk_usage	gauge	45.200000	{}	2025-09-03 17:31:57.667+00
1b5c0aa3-8d80-4e2b-9ca1-d3fdde8ebb74	cpu_usage	gauge	6.000000	{}	2025-09-03 17:32:57.667+00
ba9a3291-6ed6-4d83-9200-b8a9f415370c	uptime	gauge	1149.193574	{}	2025-09-03 17:33:57.669+00
ff8a9ce7-11ed-4d6a-b745-0a9bc6d1c205	disk_usage	gauge	45.200000	{}	2025-09-03 17:34:57.669+00
795decb9-2601-4ea4-8832-969100ce836f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:35:57.669+00
26d986f9-1670-4c1f-9a42-10ff45b8b568	uptime	gauge	1329.195144	{}	2025-09-03 17:36:57.67+00
b6a526bb-f30b-4f2f-ad9c-89139af15e67	memory_usage	gauge	70.630000	{}	2025-09-03 17:37:57.671+00
ee709e3e-7593-460a-802b-deb833e35d09	disk_usage	gauge	45.200000	{}	2025-09-03 18:21:49.691+00
0a15b3b4-f379-46ce-8af9-d168c44aeab2	uptime	gauge	549.186378	{}	2025-09-03 17:23:57.661+00
6ad01ea6-a1b0-4861-ac7a-cf5b268b0d41	memory_usage	gauge	73.440000	{}	2025-09-03 17:24:57.662+00
080ba86e-9f31-4204-b38c-e90c8b2a77d9	memory_usage	gauge	73.290000	{}	2025-09-03 17:25:57.663+00
3ff50c4b-05fd-45a2-9ce4-5f812d801dcc	uptime	gauge	729.188507	{}	2025-09-03 17:26:57.664+00
17b57c47-d80e-499e-910c-9ad81f551601	cpu_usage	gauge	6.000000	{}	2025-09-03 17:27:57.665+00
d30d63f4-b05a-42ca-8251-dd0974c9f211	uptime	gauge	849.190754	{}	2025-09-03 17:28:57.666+00
0354ef2e-c075-4603-81ad-1041c473b55a	disk_usage	gauge	45.200000	{}	2025-09-03 17:29:57.665+00
d3cac468-ee13-4041-acec-b41034829f5b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:30:57.666+00
801992ad-7028-4db7-b364-0e35e490e596	uptime	gauge	1029.191988	{}	2025-09-03 17:31:57.667+00
59646754-93a8-412e-bc0f-e7784855684f	disk_usage	gauge	45.200000	{}	2025-09-03 17:32:57.668+00
6b064bf2-3dc2-44b4-a9be-0bbed2ab5179	cpu_usage	gauge	6.000000	{}	2025-09-03 17:33:57.668+00
708e52d0-2c6a-4fb5-b20b-c4cb82132c22	uptime	gauge	1209.193943	{}	2025-09-03 17:34:57.669+00
e074298f-ffd9-4507-8fec-a87be44ed43c	memory_usage	gauge	79.260000	{}	2025-09-03 17:35:57.669+00
c6706d36-d4b3-494b-ab8c-89a1f5734be5	disk_usage	gauge	45.200000	{}	2025-09-03 17:36:57.67+00
d8b3eabb-e71e-4ae2-837f-b7346af424f0	disk_usage	gauge	45.200000	{}	2025-09-03 17:37:57.671+00
d0532994-ee21-4ceb-8950-934296b1019d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:22:49.692+00
13937912-20b8-4113-be57-e493a12cecca	disk_usage	gauge	45.200000	{}	2025-09-03 17:23:57.661+00
c3d1bd23-f8fe-4eae-916f-1f934f4b8cb4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:24:57.662+00
629a556a-601b-4458-9128-4e2dc1dc36a1	uptime	gauge	669.187821	{}	2025-09-03 17:25:57.663+00
fe1a93fc-9c50-4b43-95fc-0dfa6faa1c84	memory_usage	gauge	73.500000	{}	2025-09-03 17:26:57.663+00
9044d786-8e5b-434c-91bb-6da09a6e63c7	memory_usage	gauge	73.470000	{}	2025-09-03 17:27:57.665+00
bc2c7d0c-d302-4a4a-b821-e05a2137bab3	memory_usage	gauge	73.500000	{}	2025-09-03 17:28:57.666+00
59064047-9b82-45b7-b979-3bb383932649	cpu_usage	gauge	6.000000	{}	2025-09-03 17:29:57.665+00
f09aa6f5-024f-407e-b134-c91a1ed0d58a	uptime	gauge	969.191058	{}	2025-09-03 17:30:57.666+00
0066939d-34fc-406b-b5d3-b45f58a5d07a	memory_usage	gauge	79.090000	{}	2025-09-03 17:31:57.667+00
91090694-2e39-426f-92c3-2fda79d9f25e	memory_usage	gauge	79.030000	{}	2025-09-03 17:32:57.667+00
4b196780-ab90-448c-aa9a-0a19e2c8b3dc	disk_usage	gauge	45.200000	{}	2025-09-03 17:33:57.669+00
541b6742-58d4-48d8-a3d6-066aadbc1ea8	memory_usage	gauge	79.030000	{}	2025-09-03 17:34:57.669+00
88d3ce6e-0da9-4fbc-92f8-ba3c8fe03f9e	disk_usage	gauge	45.200000	{}	2025-09-03 17:35:57.67+00
c755aada-643f-44d8-bb4e-33d75d883543	cpu_usage	gauge	6.000000	{}	2025-09-03 17:36:57.67+00
a9020538-270b-4b5c-b26e-56433f08e4a9	uptime	gauge	1389.195707	{}	2025-09-03 17:37:57.671+00
1f36ad7d-9d78-4452-9f77-147951a9eecf	disk_usage	gauge	45.200000	{}	2025-09-03 18:22:49.692+00
36417aae-1a99-480f-9ad7-2ecbc8002489	memory_usage	gauge	79.130000	{}	2025-09-03 17:31:21.877+00
de4a318e-3ef9-498c-ae48-7c86aa7e4296	uptime	gauge	128.129944	{}	2025-09-03 17:32:21.878+00
ffb275b7-ba7c-4899-9d95-dbc249ceb8bc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:33:21.878+00
8987639c-9835-4f5a-af94-6e2d769983d3	uptime	gauge	248.130245	{}	2025-09-03 17:34:21.878+00
7e2b28cc-99bb-4acc-ba99-3434033aeb84	disk_usage	gauge	45.200000	{}	2025-09-03 17:35:21.896+00
b13f1be4-e9a2-41f2-b116-949c06980a9a	cpu_usage	gauge	6.000000	{}	2025-09-03 17:36:21.896+00
046fa173-5f02-4249-86d5-02970d53c8e2	memory_usage	gauge	70.760000	{}	2025-09-03 18:22:49.692+00
c0251be2-bbab-4abd-b534-d5369a7d0b29	cpu_usage	gauge	6.000000	{}	2025-09-03 17:31:21.877+00
f2666d49-e82b-49e6-8c8d-47c09ec09a14	memory_usage	gauge	79.130000	{}	2025-09-03 17:32:21.877+00
24264319-6b2a-46ad-98e1-5f8dcacdfca1	memory_usage	gauge	79.070000	{}	2025-09-03 17:33:21.878+00
bdcd56fe-a253-419e-a565-66221eb165be	cpu_usage	gauge	6.000000	{}	2025-09-03 17:34:21.878+00
58393ffe-d320-499f-8196-172d873b3909	uptime	gauge	308.148617	{}	2025-09-03 17:35:21.896+00
0b573faf-d572-4189-98ba-cb936d961496	disk_usage	gauge	45.200000	{}	2025-09-03 17:36:21.896+00
cd20be01-35ba-4a49-a75b-85520bfe00c0	uptime	gauge	128.127564	{}	2025-09-03 18:22:49.692+00
2c70287d-e94d-4e8a-a96a-1f120bbb3263	disk_usage	gauge	45.200000	{}	2025-09-03 17:31:21.878+00
99dd1e0f-2d4e-4529-b4ff-5dc4e93ad707	disk_usage	gauge	45.200000	{}	2025-09-03 17:32:21.878+00
ff4ced47-4133-48ff-8330-f96c1be6111d	disk_usage	gauge	45.200000	{}	2025-09-03 17:33:21.878+00
e0e0d6a7-cca0-4945-9de2-ea45236f3dd1	memory_usage	gauge	79.030000	{}	2025-09-03 17:34:21.878+00
bd01913d-aaf5-44d5-82aa-2fbffee5df55	memory_usage	gauge	79.140000	{}	2025-09-03 17:35:21.896+00
f8d33af6-0a7b-4eb3-8f97-512c5bf73e1e	memory_usage	gauge	79.490000	{}	2025-09-03 17:36:21.896+00
710e6b75-94bb-4953-b7c7-00455cb4c0af	uptime	gauge	68.129961	{}	2025-09-03 17:31:21.878+00
40817c41-def0-4764-a6df-d13c621c14a2	cpu_usage	gauge	6.000000	{}	2025-09-03 17:32:21.877+00
ea506bb9-da97-4a5b-916b-1bcad3c27027	uptime	gauge	188.130180	{}	2025-09-03 17:33:21.878+00
e677f4da-30aa-40a6-b74c-a2312f080ad7	disk_usage	gauge	45.200000	{}	2025-09-03 17:34:21.878+00
2f14a29f-be35-4d30-8ddf-e0381db7fb32	cpu_usage	gauge	6.000000	{}	2025-09-03 17:35:21.896+00
4b7c0c27-f188-4d11-93a9-4d6a3593f90e	uptime	gauge	368.148572	{}	2025-09-03 17:36:21.896+00
fe3d5110-4db6-4c81-b071-c2571f6cebd9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:38:57.671+00
5eaad519-da9e-44d2-8192-deba09e229f3	uptime	gauge	1509.197459	{}	2025-09-03 17:39:57.672+00
fcb9a5f2-f066-4423-a53e-863eab8edb15	disk_usage	gauge	45.200000	{}	2025-09-03 17:40:57.673+00
3e02f088-eb78-4e90-a71f-d53a1297fc24	memory_usage	gauge	75.520000	{}	2025-09-03 17:41:57.674+00
b9117f03-7c70-45a7-b915-54e761298d47	cpu_usage	gauge	6.000000	{}	2025-09-03 17:42:57.674+00
4c38d4c7-bae2-4e2e-8329-3439df3f7988	uptime	gauge	1749.198903	{}	2025-09-03 17:43:57.674+00
fee599d4-2852-4f9b-90a6-d4f8ad2829b6	disk_usage	gauge	45.200000	{}	2025-09-03 17:44:57.674+00
221199d9-7df6-47f8-909c-4905df8a7914	cpu_usage	gauge	6.000000	{}	2025-09-03 17:45:57.674+00
fffac2b1-4091-46fe-8578-36f72f214141	uptime	gauge	1929.199173	{}	2025-09-03 17:46:57.674+00
8af9f7d5-29f5-4f7b-8455-a5eb1be777be	memory_usage	gauge	76.370000	{}	2025-09-03 17:38:57.671+00
799c340e-1060-4683-8785-9d6151806de5	memory_usage	gauge	74.950000	{}	2025-09-03 17:39:57.672+00
fae9ae07-0f51-4954-b795-53a814086352	memory_usage	gauge	75.310000	{}	2025-09-03 17:40:57.673+00
3008853d-9ee1-48c7-9cb5-787bfae91675	disk_usage	gauge	45.200000	{}	2025-09-03 17:41:57.674+00
7c3c6e9e-4aee-445d-b08e-46bef6f7a304	disk_usage	gauge	45.200000	{}	2025-09-03 17:42:57.674+00
6b9127fa-a1fa-4524-80c7-594a09557db2	memory_usage	gauge	75.780000	{}	2025-09-03 17:43:57.674+00
c4aff36a-f867-47bc-add7-146701fe3d8e	memory_usage	gauge	74.730000	{}	2025-09-03 17:44:57.674+00
a9dc8fa0-25ad-486a-bad1-679643469a8b	memory_usage	gauge	69.380000	{}	2025-09-03 17:45:57.674+00
29e8a401-008b-4d39-903d-98eb2ffcb34b	disk_usage	gauge	45.200000	{}	2025-09-03 17:46:57.674+00
9bca934f-8695-46a4-8408-d4793599582e	uptime	gauge	1449.196557	{}	2025-09-03 17:38:57.672+00
89a5b4e0-6121-460c-a598-15876b8e40a0	disk_usage	gauge	45.200000	{}	2025-09-03 17:39:57.672+00
fce4ae47-dc85-4c73-8c4a-b8cdda4dae3e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:40:57.673+00
85dffb14-f790-47bd-a911-1e540456baab	uptime	gauge	1629.198934	{}	2025-09-03 17:41:57.674+00
c4ab9ca6-d1c0-40ad-9e34-d0adb0a1f722	memory_usage	gauge	69.660000	{}	2025-09-03 17:42:57.674+00
7d91ed18-0fa6-4112-b19f-25b6c8f5a509	cpu_usage	gauge	6.000000	{}	2025-09-03 17:43:57.674+00
d3abe193-3a28-4271-83e4-3465be6d48e8	uptime	gauge	1809.198974	{}	2025-09-03 17:44:57.674+00
ddc29f95-ebfe-4d68-972a-b473f5ee3697	disk_usage	gauge	45.200000	{}	2025-09-03 17:45:57.674+00
97271414-8b80-401d-9a9c-092086162181	cpu_usage	gauge	6.000000	{}	2025-09-03 17:46:57.674+00
b0ec73ec-05a4-41ce-a948-c185826dbd54	disk_usage	gauge	45.200000	{}	2025-09-03 17:38:57.672+00
ac9c68e5-d876-430b-91fd-0e6e2a1c3410	cpu_usage	gauge	6.000000	{}	2025-09-03 17:39:57.672+00
309b457e-be8f-409b-bb9d-a06fde29fcd8	uptime	gauge	1569.198065	{}	2025-09-03 17:40:57.673+00
d71ce269-5c80-407d-afa1-f018347e00ef	cpu_usage	gauge	6.000000	{}	2025-09-03 17:41:57.674+00
078ae03f-d1ff-46a8-a458-cfc73b02494d	uptime	gauge	1689.199280	{}	2025-09-03 17:42:57.674+00
04ee2b2c-d2dc-4d84-974c-d693aa46fb91	disk_usage	gauge	45.200000	{}	2025-09-03 17:43:57.674+00
440c1c06-07ed-4869-8e5d-2353d6b55492	cpu_usage	gauge	6.000000	{}	2025-09-03 17:44:57.674+00
8c56fa39-c143-4c5f-b813-d991ae742d5b	uptime	gauge	1869.199001	{}	2025-09-03 17:45:57.674+00
3786a258-f6c4-433c-8e6f-c638889021f2	memory_usage	gauge	70.310000	{}	2025-09-03 17:46:57.674+00
8c85cc30-28e9-477e-8d2c-404778cc91a1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:39:23.806+00
26ebe056-6cff-4f48-a7e1-68f5417523dc	memory_usage	gauge	75.370000	{}	2025-09-03 17:39:23.806+00
f60af6e3-9040-4861-b6d3-cef212220f11	uptime	gauge	68.061418	{}	2025-09-03 17:39:23.806+00
02c86c92-611c-4d24-a2e1-cd3d0d8a548b	memory_usage	gauge	75.940000	{}	2025-09-03 17:40:23.805+00
5ddc8442-3b42-4bab-bf33-0e4ee46f2d77	disk_usage	gauge	45.200000	{}	2025-09-03 17:41:23.806+00
af6d2068-bace-4835-b683-0ce0f1f1e48c	disk_usage	gauge	45.200000	{}	2025-09-03 17:42:23.806+00
800ce171-2b79-48f1-a877-c596f7d1d5d9	disk_usage	gauge	45.200000	{}	2025-09-03 17:39:23.806+00
05d91215-4be2-4ee9-8bbb-7e17ef0c6be5	cpu_usage	gauge	6.000000	{}	2025-09-03 17:40:23.805+00
377c33d9-e54d-4934-a050-e319e14c8ca0	uptime	gauge	188.060981	{}	2025-09-03 17:41:23.806+00
9592603a-aebd-400e-aed3-292b4df76954	memory_usage	gauge	75.600000	{}	2025-09-03 17:42:23.806+00
41e4600e-d2b1-474a-84cf-6c852b6e1326	disk_usage	gauge	45.200000	{}	2025-09-03 17:40:23.805+00
e36ec16a-fd6e-4c68-8460-21e79986dffd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:41:23.805+00
89d4effd-7509-4eb7-9d04-5604d97b601b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:42:23.806+00
66d39e8b-d955-4d3a-8515-4136b1f1eba0	uptime	gauge	128.060097	{}	2025-09-03 17:40:23.805+00
4d6958ef-9395-4bb6-8880-f60b7d4ba1ff	memory_usage	gauge	75.640000	{}	2025-09-03 17:41:23.805+00
daf4a31e-f83b-499b-abdb-458dd741a747	uptime	gauge	248.061567	{}	2025-09-03 17:42:23.806+00
d3e2442d-f582-479d-9cb2-17385aa5bfeb	cpu_usage	gauge	6.000000	{}	2025-09-03 17:44:34.867+00
b4ee41ec-9a53-47b0-bfee-4952c1e79fb5	memory_usage	gauge	74.730000	{}	2025-09-03 17:44:34.867+00
96785670-a783-464c-a686-3f939805ba94	disk_usage	gauge	45.200000	{}	2025-09-03 17:44:34.867+00
a8f0bf05-4139-42d9-b92f-d393075847db	uptime	gauge	67.975370	{}	2025-09-03 17:44:34.867+00
a59b9e8b-60b2-4f7d-8734-db284048f3c3	memory_usage	gauge	76.600000	{}	2025-09-03 16:48:36.215+00
763cea63-655e-43b6-a8b8-51c1a79f1f6d	memory_usage	gauge	76.550000	{}	2025-09-03 16:49:36.215+00
\.


--
-- TOC entry 4323 (class 0 OID 17239)
-- Dependencies: 253
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, user_id, user_name, user_avatar, content, rating, is_verified, is_public, is_featured, tags, metadata, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4332 (class 0 OID 17475)
-- Dependencies: 262
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, product_id, retailer_slug, rule_id, user_id_hash, status, price_paid, msrp, qty, alert_at, added_to_cart_at, purchased_at, lead_time_ms, failure_reason, region, session_fingerprint, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4309 (class 0 OID 16942)
-- Dependencies: 239
-- Data for Name: trend_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trend_analysis (id, product_id, price_trend, availability_trend, demand_score, volatility_score, analyzed_at) FROM stdin;
2f11f655-9650-48ba-8b0d-4f69eb32d5de	210293d2-cc9d-4fca-be6e-41df29fdd537	0.228118	0.000000	\N	\N	2025-09-03 18:00:01.006+00
a46f01e4-ba67-47d0-a526-4dceeccd2033	2ce8c976-7e46-4546-9ec5-7a7fbcbf9434	0.128529	0.171429	\N	\N	2025-09-03 18:00:01.007+00
f26fa6c8-a6fd-47ad-98de-f1f236975a5e	325f8360-7200-4d59-b46e-4134bd6bacc3	-0.039930	0.000000	\N	\N	2025-09-03 18:00:01.008+00
45c9fd86-5acc-4d7f-a209-ae006bb1327a	345a6e90-30bb-49d2-bf67-7b4377955cfa	-0.431049	0.085714	\N	\N	2025-09-03 18:00:01.009+00
3767c018-9922-49ce-913b-dcabdc87eca2	418e4d95-5e24-45ab-9d82-9f8fc0410132	0.000897	0.028571	\N	\N	2025-09-03 18:00:01.011+00
1755f259-c363-4501-b7cc-0baaba2dd218	464f5a27-cbb5-4107-8ebd-f1a6fe286487	0.017176	-0.057143	\N	\N	2025-09-03 18:00:01.012+00
7a35d052-05c9-4193-af07-b67228a39fd4	485c2cb8-71b4-4da7-aa48-72a06a2a6da2	-0.131765	0.228571	\N	\N	2025-09-03 18:00:01.013+00
c0324279-ba38-4e3c-9794-9af0c9d8f4a4	5b266066-2106-40ae-b282-949dc23491a9	0.448571	-0.057143	\N	\N	2025-09-03 18:00:01.014+00
c47c33ef-a919-4dd4-b189-873be2dfff4b	669e93c6-5846-4046-8d40-d94bfd34b780	-0.038712	-0.085714	\N	\N	2025-09-03 18:00:01.016+00
fafe5ac8-0935-49aa-a4f6-904ce48c5137	69e556c3-ee7f-4ac8-85da-35345a52cf5a	-0.080588	0.228571	\N	\N	2025-09-03 18:00:01.017+00
8d5a93ad-4d50-483d-90a0-bd05945695b2	70d4f1e4-5102-48d0-9d9e-fecee9c07fb2	-0.004706	0.000000	\N	\N	2025-09-03 18:00:01.018+00
1eb418b2-f107-4034-931d-e453f82ffe2e	7cbb19fa-f7bd-49f8-84f8-07f983c84132	0.246015	0.142857	\N	\N	2025-09-03 18:00:01.019+00
242f53c4-0404-463b-b266-c135c7f1a2e8	9975f314-970f-4dda-9c8f-61a36558666f	0.114941	-0.114286	\N	\N	2025-09-03 18:00:01.02+00
93f2dc4a-1362-4499-9eec-5d225cc72a1b	9ac1687e-3ccb-420c-8b08-c84e856bfaf2	0.011000	0.000000	\N	\N	2025-09-03 18:00:01.021+00
835a1404-995d-409a-8090-ae3b3d0aacb7	afccfd8f-9743-44a5-ba87-0f2ab1048f97	0.061235	0.057143	\N	\N	2025-09-03 18:00:01.022+00
57869bdc-9c2c-4c9f-b55e-755e4a450358	b4dfaf4f-ce1b-4386-ae65-65512832d284	-0.013356	0.000000	\N	\N	2025-09-03 18:00:01.023+00
720dab82-7c8e-494e-a355-81c7b8983a98	d6ca80c9-732a-49c7-ab46-2a4c71a86110	0.399161	0.142857	\N	\N	2025-09-03 18:00:01.025+00
1665b342-6cdf-4ded-a77a-76ed9f69dda0	e07633f1-7182-4567-a6c5-60456b332f0c	0.055105	-0.142857	\N	\N	2025-09-03 18:00:01.026+00
c40fe112-9cb2-4215-bda5-6d6fcdb33a9d	f1f9a969-2c82-453c-a6a3-775d3bf365ca	-0.093412	-0.057143	\N	\N	2025-09-03 18:00:01.027+00
\.


--
-- TOC entry 4305 (class 0 OID 16851)
-- Dependencies: 235
-- Data for Name: unsubscribe_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unsubscribe_tokens (id, token, user_id, email_type, expires_at, used_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4329 (class 0 OID 17385)
-- Dependencies: 259
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assignment_reason, assigned_at, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4301 (class 0 OID 16792)
-- Dependencies: 231
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, refresh_token, device_info, ip_address, user_agent, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4297 (class 0 OID 16673)
-- Dependencies: 227
-- Data for Name: user_watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_watch_packs (id, user_id, watch_pack_id, customizations, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4286 (class 0 OID 16477)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, subscription_tier, created_at, updated_at, email_verified, verification_token, reset_token, reset_token_expires, failed_login_attempts, locked_until, last_login, shipping_addresses, payment_methods, retailer_credentials, notification_settings, quiet_hours, timezone, zip_code, push_subscriptions, role, last_admin_login, admin_permissions, first_name, last_name, preferences, newsletter_subscription, terms_accepted, direct_permissions, role_last_updated, role_updated_by, permission_metadata, stripe_customer_id, subscription_id, subscription_status, subscription_start_date, subscription_end_date, trial_end_date, cancel_at_period_end, subscription_plan_id) FROM stdin;
84a8557a-b08e-405e-b391-16def0d2020d	test@boosterbeacon.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS	pro	2025-09-03 16:31:17.756398+00	2025-09-03 16:31:17.756398+00	f	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	[]	\N	\N	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
a7d94af5-6a3d-4b56-bdbf-52bec13375a1	admin@boosterbeacon.com	$2b$12$ftfCcN.wcekmC0SGMXUvB.1zzyHlyl5UyqD65Ryk/YKgax5P3L8j6	pro	2025-09-03 16:53:58.366645+00	2025-09-03 16:53:58.366645+00	t	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": true, "email": true, "discord": true, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	super_admin	\N	["user_management", "user_suspend", "user_delete", "ml_model_training", "ml_data_review", "system_monitoring", "analytics_view", "audit_log_view"]	Admin	User	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
0b5d6a4f-8fd8-439b-9d75-6e0933be5b7e	derekmihlfeith@gmail.com	$2b$12$Cuy.tpIf2h6fhYRnCUfU8OwiHQ.5gCW0xEwLP48F3WHQCG5IOBfBu	free	2025-09-03 17:06:05.918057+00	2025-09-03 18:22:54.035+00	t	\N	2851a820ce70f1433cd59c4c3a8911e0e4e01f67807699393bf983d29ed0d916	2025-09-03 19:22:54.035+00	0	\N	2025-09-03 18:22:18.679+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	Derek	Mihlfeith	{}	t	t	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
\.


--
-- TOC entry 4296 (class 0 OID 16656)
-- Dependencies: 226
-- Data for Name: watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watch_packs (id, name, slug, description, product_ids, is_active, auto_update, update_criteria, subscriber_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4295 (class 0 OID 16624)
-- Dependencies: 225
-- Data for Name: watches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watches (id, user_id, product_id, retailer_ids, max_price, availability_type, zip_code, radius_miles, is_active, alert_preferences, last_alerted, alert_count, created_at, updated_at, auto_purchase) FROM stdin;
\.


--
-- TOC entry 4320 (class 0 OID 17171)
-- Dependencies: 250
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, user_id, name, url, secret, events, headers, retry_config, filters, is_active, total_calls, successful_calls, failed_calls, last_triggered, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4345 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 17, true);


--
-- TOC entry 4346 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 3977 (class 2606 OID 17076)
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3885 (class 2606 OID 16761)
-- Name: alert_deliveries alert_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_pkey PRIMARY KEY (id);


--
-- TOC entry 3871 (class 2606 OID 16715)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3937 (class 2606 OID 16928)
-- Name: availability_snapshots availability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 4078 (class 2606 OID 17500)
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- TOC entry 4038 (class 2606 OID 17360)
-- Name: comment_likes comment_likes_comment_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_user_id_unique UNIQUE (comment_id, user_id);


--
-- TOC entry 4040 (class 2606 OID 17348)
-- Name: comment_likes comment_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4022 (class 2606 OID 17284)
-- Name: community_posts community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4086 (class 2606 OID 17516)
-- Name: conversion_analytics conversion_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversion_analytics
    ADD CONSTRAINT conversion_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4006 (class 2606 OID 17207)
-- Name: csv_operations csv_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_pkey PRIMARY KEY (id);


--
-- TOC entry 3971 (class 2606 OID 17051)
-- Name: data_quality_metrics data_quality_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3997 (class 2606 OID 17162)
-- Name: discord_servers discord_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_pkey PRIMARY KEY (id);


--
-- TOC entry 4000 (class 2606 OID 17169)
-- Name: discord_servers discord_servers_user_id_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_server_id_unique UNIQUE (user_id, server_id);


--
-- TOC entry 3930 (class 2606 OID 16872)
-- Name: email_bounces email_bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_bounces
    ADD CONSTRAINT email_bounces_pkey PRIMARY KEY (id);


--
-- TOC entry 3934 (class 2606 OID 16882)
-- Name: email_complaints email_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_complaints
    ADD CONSTRAINT email_complaints_pkey PRIMARY KEY (id);


--
-- TOC entry 3917 (class 2606 OID 16850)
-- Name: email_delivery_logs email_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3908 (class 2606 OID 16840)
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 3911 (class 2606 OID 16898)
-- Name: email_preferences email_preferences_unsubscribe_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_unsubscribe_token_unique UNIQUE (unsubscribe_token);


--
-- TOC entry 3958 (class 2606 OID 17006)
-- Name: engagement_metrics engagement_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3962 (class 2606 OID 17013)
-- Name: engagement_metrics engagement_metrics_product_id_metrics_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_metrics_date_unique UNIQUE (product_id, metrics_date);


--
-- TOC entry 4089 (class 2606 OID 17542)
-- Name: external_product_map external_product_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_pkey PRIMARY KEY (id);


--
-- TOC entry 4092 (class 2606 OID 17549)
-- Name: external_product_map external_product_map_retailer_slug_external_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_retailer_slug_external_id_unique UNIQUE (retailer_slug, external_id);


--
-- TOC entry 3816 (class 2606 OID 16508)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3814 (class 2606 OID 16501)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3954 (class 2606 OID 16985)
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3981 (class 2606 OID 17111)
-- Name: ml_models ml_models_name_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_name_version_unique UNIQUE (name, version);


--
-- TOC entry 3983 (class 2606 OID 17101)
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


--
-- TOC entry 3948 (class 2606 OID 16966)
-- Name: ml_predictions ml_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_pkey PRIMARY KEY (id);


--
-- TOC entry 3988 (class 2606 OID 17124)
-- Name: ml_training_data ml_training_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4063 (class 2606 OID 17427)
-- Name: permission_audit_log permission_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4027 (class 2606 OID 17307)
-- Name: post_comments post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_pkey PRIMARY KEY (id);


--
-- TOC entry 4031 (class 2606 OID 17327)
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 17339)
-- Name: post_likes post_likes_post_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_user_id_unique UNIQUE (post_id, user_id);


--
-- TOC entry 3889 (class 2606 OID 16777)
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3844 (class 2606 OID 16607)
-- Name: product_availability product_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_pkey PRIMARY KEY (id);


--
-- TOC entry 3847 (class 2606 OID 16619)
-- Name: product_availability product_availability_product_id_retailer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_retailer_id_unique UNIQUE (product_id, retailer_id);


--
-- TOC entry 3825 (class 2606 OID 16555)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3828 (class 2606 OID 16557)
-- Name: product_categories product_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_slug_unique UNIQUE (slug);


--
-- TOC entry 3832 (class 2606 OID 16578)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3837 (class 2606 OID 16580)
-- Name: products products_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_unique UNIQUE (slug);


--
-- TOC entry 3840 (class 2606 OID 16582)
-- Name: products products_upc_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_upc_unique UNIQUE (upc);


--
-- TOC entry 3819 (class 2606 OID 16540)
-- Name: retailers retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (id);


--
-- TOC entry 3822 (class 2606 OID 16542)
-- Name: retailers retailers_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_slug_unique UNIQUE (slug);


--
-- TOC entry 4046 (class 2606 OID 17379)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 4048 (class 2606 OID 17377)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4050 (class 2606 OID 17381)
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- TOC entry 3966 (class 2606 OID 17027)
-- Name: seasonal_patterns seasonal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 4010 (class 2606 OID 17225)
-- Name: social_shares social_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_pkey PRIMARY KEY (id);


--
-- TOC entry 4066 (class 2606 OID 17468)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4068 (class 2606 OID 17470)
-- Name: subscription_plans subscription_plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_unique UNIQUE (slug);


--
-- TOC entry 4070 (class 2606 OID 17472)
-- Name: subscription_plans subscription_plans_stripe_price_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_stripe_price_id_unique UNIQUE (stripe_price_id);


--
-- TOC entry 3904 (class 2606 OID 16824)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 3994 (class 2606 OID 17143)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4016 (class 2606 OID 17256)
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- TOC entry 4076 (class 2606 OID 17485)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3943 (class 2606 OID 16948)
-- Name: trend_analysis trend_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_pkey PRIMARY KEY (id);


--
-- TOC entry 3922 (class 2606 OID 16861)
-- Name: unsubscribe_tokens unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3925 (class 2606 OID 16894)
-- Name: unsubscribe_tokens unsubscribe_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4054 (class 2606 OID 17396)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 17413)
-- Name: user_roles user_roles_user_id_role_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_unique UNIQUE (user_id, role_id);


--
-- TOC entry 3897 (class 2606 OID 16802)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3900 (class 2606 OID 16809)
-- Name: user_sessions user_sessions_refresh_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_unique UNIQUE (refresh_token);


--
-- TOC entry 3864 (class 2606 OID 16684)
-- Name: user_watch_packs user_watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3867 (class 2606 OID 16696)
-- Name: user_watch_packs user_watch_packs_user_id_watch_pack_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique UNIQUE (user_id, watch_pack_id);


--
-- TOC entry 3798 (class 2606 OID 16489)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3800 (class 2606 OID 16510)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3803 (class 2606 OID 16487)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3808 (class 2606 OID 17522)
-- Name: users users_stripe_customer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_unique UNIQUE (stripe_customer_id);


--
-- TOC entry 3810 (class 2606 OID 17524)
-- Name: users users_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_subscription_id_unique UNIQUE (subscription_id);


--
-- TOC entry 3859 (class 2606 OID 16668)
-- Name: watch_packs watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3862 (class 2606 OID 16670)
-- Name: watch_packs watch_packs_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_slug_unique UNIQUE (slug);


--
-- TOC entry 3851 (class 2606 OID 16639)
-- Name: watches watches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_pkey PRIMARY KEY (id);


--
-- TOC entry 3856 (class 2606 OID 16651)
-- Name: watches watches_user_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_product_id_unique UNIQUE (user_id, product_id);


--
-- TOC entry 4002 (class 2606 OID 17187)
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 3973 (class 1259 OID 17083)
-- Name: admin_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_action_created_at_index ON public.admin_audit_log USING btree (action, created_at);


--
-- TOC entry 3974 (class 1259 OID 17082)
-- Name: admin_audit_log_admin_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_admin_user_id_created_at_index ON public.admin_audit_log USING btree (admin_user_id, created_at);


--
-- TOC entry 3975 (class 1259 OID 17085)
-- Name: admin_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_created_at_index ON public.admin_audit_log USING btree (created_at);


--
-- TOC entry 3978 (class 1259 OID 17084)
-- Name: admin_audit_log_target_type_target_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_target_type_target_id_index ON public.admin_audit_log USING btree (target_type, target_id);


--
-- TOC entry 3882 (class 1259 OID 16767)
-- Name: alert_deliveries_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_alert_id_index ON public.alert_deliveries USING btree (alert_id);


--
-- TOC entry 3883 (class 1259 OID 16768)
-- Name: alert_deliveries_channel_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_channel_index ON public.alert_deliveries USING btree (channel);


--
-- TOC entry 3886 (class 1259 OID 16770)
-- Name: alert_deliveries_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_sent_at_index ON public.alert_deliveries USING btree (sent_at);


--
-- TOC entry 3887 (class 1259 OID 16769)
-- Name: alert_deliveries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_status_index ON public.alert_deliveries USING btree (status);


--
-- TOC entry 3869 (class 1259 OID 16744)
-- Name: alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_index ON public.alerts USING btree (created_at);


--
-- TOC entry 3872 (class 1259 OID 16742)
-- Name: alerts_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_priority_index ON public.alerts USING btree (priority);


--
-- TOC entry 3873 (class 1259 OID 16737)
-- Name: alerts_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_product_id_index ON public.alerts USING btree (product_id);


--
-- TOC entry 3874 (class 1259 OID 16738)
-- Name: alerts_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_retailer_id_index ON public.alerts USING btree (retailer_id);


--
-- TOC entry 3875 (class 1259 OID 16743)
-- Name: alerts_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_scheduled_for_index ON public.alerts USING btree (scheduled_for);


--
-- TOC entry 3876 (class 1259 OID 16740)
-- Name: alerts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_index ON public.alerts USING btree (status);


--
-- TOC entry 3877 (class 1259 OID 16746)
-- Name: alerts_status_priority_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_priority_created_at_index ON public.alerts USING btree (status, priority, created_at);


--
-- TOC entry 3878 (class 1259 OID 16741)
-- Name: alerts_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_index ON public.alerts USING btree (type);


--
-- TOC entry 3879 (class 1259 OID 16736)
-- Name: alerts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_index ON public.alerts USING btree (user_id);


--
-- TOC entry 3880 (class 1259 OID 16745)
-- Name: alerts_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_status_index ON public.alerts USING btree (user_id, status);


--
-- TOC entry 3881 (class 1259 OID 16739)
-- Name: alerts_watch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_watch_id_index ON public.alerts USING btree (watch_id);


--
-- TOC entry 3938 (class 1259 OID 16939)
-- Name: availability_snapshots_product_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_product_id_snapshot_time_index ON public.availability_snapshots USING btree (product_id, snapshot_time);


--
-- TOC entry 3939 (class 1259 OID 16940)
-- Name: availability_snapshots_retailer_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_retailer_id_snapshot_time_index ON public.availability_snapshots USING btree (retailer_id, snapshot_time);


--
-- TOC entry 3940 (class 1259 OID 16941)
-- Name: availability_snapshots_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_snapshot_time_index ON public.availability_snapshots USING btree (snapshot_time);


--
-- TOC entry 4036 (class 1259 OID 17361)
-- Name: comment_likes_comment_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_comment_id_index ON public.comment_likes USING btree (comment_id);


--
-- TOC entry 4041 (class 1259 OID 17362)
-- Name: comment_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_user_id_index ON public.comment_likes USING btree (user_id);


--
-- TOC entry 4019 (class 1259 OID 17293)
-- Name: community_posts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_created_at_index ON public.community_posts USING btree (created_at);


--
-- TOC entry 4020 (class 1259 OID 17292)
-- Name: community_posts_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_is_featured_is_public_index ON public.community_posts USING btree (is_featured, is_public);


--
-- TOC entry 4023 (class 1259 OID 17291)
-- Name: community_posts_type_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_type_moderation_status_index ON public.community_posts USING btree (type, moderation_status);


--
-- TOC entry 4024 (class 1259 OID 17290)
-- Name: community_posts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_user_id_index ON public.community_posts USING btree (user_id);


--
-- TOC entry 4083 (class 1259 OID 17519)
-- Name: conversion_analytics_event_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_date_index ON public.conversion_analytics USING btree (event_date);


--
-- TOC entry 4084 (class 1259 OID 17518)
-- Name: conversion_analytics_event_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_type_index ON public.conversion_analytics USING btree (event_type);


--
-- TOC entry 4087 (class 1259 OID 17517)
-- Name: conversion_analytics_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_user_id_index ON public.conversion_analytics USING btree (user_id);


--
-- TOC entry 4004 (class 1259 OID 17214)
-- Name: csv_operations_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_created_at_index ON public.csv_operations USING btree (created_at);


--
-- TOC entry 4007 (class 1259 OID 17213)
-- Name: csv_operations_user_id_operation_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_user_id_operation_type_index ON public.csv_operations USING btree (user_id, operation_type);


--
-- TOC entry 3968 (class 1259 OID 17058)
-- Name: data_quality_metrics_assessed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_assessed_at_index ON public.data_quality_metrics USING btree (assessed_at);


--
-- TOC entry 3969 (class 1259 OID 17059)
-- Name: data_quality_metrics_overall_quality_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_overall_quality_score_index ON public.data_quality_metrics USING btree (overall_quality_score);


--
-- TOC entry 3972 (class 1259 OID 17057)
-- Name: data_quality_metrics_product_id_data_source_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_product_id_data_source_index ON public.data_quality_metrics USING btree (product_id, data_source);


--
-- TOC entry 3998 (class 1259 OID 17170)
-- Name: discord_servers_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX discord_servers_user_id_is_active_index ON public.discord_servers USING btree (user_id, is_active);


--
-- TOC entry 3927 (class 1259 OID 16909)
-- Name: email_bounces_bounce_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_bounce_type_index ON public.email_bounces USING btree (bounce_type);


--
-- TOC entry 3928 (class 1259 OID 16895)
-- Name: email_bounces_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_message_id_index ON public.email_bounces USING btree (message_id);


--
-- TOC entry 3931 (class 1259 OID 16914)
-- Name: email_bounces_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_timestamp_index ON public.email_bounces USING btree ("timestamp");


--
-- TOC entry 3932 (class 1259 OID 16896)
-- Name: email_complaints_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_message_id_index ON public.email_complaints USING btree (message_id);


--
-- TOC entry 3935 (class 1259 OID 16910)
-- Name: email_complaints_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_timestamp_index ON public.email_complaints USING btree ("timestamp");


--
-- TOC entry 3913 (class 1259 OID 16916)
-- Name: email_delivery_logs_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_alert_id_index ON public.email_delivery_logs USING btree (alert_id);


--
-- TOC entry 3914 (class 1259 OID 16921)
-- Name: email_delivery_logs_email_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_email_type_index ON public.email_delivery_logs USING btree (email_type);


--
-- TOC entry 3915 (class 1259 OID 16918)
-- Name: email_delivery_logs_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_message_id_index ON public.email_delivery_logs USING btree (message_id);


--
-- TOC entry 3918 (class 1259 OID 16920)
-- Name: email_delivery_logs_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_sent_at_index ON public.email_delivery_logs USING btree (sent_at);


--
-- TOC entry 3919 (class 1259 OID 16912)
-- Name: email_delivery_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_user_id_index ON public.email_delivery_logs USING btree (user_id);


--
-- TOC entry 3909 (class 1259 OID 16915)
-- Name: email_preferences_unsubscribe_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_unsubscribe_token_index ON public.email_preferences USING btree (unsubscribe_token);


--
-- TOC entry 3912 (class 1259 OID 16911)
-- Name: email_preferences_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_user_id_index ON public.email_preferences USING btree (user_id);


--
-- TOC entry 3956 (class 1259 OID 17015)
-- Name: engagement_metrics_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_metrics_date_index ON public.engagement_metrics USING btree (metrics_date);


--
-- TOC entry 3959 (class 1259 OID 17014)
-- Name: engagement_metrics_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_index ON public.engagement_metrics USING btree (product_id);


--
-- TOC entry 3960 (class 1259 OID 17016)
-- Name: engagement_metrics_product_id_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_metrics_date_index ON public.engagement_metrics USING btree (product_id, metrics_date);


--
-- TOC entry 4090 (class 1259 OID 17550)
-- Name: external_product_map_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_product_map_product_id_index ON public.external_product_map USING btree (product_id);


--
-- TOC entry 4079 (class 1259 OID 17501)
-- Name: idx_billing_events_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_customer ON public.billing_events USING btree (stripe_customer_id);


--
-- TOC entry 4080 (class 1259 OID 17503)
-- Name: idx_billing_events_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_invoice ON public.billing_events USING btree (invoice_id);


--
-- TOC entry 4081 (class 1259 OID 17502)
-- Name: idx_billing_events_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_subscription ON public.billing_events USING btree (subscription_id);


--
-- TOC entry 4082 (class 1259 OID 17504)
-- Name: idx_billing_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_type ON public.billing_events USING btree (event_type);


--
-- TOC entry 4071 (class 1259 OID 17487)
-- Name: idx_transactions_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_product ON public.transactions USING btree (product_id);


--
-- TOC entry 4072 (class 1259 OID 17488)
-- Name: idx_transactions_retailer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_retailer ON public.transactions USING btree (retailer_slug);


--
-- TOC entry 4073 (class 1259 OID 17489)
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- TOC entry 4074 (class 1259 OID 17486)
-- Name: idx_transactions_user_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_hash ON public.transactions USING btree (user_id_hash);


--
-- TOC entry 3792 (class 1259 OID 16490)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3793 (class 1259 OID 16829)
-- Name: idx_users_push_subscriptions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_push_subscriptions ON public.users USING btree (id);


--
-- TOC entry 3794 (class 1259 OID 17525)
-- Name: idx_users_stripe_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_stripe_customer ON public.users USING btree (stripe_customer_id);


--
-- TOC entry 3795 (class 1259 OID 17526)
-- Name: idx_users_subscription_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_subscription_status ON public.users USING btree (subscription_status);


--
-- TOC entry 3951 (class 1259 OID 16988)
-- Name: ml_model_metrics_last_evaluated_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_last_evaluated_at_index ON public.ml_model_metrics USING btree (last_evaluated_at);


--
-- TOC entry 3952 (class 1259 OID 16986)
-- Name: ml_model_metrics_model_name_model_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_model_name_model_version_index ON public.ml_model_metrics USING btree (model_name, model_version);


--
-- TOC entry 3955 (class 1259 OID 16987)
-- Name: ml_model_metrics_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_prediction_type_index ON public.ml_model_metrics USING btree (prediction_type);


--
-- TOC entry 3979 (class 1259 OID 17107)
-- Name: ml_models_name_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_name_status_created_at_index ON public.ml_models USING btree (name, status, created_at);


--
-- TOC entry 3984 (class 1259 OID 17108)
-- Name: ml_models_status_deployed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_status_deployed_at_index ON public.ml_models USING btree (status, deployed_at);


--
-- TOC entry 3985 (class 1259 OID 17109)
-- Name: ml_models_trained_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_trained_by_index ON public.ml_models USING btree (trained_by);


--
-- TOC entry 3946 (class 1259 OID 16973)
-- Name: ml_predictions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_expires_at_index ON public.ml_predictions USING btree (expires_at);


--
-- TOC entry 3949 (class 1259 OID 16972)
-- Name: ml_predictions_product_id_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_index ON public.ml_predictions USING btree (product_id, prediction_type);


--
-- TOC entry 3950 (class 1259 OID 16974)
-- Name: ml_predictions_product_id_prediction_type_timeframe_days_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_timeframe_days_index ON public.ml_predictions USING btree (product_id, prediction_type, timeframe_days);


--
-- TOC entry 3986 (class 1259 OID 17131)
-- Name: ml_training_data_dataset_name_data_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_dataset_name_data_type_index ON public.ml_training_data USING btree (dataset_name, data_type);


--
-- TOC entry 3989 (class 1259 OID 17132)
-- Name: ml_training_data_reviewed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_reviewed_by_index ON public.ml_training_data USING btree (reviewed_by);


--
-- TOC entry 3990 (class 1259 OID 17130)
-- Name: ml_training_data_status_data_type_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_status_data_type_created_at_index ON public.ml_training_data USING btree (status, data_type, created_at);


--
-- TOC entry 4059 (class 1259 OID 17440)
-- Name: permission_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_action_created_at_index ON public.permission_audit_log USING btree (action, created_at);


--
-- TOC entry 4060 (class 1259 OID 17439)
-- Name: permission_audit_log_actor_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_actor_user_id_created_at_index ON public.permission_audit_log USING btree (actor_user_id, created_at);


--
-- TOC entry 4061 (class 1259 OID 17441)
-- Name: permission_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_created_at_index ON public.permission_audit_log USING btree (created_at);


--
-- TOC entry 4064 (class 1259 OID 17438)
-- Name: permission_audit_log_target_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_target_user_id_created_at_index ON public.permission_audit_log USING btree (target_user_id, created_at);


--
-- TOC entry 4025 (class 1259 OID 17320)
-- Name: post_comments_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_created_at_index ON public.post_comments USING btree (created_at);


--
-- TOC entry 4028 (class 1259 OID 17318)
-- Name: post_comments_post_id_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_post_id_moderation_status_index ON public.post_comments USING btree (post_id, moderation_status);


--
-- TOC entry 4029 (class 1259 OID 17319)
-- Name: post_comments_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_user_id_index ON public.post_comments USING btree (user_id);


--
-- TOC entry 4032 (class 1259 OID 17340)
-- Name: post_likes_post_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_post_id_index ON public.post_likes USING btree (post_id);


--
-- TOC entry 4035 (class 1259 OID 17341)
-- Name: post_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_user_id_index ON public.post_likes USING btree (user_id);


--
-- TOC entry 3890 (class 1259 OID 16788)
-- Name: price_history_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_index ON public.price_history USING btree (product_id);


--
-- TOC entry 3891 (class 1259 OID 16791)
-- Name: price_history_product_id_retailer_id_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_retailer_id_recorded_at_index ON public.price_history USING btree (product_id, retailer_id, recorded_at);


--
-- TOC entry 3892 (class 1259 OID 16790)
-- Name: price_history_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_recorded_at_index ON public.price_history USING btree (recorded_at);


--
-- TOC entry 3893 (class 1259 OID 16789)
-- Name: price_history_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_retailer_id_index ON public.price_history USING btree (retailer_id);


--
-- TOC entry 3841 (class 1259 OID 16622)
-- Name: product_availability_in_stock_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_in_stock_index ON public.product_availability USING btree (in_stock);


--
-- TOC entry 3842 (class 1259 OID 16623)
-- Name: product_availability_last_checked_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_last_checked_index ON public.product_availability USING btree (last_checked);


--
-- TOC entry 3845 (class 1259 OID 16620)
-- Name: product_availability_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_product_id_index ON public.product_availability USING btree (product_id);


--
-- TOC entry 3848 (class 1259 OID 16621)
-- Name: product_availability_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_retailer_id_index ON public.product_availability USING btree (retailer_id);


--
-- TOC entry 3823 (class 1259 OID 16564)
-- Name: product_categories_parent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_parent_id_index ON public.product_categories USING btree (parent_id);


--
-- TOC entry 3826 (class 1259 OID 16563)
-- Name: product_categories_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_slug_index ON public.product_categories USING btree (slug);


--
-- TOC entry 3829 (class 1259 OID 16590)
-- Name: products_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_index ON public.products USING btree (category_id);


--
-- TOC entry 3830 (class 1259 OID 16592)
-- Name: products_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_is_active_index ON public.products USING btree (is_active);


--
-- TOC entry 3833 (class 1259 OID 16593)
-- Name: products_release_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_release_date_index ON public.products USING btree (release_date);


--
-- TOC entry 3834 (class 1259 OID 16591)
-- Name: products_set_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_set_name_index ON public.products USING btree (set_name);


--
-- TOC entry 3835 (class 1259 OID 16588)
-- Name: products_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_index ON public.products USING btree (slug);


--
-- TOC entry 3838 (class 1259 OID 16589)
-- Name: products_upc_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_upc_index ON public.products USING btree (upc);


--
-- TOC entry 3817 (class 1259 OID 16544)
-- Name: retailers_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_is_active_index ON public.retailers USING btree (is_active);


--
-- TOC entry 3820 (class 1259 OID 16543)
-- Name: retailers_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_slug_index ON public.retailers USING btree (slug);


--
-- TOC entry 4042 (class 1259 OID 17384)
-- Name: roles_created_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_created_by_index ON public.roles USING btree (created_by);


--
-- TOC entry 4043 (class 1259 OID 17382)
-- Name: roles_is_system_role_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_is_system_role_is_active_index ON public.roles USING btree (is_system_role, is_active);


--
-- TOC entry 4044 (class 1259 OID 17383)
-- Name: roles_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_level_index ON public.roles USING btree (level);


--
-- TOC entry 3963 (class 1259 OID 17039)
-- Name: seasonal_patterns_category_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_category_id_pattern_type_index ON public.seasonal_patterns USING btree (category_id, pattern_type);


--
-- TOC entry 3964 (class 1259 OID 17040)
-- Name: seasonal_patterns_pattern_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_pattern_name_index ON public.seasonal_patterns USING btree (pattern_name);


--
-- TOC entry 3967 (class 1259 OID 17038)
-- Name: seasonal_patterns_product_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_product_id_pattern_type_index ON public.seasonal_patterns USING btree (product_id, pattern_type);


--
-- TOC entry 4008 (class 1259 OID 17237)
-- Name: social_shares_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_alert_id_index ON public.social_shares USING btree (alert_id);


--
-- TOC entry 4011 (class 1259 OID 17238)
-- Name: social_shares_shared_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_shared_at_index ON public.social_shares USING btree (shared_at);


--
-- TOC entry 4012 (class 1259 OID 17236)
-- Name: social_shares_user_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_user_id_platform_index ON public.social_shares USING btree (user_id, platform);


--
-- TOC entry 3902 (class 1259 OID 16827)
-- Name: system_health_checked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_checked_at_index ON public.system_health USING btree (checked_at);


--
-- TOC entry 3905 (class 1259 OID 16825)
-- Name: system_health_service_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_service_name_index ON public.system_health USING btree (service_name);


--
-- TOC entry 3906 (class 1259 OID 16826)
-- Name: system_health_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_status_index ON public.system_health USING btree (status);


--
-- TOC entry 3991 (class 1259 OID 17144)
-- Name: system_metrics_metric_name_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_name_recorded_at_index ON public.system_metrics USING btree (metric_name, recorded_at);


--
-- TOC entry 3992 (class 1259 OID 17145)
-- Name: system_metrics_metric_type_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_type_recorded_at_index ON public.system_metrics USING btree (metric_type, recorded_at);


--
-- TOC entry 3995 (class 1259 OID 17146)
-- Name: system_metrics_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_recorded_at_index ON public.system_metrics USING btree (recorded_at);


--
-- TOC entry 4013 (class 1259 OID 17264)
-- Name: testimonials_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_is_featured_is_public_index ON public.testimonials USING btree (is_featured, is_public);


--
-- TOC entry 4014 (class 1259 OID 17263)
-- Name: testimonials_moderation_status_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_moderation_status_is_public_index ON public.testimonials USING btree (moderation_status, is_public);


--
-- TOC entry 4017 (class 1259 OID 17265)
-- Name: testimonials_rating_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_rating_index ON public.testimonials USING btree (rating);


--
-- TOC entry 4018 (class 1259 OID 17262)
-- Name: testimonials_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_user_id_index ON public.testimonials USING btree (user_id);


--
-- TOC entry 3941 (class 1259 OID 16955)
-- Name: trend_analysis_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_analyzed_at_index ON public.trend_analysis USING btree (analyzed_at);


--
-- TOC entry 3944 (class 1259 OID 16956)
-- Name: trend_analysis_product_id_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_analyzed_at_index ON public.trend_analysis USING btree (product_id, analyzed_at);


--
-- TOC entry 3945 (class 1259 OID 16954)
-- Name: trend_analysis_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_index ON public.trend_analysis USING btree (product_id);


--
-- TOC entry 3920 (class 1259 OID 16919)
-- Name: unsubscribe_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_expires_at_index ON public.unsubscribe_tokens USING btree (expires_at);


--
-- TOC entry 3923 (class 1259 OID 16913)
-- Name: unsubscribe_tokens_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_token_index ON public.unsubscribe_tokens USING btree (token);


--
-- TOC entry 3926 (class 1259 OID 16917)
-- Name: unsubscribe_tokens_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_user_id_index ON public.unsubscribe_tokens USING btree (user_id);


--
-- TOC entry 4051 (class 1259 OID 17416)
-- Name: user_roles_assigned_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_assigned_by_index ON public.user_roles USING btree (assigned_by);


--
-- TOC entry 4052 (class 1259 OID 17417)
-- Name: user_roles_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_expires_at_index ON public.user_roles USING btree (expires_at);


--
-- TOC entry 4055 (class 1259 OID 17415)
-- Name: user_roles_role_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_role_id_is_active_index ON public.user_roles USING btree (role_id, is_active);


--
-- TOC entry 4056 (class 1259 OID 17414)
-- Name: user_roles_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_user_id_is_active_index ON public.user_roles USING btree (user_id, is_active);


--
-- TOC entry 3894 (class 1259 OID 16812)
-- Name: user_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_expires_at_index ON public.user_sessions USING btree (expires_at);


--
-- TOC entry 3895 (class 1259 OID 16813)
-- Name: user_sessions_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_is_active_index ON public.user_sessions USING btree (is_active);


--
-- TOC entry 3898 (class 1259 OID 16811)
-- Name: user_sessions_refresh_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_refresh_token_index ON public.user_sessions USING btree (refresh_token);


--
-- TOC entry 3901 (class 1259 OID 16810)
-- Name: user_sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_user_id_index ON public.user_sessions USING btree (user_id);


--
-- TOC entry 3865 (class 1259 OID 16697)
-- Name: user_watch_packs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_user_id_index ON public.user_watch_packs USING btree (user_id);


--
-- TOC entry 3868 (class 1259 OID 16698)
-- Name: user_watch_packs_watch_pack_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_watch_pack_id_index ON public.user_watch_packs USING btree (watch_pack_id);


--
-- TOC entry 3796 (class 1259 OID 16511)
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- TOC entry 3801 (class 1259 OID 17064)
-- Name: users_last_admin_login_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_last_admin_login_index ON public.users USING btree (last_admin_login);


--
-- TOC entry 3804 (class 1259 OID 16522)
-- Name: users_reset_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reset_token_index ON public.users USING btree (reset_token);


--
-- TOC entry 3805 (class 1259 OID 17449)
-- Name: users_role_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_created_at_index ON public.users USING btree (role, created_at);


--
-- TOC entry 3806 (class 1259 OID 17063)
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- TOC entry 3811 (class 1259 OID 17527)
-- Name: users_subscription_plan_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_subscription_plan_id_index ON public.users USING btree (subscription_plan_id);


--
-- TOC entry 3812 (class 1259 OID 16521)
-- Name: users_verification_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_verification_token_index ON public.users USING btree (verification_token);


--
-- TOC entry 3857 (class 1259 OID 16672)
-- Name: watch_packs_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_is_active_index ON public.watch_packs USING btree (is_active);


--
-- TOC entry 3860 (class 1259 OID 16671)
-- Name: watch_packs_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_slug_index ON public.watch_packs USING btree (slug);


--
-- TOC entry 3849 (class 1259 OID 16654)
-- Name: watches_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_is_active_index ON public.watches USING btree (is_active);


--
-- TOC entry 3852 (class 1259 OID 16653)
-- Name: watches_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_product_id_index ON public.watches USING btree (product_id);


--
-- TOC entry 3853 (class 1259 OID 16652)
-- Name: watches_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_index ON public.watches USING btree (user_id);


--
-- TOC entry 3854 (class 1259 OID 16655)
-- Name: watches_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_is_active_index ON public.watches USING btree (user_id, is_active);


--
-- TOC entry 4003 (class 1259 OID 17193)
-- Name: webhooks_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_user_id_is_active_index ON public.webhooks USING btree (user_id, is_active);


--
-- TOC entry 4122 (class 2606 OID 17077)
-- Name: admin_audit_log admin_audit_log_admin_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_user_id_foreign FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4106 (class 2606 OID 16762)
-- Name: alert_deliveries alert_deliveries_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4102 (class 2606 OID 16721)
-- Name: alerts alerts_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4103 (class 2606 OID 16726)
-- Name: alerts alerts_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4104 (class 2606 OID 16716)
-- Name: alerts alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4105 (class 2606 OID 16731)
-- Name: alerts alerts_watch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watch_id_foreign FOREIGN KEY (watch_id) REFERENCES public.watches(id) ON DELETE SET NULL;


--
-- TOC entry 4114 (class 2606 OID 16929)
-- Name: availability_snapshots availability_snapshots_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4115 (class 2606 OID 16934)
-- Name: availability_snapshots availability_snapshots_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4136 (class 2606 OID 17349)
-- Name: comment_likes comment_likes_comment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_foreign FOREIGN KEY (comment_id) REFERENCES public.post_comments(id) ON DELETE CASCADE;


--
-- TOC entry 4137 (class 2606 OID 17354)
-- Name: comment_likes comment_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4131 (class 2606 OID 17285)
-- Name: community_posts community_posts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4127 (class 2606 OID 17208)
-- Name: csv_operations csv_operations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4121 (class 2606 OID 17052)
-- Name: data_quality_metrics data_quality_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4125 (class 2606 OID 17163)
-- Name: discord_servers discord_servers_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4111 (class 2606 OID 16899)
-- Name: email_delivery_logs email_delivery_logs_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE SET NULL;


--
-- TOC entry 4112 (class 2606 OID 16888)
-- Name: email_delivery_logs email_delivery_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4110 (class 2606 OID 16883)
-- Name: email_preferences email_preferences_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4118 (class 2606 OID 17007)
-- Name: engagement_metrics engagement_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4143 (class 2606 OID 17543)
-- Name: external_product_map external_product_map_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4123 (class 2606 OID 17102)
-- Name: ml_models ml_models_trained_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_trained_by_foreign FOREIGN KEY (trained_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4117 (class 2606 OID 16967)
-- Name: ml_predictions ml_predictions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4124 (class 2606 OID 17125)
-- Name: ml_training_data ml_training_data_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4141 (class 2606 OID 17428)
-- Name: permission_audit_log permission_audit_log_actor_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_actor_user_id_foreign FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- TOC entry 4142 (class 2606 OID 17433)
-- Name: permission_audit_log permission_audit_log_target_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_target_user_id_foreign FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- TOC entry 4132 (class 2606 OID 17308)
-- Name: post_comments post_comments_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4133 (class 2606 OID 17313)
-- Name: post_comments post_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4134 (class 2606 OID 17328)
-- Name: post_likes post_likes_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4135 (class 2606 OID 17333)
-- Name: post_likes post_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4107 (class 2606 OID 16778)
-- Name: price_history price_history_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4108 (class 2606 OID 16783)
-- Name: price_history price_history_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4096 (class 2606 OID 16608)
-- Name: product_availability product_availability_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4097 (class 2606 OID 16613)
-- Name: product_availability product_availability_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4094 (class 2606 OID 16558)
-- Name: product_categories product_categories_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4095 (class 2606 OID 16583)
-- Name: products products_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4119 (class 2606 OID 17033)
-- Name: seasonal_patterns seasonal_patterns_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE CASCADE;


--
-- TOC entry 4120 (class 2606 OID 17028)
-- Name: seasonal_patterns seasonal_patterns_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4128 (class 2606 OID 17231)
-- Name: social_shares social_shares_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4129 (class 2606 OID 17226)
-- Name: social_shares social_shares_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4130 (class 2606 OID 17257)
-- Name: testimonials testimonials_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4116 (class 2606 OID 16949)
-- Name: trend_analysis trend_analysis_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4113 (class 2606 OID 16904)
-- Name: unsubscribe_tokens unsubscribe_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4138 (class 2606 OID 17407)
-- Name: user_roles user_roles_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- TOC entry 4139 (class 2606 OID 17402)
-- Name: user_roles user_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4140 (class 2606 OID 17397)
-- Name: user_roles user_roles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4109 (class 2606 OID 16803)
-- Name: user_sessions user_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4100 (class 2606 OID 16685)
-- Name: user_watch_packs user_watch_packs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4101 (class 2606 OID 16690)
-- Name: user_watch_packs user_watch_packs_watch_pack_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_watch_pack_id_foreign FOREIGN KEY (watch_pack_id) REFERENCES public.watch_packs(id) ON DELETE CASCADE;


--
-- TOC entry 4093 (class 2606 OID 17444)
-- Name: users users_role_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_updated_by_foreign FOREIGN KEY (role_updated_by) REFERENCES public.users(id);


--
-- TOC entry 4098 (class 2606 OID 16645)
-- Name: watches watches_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4099 (class 2606 OID 16640)
-- Name: watches watches_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4126 (class 2606 OID 17188)
-- Name: webhooks webhooks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-09-03 18:53:04 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict IQXIUVJzVW1TXhSCJ8EPypBSEd8lDBB3Iadmf8Xm4FaMldZ7NXr4iWySNVvxGxb

