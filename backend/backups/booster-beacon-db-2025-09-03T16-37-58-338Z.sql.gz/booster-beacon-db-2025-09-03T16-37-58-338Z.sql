--
-- PostgreSQL database dump
--

-- Dumped from database version 15.14
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

-- Started on 2025-09-03 10:37:58 MDT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_product_id_foreign;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_role_updated_by_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_watch_pack_id_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_foreign;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_role_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_assigned_by_foreign;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_user_id_foreign;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_product_id_foreign;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_alert_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_product_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_category_id_foreign;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_category_id_foreign;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_parent_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_retailer_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_retailer_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_product_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_user_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_user_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_post_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_target_user_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_actor_user_id_foreign;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_reviewed_by_foreign;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_product_id_foreign;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_trained_by_foreign;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_foreign;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_alert_id_foreign;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_foreign;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_product_id_foreign;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_user_id_foreign;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_retailer_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_product_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_watch_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_user_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_retailer_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_product_id_foreign;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_alert_id_foreign;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_admin_user_id_foreign;
DROP INDEX public.webhooks_user_id_is_active_index;
DROP INDEX public.watches_user_id_is_active_index;
DROP INDEX public.watches_user_id_index;
DROP INDEX public.watches_product_id_index;
DROP INDEX public.watches_is_active_index;
DROP INDEX public.watch_packs_slug_index;
DROP INDEX public.watch_packs_is_active_index;
DROP INDEX public.users_verification_token_index;
DROP INDEX public.users_subscription_plan_id_index;
DROP INDEX public.users_role_index;
DROP INDEX public.users_role_created_at_index;
DROP INDEX public.users_reset_token_index;
DROP INDEX public.users_last_admin_login_index;
DROP INDEX public.users_email_index;
DROP INDEX public.user_watch_packs_watch_pack_id_index;
DROP INDEX public.user_watch_packs_user_id_index;
DROP INDEX public.user_sessions_user_id_index;
DROP INDEX public.user_sessions_refresh_token_index;
DROP INDEX public.user_sessions_is_active_index;
DROP INDEX public.user_sessions_expires_at_index;
DROP INDEX public.user_roles_user_id_is_active_index;
DROP INDEX public.user_roles_role_id_is_active_index;
DROP INDEX public.user_roles_expires_at_index;
DROP INDEX public.user_roles_assigned_by_index;
DROP INDEX public.unsubscribe_tokens_user_id_index;
DROP INDEX public.unsubscribe_tokens_token_index;
DROP INDEX public.unsubscribe_tokens_expires_at_index;
DROP INDEX public.trend_analysis_product_id_index;
DROP INDEX public.trend_analysis_product_id_analyzed_at_index;
DROP INDEX public.trend_analysis_analyzed_at_index;
DROP INDEX public.testimonials_user_id_index;
DROP INDEX public.testimonials_rating_index;
DROP INDEX public.testimonials_moderation_status_is_public_index;
DROP INDEX public.testimonials_is_featured_is_public_index;
DROP INDEX public.system_metrics_recorded_at_index;
DROP INDEX public.system_metrics_metric_type_recorded_at_index;
DROP INDEX public.system_metrics_metric_name_recorded_at_index;
DROP INDEX public.system_health_status_index;
DROP INDEX public.system_health_service_name_index;
DROP INDEX public.system_health_checked_at_index;
DROP INDEX public.social_shares_user_id_platform_index;
DROP INDEX public.social_shares_shared_at_index;
DROP INDEX public.social_shares_alert_id_index;
DROP INDEX public.seasonal_patterns_product_id_pattern_type_index;
DROP INDEX public.seasonal_patterns_pattern_name_index;
DROP INDEX public.seasonal_patterns_category_id_pattern_type_index;
DROP INDEX public.roles_level_index;
DROP INDEX public.roles_is_system_role_is_active_index;
DROP INDEX public.roles_created_by_index;
DROP INDEX public.retailers_slug_index;
DROP INDEX public.retailers_is_active_index;
DROP INDEX public.products_upc_index;
DROP INDEX public.products_slug_index;
DROP INDEX public.products_set_name_index;
DROP INDEX public.products_release_date_index;
DROP INDEX public.products_is_active_index;
DROP INDEX public.products_category_id_index;
DROP INDEX public.product_categories_slug_index;
DROP INDEX public.product_categories_parent_id_index;
DROP INDEX public.product_availability_retailer_id_index;
DROP INDEX public.product_availability_product_id_index;
DROP INDEX public.product_availability_last_checked_index;
DROP INDEX public.product_availability_in_stock_index;
DROP INDEX public.price_history_retailer_id_index;
DROP INDEX public.price_history_recorded_at_index;
DROP INDEX public.price_history_product_id_retailer_id_recorded_at_index;
DROP INDEX public.price_history_product_id_index;
DROP INDEX public.post_likes_user_id_index;
DROP INDEX public.post_likes_post_id_index;
DROP INDEX public.post_comments_user_id_index;
DROP INDEX public.post_comments_post_id_moderation_status_index;
DROP INDEX public.post_comments_created_at_index;
DROP INDEX public.permission_audit_log_target_user_id_created_at_index;
DROP INDEX public.permission_audit_log_created_at_index;
DROP INDEX public.permission_audit_log_actor_user_id_created_at_index;
DROP INDEX public.permission_audit_log_action_created_at_index;
DROP INDEX public.ml_training_data_status_data_type_created_at_index;
DROP INDEX public.ml_training_data_reviewed_by_index;
DROP INDEX public.ml_training_data_dataset_name_data_type_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_timeframe_days_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_index;
DROP INDEX public.ml_predictions_expires_at_index;
DROP INDEX public.ml_models_trained_by_index;
DROP INDEX public.ml_models_status_deployed_at_index;
DROP INDEX public.ml_models_name_status_created_at_index;
DROP INDEX public.ml_model_metrics_prediction_type_index;
DROP INDEX public.ml_model_metrics_model_name_model_version_index;
DROP INDEX public.ml_model_metrics_last_evaluated_at_index;
DROP INDEX public.idx_users_subscription_status;
DROP INDEX public.idx_users_stripe_customer;
DROP INDEX public.idx_users_push_subscriptions;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_transactions_user_hash;
DROP INDEX public.idx_transactions_status;
DROP INDEX public.idx_transactions_retailer;
DROP INDEX public.idx_transactions_product;
DROP INDEX public.idx_billing_events_type;
DROP INDEX public.idx_billing_events_subscription;
DROP INDEX public.idx_billing_events_invoice;
DROP INDEX public.idx_billing_events_customer;
DROP INDEX public.engagement_metrics_product_id_metrics_date_index;
DROP INDEX public.engagement_metrics_product_id_index;
DROP INDEX public.engagement_metrics_metrics_date_index;
DROP INDEX public.email_preferences_user_id_index;
DROP INDEX public.email_preferences_unsubscribe_token_index;
DROP INDEX public.email_delivery_logs_user_id_index;
DROP INDEX public.email_delivery_logs_sent_at_index;
DROP INDEX public.email_delivery_logs_message_id_index;
DROP INDEX public.email_delivery_logs_email_type_index;
DROP INDEX public.email_delivery_logs_alert_id_index;
DROP INDEX public.email_complaints_timestamp_index;
DROP INDEX public.email_complaints_message_id_index;
DROP INDEX public.email_bounces_timestamp_index;
DROP INDEX public.email_bounces_message_id_index;
DROP INDEX public.email_bounces_bounce_type_index;
DROP INDEX public.discord_servers_user_id_is_active_index;
DROP INDEX public.data_quality_metrics_product_id_data_source_index;
DROP INDEX public.data_quality_metrics_overall_quality_score_index;
DROP INDEX public.data_quality_metrics_assessed_at_index;
DROP INDEX public.csv_operations_user_id_operation_type_index;
DROP INDEX public.csv_operations_created_at_index;
DROP INDEX public.conversion_analytics_user_id_index;
DROP INDEX public.conversion_analytics_event_type_index;
DROP INDEX public.conversion_analytics_event_date_index;
DROP INDEX public.community_posts_user_id_index;
DROP INDEX public.community_posts_type_moderation_status_index;
DROP INDEX public.community_posts_is_featured_is_public_index;
DROP INDEX public.community_posts_created_at_index;
DROP INDEX public.comment_likes_user_id_index;
DROP INDEX public.comment_likes_comment_id_index;
DROP INDEX public.availability_snapshots_snapshot_time_index;
DROP INDEX public.availability_snapshots_retailer_id_snapshot_time_index;
DROP INDEX public.availability_snapshots_product_id_snapshot_time_index;
DROP INDEX public.alerts_watch_id_index;
DROP INDEX public.alerts_user_id_status_index;
DROP INDEX public.alerts_user_id_index;
DROP INDEX public.alerts_type_index;
DROP INDEX public.alerts_status_priority_created_at_index;
DROP INDEX public.alerts_status_index;
DROP INDEX public.alerts_scheduled_for_index;
DROP INDEX public.alerts_retailer_id_index;
DROP INDEX public.alerts_product_id_index;
DROP INDEX public.alerts_priority_index;
DROP INDEX public.alerts_created_at_index;
DROP INDEX public.alert_deliveries_status_index;
DROP INDEX public.alert_deliveries_sent_at_index;
DROP INDEX public.alert_deliveries_channel_index;
DROP INDEX public.alert_deliveries_alert_id_index;
DROP INDEX public.admin_audit_log_target_type_target_id_index;
DROP INDEX public.admin_audit_log_created_at_index;
DROP INDEX public.admin_audit_log_admin_user_id_created_at_index;
DROP INDEX public.admin_audit_log_action_created_at_index;
ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_pkey;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_product_id_unique;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_pkey;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_slug_unique;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_subscription_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_stripe_customer_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_pkey;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_refresh_token_unique;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_pkey;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_role_id_unique;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_pkey;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_token_unique;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_pkey;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_pkey;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_pkey;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_pkey;
ALTER TABLE ONLY public.system_metrics DROP CONSTRAINT system_metrics_pkey;
ALTER TABLE ONLY public.system_health DROP CONSTRAINT system_health_pkey;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_stripe_price_id_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_slug_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_pkey;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_pkey;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_slug_unique;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_name_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_slug_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_upc_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_slug_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_slug_unique;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_pkey;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_retailer_id_unique;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_pkey;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_pkey;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_user_id_unique;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_pkey;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_pkey;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_pkey;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_pkey;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_name_version_unique;
ALTER TABLE ONLY public.ml_model_metrics DROP CONSTRAINT ml_model_metrics_pkey;
ALTER TABLE ONLY public.knex_migrations DROP CONSTRAINT knex_migrations_pkey;
ALTER TABLE ONLY public.knex_migrations_lock DROP CONSTRAINT knex_migrations_lock_pkey;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_metrics_date_unique;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_pkey;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_unsubscribe_token_unique;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_pkey;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_pkey;
ALTER TABLE ONLY public.email_complaints DROP CONSTRAINT email_complaints_pkey;
ALTER TABLE ONLY public.email_bounces DROP CONSTRAINT email_bounces_pkey;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_server_id_unique;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_pkey;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_pkey;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_pkey;
ALTER TABLE ONLY public.conversion_analytics DROP CONSTRAINT conversion_analytics_pkey;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_user_id_unique;
ALTER TABLE ONLY public.billing_events DROP CONSTRAINT billing_events_pkey;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_pkey;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_pkey;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_pkey;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_pkey;
ALTER TABLE public.knex_migrations_lock ALTER COLUMN index DROP DEFAULT;
ALTER TABLE public.knex_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.webhooks;
DROP TABLE public.watches;
DROP TABLE public.watch_packs;
DROP TABLE public.users;
DROP TABLE public.user_watch_packs;
DROP TABLE public.user_sessions;
DROP TABLE public.user_roles;
DROP TABLE public.unsubscribe_tokens;
DROP TABLE public.trend_analysis;
DROP TABLE public.transactions;
DROP TABLE public.testimonials;
DROP TABLE public.system_metrics;
DROP TABLE public.system_health;
DROP TABLE public.subscription_plans;
DROP TABLE public.social_shares;
DROP TABLE public.seasonal_patterns;
DROP TABLE public.roles;
DROP TABLE public.retailers;
DROP TABLE public.products;
DROP TABLE public.product_categories;
DROP TABLE public.product_availability;
DROP TABLE public.price_history;
DROP TABLE public.post_likes;
DROP TABLE public.post_comments;
DROP TABLE public.permission_audit_log;
DROP TABLE public.ml_training_data;
DROP TABLE public.ml_predictions;
DROP TABLE public.ml_models;
DROP TABLE public.ml_model_metrics;
DROP SEQUENCE public.knex_migrations_lock_index_seq;
DROP TABLE public.knex_migrations_lock;
DROP SEQUENCE public.knex_migrations_id_seq;
DROP TABLE public.knex_migrations;
DROP TABLE public.engagement_metrics;
DROP TABLE public.email_preferences;
DROP TABLE public.email_delivery_logs;
DROP TABLE public.email_complaints;
DROP TABLE public.email_bounces;
DROP TABLE public.discord_servers;
DROP TABLE public.data_quality_metrics;
DROP TABLE public.csv_operations;
DROP TABLE public.conversion_analytics;
DROP TABLE public.community_posts;
DROP TABLE public.comment_likes;
DROP TABLE public.billing_events;
DROP TABLE public.availability_snapshots;
DROP TABLE public.alerts;
DROP TABLE public.alert_deliveries;
DROP TABLE public.admin_audit_log;
DROP TYPE public.billing_period_enum;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pg_trgm;
--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4326 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4327 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1060 (class 1247 OID 17451)
-- Name: billing_period_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.billing_period_enum AS ENUM (
    'monthly',
    'yearly'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 17065)
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50),
    target_id character varying(255),
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT admin_audit_log_check CHECK ((((target_type IS NULL) AND (target_id IS NULL)) OR ((target_type IS NOT NULL) AND (target_id IS NOT NULL))))
);


--
-- TOC entry 229 (class 1259 OID 16747)
-- Name: alert_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id uuid NOT NULL,
    channel text NOT NULL,
    status text DEFAULT 'pending'::text,
    external_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alert_deliveries_channel_check CHECK ((channel = ANY (ARRAY['web_push'::text, 'email'::text, 'sms'::text, 'discord'::text]))),
    CONSTRAINT alert_deliveries_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'delivered'::text, 'failed'::text, 'bounced'::text])))
);


--
-- TOC entry 228 (class 1259 OID 16699)
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    watch_id uuid,
    type text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text,
    delivery_channels jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    sent_at timestamp with time zone,
    read_at timestamp with time zone,
    clicked_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alerts_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'urgent'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'failed'::text, 'read'::text]))),
    CONSTRAINT alerts_type_check CHECK ((type = ANY (ARRAY['restock'::text, 'price_drop'::text, 'low_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 238 (class 1259 OID 16922)
-- Name: availability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    stock_level integer,
    last_checked timestamp with time zone,
    snapshot_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 263 (class 1259 OID 17490)
-- Name: billing_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stripe_customer_id character varying(255) NOT NULL,
    subscription_id character varying(255),
    event_type character varying(100) NOT NULL,
    amount_cents integer,
    currency character varying(10),
    status character varying(50),
    invoice_id character varying(255),
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    raw_event jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 17342)
-- Name: comment_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 254 (class 1259 OID 17266)
-- Name: community_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.community_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    type text NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    images jsonb DEFAULT '[]'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    likes integer DEFAULT 0,
    comments_count integer DEFAULT 0,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT community_posts_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT community_posts_type_check CHECK ((type = ANY (ARRAY['success_story'::text, 'tip'::text, 'collection_showcase'::text, 'deal_share'::text, 'question'::text])))
);


--
-- TOC entry 264 (class 1259 OID 17505)
-- Name: conversion_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversion_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type character varying(255) NOT NULL,
    source character varying(255) DEFAULT 'direct'::character varying,
    medium character varying(255) DEFAULT 'organic'::character varying,
    campaign character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    event_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 251 (class 1259 OID 17194)
-- Name: csv_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csv_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    operation_type text NOT NULL,
    filename character varying(255),
    total_rows integer,
    successful_rows integer,
    failed_rows integer,
    errors jsonb DEFAULT '[]'::jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT csv_operations_operation_type_check CHECK ((operation_type = ANY (ARRAY['import'::text, 'export'::text]))),
    CONSTRAINT csv_operations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text])))
);


--
-- TOC entry 244 (class 1259 OID 17041)
-- Name: data_quality_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_quality_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    data_source character varying(255) NOT NULL,
    completeness_score numeric(5,2),
    freshness_hours numeric(8,2),
    accuracy_score numeric(5,2),
    missing_fields jsonb DEFAULT '[]'::jsonb,
    overall_quality_score numeric(5,2),
    recommendations jsonb DEFAULT '[]'::jsonb,
    assessed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 249 (class 1259 OID 17150)
-- Name: discord_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discord_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    server_id character varying(255) NOT NULL,
    channel_id character varying(255) NOT NULL,
    token text,
    alert_filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_alerts_sent integer DEFAULT 0,
    last_alert_sent timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 16862)
-- Name: email_bounces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_bounces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    bounce_type text NOT NULL,
    bounce_sub_type character varying(255) NOT NULL,
    bounced_recipients jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_bounces_bounce_type_check CHECK ((bounce_type = ANY (ARRAY['permanent'::text, 'transient'::text])))
);


--
-- TOC entry 237 (class 1259 OID 16873)
-- Name: email_complaints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_complaints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    complained_recipients jsonb NOT NULL,
    feedback_type character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16841)
-- Name: email_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_delivery_logs (
    id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    alert_id uuid,
    email_type text NOT NULL,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message_id character varying(255),
    sent_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    bounced_at timestamp with time zone,
    complained_at timestamp with time zone,
    bounce_reason text,
    complaint_reason text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_delivery_logs_email_type_check CHECK ((email_type = ANY (ARRAY['alert'::text, 'welcome'::text, 'marketing'::text, 'digest'::text, 'system'::text])))
);


--
-- TOC entry 233 (class 1259 OID 16830)
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    alert_emails boolean DEFAULT true,
    marketing_emails boolean DEFAULT true,
    weekly_digest boolean DEFAULT true,
    unsubscribe_token character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 16989)
-- Name: engagement_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    watch_count integer DEFAULT 0,
    alert_count integer DEFAULT 0,
    click_count integer DEFAULT 0,
    click_through_rate numeric(5,2) DEFAULT '0'::numeric,
    search_volume integer DEFAULT 0,
    social_mentions integer DEFAULT 0,
    engagement_score numeric(5,2) DEFAULT '0'::numeric,
    trend_direction text DEFAULT 'stable'::text,
    metrics_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT engagement_metrics_trend_direction_check CHECK ((trend_direction = ANY (ARRAY['rising'::text, 'falling'::text, 'stable'::text])))
);


--
-- TOC entry 218 (class 1259 OID 16496)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- TOC entry 217 (class 1259 OID 16495)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4328 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 220 (class 1259 OID 16503)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- TOC entry 219 (class 1259 OID 16502)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4329 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 241 (class 1259 OID 16975)
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_model_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(255) NOT NULL,
    prediction_type text NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    mean_absolute_error numeric(10,4),
    root_mean_square_error numeric(10,4),
    training_data_size integer,
    prediction_count integer DEFAULT 0,
    avg_processing_time numeric(8,2),
    last_trained_at timestamp with time zone,
    last_evaluated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_model_metrics_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 246 (class 1259 OID 17086)
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    status text DEFAULT 'training'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    model_path character varying(500),
    training_started_at timestamp with time zone,
    training_completed_at timestamp with time zone,
    deployed_at timestamp with time zone,
    trained_by uuid,
    training_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_models_check CHECK (((status <> 'active'::text) OR (deployed_at IS NOT NULL))),
    CONSTRAINT ml_models_check1 CHECK (((status <> 'training'::text) OR (training_started_at IS NOT NULL))),
    CONSTRAINT ml_models_status_check CHECK ((status = ANY (ARRAY['training'::text, 'active'::text, 'deprecated'::text, 'failed'::text])))
);


--
-- TOC entry 240 (class 1259 OID 16957)
-- Name: ml_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_predictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    prediction_type text NOT NULL,
    prediction_data jsonb NOT NULL,
    timeframe_days integer,
    input_price numeric(10,2),
    confidence_score numeric(5,2),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_predictions_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 247 (class 1259 OID 17112)
-- Name: ml_training_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_training_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dataset_name character varying(200) NOT NULL,
    data_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_training_data_check CHECK (((status = 'pending'::text) OR ((reviewed_by IS NOT NULL) AND (reviewed_at IS NOT NULL)))),
    CONSTRAINT ml_training_data_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 260 (class 1259 OID 17418)
-- Name: permission_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid NOT NULL,
    target_user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    permission_or_role character varying(100),
    old_value json,
    new_value json,
    reason text,
    ip_address character varying(45),
    user_agent text,
    metadata json DEFAULT '{}'::json,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 255 (class 1259 OID 17294)
-- Name: post_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    likes integer DEFAULT 0,
    is_public boolean DEFAULT true,
    moderation_status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT post_comments_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 256 (class 1259 OID 17321)
-- Name: post_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 16771)
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 224 (class 1259 OID 16594)
-- Name: product_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_availability (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean DEFAULT false,
    price numeric(10,2),
    original_price numeric(10,2),
    availability_status text,
    product_url character varying(255) NOT NULL,
    cart_url character varying(255),
    stock_level integer,
    store_locations jsonb DEFAULT '[]'::jsonb,
    last_checked timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_in_stock timestamp with time zone,
    last_price_change timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_availability_availability_status_check CHECK ((availability_status = ANY (ARRAY['in_stock'::text, 'low_stock'::text, 'out_of_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 222 (class 1259 OID 16545)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    parent_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16565)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    sku character varying(255),
    upc character varying(255),
    category_id uuid,
    set_name character varying(255),
    series character varying(255),
    release_date date,
    msrp numeric(10,2),
    image_url character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    popularity_score integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT products_popularity_score_check CHECK (((popularity_score >= 0) AND (popularity_score <= 1000)))
);


--
-- TOC entry 221 (class 1259 OID 16523)
-- Name: retailers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retailers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    website_url character varying(255) NOT NULL,
    api_type text NOT NULL,
    api_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    rate_limit_per_minute integer DEFAULT 60,
    health_score integer DEFAULT 100,
    last_health_check timestamp with time zone,
    supported_features jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT retailers_api_type_check CHECK ((api_type = ANY (ARRAY['official'::text, 'affiliate'::text, 'scraping'::text]))),
    CONSTRAINT retailers_health_score_check CHECK (((health_score >= 0) AND (health_score <= 100))),
    CONSTRAINT retailers_rate_limit_per_minute_check CHECK (((rate_limit_per_minute >= 1) AND (rate_limit_per_minute <= 10000)))
);


--
-- TOC entry 258 (class 1259 OID 17363)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    permissions json DEFAULT '[]'::json,
    is_system_role boolean DEFAULT false,
    categories json DEFAULT '[]'::json,
    level integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 17017)
-- Name: seasonal_patterns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasonal_patterns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    category_id uuid,
    pattern_type character varying(255) NOT NULL,
    pattern_name character varying(255) NOT NULL,
    avg_price_change numeric(5,2),
    availability_change numeric(5,2),
    demand_multiplier numeric(4,2) DEFAULT '1'::numeric,
    historical_occurrences integer DEFAULT 1,
    confidence numeric(5,2),
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 252 (class 1259 OID 17215)
-- Name: social_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    alert_id uuid,
    platform character varying(255) NOT NULL,
    share_type character varying(255) DEFAULT 'manual'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    shared_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 261 (class 1259 OID 17455)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    billing_period public.billing_period_enum NOT NULL,
    stripe_price_id character varying(255),
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    limits jsonb DEFAULT '{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT name_not_empty CHECK ((length(TRIM(BOTH FROM name)) > 0)),
    CONSTRAINT price_non_negative CHECK ((price >= (0)::numeric))
);


--
-- TOC entry 232 (class 1259 OID 16814)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    status text NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    message text,
    checked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_health_status_check CHECK ((status = ANY (ARRAY['healthy'::text, 'degraded'::text, 'down'::text])))
);


--
-- TOC entry 248 (class 1259 OID 17133)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type text NOT NULL,
    value numeric(15,6) NOT NULL,
    labels jsonb DEFAULT '{}'::jsonb NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['gauge'::text, 'counter'::text, 'histogram'::text, 'summary'::text])))
);


--
-- TOC entry 253 (class 1259 OID 17239)
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    rating integer NOT NULL,
    is_verified boolean DEFAULT false,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT testimonials_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- TOC entry 262 (class 1259 OID 17475)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_slug character varying(100) NOT NULL,
    rule_id uuid,
    user_id_hash character varying(200) NOT NULL,
    status character varying(32) NOT NULL,
    price_paid numeric(10,2),
    msrp numeric(10,2),
    qty integer DEFAULT 1 NOT NULL,
    alert_at timestamp with time zone,
    added_to_cart_at timestamp with time zone,
    purchased_at timestamp with time zone,
    lead_time_ms integer,
    failure_reason text,
    region character varying(64),
    session_fingerprint character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 16942)
-- Name: trend_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trend_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    price_trend numeric(10,6),
    availability_trend numeric(10,6),
    demand_score numeric(5,2),
    volatility_score numeric(5,2),
    analyzed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 16851)
-- Name: unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unsubscribe_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    email_type text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT unsubscribe_tokens_email_type_check CHECK ((email_type = ANY (ARRAY['all'::text, 'alerts'::text, 'marketing'::text, 'digest'::text])))
);


--
-- TOC entry 259 (class 1259 OID 17385)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assignment_reason text,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 16792)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    refresh_token character varying(255) NOT NULL,
    device_info character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 16673)
-- Name: user_watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    watch_pack_id uuid NOT NULL,
    customizations jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16477)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    subscription_tier character varying(20) DEFAULT 'free'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_verified boolean DEFAULT false,
    verification_token character varying(255),
    reset_token character varying(255),
    reset_token_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login timestamp with time zone,
    shipping_addresses jsonb DEFAULT '[]'::jsonb,
    payment_methods jsonb DEFAULT '[]'::jsonb,
    retailer_credentials jsonb DEFAULT '{}'::jsonb,
    notification_settings jsonb DEFAULT '{"sms": false, "email": true, "discord": false, "web_push": true}'::jsonb,
    quiet_hours jsonb DEFAULT '{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}'::jsonb,
    timezone character varying(255) DEFAULT 'UTC'::character varying,
    zip_code character varying(255),
    push_subscriptions jsonb DEFAULT '[]'::jsonb,
    role text DEFAULT 'user'::text NOT NULL,
    last_admin_login timestamp with time zone,
    admin_permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    preferences jsonb DEFAULT '{}'::jsonb,
    newsletter_subscription boolean DEFAULT false,
    terms_accepted boolean DEFAULT false,
    direct_permissions json DEFAULT '[]'::json,
    role_last_updated timestamp with time zone,
    role_updated_by uuid,
    permission_metadata json DEFAULT '{}'::json,
    stripe_customer_id character varying(255),
    subscription_id character varying(255),
    subscription_status character varying(50),
    subscription_start_date timestamp with time zone,
    subscription_end_date timestamp with time zone,
    trial_end_date timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    subscription_plan_id character varying(255),
    CONSTRAINT users_failed_login_attempts_check CHECK (((failed_login_attempts >= 0) AND (failed_login_attempts <= 10))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['user'::text, 'admin'::text, 'super_admin'::text])))
);


--
-- TOC entry 226 (class 1259 OID 16656)
-- Name: watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    product_ids jsonb NOT NULL,
    is_active boolean DEFAULT true,
    auto_update boolean DEFAULT true,
    update_criteria character varying(255),
    subscriber_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 16624)
-- Name: watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_ids jsonb DEFAULT '[]'::jsonb,
    max_price numeric(10,2),
    availability_type text DEFAULT 'both'::text,
    zip_code character varying(255),
    radius_miles integer,
    is_active boolean DEFAULT true,
    alert_preferences jsonb DEFAULT '{}'::jsonb,
    last_alerted timestamp with time zone,
    alert_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    auto_purchase jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT watches_availability_type_check CHECK ((availability_type = ANY (ARRAY['online'::text, 'in_store'::text, 'both'::text])))
);


--
-- TOC entry 250 (class 1259 OID 17171)
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret text,
    events jsonb NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb,
    retry_config jsonb DEFAULT '{"maxRetries": 3, "retryDelay": 1000, "backoffMultiplier": 2}'::jsonb,
    filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_calls integer DEFAULT 0,
    successful_calls integer DEFAULT 0,
    failed_calls integer DEFAULT 0,
    last_triggered timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3529 (class 2604 OID 16499)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3530 (class 2604 OID 16506)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 4301 (class 0 OID 17065)
-- Dependencies: 245
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, details, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4285 (class 0 OID 16747)
-- Dependencies: 229
-- Data for Name: alert_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_deliveries (id, alert_id, channel, status, external_id, metadata, sent_at, delivered_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4284 (class 0 OID 16699)
-- Dependencies: 228
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, product_id, retailer_id, watch_id, type, priority, data, status, delivery_channels, scheduled_for, sent_at, read_at, clicked_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4294 (class 0 OID 16922)
-- Dependencies: 238
-- Data for Name: availability_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_snapshots (id, product_id, retailer_id, in_stock, availability_status, stock_level, last_checked, snapshot_time) FROM stdin;
\.


--
-- TOC entry 4319 (class 0 OID 17490)
-- Dependencies: 263
-- Data for Name: billing_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_events (id, stripe_customer_id, subscription_id, event_type, amount_cents, currency, status, invoice_id, occurred_at, raw_event, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4313 (class 0 OID 17342)
-- Dependencies: 257
-- Data for Name: comment_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_likes (id, comment_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4310 (class 0 OID 17266)
-- Dependencies: 254
-- Data for Name: community_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.community_posts (id, user_id, user_name, user_avatar, type, title, content, images, tags, likes, comments_count, is_public, is_featured, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4320 (class 0 OID 17505)
-- Dependencies: 264
-- Data for Name: conversion_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversion_analytics (id, user_id, event_type, source, medium, campaign, metadata, event_date) FROM stdin;
\.


--
-- TOC entry 4307 (class 0 OID 17194)
-- Dependencies: 251
-- Data for Name: csv_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.csv_operations (id, user_id, operation_type, filename, total_rows, successful_rows, failed_rows, errors, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4300 (class 0 OID 17041)
-- Dependencies: 244
-- Data for Name: data_quality_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_quality_metrics (id, product_id, data_source, completeness_score, freshness_hours, accuracy_score, missing_fields, overall_quality_score, recommendations, assessed_at) FROM stdin;
\.


--
-- TOC entry 4305 (class 0 OID 17150)
-- Dependencies: 249
-- Data for Name: discord_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discord_servers (id, user_id, server_id, channel_id, token, alert_filters, is_active, total_alerts_sent, last_alert_sent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4292 (class 0 OID 16862)
-- Dependencies: 236
-- Data for Name: email_bounces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_bounces (id, message_id, bounce_type, bounce_sub_type, bounced_recipients, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4293 (class 0 OID 16873)
-- Dependencies: 237
-- Data for Name: email_complaints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_complaints (id, message_id, complained_recipients, feedback_type, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4290 (class 0 OID 16841)
-- Dependencies: 234
-- Data for Name: email_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_delivery_logs (id, user_id, alert_id, email_type, recipient_email, subject, message_id, sent_at, delivered_at, bounced_at, complained_at, bounce_reason, complaint_reason, metadata, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4289 (class 0 OID 16830)
-- Dependencies: 233
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_preferences (id, user_id, alert_emails, marketing_emails, weekly_digest, unsubscribe_token, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4298 (class 0 OID 16989)
-- Dependencies: 242
-- Data for Name: engagement_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.engagement_metrics (id, product_id, watch_count, alert_count, click_count, click_through_rate, search_volume, social_mentions, engagement_score, trend_direction, metrics_date, calculated_at) FROM stdin;
\.


--
-- TOC entry 4274 (class 0 OID 16496)
-- Dependencies: 218
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	001_initial_schema.js	1	2025-09-03 16:36:02.672+00
2	20250826174814_expand_core_schema.js	1	2025-09-03 16:36:02.826+00
3	20250826180000_add_push_subscriptions.js	1	2025-09-03 16:36:02.828+00
4	20250827000001_email_system.js	1	2025-09-03 16:36:02.876+00
5	20250827130000_add_ml_tables.js	1	2025-09-03 16:36:02.937+00
6	20250827140000_add_user_roles.js	1	2025-09-03 16:36:02.98+00
7	20250827140001_add_missing_user_fields.js	1	2025-09-03 16:36:02.981+00
8	20250827140005_validate_admin_setup.js	1	2025-09-03 16:36:02.997+00
9	20250827140006_add_registration_fields.js	1	2025-09-03 16:36:02.998+00
10	20250827150000_add_community_integration_tables.js	1	2025-09-03 16:36:03.08+00
11	20250827160000_implement_granular_rbac.js	1	2025-09-03 16:36:03.122+00
12	20250829151931_create_subscription_plans_table.js	1	2025-09-03 16:36:03.132+00
13	20250901090000_create_transactions_and_billing_events.js	1	2025-09-03 16:36:03.15+00
14	20250901151600_add_conversion_analytics.js	1	2025-09-03 16:36:03.158+00
15	20250901152000_add_user_subscription_columns.js	1	2025-09-03 16:36:03.166+00
16	20250901154000_add_user_subscription_plan_id.js	1	2025-09-03 16:36:03.168+00
17	20250902140000_add_watch_auto_purchase.js	1	2025-09-03 16:36:03.174+00
\.


--
-- TOC entry 4276 (class 0 OID 16503)
-- Dependencies: 220
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- TOC entry 4297 (class 0 OID 16975)
-- Dependencies: 241
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_model_metrics (id, model_name, model_version, prediction_type, accuracy, "precision", recall, f1_score, mean_absolute_error, root_mean_square_error, training_data_size, prediction_count, avg_processing_time, last_trained_at, last_evaluated_at, created_at) FROM stdin;
\.


--
-- TOC entry 4302 (class 0 OID 17086)
-- Dependencies: 246
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, version, status, config, metrics, model_path, training_started_at, training_completed_at, deployed_at, trained_by, training_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4296 (class 0 OID 16957)
-- Dependencies: 240
-- Data for Name: ml_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_predictions (id, product_id, prediction_type, prediction_data, timeframe_days, input_price, confidence_score, expires_at, created_at) FROM stdin;
\.


--
-- TOC entry 4303 (class 0 OID 17112)
-- Dependencies: 247
-- Data for Name: ml_training_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_training_data (id, dataset_name, data_type, data, status, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4316 (class 0 OID 17418)
-- Dependencies: 260
-- Data for Name: permission_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_audit_log (id, actor_user_id, target_user_id, action, permission_or_role, old_value, new_value, reason, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4311 (class 0 OID 17294)
-- Dependencies: 255
-- Data for Name: post_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_comments (id, post_id, user_id, user_name, user_avatar, content, likes, is_public, moderation_status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4312 (class 0 OID 17321)
-- Dependencies: 256
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_likes (id, post_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4286 (class 0 OID 16771)
-- Dependencies: 230
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, product_id, retailer_id, price, original_price, in_stock, availability_status, recorded_at) FROM stdin;
\.


--
-- TOC entry 4280 (class 0 OID 16594)
-- Dependencies: 224
-- Data for Name: product_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_availability (id, product_id, retailer_id, in_stock, price, original_price, availability_status, product_url, cart_url, stock_level, store_locations, last_checked, last_in_stock, last_price_change, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4278 (class 0 OID 16545)
-- Dependencies: 222
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name, slug, description, parent_id, sort_order, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4279 (class 0 OID 16565)
-- Dependencies: 223
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, slug, sku, upc, category_id, set_name, series, release_date, msrp, image_url, description, metadata, is_active, popularity_score, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4277 (class 0 OID 16523)
-- Dependencies: 221
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retailers (id, name, slug, website_url, api_type, api_config, is_active, rate_limit_per_minute, health_score, last_health_check, supported_features, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4314 (class 0 OID 17363)
-- Dependencies: 258
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, slug, description, permissions, is_system_role, categories, level, is_active, created_by, created_at, updated_at) FROM stdin;
9425e23e-c63c-434e-a688-0e786cd19608	Super Administrator	super_admin	Full system access with all permissions	[]	t	["user_management","system_administration","ml_operations","analytics","content_management","security","billing","monitoring"]	100	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6fc7d6b5-cde0-4c33-9206-d20f107f1906	Administrator	admin	Administrative access with most permissions	[]	t	["user_management","system_administration","analytics","content_management","security","monitoring"]	80	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
96520317-38af-41b0-b46e-3890d4d99f25	User Manager	user_manager	Manage users and basic administrative tasks	[]	t	["user_management","analytics"]	60	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
8c185a4e-5962-4d59-af7f-56b68fda06df	Content Manager	content_manager	Manage products, retailers, and content	[]	t	["content_management","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6814f358-63ad-4530-a185-9c5cd7dbf0c2	ML Engineer	ml_engineer	Manage machine learning models and data	[]	t	["ml_operations","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
7dff1611-3ec6-4d08-bc90-2d5db769de78	Analyst	analyst	View and analyze system data and metrics	[]	t	["analytics"]	40	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
58b9d7f9-b295-4b7a-8abc-9e650d4586b2	Support Agent	support_agent	Provide customer support and basic user management	[]	t	["user_management"]	30	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
cf9919c8-4c2f-4768-8c0c-3bc770a34e5b	Billing Manager	billing_manager	Manage billing, subscriptions, and financial data	[]	t	["billing","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
4c762ab2-3f74-43ec-906b-bfdb46b58b21	Security Officer	security_officer	Manage security, audit logs, and compliance	[]	t	["security","monitoring"]	70	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
2d0c24b1-6468-4cd9-833e-fc310409aea1	User	user	Standard user with no administrative permissions	[]	t	[]	0	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
\.


--
-- TOC entry 4299 (class 0 OID 17017)
-- Dependencies: 243
-- Data for Name: seasonal_patterns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasonal_patterns (id, product_id, category_id, pattern_type, pattern_name, avg_price_change, availability_change, demand_multiplier, historical_occurrences, confidence, last_updated) FROM stdin;
\.


--
-- TOC entry 4308 (class 0 OID 17215)
-- Dependencies: 252
-- Data for Name: social_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_shares (id, user_id, alert_id, platform, share_type, metadata, shared_at) FROM stdin;
\.


--
-- TOC entry 4317 (class 0 OID 17455)
-- Dependencies: 261
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, slug, description, price, billing_period, stripe_price_id, features, limits, is_active, trial_days, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4288 (class 0 OID 16814)
-- Dependencies: 232
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, service_name, status, metrics, message, checked_at) FROM stdin;
\.


--
-- TOC entry 4304 (class 0 OID 17133)
-- Dependencies: 248
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_metrics (id, metric_name, metric_type, value, labels, recorded_at) FROM stdin;
3c802948-0f8e-492d-88c0-dff25cdf27e4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:36.212+00
1695bdb1-2765-4c19-a26e-084c4d42b365	uptime	gauge	309.459464	{}	2025-09-03 16:36:36.212+00
0d1258c5-8d93-468e-a339-4b355ed35026	memory_usage	gauge	75.570000	{}	2025-09-03 16:36:36.212+00
9a2765b6-8abb-4553-84e9-8869a040d12b	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:36.212+00
4e3a89f2-6edb-4eed-a9ad-e7cadac60073	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:58.34+00
d2c8d491-5e7f-48fc-922f-0ee7ca343eb7	uptime	gauge	248.100242	{}	2025-09-03 16:36:58.341+00
4de06082-95a8-4707-9774-4ee6b4bf76fd	memory_usage	gauge	75.680000	{}	2025-09-03 16:36:58.34+00
efe07c33-9f0c-405b-9cd3-a904a9d646fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:58.341+00
31fe1c93-cb08-4c5f-9d97-5d675f8a84af	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:36.212+00
65f93504-e136-41de-b03c-b19121f38d51	memory_usage	gauge	75.830000	{}	2025-09-03 16:37:36.212+00
b0af6be9-90c2-43f0-b255-6ef5f650c0de	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:36.212+00
8d116f32-15ae-4daf-847f-b4d379c6ba64	uptime	gauge	369.458978	{}	2025-09-03 16:37:36.212+00
0f03de57-b8e4-400e-a640-1501056f4f1b	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:58.346+00
4605f34f-cf0b-44ed-b844-bc8e987d994f	memory_usage	gauge	75.730000	{}	2025-09-03 16:37:58.346+00
19f45d60-ddb5-4ed0-9807-26a7668c7571	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:58.346+00
733ca3c5-1cfc-4bc9-bf30-dd81e206c078	uptime	gauge	308.106181	{}	2025-09-03 16:37:58.346+00
\.


--
-- TOC entry 4309 (class 0 OID 17239)
-- Dependencies: 253
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, user_id, user_name, user_avatar, content, rating, is_verified, is_public, is_featured, tags, metadata, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4318 (class 0 OID 17475)
-- Dependencies: 262
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, product_id, retailer_slug, rule_id, user_id_hash, status, price_paid, msrp, qty, alert_at, added_to_cart_at, purchased_at, lead_time_ms, failure_reason, region, session_fingerprint, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4295 (class 0 OID 16942)
-- Dependencies: 239
-- Data for Name: trend_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trend_analysis (id, product_id, price_trend, availability_trend, demand_score, volatility_score, analyzed_at) FROM stdin;
\.


--
-- TOC entry 4291 (class 0 OID 16851)
-- Dependencies: 235
-- Data for Name: unsubscribe_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unsubscribe_tokens (id, token, user_id, email_type, expires_at, used_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4315 (class 0 OID 17385)
-- Dependencies: 259
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assignment_reason, assigned_at, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4287 (class 0 OID 16792)
-- Dependencies: 231
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, refresh_token, device_info, ip_address, user_agent, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4283 (class 0 OID 16673)
-- Dependencies: 227
-- Data for Name: user_watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_watch_packs (id, user_id, watch_pack_id, customizations, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4272 (class 0 OID 16477)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, subscription_tier, created_at, updated_at, email_verified, verification_token, reset_token, reset_token_expires, failed_login_attempts, locked_until, last_login, shipping_addresses, payment_methods, retailer_credentials, notification_settings, quiet_hours, timezone, zip_code, push_subscriptions, role, last_admin_login, admin_permissions, first_name, last_name, preferences, newsletter_subscription, terms_accepted, direct_permissions, role_last_updated, role_updated_by, permission_metadata, stripe_customer_id, subscription_id, subscription_status, subscription_start_date, subscription_end_date, trial_end_date, cancel_at_period_end, subscription_plan_id) FROM stdin;
84a8557a-b08e-405e-b391-16def0d2020d	test@boosterbeacon.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS	pro	2025-09-03 16:31:17.756398+00	2025-09-03 16:31:17.756398+00	f	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	[]	\N	\N	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
\.


--
-- TOC entry 4282 (class 0 OID 16656)
-- Dependencies: 226
-- Data for Name: watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watch_packs (id, name, slug, description, product_ids, is_active, auto_update, update_criteria, subscriber_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4281 (class 0 OID 16624)
-- Dependencies: 225
-- Data for Name: watches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watches (id, user_id, product_id, retailer_ids, max_price, availability_type, zip_code, radius_miles, is_active, alert_preferences, last_alerted, alert_count, created_at, updated_at, auto_purchase) FROM stdin;
\.


--
-- TOC entry 4306 (class 0 OID 17171)
-- Dependencies: 250
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, user_id, name, url, secret, events, headers, retry_config, filters, is_active, total_calls, successful_calls, failed_calls, last_triggered, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4330 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 17, true);


--
-- TOC entry 4331 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 3969 (class 2606 OID 17076)
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3877 (class 2606 OID 16761)
-- Name: alert_deliveries alert_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_pkey PRIMARY KEY (id);


--
-- TOC entry 3863 (class 2606 OID 16715)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3929 (class 2606 OID 16928)
-- Name: availability_snapshots availability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 4070 (class 2606 OID 17500)
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 17360)
-- Name: comment_likes comment_likes_comment_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_user_id_unique UNIQUE (comment_id, user_id);


--
-- TOC entry 4032 (class 2606 OID 17348)
-- Name: comment_likes comment_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4014 (class 2606 OID 17284)
-- Name: community_posts community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4078 (class 2606 OID 17516)
-- Name: conversion_analytics conversion_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversion_analytics
    ADD CONSTRAINT conversion_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 3998 (class 2606 OID 17207)
-- Name: csv_operations csv_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_pkey PRIMARY KEY (id);


--
-- TOC entry 3963 (class 2606 OID 17051)
-- Name: data_quality_metrics data_quality_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3989 (class 2606 OID 17162)
-- Name: discord_servers discord_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_pkey PRIMARY KEY (id);


--
-- TOC entry 3992 (class 2606 OID 17169)
-- Name: discord_servers discord_servers_user_id_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_server_id_unique UNIQUE (user_id, server_id);


--
-- TOC entry 3922 (class 2606 OID 16872)
-- Name: email_bounces email_bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_bounces
    ADD CONSTRAINT email_bounces_pkey PRIMARY KEY (id);


--
-- TOC entry 3926 (class 2606 OID 16882)
-- Name: email_complaints email_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_complaints
    ADD CONSTRAINT email_complaints_pkey PRIMARY KEY (id);


--
-- TOC entry 3909 (class 2606 OID 16850)
-- Name: email_delivery_logs email_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3900 (class 2606 OID 16840)
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 3903 (class 2606 OID 16898)
-- Name: email_preferences email_preferences_unsubscribe_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_unsubscribe_token_unique UNIQUE (unsubscribe_token);


--
-- TOC entry 3950 (class 2606 OID 17006)
-- Name: engagement_metrics engagement_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3954 (class 2606 OID 17013)
-- Name: engagement_metrics engagement_metrics_product_id_metrics_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_metrics_date_unique UNIQUE (product_id, metrics_date);


--
-- TOC entry 3808 (class 2606 OID 16508)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3806 (class 2606 OID 16501)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3946 (class 2606 OID 16985)
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3973 (class 2606 OID 17111)
-- Name: ml_models ml_models_name_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_name_version_unique UNIQUE (name, version);


--
-- TOC entry 3975 (class 2606 OID 17101)
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


--
-- TOC entry 3940 (class 2606 OID 16966)
-- Name: ml_predictions ml_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_pkey PRIMARY KEY (id);


--
-- TOC entry 3980 (class 2606 OID 17124)
-- Name: ml_training_data ml_training_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4055 (class 2606 OID 17427)
-- Name: permission_audit_log permission_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4019 (class 2606 OID 17307)
-- Name: post_comments post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_pkey PRIMARY KEY (id);


--
-- TOC entry 4023 (class 2606 OID 17327)
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 17339)
-- Name: post_likes post_likes_post_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_user_id_unique UNIQUE (post_id, user_id);


--
-- TOC entry 3881 (class 2606 OID 16777)
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3836 (class 2606 OID 16607)
-- Name: product_availability product_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_pkey PRIMARY KEY (id);


--
-- TOC entry 3839 (class 2606 OID 16619)
-- Name: product_availability product_availability_product_id_retailer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_retailer_id_unique UNIQUE (product_id, retailer_id);


--
-- TOC entry 3817 (class 2606 OID 16555)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3820 (class 2606 OID 16557)
-- Name: product_categories product_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_slug_unique UNIQUE (slug);


--
-- TOC entry 3824 (class 2606 OID 16578)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3829 (class 2606 OID 16580)
-- Name: products products_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_unique UNIQUE (slug);


--
-- TOC entry 3832 (class 2606 OID 16582)
-- Name: products products_upc_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_upc_unique UNIQUE (upc);


--
-- TOC entry 3811 (class 2606 OID 16540)
-- Name: retailers retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (id);


--
-- TOC entry 3814 (class 2606 OID 16542)
-- Name: retailers retailers_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_slug_unique UNIQUE (slug);


--
-- TOC entry 4038 (class 2606 OID 17379)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 4040 (class 2606 OID 17377)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4042 (class 2606 OID 17381)
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- TOC entry 3958 (class 2606 OID 17027)
-- Name: seasonal_patterns seasonal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 4002 (class 2606 OID 17225)
-- Name: social_shares social_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_pkey PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 17468)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4060 (class 2606 OID 17470)
-- Name: subscription_plans subscription_plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_unique UNIQUE (slug);


--
-- TOC entry 4062 (class 2606 OID 17472)
-- Name: subscription_plans subscription_plans_stripe_price_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_stripe_price_id_unique UNIQUE (stripe_price_id);


--
-- TOC entry 3896 (class 2606 OID 16824)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 3986 (class 2606 OID 17143)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4008 (class 2606 OID 17256)
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- TOC entry 4068 (class 2606 OID 17485)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3935 (class 2606 OID 16948)
-- Name: trend_analysis trend_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_pkey PRIMARY KEY (id);


--
-- TOC entry 3914 (class 2606 OID 16861)
-- Name: unsubscribe_tokens unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3917 (class 2606 OID 16894)
-- Name: unsubscribe_tokens unsubscribe_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4046 (class 2606 OID 17396)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4050 (class 2606 OID 17413)
-- Name: user_roles user_roles_user_id_role_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_unique UNIQUE (user_id, role_id);


--
-- TOC entry 3889 (class 2606 OID 16802)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3892 (class 2606 OID 16809)
-- Name: user_sessions user_sessions_refresh_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_unique UNIQUE (refresh_token);


--
-- TOC entry 3856 (class 2606 OID 16684)
-- Name: user_watch_packs user_watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3859 (class 2606 OID 16696)
-- Name: user_watch_packs user_watch_packs_user_id_watch_pack_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique UNIQUE (user_id, watch_pack_id);


--
-- TOC entry 3790 (class 2606 OID 16489)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3792 (class 2606 OID 16510)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3795 (class 2606 OID 16487)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3800 (class 2606 OID 17522)
-- Name: users users_stripe_customer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_unique UNIQUE (stripe_customer_id);


--
-- TOC entry 3802 (class 2606 OID 17524)
-- Name: users users_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_subscription_id_unique UNIQUE (subscription_id);


--
-- TOC entry 3851 (class 2606 OID 16668)
-- Name: watch_packs watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3854 (class 2606 OID 16670)
-- Name: watch_packs watch_packs_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_slug_unique UNIQUE (slug);


--
-- TOC entry 3843 (class 2606 OID 16639)
-- Name: watches watches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_pkey PRIMARY KEY (id);


--
-- TOC entry 3848 (class 2606 OID 16651)
-- Name: watches watches_user_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_product_id_unique UNIQUE (user_id, product_id);


--
-- TOC entry 3994 (class 2606 OID 17187)
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 3965 (class 1259 OID 17083)
-- Name: admin_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_action_created_at_index ON public.admin_audit_log USING btree (action, created_at);


--
-- TOC entry 3966 (class 1259 OID 17082)
-- Name: admin_audit_log_admin_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_admin_user_id_created_at_index ON public.admin_audit_log USING btree (admin_user_id, created_at);


--
-- TOC entry 3967 (class 1259 OID 17085)
-- Name: admin_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_created_at_index ON public.admin_audit_log USING btree (created_at);


--
-- TOC entry 3970 (class 1259 OID 17084)
-- Name: admin_audit_log_target_type_target_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_target_type_target_id_index ON public.admin_audit_log USING btree (target_type, target_id);


--
-- TOC entry 3874 (class 1259 OID 16767)
-- Name: alert_deliveries_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_alert_id_index ON public.alert_deliveries USING btree (alert_id);


--
-- TOC entry 3875 (class 1259 OID 16768)
-- Name: alert_deliveries_channel_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_channel_index ON public.alert_deliveries USING btree (channel);


--
-- TOC entry 3878 (class 1259 OID 16770)
-- Name: alert_deliveries_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_sent_at_index ON public.alert_deliveries USING btree (sent_at);


--
-- TOC entry 3879 (class 1259 OID 16769)
-- Name: alert_deliveries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_status_index ON public.alert_deliveries USING btree (status);


--
-- TOC entry 3861 (class 1259 OID 16744)
-- Name: alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_index ON public.alerts USING btree (created_at);


--
-- TOC entry 3864 (class 1259 OID 16742)
-- Name: alerts_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_priority_index ON public.alerts USING btree (priority);


--
-- TOC entry 3865 (class 1259 OID 16737)
-- Name: alerts_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_product_id_index ON public.alerts USING btree (product_id);


--
-- TOC entry 3866 (class 1259 OID 16738)
-- Name: alerts_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_retailer_id_index ON public.alerts USING btree (retailer_id);


--
-- TOC entry 3867 (class 1259 OID 16743)
-- Name: alerts_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_scheduled_for_index ON public.alerts USING btree (scheduled_for);


--
-- TOC entry 3868 (class 1259 OID 16740)
-- Name: alerts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_index ON public.alerts USING btree (status);


--
-- TOC entry 3869 (class 1259 OID 16746)
-- Name: alerts_status_priority_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_priority_created_at_index ON public.alerts USING btree (status, priority, created_at);


--
-- TOC entry 3870 (class 1259 OID 16741)
-- Name: alerts_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_index ON public.alerts USING btree (type);


--
-- TOC entry 3871 (class 1259 OID 16736)
-- Name: alerts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_index ON public.alerts USING btree (user_id);


--
-- TOC entry 3872 (class 1259 OID 16745)
-- Name: alerts_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_status_index ON public.alerts USING btree (user_id, status);


--
-- TOC entry 3873 (class 1259 OID 16739)
-- Name: alerts_watch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_watch_id_index ON public.alerts USING btree (watch_id);


--
-- TOC entry 3930 (class 1259 OID 16939)
-- Name: availability_snapshots_product_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_product_id_snapshot_time_index ON public.availability_snapshots USING btree (product_id, snapshot_time);


--
-- TOC entry 3931 (class 1259 OID 16940)
-- Name: availability_snapshots_retailer_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_retailer_id_snapshot_time_index ON public.availability_snapshots USING btree (retailer_id, snapshot_time);


--
-- TOC entry 3932 (class 1259 OID 16941)
-- Name: availability_snapshots_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_snapshot_time_index ON public.availability_snapshots USING btree (snapshot_time);


--
-- TOC entry 4028 (class 1259 OID 17361)
-- Name: comment_likes_comment_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_comment_id_index ON public.comment_likes USING btree (comment_id);


--
-- TOC entry 4033 (class 1259 OID 17362)
-- Name: comment_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_user_id_index ON public.comment_likes USING btree (user_id);


--
-- TOC entry 4011 (class 1259 OID 17293)
-- Name: community_posts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_created_at_index ON public.community_posts USING btree (created_at);


--
-- TOC entry 4012 (class 1259 OID 17292)
-- Name: community_posts_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_is_featured_is_public_index ON public.community_posts USING btree (is_featured, is_public);


--
-- TOC entry 4015 (class 1259 OID 17291)
-- Name: community_posts_type_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_type_moderation_status_index ON public.community_posts USING btree (type, moderation_status);


--
-- TOC entry 4016 (class 1259 OID 17290)
-- Name: community_posts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_user_id_index ON public.community_posts USING btree (user_id);


--
-- TOC entry 4075 (class 1259 OID 17519)
-- Name: conversion_analytics_event_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_date_index ON public.conversion_analytics USING btree (event_date);


--
-- TOC entry 4076 (class 1259 OID 17518)
-- Name: conversion_analytics_event_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_type_index ON public.conversion_analytics USING btree (event_type);


--
-- TOC entry 4079 (class 1259 OID 17517)
-- Name: conversion_analytics_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_user_id_index ON public.conversion_analytics USING btree (user_id);


--
-- TOC entry 3996 (class 1259 OID 17214)
-- Name: csv_operations_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_created_at_index ON public.csv_operations USING btree (created_at);


--
-- TOC entry 3999 (class 1259 OID 17213)
-- Name: csv_operations_user_id_operation_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_user_id_operation_type_index ON public.csv_operations USING btree (user_id, operation_type);


--
-- TOC entry 3960 (class 1259 OID 17058)
-- Name: data_quality_metrics_assessed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_assessed_at_index ON public.data_quality_metrics USING btree (assessed_at);


--
-- TOC entry 3961 (class 1259 OID 17059)
-- Name: data_quality_metrics_overall_quality_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_overall_quality_score_index ON public.data_quality_metrics USING btree (overall_quality_score);


--
-- TOC entry 3964 (class 1259 OID 17057)
-- Name: data_quality_metrics_product_id_data_source_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_product_id_data_source_index ON public.data_quality_metrics USING btree (product_id, data_source);


--
-- TOC entry 3990 (class 1259 OID 17170)
-- Name: discord_servers_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX discord_servers_user_id_is_active_index ON public.discord_servers USING btree (user_id, is_active);


--
-- TOC entry 3919 (class 1259 OID 16909)
-- Name: email_bounces_bounce_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_bounce_type_index ON public.email_bounces USING btree (bounce_type);


--
-- TOC entry 3920 (class 1259 OID 16895)
-- Name: email_bounces_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_message_id_index ON public.email_bounces USING btree (message_id);


--
-- TOC entry 3923 (class 1259 OID 16914)
-- Name: email_bounces_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_timestamp_index ON public.email_bounces USING btree ("timestamp");


--
-- TOC entry 3924 (class 1259 OID 16896)
-- Name: email_complaints_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_message_id_index ON public.email_complaints USING btree (message_id);


--
-- TOC entry 3927 (class 1259 OID 16910)
-- Name: email_complaints_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_timestamp_index ON public.email_complaints USING btree ("timestamp");


--
-- TOC entry 3905 (class 1259 OID 16916)
-- Name: email_delivery_logs_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_alert_id_index ON public.email_delivery_logs USING btree (alert_id);


--
-- TOC entry 3906 (class 1259 OID 16921)
-- Name: email_delivery_logs_email_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_email_type_index ON public.email_delivery_logs USING btree (email_type);


--
-- TOC entry 3907 (class 1259 OID 16918)
-- Name: email_delivery_logs_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_message_id_index ON public.email_delivery_logs USING btree (message_id);


--
-- TOC entry 3910 (class 1259 OID 16920)
-- Name: email_delivery_logs_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_sent_at_index ON public.email_delivery_logs USING btree (sent_at);


--
-- TOC entry 3911 (class 1259 OID 16912)
-- Name: email_delivery_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_user_id_index ON public.email_delivery_logs USING btree (user_id);


--
-- TOC entry 3901 (class 1259 OID 16915)
-- Name: email_preferences_unsubscribe_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_unsubscribe_token_index ON public.email_preferences USING btree (unsubscribe_token);


--
-- TOC entry 3904 (class 1259 OID 16911)
-- Name: email_preferences_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_user_id_index ON public.email_preferences USING btree (user_id);


--
-- TOC entry 3948 (class 1259 OID 17015)
-- Name: engagement_metrics_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_metrics_date_index ON public.engagement_metrics USING btree (metrics_date);


--
-- TOC entry 3951 (class 1259 OID 17014)
-- Name: engagement_metrics_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_index ON public.engagement_metrics USING btree (product_id);


--
-- TOC entry 3952 (class 1259 OID 17016)
-- Name: engagement_metrics_product_id_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_metrics_date_index ON public.engagement_metrics USING btree (product_id, metrics_date);


--
-- TOC entry 4071 (class 1259 OID 17501)
-- Name: idx_billing_events_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_customer ON public.billing_events USING btree (stripe_customer_id);


--
-- TOC entry 4072 (class 1259 OID 17503)
-- Name: idx_billing_events_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_invoice ON public.billing_events USING btree (invoice_id);


--
-- TOC entry 4073 (class 1259 OID 17502)
-- Name: idx_billing_events_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_subscription ON public.billing_events USING btree (subscription_id);


--
-- TOC entry 4074 (class 1259 OID 17504)
-- Name: idx_billing_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_type ON public.billing_events USING btree (event_type);


--
-- TOC entry 4063 (class 1259 OID 17487)
-- Name: idx_transactions_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_product ON public.transactions USING btree (product_id);


--
-- TOC entry 4064 (class 1259 OID 17488)
-- Name: idx_transactions_retailer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_retailer ON public.transactions USING btree (retailer_slug);


--
-- TOC entry 4065 (class 1259 OID 17489)
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- TOC entry 4066 (class 1259 OID 17486)
-- Name: idx_transactions_user_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_hash ON public.transactions USING btree (user_id_hash);


--
-- TOC entry 3784 (class 1259 OID 16490)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3785 (class 1259 OID 16829)
-- Name: idx_users_push_subscriptions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_push_subscriptions ON public.users USING btree (id);


--
-- TOC entry 3786 (class 1259 OID 17525)
-- Name: idx_users_stripe_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_stripe_customer ON public.users USING btree (stripe_customer_id);


--
-- TOC entry 3787 (class 1259 OID 17526)
-- Name: idx_users_subscription_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_subscription_status ON public.users USING btree (subscription_status);


--
-- TOC entry 3943 (class 1259 OID 16988)
-- Name: ml_model_metrics_last_evaluated_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_last_evaluated_at_index ON public.ml_model_metrics USING btree (last_evaluated_at);


--
-- TOC entry 3944 (class 1259 OID 16986)
-- Name: ml_model_metrics_model_name_model_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_model_name_model_version_index ON public.ml_model_metrics USING btree (model_name, model_version);


--
-- TOC entry 3947 (class 1259 OID 16987)
-- Name: ml_model_metrics_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_prediction_type_index ON public.ml_model_metrics USING btree (prediction_type);


--
-- TOC entry 3971 (class 1259 OID 17107)
-- Name: ml_models_name_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_name_status_created_at_index ON public.ml_models USING btree (name, status, created_at);


--
-- TOC entry 3976 (class 1259 OID 17108)
-- Name: ml_models_status_deployed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_status_deployed_at_index ON public.ml_models USING btree (status, deployed_at);


--
-- TOC entry 3977 (class 1259 OID 17109)
-- Name: ml_models_trained_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_trained_by_index ON public.ml_models USING btree (trained_by);


--
-- TOC entry 3938 (class 1259 OID 16973)
-- Name: ml_predictions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_expires_at_index ON public.ml_predictions USING btree (expires_at);


--
-- TOC entry 3941 (class 1259 OID 16972)
-- Name: ml_predictions_product_id_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_index ON public.ml_predictions USING btree (product_id, prediction_type);


--
-- TOC entry 3942 (class 1259 OID 16974)
-- Name: ml_predictions_product_id_prediction_type_timeframe_days_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_timeframe_days_index ON public.ml_predictions USING btree (product_id, prediction_type, timeframe_days);


--
-- TOC entry 3978 (class 1259 OID 17131)
-- Name: ml_training_data_dataset_name_data_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_dataset_name_data_type_index ON public.ml_training_data USING btree (dataset_name, data_type);


--
-- TOC entry 3981 (class 1259 OID 17132)
-- Name: ml_training_data_reviewed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_reviewed_by_index ON public.ml_training_data USING btree (reviewed_by);


--
-- TOC entry 3982 (class 1259 OID 17130)
-- Name: ml_training_data_status_data_type_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_status_data_type_created_at_index ON public.ml_training_data USING btree (status, data_type, created_at);


--
-- TOC entry 4051 (class 1259 OID 17440)
-- Name: permission_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_action_created_at_index ON public.permission_audit_log USING btree (action, created_at);


--
-- TOC entry 4052 (class 1259 OID 17439)
-- Name: permission_audit_log_actor_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_actor_user_id_created_at_index ON public.permission_audit_log USING btree (actor_user_id, created_at);


--
-- TOC entry 4053 (class 1259 OID 17441)
-- Name: permission_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_created_at_index ON public.permission_audit_log USING btree (created_at);


--
-- TOC entry 4056 (class 1259 OID 17438)
-- Name: permission_audit_log_target_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_target_user_id_created_at_index ON public.permission_audit_log USING btree (target_user_id, created_at);


--
-- TOC entry 4017 (class 1259 OID 17320)
-- Name: post_comments_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_created_at_index ON public.post_comments USING btree (created_at);


--
-- TOC entry 4020 (class 1259 OID 17318)
-- Name: post_comments_post_id_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_post_id_moderation_status_index ON public.post_comments USING btree (post_id, moderation_status);


--
-- TOC entry 4021 (class 1259 OID 17319)
-- Name: post_comments_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_user_id_index ON public.post_comments USING btree (user_id);


--
-- TOC entry 4024 (class 1259 OID 17340)
-- Name: post_likes_post_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_post_id_index ON public.post_likes USING btree (post_id);


--
-- TOC entry 4027 (class 1259 OID 17341)
-- Name: post_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_user_id_index ON public.post_likes USING btree (user_id);


--
-- TOC entry 3882 (class 1259 OID 16788)
-- Name: price_history_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_index ON public.price_history USING btree (product_id);


--
-- TOC entry 3883 (class 1259 OID 16791)
-- Name: price_history_product_id_retailer_id_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_retailer_id_recorded_at_index ON public.price_history USING btree (product_id, retailer_id, recorded_at);


--
-- TOC entry 3884 (class 1259 OID 16790)
-- Name: price_history_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_recorded_at_index ON public.price_history USING btree (recorded_at);


--
-- TOC entry 3885 (class 1259 OID 16789)
-- Name: price_history_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_retailer_id_index ON public.price_history USING btree (retailer_id);


--
-- TOC entry 3833 (class 1259 OID 16622)
-- Name: product_availability_in_stock_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_in_stock_index ON public.product_availability USING btree (in_stock);


--
-- TOC entry 3834 (class 1259 OID 16623)
-- Name: product_availability_last_checked_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_last_checked_index ON public.product_availability USING btree (last_checked);


--
-- TOC entry 3837 (class 1259 OID 16620)
-- Name: product_availability_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_product_id_index ON public.product_availability USING btree (product_id);


--
-- TOC entry 3840 (class 1259 OID 16621)
-- Name: product_availability_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_retailer_id_index ON public.product_availability USING btree (retailer_id);


--
-- TOC entry 3815 (class 1259 OID 16564)
-- Name: product_categories_parent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_parent_id_index ON public.product_categories USING btree (parent_id);


--
-- TOC entry 3818 (class 1259 OID 16563)
-- Name: product_categories_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_slug_index ON public.product_categories USING btree (slug);


--
-- TOC entry 3821 (class 1259 OID 16590)
-- Name: products_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_index ON public.products USING btree (category_id);


--
-- TOC entry 3822 (class 1259 OID 16592)
-- Name: products_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_is_active_index ON public.products USING btree (is_active);


--
-- TOC entry 3825 (class 1259 OID 16593)
-- Name: products_release_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_release_date_index ON public.products USING btree (release_date);


--
-- TOC entry 3826 (class 1259 OID 16591)
-- Name: products_set_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_set_name_index ON public.products USING btree (set_name);


--
-- TOC entry 3827 (class 1259 OID 16588)
-- Name: products_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_index ON public.products USING btree (slug);


--
-- TOC entry 3830 (class 1259 OID 16589)
-- Name: products_upc_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_upc_index ON public.products USING btree (upc);


--
-- TOC entry 3809 (class 1259 OID 16544)
-- Name: retailers_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_is_active_index ON public.retailers USING btree (is_active);


--
-- TOC entry 3812 (class 1259 OID 16543)
-- Name: retailers_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_slug_index ON public.retailers USING btree (slug);


--
-- TOC entry 4034 (class 1259 OID 17384)
-- Name: roles_created_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_created_by_index ON public.roles USING btree (created_by);


--
-- TOC entry 4035 (class 1259 OID 17382)
-- Name: roles_is_system_role_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_is_system_role_is_active_index ON public.roles USING btree (is_system_role, is_active);


--
-- TOC entry 4036 (class 1259 OID 17383)
-- Name: roles_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_level_index ON public.roles USING btree (level);


--
-- TOC entry 3955 (class 1259 OID 17039)
-- Name: seasonal_patterns_category_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_category_id_pattern_type_index ON public.seasonal_patterns USING btree (category_id, pattern_type);


--
-- TOC entry 3956 (class 1259 OID 17040)
-- Name: seasonal_patterns_pattern_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_pattern_name_index ON public.seasonal_patterns USING btree (pattern_name);


--
-- TOC entry 3959 (class 1259 OID 17038)
-- Name: seasonal_patterns_product_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_product_id_pattern_type_index ON public.seasonal_patterns USING btree (product_id, pattern_type);


--
-- TOC entry 4000 (class 1259 OID 17237)
-- Name: social_shares_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_alert_id_index ON public.social_shares USING btree (alert_id);


--
-- TOC entry 4003 (class 1259 OID 17238)
-- Name: social_shares_shared_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_shared_at_index ON public.social_shares USING btree (shared_at);


--
-- TOC entry 4004 (class 1259 OID 17236)
-- Name: social_shares_user_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_user_id_platform_index ON public.social_shares USING btree (user_id, platform);


--
-- TOC entry 3894 (class 1259 OID 16827)
-- Name: system_health_checked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_checked_at_index ON public.system_health USING btree (checked_at);


--
-- TOC entry 3897 (class 1259 OID 16825)
-- Name: system_health_service_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_service_name_index ON public.system_health USING btree (service_name);


--
-- TOC entry 3898 (class 1259 OID 16826)
-- Name: system_health_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_status_index ON public.system_health USING btree (status);


--
-- TOC entry 3983 (class 1259 OID 17144)
-- Name: system_metrics_metric_name_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_name_recorded_at_index ON public.system_metrics USING btree (metric_name, recorded_at);


--
-- TOC entry 3984 (class 1259 OID 17145)
-- Name: system_metrics_metric_type_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_type_recorded_at_index ON public.system_metrics USING btree (metric_type, recorded_at);


--
-- TOC entry 3987 (class 1259 OID 17146)
-- Name: system_metrics_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_recorded_at_index ON public.system_metrics USING btree (recorded_at);


--
-- TOC entry 4005 (class 1259 OID 17264)
-- Name: testimonials_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_is_featured_is_public_index ON public.testimonials USING btree (is_featured, is_public);


--
-- TOC entry 4006 (class 1259 OID 17263)
-- Name: testimonials_moderation_status_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_moderation_status_is_public_index ON public.testimonials USING btree (moderation_status, is_public);


--
-- TOC entry 4009 (class 1259 OID 17265)
-- Name: testimonials_rating_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_rating_index ON public.testimonials USING btree (rating);


--
-- TOC entry 4010 (class 1259 OID 17262)
-- Name: testimonials_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_user_id_index ON public.testimonials USING btree (user_id);


--
-- TOC entry 3933 (class 1259 OID 16955)
-- Name: trend_analysis_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_analyzed_at_index ON public.trend_analysis USING btree (analyzed_at);


--
-- TOC entry 3936 (class 1259 OID 16956)
-- Name: trend_analysis_product_id_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_analyzed_at_index ON public.trend_analysis USING btree (product_id, analyzed_at);


--
-- TOC entry 3937 (class 1259 OID 16954)
-- Name: trend_analysis_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_index ON public.trend_analysis USING btree (product_id);


--
-- TOC entry 3912 (class 1259 OID 16919)
-- Name: unsubscribe_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_expires_at_index ON public.unsubscribe_tokens USING btree (expires_at);


--
-- TOC entry 3915 (class 1259 OID 16913)
-- Name: unsubscribe_tokens_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_token_index ON public.unsubscribe_tokens USING btree (token);


--
-- TOC entry 3918 (class 1259 OID 16917)
-- Name: unsubscribe_tokens_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_user_id_index ON public.unsubscribe_tokens USING btree (user_id);


--
-- TOC entry 4043 (class 1259 OID 17416)
-- Name: user_roles_assigned_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_assigned_by_index ON public.user_roles USING btree (assigned_by);


--
-- TOC entry 4044 (class 1259 OID 17417)
-- Name: user_roles_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_expires_at_index ON public.user_roles USING btree (expires_at);


--
-- TOC entry 4047 (class 1259 OID 17415)
-- Name: user_roles_role_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_role_id_is_active_index ON public.user_roles USING btree (role_id, is_active);


--
-- TOC entry 4048 (class 1259 OID 17414)
-- Name: user_roles_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_user_id_is_active_index ON public.user_roles USING btree (user_id, is_active);


--
-- TOC entry 3886 (class 1259 OID 16812)
-- Name: user_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_expires_at_index ON public.user_sessions USING btree (expires_at);


--
-- TOC entry 3887 (class 1259 OID 16813)
-- Name: user_sessions_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_is_active_index ON public.user_sessions USING btree (is_active);


--
-- TOC entry 3890 (class 1259 OID 16811)
-- Name: user_sessions_refresh_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_refresh_token_index ON public.user_sessions USING btree (refresh_token);


--
-- TOC entry 3893 (class 1259 OID 16810)
-- Name: user_sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_user_id_index ON public.user_sessions USING btree (user_id);


--
-- TOC entry 3857 (class 1259 OID 16697)
-- Name: user_watch_packs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_user_id_index ON public.user_watch_packs USING btree (user_id);


--
-- TOC entry 3860 (class 1259 OID 16698)
-- Name: user_watch_packs_watch_pack_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_watch_pack_id_index ON public.user_watch_packs USING btree (watch_pack_id);


--
-- TOC entry 3788 (class 1259 OID 16511)
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- TOC entry 3793 (class 1259 OID 17064)
-- Name: users_last_admin_login_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_last_admin_login_index ON public.users USING btree (last_admin_login);


--
-- TOC entry 3796 (class 1259 OID 16522)
-- Name: users_reset_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reset_token_index ON public.users USING btree (reset_token);


--
-- TOC entry 3797 (class 1259 OID 17449)
-- Name: users_role_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_created_at_index ON public.users USING btree (role, created_at);


--
-- TOC entry 3798 (class 1259 OID 17063)
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- TOC entry 3803 (class 1259 OID 17527)
-- Name: users_subscription_plan_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_subscription_plan_id_index ON public.users USING btree (subscription_plan_id);


--
-- TOC entry 3804 (class 1259 OID 16521)
-- Name: users_verification_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_verification_token_index ON public.users USING btree (verification_token);


--
-- TOC entry 3849 (class 1259 OID 16672)
-- Name: watch_packs_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_is_active_index ON public.watch_packs USING btree (is_active);


--
-- TOC entry 3852 (class 1259 OID 16671)
-- Name: watch_packs_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_slug_index ON public.watch_packs USING btree (slug);


--
-- TOC entry 3841 (class 1259 OID 16654)
-- Name: watches_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_is_active_index ON public.watches USING btree (is_active);


--
-- TOC entry 3844 (class 1259 OID 16653)
-- Name: watches_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_product_id_index ON public.watches USING btree (product_id);


--
-- TOC entry 3845 (class 1259 OID 16652)
-- Name: watches_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_index ON public.watches USING btree (user_id);


--
-- TOC entry 3846 (class 1259 OID 16655)
-- Name: watches_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_is_active_index ON public.watches USING btree (user_id, is_active);


--
-- TOC entry 3995 (class 1259 OID 17193)
-- Name: webhooks_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_user_id_is_active_index ON public.webhooks USING btree (user_id, is_active);


--
-- TOC entry 4109 (class 2606 OID 17077)
-- Name: admin_audit_log admin_audit_log_admin_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_user_id_foreign FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4093 (class 2606 OID 16762)
-- Name: alert_deliveries alert_deliveries_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4089 (class 2606 OID 16721)
-- Name: alerts alerts_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4090 (class 2606 OID 16726)
-- Name: alerts alerts_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4091 (class 2606 OID 16716)
-- Name: alerts alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4092 (class 2606 OID 16731)
-- Name: alerts alerts_watch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watch_id_foreign FOREIGN KEY (watch_id) REFERENCES public.watches(id) ON DELETE SET NULL;


--
-- TOC entry 4101 (class 2606 OID 16929)
-- Name: availability_snapshots availability_snapshots_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4102 (class 2606 OID 16934)
-- Name: availability_snapshots availability_snapshots_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4123 (class 2606 OID 17349)
-- Name: comment_likes comment_likes_comment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_foreign FOREIGN KEY (comment_id) REFERENCES public.post_comments(id) ON DELETE CASCADE;


--
-- TOC entry 4124 (class 2606 OID 17354)
-- Name: comment_likes comment_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4118 (class 2606 OID 17285)
-- Name: community_posts community_posts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4114 (class 2606 OID 17208)
-- Name: csv_operations csv_operations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4108 (class 2606 OID 17052)
-- Name: data_quality_metrics data_quality_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4112 (class 2606 OID 17163)
-- Name: discord_servers discord_servers_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4098 (class 2606 OID 16899)
-- Name: email_delivery_logs email_delivery_logs_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE SET NULL;


--
-- TOC entry 4099 (class 2606 OID 16888)
-- Name: email_delivery_logs email_delivery_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4097 (class 2606 OID 16883)
-- Name: email_preferences email_preferences_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4105 (class 2606 OID 17007)
-- Name: engagement_metrics engagement_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4110 (class 2606 OID 17102)
-- Name: ml_models ml_models_trained_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_trained_by_foreign FOREIGN KEY (trained_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4104 (class 2606 OID 16967)
-- Name: ml_predictions ml_predictions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4111 (class 2606 OID 17125)
-- Name: ml_training_data ml_training_data_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4128 (class 2606 OID 17428)
-- Name: permission_audit_log permission_audit_log_actor_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_actor_user_id_foreign FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- TOC entry 4129 (class 2606 OID 17433)
-- Name: permission_audit_log permission_audit_log_target_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_target_user_id_foreign FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- TOC entry 4119 (class 2606 OID 17308)
-- Name: post_comments post_comments_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4120 (class 2606 OID 17313)
-- Name: post_comments post_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4121 (class 2606 OID 17328)
-- Name: post_likes post_likes_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4122 (class 2606 OID 17333)
-- Name: post_likes post_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4094 (class 2606 OID 16778)
-- Name: price_history price_history_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4095 (class 2606 OID 16783)
-- Name: price_history price_history_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4083 (class 2606 OID 16608)
-- Name: product_availability product_availability_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4084 (class 2606 OID 16613)
-- Name: product_availability product_availability_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4081 (class 2606 OID 16558)
-- Name: product_categories product_categories_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4082 (class 2606 OID 16583)
-- Name: products products_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4106 (class 2606 OID 17033)
-- Name: seasonal_patterns seasonal_patterns_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE CASCADE;


--
-- TOC entry 4107 (class 2606 OID 17028)
-- Name: seasonal_patterns seasonal_patterns_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4115 (class 2606 OID 17231)
-- Name: social_shares social_shares_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4116 (class 2606 OID 17226)
-- Name: social_shares social_shares_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4117 (class 2606 OID 17257)
-- Name: testimonials testimonials_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4103 (class 2606 OID 16949)
-- Name: trend_analysis trend_analysis_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4100 (class 2606 OID 16904)
-- Name: unsubscribe_tokens unsubscribe_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4125 (class 2606 OID 17407)
-- Name: user_roles user_roles_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- TOC entry 4126 (class 2606 OID 17402)
-- Name: user_roles user_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4127 (class 2606 OID 17397)
-- Name: user_roles user_roles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4096 (class 2606 OID 16803)
-- Name: user_sessions user_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4087 (class 2606 OID 16685)
-- Name: user_watch_packs user_watch_packs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4088 (class 2606 OID 16690)
-- Name: user_watch_packs user_watch_packs_watch_pack_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_watch_pack_id_foreign FOREIGN KEY (watch_pack_id) REFERENCES public.watch_packs(id) ON DELETE CASCADE;


--
-- TOC entry 4080 (class 2606 OID 17444)
-- Name: users users_role_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_updated_by_foreign FOREIGN KEY (role_updated_by) REFERENCES public.users(id);


--
-- TOC entry 4085 (class 2606 OID 16645)
-- Name: watches watches_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4086 (class 2606 OID 16640)
-- Name: watches watches_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4113 (class 2606 OID 17188)
-- Name: webhooks webhooks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-09-03 10:37:58 MDT

--
-- PostgreSQL database dump complete
--

