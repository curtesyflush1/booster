--
-- PostgreSQL database dump
--

\restrict ShhA6We53d3MEfqu2sKKv3JEQdLsi6k5VYYFajuUJCua6ekSlt96v8axBAzdg1e

-- Dumped from database version 15.14
-- Dumped by pg_dump version 17.6

-- Started on 2025-09-03 22:20:12 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_foreign;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_product_id_foreign;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_role_updated_by_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_watch_pack_id_foreign;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_foreign;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_role_id_foreign;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_assigned_by_foreign;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_user_id_foreign;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_product_id_foreign;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_user_id_foreign;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_alert_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_product_id_foreign;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_category_id_foreign;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_category_id_foreign;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_parent_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_retailer_id_foreign;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_retailer_id_foreign;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_product_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_user_id_foreign;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_user_id_foreign;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_post_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_target_user_id_foreign;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_actor_user_id_foreign;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_reviewed_by_foreign;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_product_id_foreign;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_trained_by_foreign;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_product_id_foreign;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_foreign;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_user_id_foreign;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_alert_id_foreign;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_foreign;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_product_id_foreign;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_user_id_foreign;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_user_id_foreign;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_retailer_id_foreign;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_product_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_watch_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_user_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_retailer_id_foreign;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_product_id_foreign;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_alert_id_foreign;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_admin_user_id_foreign;
DROP INDEX public.webhooks_user_id_is_active_index;
DROP INDEX public.watches_user_id_is_active_index;
DROP INDEX public.watches_user_id_index;
DROP INDEX public.watches_product_id_index;
DROP INDEX public.watches_is_active_index;
DROP INDEX public.watch_packs_slug_index;
DROP INDEX public.watch_packs_is_active_index;
DROP INDEX public.users_verification_token_index;
DROP INDEX public.users_subscription_plan_id_index;
DROP INDEX public.users_role_index;
DROP INDEX public.users_role_created_at_index;
DROP INDEX public.users_reset_token_index;
DROP INDEX public.users_last_admin_login_index;
DROP INDEX public.users_email_index;
DROP INDEX public.user_watch_packs_watch_pack_id_index;
DROP INDEX public.user_watch_packs_user_id_index;
DROP INDEX public.user_sessions_user_id_index;
DROP INDEX public.user_sessions_refresh_token_index;
DROP INDEX public.user_sessions_is_active_index;
DROP INDEX public.user_sessions_expires_at_index;
DROP INDEX public.user_roles_user_id_is_active_index;
DROP INDEX public.user_roles_role_id_is_active_index;
DROP INDEX public.user_roles_expires_at_index;
DROP INDEX public.user_roles_assigned_by_index;
DROP INDEX public.unsubscribe_tokens_user_id_index;
DROP INDEX public.unsubscribe_tokens_token_index;
DROP INDEX public.unsubscribe_tokens_expires_at_index;
DROP INDEX public.trend_analysis_product_id_index;
DROP INDEX public.trend_analysis_product_id_analyzed_at_index;
DROP INDEX public.trend_analysis_analyzed_at_index;
DROP INDEX public.testimonials_user_id_index;
DROP INDEX public.testimonials_rating_index;
DROP INDEX public.testimonials_moderation_status_is_public_index;
DROP INDEX public.testimonials_is_featured_is_public_index;
DROP INDEX public.system_metrics_recorded_at_index;
DROP INDEX public.system_metrics_metric_type_recorded_at_index;
DROP INDEX public.system_metrics_metric_name_recorded_at_index;
DROP INDEX public.system_health_status_index;
DROP INDEX public.system_health_service_name_index;
DROP INDEX public.system_health_checked_at_index;
DROP INDEX public.social_shares_user_id_platform_index;
DROP INDEX public.social_shares_shared_at_index;
DROP INDEX public.social_shares_alert_id_index;
DROP INDEX public.seasonal_patterns_product_id_pattern_type_index;
DROP INDEX public.seasonal_patterns_pattern_name_index;
DROP INDEX public.seasonal_patterns_category_id_pattern_type_index;
DROP INDEX public.roles_level_index;
DROP INDEX public.roles_is_system_role_is_active_index;
DROP INDEX public.roles_created_by_index;
DROP INDEX public.retailers_slug_index;
DROP INDEX public.retailers_is_active_index;
DROP INDEX public.products_upc_index;
DROP INDEX public.products_slug_index;
DROP INDEX public.products_set_name_index;
DROP INDEX public.products_release_date_index;
DROP INDEX public.products_is_active_index;
DROP INDEX public.products_category_id_index;
DROP INDEX public.product_categories_slug_index;
DROP INDEX public.product_categories_parent_id_index;
DROP INDEX public.product_availability_retailer_id_index;
DROP INDEX public.product_availability_product_id_index;
DROP INDEX public.product_availability_last_checked_index;
DROP INDEX public.product_availability_in_stock_index;
DROP INDEX public.price_history_retailer_id_index;
DROP INDEX public.price_history_recorded_at_index;
DROP INDEX public.price_history_product_id_retailer_id_recorded_at_index;
DROP INDEX public.price_history_product_id_index;
DROP INDEX public.post_likes_user_id_index;
DROP INDEX public.post_likes_post_id_index;
DROP INDEX public.post_comments_user_id_index;
DROP INDEX public.post_comments_post_id_moderation_status_index;
DROP INDEX public.post_comments_created_at_index;
DROP INDEX public.permission_audit_log_target_user_id_created_at_index;
DROP INDEX public.permission_audit_log_created_at_index;
DROP INDEX public.permission_audit_log_actor_user_id_created_at_index;
DROP INDEX public.permission_audit_log_action_created_at_index;
DROP INDEX public.ml_training_data_status_data_type_created_at_index;
DROP INDEX public.ml_training_data_reviewed_by_index;
DROP INDEX public.ml_training_data_dataset_name_data_type_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_timeframe_days_index;
DROP INDEX public.ml_predictions_product_id_prediction_type_index;
DROP INDEX public.ml_predictions_expires_at_index;
DROP INDEX public.ml_models_trained_by_index;
DROP INDEX public.ml_models_status_deployed_at_index;
DROP INDEX public.ml_models_name_status_created_at_index;
DROP INDEX public.ml_model_metrics_prediction_type_index;
DROP INDEX public.ml_model_metrics_model_name_model_version_index;
DROP INDEX public.ml_model_metrics_last_evaluated_at_index;
DROP INDEX public.idx_users_subscription_status;
DROP INDEX public.idx_users_stripe_customer;
DROP INDEX public.idx_users_push_subscriptions;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_transactions_user_hash;
DROP INDEX public.idx_transactions_status;
DROP INDEX public.idx_transactions_retailer;
DROP INDEX public.idx_transactions_product;
DROP INDEX public.idx_billing_events_type;
DROP INDEX public.idx_billing_events_subscription;
DROP INDEX public.idx_billing_events_invoice;
DROP INDEX public.idx_billing_events_customer;
DROP INDEX public.external_product_map_product_id_index;
DROP INDEX public.engagement_metrics_product_id_metrics_date_index;
DROP INDEX public.engagement_metrics_product_id_index;
DROP INDEX public.engagement_metrics_metrics_date_index;
DROP INDEX public.email_preferences_user_id_index;
DROP INDEX public.email_preferences_unsubscribe_token_index;
DROP INDEX public.email_delivery_logs_user_id_index;
DROP INDEX public.email_delivery_logs_sent_at_index;
DROP INDEX public.email_delivery_logs_message_id_index;
DROP INDEX public.email_delivery_logs_email_type_index;
DROP INDEX public.email_delivery_logs_alert_id_index;
DROP INDEX public.email_complaints_timestamp_index;
DROP INDEX public.email_complaints_message_id_index;
DROP INDEX public.email_bounces_timestamp_index;
DROP INDEX public.email_bounces_message_id_index;
DROP INDEX public.email_bounces_bounce_type_index;
DROP INDEX public.discord_servers_user_id_is_active_index;
DROP INDEX public.data_quality_metrics_product_id_data_source_index;
DROP INDEX public.data_quality_metrics_overall_quality_score_index;
DROP INDEX public.data_quality_metrics_assessed_at_index;
DROP INDEX public.csv_operations_user_id_operation_type_index;
DROP INDEX public.csv_operations_created_at_index;
DROP INDEX public.conversion_analytics_user_id_index;
DROP INDEX public.conversion_analytics_event_type_index;
DROP INDEX public.conversion_analytics_event_date_index;
DROP INDEX public.community_posts_user_id_index;
DROP INDEX public.community_posts_type_moderation_status_index;
DROP INDEX public.community_posts_is_featured_is_public_index;
DROP INDEX public.community_posts_created_at_index;
DROP INDEX public.comment_likes_user_id_index;
DROP INDEX public.comment_likes_comment_id_index;
DROP INDEX public.availability_snapshots_snapshot_time_index;
DROP INDEX public.availability_snapshots_retailer_id_snapshot_time_index;
DROP INDEX public.availability_snapshots_product_id_snapshot_time_index;
DROP INDEX public.alerts_watch_id_index;
DROP INDEX public.alerts_user_id_status_index;
DROP INDEX public.alerts_user_id_index;
DROP INDEX public.alerts_type_index;
DROP INDEX public.alerts_status_priority_created_at_index;
DROP INDEX public.alerts_status_index;
DROP INDEX public.alerts_scheduled_for_index;
DROP INDEX public.alerts_retailer_id_index;
DROP INDEX public.alerts_product_id_index;
DROP INDEX public.alerts_priority_index;
DROP INDEX public.alerts_created_at_index;
DROP INDEX public.alert_deliveries_status_index;
DROP INDEX public.alert_deliveries_sent_at_index;
DROP INDEX public.alert_deliveries_channel_index;
DROP INDEX public.alert_deliveries_alert_id_index;
DROP INDEX public.admin_audit_log_target_type_target_id_index;
DROP INDEX public.admin_audit_log_created_at_index;
DROP INDEX public.admin_audit_log_admin_user_id_created_at_index;
DROP INDEX public.admin_audit_log_action_created_at_index;
ALTER TABLE ONLY public.webhooks DROP CONSTRAINT webhooks_pkey;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_user_id_product_id_unique;
ALTER TABLE ONLY public.watches DROP CONSTRAINT watches_pkey;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_slug_unique;
ALTER TABLE ONLY public.watch_packs DROP CONSTRAINT watch_packs_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_subscription_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_stripe_customer_id_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_key;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique;
ALTER TABLE ONLY public.user_watch_packs DROP CONSTRAINT user_watch_packs_pkey;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_refresh_token_unique;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_pkey;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_user_id_role_id_unique;
ALTER TABLE ONLY public.user_roles DROP CONSTRAINT user_roles_pkey;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_token_unique;
ALTER TABLE ONLY public.unsubscribe_tokens DROP CONSTRAINT unsubscribe_tokens_pkey;
ALTER TABLE ONLY public.trend_analysis DROP CONSTRAINT trend_analysis_pkey;
ALTER TABLE ONLY public.transactions DROP CONSTRAINT transactions_pkey;
ALTER TABLE ONLY public.testimonials DROP CONSTRAINT testimonials_pkey;
ALTER TABLE ONLY public.system_metrics DROP CONSTRAINT system_metrics_pkey;
ALTER TABLE ONLY public.system_health DROP CONSTRAINT system_health_pkey;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_stripe_price_id_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_slug_unique;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_pkey;
ALTER TABLE ONLY public.social_shares DROP CONSTRAINT social_shares_pkey;
ALTER TABLE ONLY public.seasonal_patterns DROP CONSTRAINT seasonal_patterns_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_slug_unique;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_name_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_slug_unique;
ALTER TABLE ONLY public.retailers DROP CONSTRAINT retailers_pkey;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_upc_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_slug_unique;
ALTER TABLE ONLY public.products DROP CONSTRAINT products_pkey;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_slug_unique;
ALTER TABLE ONLY public.product_categories DROP CONSTRAINT product_categories_pkey;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_product_id_retailer_id_unique;
ALTER TABLE ONLY public.product_availability DROP CONSTRAINT product_availability_pkey;
ALTER TABLE ONLY public.price_history DROP CONSTRAINT price_history_pkey;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_post_id_user_id_unique;
ALTER TABLE ONLY public.post_likes DROP CONSTRAINT post_likes_pkey;
ALTER TABLE ONLY public.post_comments DROP CONSTRAINT post_comments_pkey;
ALTER TABLE ONLY public.permission_audit_log DROP CONSTRAINT permission_audit_log_pkey;
ALTER TABLE ONLY public.ml_training_data DROP CONSTRAINT ml_training_data_pkey;
ALTER TABLE ONLY public.ml_predictions DROP CONSTRAINT ml_predictions_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_pkey;
ALTER TABLE ONLY public.ml_models DROP CONSTRAINT ml_models_name_version_unique;
ALTER TABLE ONLY public.ml_model_metrics DROP CONSTRAINT ml_model_metrics_pkey;
ALTER TABLE ONLY public.knex_migrations DROP CONSTRAINT knex_migrations_pkey;
ALTER TABLE ONLY public.knex_migrations_lock DROP CONSTRAINT knex_migrations_lock_pkey;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_retailer_slug_external_id_unique;
ALTER TABLE ONLY public.external_product_map DROP CONSTRAINT external_product_map_pkey;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_product_id_metrics_date_unique;
ALTER TABLE ONLY public.engagement_metrics DROP CONSTRAINT engagement_metrics_pkey;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_unsubscribe_token_unique;
ALTER TABLE ONLY public.email_preferences DROP CONSTRAINT email_preferences_pkey;
ALTER TABLE ONLY public.email_delivery_logs DROP CONSTRAINT email_delivery_logs_pkey;
ALTER TABLE ONLY public.email_complaints DROP CONSTRAINT email_complaints_pkey;
ALTER TABLE ONLY public.email_bounces DROP CONSTRAINT email_bounces_pkey;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_user_id_server_id_unique;
ALTER TABLE ONLY public.discord_servers DROP CONSTRAINT discord_servers_pkey;
ALTER TABLE ONLY public.data_quality_metrics DROP CONSTRAINT data_quality_metrics_pkey;
ALTER TABLE ONLY public.csv_operations DROP CONSTRAINT csv_operations_pkey;
ALTER TABLE ONLY public.conversion_analytics DROP CONSTRAINT conversion_analytics_pkey;
ALTER TABLE ONLY public.community_posts DROP CONSTRAINT community_posts_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_pkey;
ALTER TABLE ONLY public.comment_likes DROP CONSTRAINT comment_likes_comment_id_user_id_unique;
ALTER TABLE ONLY public.billing_events DROP CONSTRAINT billing_events_pkey;
ALTER TABLE ONLY public.availability_snapshots DROP CONSTRAINT availability_snapshots_pkey;
ALTER TABLE ONLY public.alerts DROP CONSTRAINT alerts_pkey;
ALTER TABLE ONLY public.alert_deliveries DROP CONSTRAINT alert_deliveries_pkey;
ALTER TABLE ONLY public.admin_audit_log DROP CONSTRAINT admin_audit_log_pkey;
ALTER TABLE public.knex_migrations_lock ALTER COLUMN index DROP DEFAULT;
ALTER TABLE public.knex_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.webhooks;
DROP TABLE public.watches;
DROP TABLE public.watch_packs;
DROP TABLE public.users;
DROP TABLE public.user_watch_packs;
DROP TABLE public.user_sessions;
DROP TABLE public.user_roles;
DROP TABLE public.unsubscribe_tokens;
DROP TABLE public.trend_analysis;
DROP TABLE public.transactions;
DROP TABLE public.testimonials;
DROP TABLE public.system_metrics;
DROP TABLE public.system_health;
DROP TABLE public.subscription_plans;
DROP TABLE public.social_shares;
DROP TABLE public.seasonal_patterns;
DROP TABLE public.roles;
DROP TABLE public.retailers;
DROP TABLE public.products;
DROP TABLE public.product_categories;
DROP TABLE public.product_availability;
DROP TABLE public.price_history;
DROP TABLE public.post_likes;
DROP TABLE public.post_comments;
DROP TABLE public.permission_audit_log;
DROP TABLE public.ml_training_data;
DROP TABLE public.ml_predictions;
DROP TABLE public.ml_models;
DROP TABLE public.ml_model_metrics;
DROP SEQUENCE public.knex_migrations_lock_index_seq;
DROP TABLE public.knex_migrations_lock;
DROP SEQUENCE public.knex_migrations_id_seq;
DROP TABLE public.knex_migrations;
DROP TABLE public.external_product_map;
DROP TABLE public.engagement_metrics;
DROP TABLE public.email_preferences;
DROP TABLE public.email_delivery_logs;
DROP TABLE public.email_complaints;
DROP TABLE public.email_bounces;
DROP TABLE public.discord_servers;
DROP TABLE public.data_quality_metrics;
DROP TABLE public.csv_operations;
DROP TABLE public.conversion_analytics;
DROP TABLE public.community_posts;
DROP TABLE public.comment_likes;
DROP TABLE public.billing_events;
DROP TABLE public.availability_snapshots;
DROP TABLE public.alerts;
DROP TABLE public.alert_deliveries;
DROP TABLE public.admin_audit_log;
DROP TYPE public.billing_period_enum;
DROP EXTENSION "uuid-ossp";
DROP EXTENSION pg_trgm;
--
-- TOC entry 3 (class 3079 OID 16396)
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- TOC entry 4341 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- TOC entry 2 (class 3079 OID 16385)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 4342 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1061 (class 1247 OID 17451)
-- Name: billing_period_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.billing_period_enum AS ENUM (
    'monthly',
    'yearly'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 245 (class 1259 OID 17065)
-- Name: admin_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    target_type character varying(50),
    target_id character varying(255),
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT admin_audit_log_check CHECK ((((target_type IS NULL) AND (target_id IS NULL)) OR ((target_type IS NOT NULL) AND (target_id IS NOT NULL))))
);


--
-- TOC entry 229 (class 1259 OID 16747)
-- Name: alert_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_deliveries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id uuid NOT NULL,
    channel text NOT NULL,
    status text DEFAULT 'pending'::text,
    external_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alert_deliveries_channel_check CHECK ((channel = ANY (ARRAY['web_push'::text, 'email'::text, 'sms'::text, 'discord'::text]))),
    CONSTRAINT alert_deliveries_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'delivered'::text, 'failed'::text, 'bounced'::text])))
);


--
-- TOC entry 228 (class 1259 OID 16699)
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    watch_id uuid,
    type text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text,
    delivery_channels jsonb DEFAULT '[]'::jsonb,
    scheduled_for timestamp with time zone,
    sent_at timestamp with time zone,
    read_at timestamp with time zone,
    clicked_at timestamp with time zone,
    failure_reason character varying(255),
    retry_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT alerts_priority_check CHECK ((priority = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'urgent'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'failed'::text, 'read'::text]))),
    CONSTRAINT alerts_type_check CHECK ((type = ANY (ARRAY['restock'::text, 'price_drop'::text, 'low_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 238 (class 1259 OID 16922)
-- Name: availability_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    stock_level integer,
    last_checked timestamp with time zone,
    snapshot_time timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 263 (class 1259 OID 17490)
-- Name: billing_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.billing_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stripe_customer_id character varying(255) NOT NULL,
    subscription_id character varying(255),
    event_type character varying(100) NOT NULL,
    amount_cents integer,
    currency character varying(10),
    status character varying(50),
    invoice_id character varying(255),
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    raw_event jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 257 (class 1259 OID 17342)
-- Name: comment_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 254 (class 1259 OID 17266)
-- Name: community_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.community_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    type text NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    images jsonb DEFAULT '[]'::jsonb,
    tags jsonb DEFAULT '[]'::jsonb,
    likes integer DEFAULT 0,
    comments_count integer DEFAULT 0,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT community_posts_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT community_posts_type_check CHECK ((type = ANY (ARRAY['success_story'::text, 'tip'::text, 'collection_showcase'::text, 'deal_share'::text, 'question'::text])))
);


--
-- TOC entry 264 (class 1259 OID 17505)
-- Name: conversion_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversion_analytics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    event_type character varying(255) NOT NULL,
    source character varying(255) DEFAULT 'direct'::character varying,
    medium character varying(255) DEFAULT 'organic'::character varying,
    campaign character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    event_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 251 (class 1259 OID 17194)
-- Name: csv_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.csv_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    operation_type text NOT NULL,
    filename character varying(255),
    total_rows integer,
    successful_rows integer,
    failed_rows integer,
    errors jsonb DEFAULT '[]'::jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT csv_operations_operation_type_check CHECK ((operation_type = ANY (ARRAY['import'::text, 'export'::text]))),
    CONSTRAINT csv_operations_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'completed'::text, 'failed'::text])))
);


--
-- TOC entry 244 (class 1259 OID 17041)
-- Name: data_quality_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_quality_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    data_source character varying(255) NOT NULL,
    completeness_score numeric(5,2),
    freshness_hours numeric(8,2),
    accuracy_score numeric(5,2),
    missing_fields jsonb DEFAULT '[]'::jsonb,
    overall_quality_score numeric(5,2),
    recommendations jsonb DEFAULT '[]'::jsonb,
    assessed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 249 (class 1259 OID 17150)
-- Name: discord_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.discord_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    server_id character varying(255) NOT NULL,
    channel_id character varying(255) NOT NULL,
    token text,
    alert_filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_alerts_sent integer DEFAULT 0,
    last_alert_sent timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 16862)
-- Name: email_bounces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_bounces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    bounce_type text NOT NULL,
    bounce_sub_type character varying(255) NOT NULL,
    bounced_recipients jsonb NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_bounces_bounce_type_check CHECK ((bounce_type = ANY (ARRAY['permanent'::text, 'transient'::text])))
);


--
-- TOC entry 237 (class 1259 OID 16873)
-- Name: email_complaints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_complaints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id character varying(255) NOT NULL,
    complained_recipients jsonb NOT NULL,
    feedback_type character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16841)
-- Name: email_delivery_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_delivery_logs (
    id character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    alert_id uuid,
    email_type text NOT NULL,
    recipient_email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message_id character varying(255),
    sent_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    bounced_at timestamp with time zone,
    complained_at timestamp with time zone,
    bounce_reason text,
    complaint_reason text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT email_delivery_logs_email_type_check CHECK ((email_type = ANY (ARRAY['alert'::text, 'welcome'::text, 'marketing'::text, 'digest'::text, 'system'::text])))
);


--
-- TOC entry 233 (class 1259 OID 16830)
-- Name: email_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    alert_emails boolean DEFAULT true,
    marketing_emails boolean DEFAULT true,
    weekly_digest boolean DEFAULT true,
    unsubscribe_token character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 242 (class 1259 OID 16989)
-- Name: engagement_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    watch_count integer DEFAULT 0,
    alert_count integer DEFAULT 0,
    click_count integer DEFAULT 0,
    click_through_rate numeric(5,2) DEFAULT '0'::numeric,
    search_volume integer DEFAULT 0,
    social_mentions integer DEFAULT 0,
    engagement_score numeric(5,2) DEFAULT '0'::numeric,
    trend_direction text DEFAULT 'stable'::text,
    metrics_date date NOT NULL,
    calculated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT engagement_metrics_trend_direction_check CHECK ((trend_direction = ANY (ARRAY['rising'::text, 'falling'::text, 'stable'::text])))
);


--
-- TOC entry 265 (class 1259 OID 17532)
-- Name: external_product_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_product_map (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    retailer_slug character varying(255) NOT NULL,
    external_id character varying(255) NOT NULL,
    product_id uuid NOT NULL,
    product_url character varying(255) NOT NULL,
    last_seen_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 16496)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- TOC entry 217 (class 1259 OID 16495)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4343 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 220 (class 1259 OID 16503)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- TOC entry 219 (class 1259 OID 16502)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4344 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 241 (class 1259 OID 16975)
-- Name: ml_model_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_model_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model_name character varying(255) NOT NULL,
    model_version character varying(255) NOT NULL,
    prediction_type text NOT NULL,
    accuracy numeric(5,4),
    "precision" numeric(5,4),
    recall numeric(5,4),
    f1_score numeric(5,4),
    mean_absolute_error numeric(10,4),
    root_mean_square_error numeric(10,4),
    training_data_size integer,
    prediction_count integer DEFAULT 0,
    avg_processing_time numeric(8,2),
    last_trained_at timestamp with time zone,
    last_evaluated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_model_metrics_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 246 (class 1259 OID 17086)
-- Name: ml_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_models (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(50) NOT NULL,
    status text DEFAULT 'training'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    model_path character varying(500),
    training_started_at timestamp with time zone,
    training_completed_at timestamp with time zone,
    deployed_at timestamp with time zone,
    trained_by uuid,
    training_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_models_check CHECK (((status <> 'active'::text) OR (deployed_at IS NOT NULL))),
    CONSTRAINT ml_models_check1 CHECK (((status <> 'training'::text) OR (training_started_at IS NOT NULL))),
    CONSTRAINT ml_models_status_check CHECK ((status = ANY (ARRAY['training'::text, 'active'::text, 'deprecated'::text, 'failed'::text])))
);


--
-- TOC entry 240 (class 1259 OID 16957)
-- Name: ml_predictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_predictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    prediction_type text NOT NULL,
    prediction_data jsonb NOT NULL,
    timeframe_days integer,
    input_price numeric(10,2),
    confidence_score numeric(5,2),
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ml_predictions_prediction_type_check CHECK ((prediction_type = ANY (ARRAY['price'::text, 'sellout'::text, 'roi'::text, 'hype'::text])))
);


--
-- TOC entry 247 (class 1259 OID 17112)
-- Name: ml_training_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ml_training_data (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dataset_name character varying(200) NOT NULL,
    data_type character varying(100) NOT NULL,
    data jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ml_training_data_check CHECK (((status = 'pending'::text) OR ((reviewed_by IS NOT NULL) AND (reviewed_at IS NOT NULL)))),
    CONSTRAINT ml_training_data_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 260 (class 1259 OID 17418)
-- Name: permission_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permission_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid NOT NULL,
    target_user_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    permission_or_role character varying(100),
    old_value json,
    new_value json,
    reason text,
    ip_address character varying(45),
    user_agent text,
    metadata json DEFAULT '{}'::json,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 255 (class 1259 OID 17294)
-- Name: post_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    likes integer DEFAULT 0,
    is_public boolean DEFAULT true,
    moderation_status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT post_comments_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- TOC entry 256 (class 1259 OID 17321)
-- Name: post_likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.post_likes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    post_id uuid NOT NULL,
    user_id uuid NOT NULL,
    liked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 230 (class 1259 OID 16771)
-- Name: price_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.price_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    price numeric(10,2) NOT NULL,
    original_price numeric(10,2),
    in_stock boolean NOT NULL,
    availability_status character varying(255),
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 224 (class 1259 OID 16594)
-- Name: product_availability; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_availability (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_id uuid NOT NULL,
    in_stock boolean DEFAULT false,
    price numeric(10,2),
    original_price numeric(10,2),
    availability_status text,
    product_url character varying(255) NOT NULL,
    cart_url character varying(255),
    stock_level integer,
    store_locations jsonb DEFAULT '[]'::jsonb,
    last_checked timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_in_stock timestamp with time zone,
    last_price_change timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT product_availability_availability_status_check CHECK ((availability_status = ANY (ARRAY['in_stock'::text, 'low_stock'::text, 'out_of_stock'::text, 'pre_order'::text])))
);


--
-- TOC entry 222 (class 1259 OID 16545)
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    parent_id uuid,
    sort_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 16565)
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    sku character varying(255),
    upc character varying(255),
    category_id uuid,
    set_name character varying(255),
    series character varying(255),
    release_date date,
    msrp numeric(10,2),
    image_url character varying(255),
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    popularity_score integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT products_popularity_score_check CHECK (((popularity_score >= 0) AND (popularity_score <= 1000)))
);


--
-- TOC entry 221 (class 1259 OID 16523)
-- Name: retailers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retailers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    website_url character varying(255) NOT NULL,
    api_type text NOT NULL,
    api_config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    rate_limit_per_minute integer DEFAULT 60,
    health_score integer DEFAULT 100,
    last_health_check timestamp with time zone,
    supported_features jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT retailers_api_type_check CHECK ((api_type = ANY (ARRAY['official'::text, 'affiliate'::text, 'scraping'::text]))),
    CONSTRAINT retailers_health_score_check CHECK (((health_score >= 0) AND (health_score <= 100))),
    CONSTRAINT retailers_rate_limit_per_minute_check CHECK (((rate_limit_per_minute >= 1) AND (rate_limit_per_minute <= 10000)))
);


--
-- TOC entry 258 (class 1259 OID 17363)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL,
    description text,
    permissions json DEFAULT '[]'::json,
    is_system_role boolean DEFAULT false,
    categories json DEFAULT '[]'::json,
    level integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 17017)
-- Name: seasonal_patterns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.seasonal_patterns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid,
    category_id uuid,
    pattern_type character varying(255) NOT NULL,
    pattern_name character varying(255) NOT NULL,
    avg_price_change numeric(5,2),
    availability_change numeric(5,2),
    demand_multiplier numeric(4,2) DEFAULT '1'::numeric,
    historical_occurrences integer DEFAULT 1,
    confidence numeric(5,2),
    last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 252 (class 1259 OID 17215)
-- Name: social_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    alert_id uuid,
    platform character varying(255) NOT NULL,
    share_type character varying(255) DEFAULT 'manual'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    shared_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 261 (class 1259 OID 17455)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(50) NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    billing_period public.billing_period_enum NOT NULL,
    stripe_price_id character varying(255),
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    limits jsonb DEFAULT '{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    trial_days integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT name_not_empty CHECK ((length(TRIM(BOTH FROM name)) > 0)),
    CONSTRAINT price_non_negative CHECK ((price >= (0)::numeric))
);


--
-- TOC entry 232 (class 1259 OID 16814)
-- Name: system_health; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name character varying(255) NOT NULL,
    status text NOT NULL,
    metrics jsonb DEFAULT '{}'::jsonb,
    message text,
    checked_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT system_health_status_check CHECK ((status = ANY (ARRAY['healthy'::text, 'degraded'::text, 'down'::text])))
);


--
-- TOC entry 248 (class 1259 OID 17133)
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_type text NOT NULL,
    value numeric(15,6) NOT NULL,
    labels jsonb DEFAULT '{}'::jsonb NOT NULL,
    recorded_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT system_metrics_metric_type_check CHECK ((metric_type = ANY (ARRAY['gauge'::text, 'counter'::text, 'histogram'::text, 'summary'::text])))
);


--
-- TOC entry 253 (class 1259 OID 17239)
-- Name: testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimonials (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_name character varying(255) NOT NULL,
    user_avatar character varying(255),
    content text NOT NULL,
    rating integer NOT NULL,
    is_verified boolean DEFAULT false,
    is_public boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    tags jsonb DEFAULT '[]'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    moderation_status text DEFAULT 'pending'::text,
    moderation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT testimonials_moderation_status_check CHECK ((moderation_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


--
-- TOC entry 262 (class 1259 OID 17475)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    retailer_slug character varying(100) NOT NULL,
    rule_id uuid,
    user_id_hash character varying(200) NOT NULL,
    status character varying(32) NOT NULL,
    price_paid numeric(10,2),
    msrp numeric(10,2),
    qty integer DEFAULT 1 NOT NULL,
    alert_at timestamp with time zone,
    added_to_cart_at timestamp with time zone,
    purchased_at timestamp with time zone,
    lead_time_ms integer,
    failure_reason text,
    region character varying(64),
    session_fingerprint character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 16942)
-- Name: trend_analysis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trend_analysis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    price_trend numeric(10,6),
    availability_trend numeric(10,6),
    demand_score numeric(5,2),
    volatility_score numeric(5,2),
    analyzed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 235 (class 1259 OID 16851)
-- Name: unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unsubscribe_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying(255) NOT NULL,
    user_id uuid NOT NULL,
    email_type text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT unsubscribe_tokens_email_type_check CHECK ((email_type = ANY (ARRAY['all'::text, 'alerts'::text, 'marketing'::text, 'digest'::text])))
);


--
-- TOC entry 259 (class 1259 OID 17385)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assignment_reason text,
    assigned_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 16792)
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    refresh_token character varying(255) NOT NULL,
    device_info character varying(255),
    ip_address character varying(255),
    user_agent character varying(255),
    expires_at timestamp with time zone NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 16673)
-- Name: user_watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    watch_pack_id uuid NOT NULL,
    customizations jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 16477)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    subscription_tier character varying(20) DEFAULT 'free'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    email_verified boolean DEFAULT false,
    verification_token character varying(255),
    reset_token character varying(255),
    reset_token_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login timestamp with time zone,
    shipping_addresses jsonb DEFAULT '[]'::jsonb,
    payment_methods jsonb DEFAULT '[]'::jsonb,
    retailer_credentials jsonb DEFAULT '{}'::jsonb,
    notification_settings jsonb DEFAULT '{"sms": false, "email": true, "discord": false, "web_push": true}'::jsonb,
    quiet_hours jsonb DEFAULT '{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}'::jsonb,
    timezone character varying(255) DEFAULT 'UTC'::character varying,
    zip_code character varying(255),
    push_subscriptions jsonb DEFAULT '[]'::jsonb,
    role text DEFAULT 'user'::text NOT NULL,
    last_admin_login timestamp with time zone,
    admin_permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    preferences jsonb DEFAULT '{}'::jsonb,
    newsletter_subscription boolean DEFAULT false,
    terms_accepted boolean DEFAULT false,
    direct_permissions json DEFAULT '[]'::json,
    role_last_updated timestamp with time zone,
    role_updated_by uuid,
    permission_metadata json DEFAULT '{}'::json,
    stripe_customer_id character varying(255),
    subscription_id character varying(255),
    subscription_status character varying(50),
    subscription_start_date timestamp with time zone,
    subscription_end_date timestamp with time zone,
    trial_end_date timestamp with time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    subscription_plan_id character varying(255),
    CONSTRAINT users_failed_login_attempts_check CHECK (((failed_login_attempts >= 0) AND (failed_login_attempts <= 10))),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['user'::text, 'admin'::text, 'super_admin'::text])))
);


--
-- TOC entry 226 (class 1259 OID 16656)
-- Name: watch_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watch_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    product_ids jsonb NOT NULL,
    is_active boolean DEFAULT true,
    auto_update boolean DEFAULT true,
    update_criteria character varying(255),
    subscriber_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 16624)
-- Name: watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    retailer_ids jsonb DEFAULT '[]'::jsonb,
    max_price numeric(10,2),
    availability_type text DEFAULT 'both'::text,
    zip_code character varying(255),
    radius_miles integer,
    is_active boolean DEFAULT true,
    alert_preferences jsonb DEFAULT '{}'::jsonb,
    last_alerted timestamp with time zone,
    alert_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    auto_purchase jsonb DEFAULT '{}'::jsonb,
    CONSTRAINT watches_availability_type_check CHECK ((availability_type = ANY (ARRAY['online'::text, 'in_store'::text, 'both'::text])))
);


--
-- TOC entry 250 (class 1259 OID 17171)
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    url text NOT NULL,
    secret text,
    events jsonb NOT NULL,
    headers jsonb DEFAULT '{}'::jsonb,
    retry_config jsonb DEFAULT '{"maxRetries": 3, "retryDelay": 1000, "backoffMultiplier": 2}'::jsonb,
    filters jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    total_calls integer DEFAULT 0,
    successful_calls integer DEFAULT 0,
    failed_calls integer DEFAULT 0,
    last_triggered timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3533 (class 2604 OID 16499)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3534 (class 2604 OID 16506)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 4315 (class 0 OID 17065)
-- Dependencies: 245
-- Data for Name: admin_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_audit_log (id, admin_user_id, action, target_type, target_id, details, ip_address, user_agent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4299 (class 0 OID 16747)
-- Dependencies: 229
-- Data for Name: alert_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_deliveries (id, alert_id, channel, status, external_id, metadata, sent_at, delivered_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4298 (class 0 OID 16699)
-- Dependencies: 228
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, user_id, product_id, retailer_id, watch_id, type, priority, data, status, delivery_channels, scheduled_for, sent_at, read_at, clicked_at, failure_reason, retry_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4308 (class 0 OID 16922)
-- Dependencies: 238
-- Data for Name: availability_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_snapshots (id, product_id, retailer_id, in_stock, availability_status, stock_level, last_checked, snapshot_time) FROM stdin;
\.


--
-- TOC entry 4333 (class 0 OID 17490)
-- Dependencies: 263
-- Data for Name: billing_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.billing_events (id, stripe_customer_id, subscription_id, event_type, amount_cents, currency, status, invoice_id, occurred_at, raw_event, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4327 (class 0 OID 17342)
-- Dependencies: 257
-- Data for Name: comment_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_likes (id, comment_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4324 (class 0 OID 17266)
-- Dependencies: 254
-- Data for Name: community_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.community_posts (id, user_id, user_name, user_avatar, type, title, content, images, tags, likes, comments_count, is_public, is_featured, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4334 (class 0 OID 17505)
-- Dependencies: 264
-- Data for Name: conversion_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversion_analytics (id, user_id, event_type, source, medium, campaign, metadata, event_date) FROM stdin;
\.


--
-- TOC entry 4321 (class 0 OID 17194)
-- Dependencies: 251
-- Data for Name: csv_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.csv_operations (id, user_id, operation_type, filename, total_rows, successful_rows, failed_rows, errors, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4314 (class 0 OID 17041)
-- Dependencies: 244
-- Data for Name: data_quality_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_quality_metrics (id, product_id, data_source, completeness_score, freshness_hours, accuracy_score, missing_fields, overall_quality_score, recommendations, assessed_at) FROM stdin;
\.


--
-- TOC entry 4319 (class 0 OID 17150)
-- Dependencies: 249
-- Data for Name: discord_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.discord_servers (id, user_id, server_id, channel_id, token, alert_filters, is_active, total_alerts_sent, last_alert_sent, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4306 (class 0 OID 16862)
-- Dependencies: 236
-- Data for Name: email_bounces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_bounces (id, message_id, bounce_type, bounce_sub_type, bounced_recipients, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4307 (class 0 OID 16873)
-- Dependencies: 237
-- Data for Name: email_complaints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_complaints (id, message_id, complained_recipients, feedback_type, "timestamp", created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4304 (class 0 OID 16841)
-- Dependencies: 234
-- Data for Name: email_delivery_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_delivery_logs (id, user_id, alert_id, email_type, recipient_email, subject, message_id, sent_at, delivered_at, bounced_at, complained_at, bounce_reason, complaint_reason, metadata, created_at, updated_at) FROM stdin;
email_1756919173617_bv7v21nkg	0b5d6a4f-8fd8-439b-9d75-6e0933be5b7e	\N	system	derekmihlfeith@gmail.com	Verify your email for BoosterBeacon	<8dfd01f4-f9d6-446a-c6fb-c6c23dc24dad@boosterbeacon.com>	2025-09-03 17:06:13.617+00	\N	\N	\N	\N	\N	{"category": "verification"}	2025-09-03 17:06:13.617743+00	2025-09-03 17:06:13.617743+00
\.


--
-- TOC entry 4303 (class 0 OID 16830)
-- Dependencies: 233
-- Data for Name: email_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_preferences (id, user_id, alert_emails, marketing_emails, weekly_digest, unsubscribe_token, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4312 (class 0 OID 16989)
-- Dependencies: 242
-- Data for Name: engagement_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.engagement_metrics (id, product_id, watch_count, alert_count, click_count, click_through_rate, search_volume, social_mentions, engagement_score, trend_direction, metrics_date, calculated_at) FROM stdin;
\.


--
-- TOC entry 4335 (class 0 OID 17532)
-- Dependencies: 265
-- Data for Name: external_product_map; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_product_map (id, retailer_slug, external_id, product_id, product_url, last_seen_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4288 (class 0 OID 16496)
-- Dependencies: 218
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	001_initial_schema.js	1	2025-09-03 16:36:02.672+00
2	20250826174814_expand_core_schema.js	1	2025-09-03 16:36:02.826+00
3	20250826180000_add_push_subscriptions.js	1	2025-09-03 16:36:02.828+00
4	20250827000001_email_system.js	1	2025-09-03 16:36:02.876+00
5	20250827130000_add_ml_tables.js	1	2025-09-03 16:36:02.937+00
6	20250827140000_add_user_roles.js	1	2025-09-03 16:36:02.98+00
7	20250827140001_add_missing_user_fields.js	1	2025-09-03 16:36:02.981+00
8	20250827140005_validate_admin_setup.js	1	2025-09-03 16:36:02.997+00
9	20250827140006_add_registration_fields.js	1	2025-09-03 16:36:02.998+00
10	20250827150000_add_community_integration_tables.js	1	2025-09-03 16:36:03.08+00
11	20250827160000_implement_granular_rbac.js	1	2025-09-03 16:36:03.122+00
12	20250829151931_create_subscription_plans_table.js	1	2025-09-03 16:36:03.132+00
13	20250901090000_create_transactions_and_billing_events.js	1	2025-09-03 16:36:03.15+00
14	20250901151600_add_conversion_analytics.js	1	2025-09-03 16:36:03.158+00
15	20250901152000_add_user_subscription_columns.js	1	2025-09-03 16:36:03.166+00
16	20250901154000_add_user_subscription_plan_id.js	1	2025-09-03 16:36:03.168+00
17	20250902140000_add_watch_auto_purchase.js	1	2025-09-03 16:36:03.174+00
\.


--
-- TOC entry 4290 (class 0 OID 16503)
-- Dependencies: 220
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- TOC entry 4311 (class 0 OID 16975)
-- Dependencies: 241
-- Data for Name: ml_model_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_model_metrics (id, model_name, model_version, prediction_type, accuracy, "precision", recall, f1_score, mean_absolute_error, root_mean_square_error, training_data_size, prediction_count, avg_processing_time, last_trained_at, last_evaluated_at, created_at) FROM stdin;
\.


--
-- TOC entry 4316 (class 0 OID 17086)
-- Dependencies: 246
-- Data for Name: ml_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_models (id, name, version, status, config, metrics, model_path, training_started_at, training_completed_at, deployed_at, trained_by, training_notes, created_at, updated_at) FROM stdin;
a139aaf0-9ce6-43d5-a308-130a64588316	price_prediction	v1.0	active	{"algorithm": "ARIMA", "forecast_days": 7, "lookback_days": 30}	{"mae": 2.34, "rmse": 3.12, "accuracy": 0.85}	\N	2025-08-27 16:53:58.369+00	2025-08-28 16:53:58.369+00	2025-08-28 16:53:58.369+00	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
b9f29bf2-92a8-4efe-8ed8-026c5fa19350	sellout_risk	v1.2	active	{"features": ["price_history", "availability_patterns", "user_engagement"], "algorithm": "Random Forest"}	{"recall": 0.94, "accuracy": 0.92, "precision": 0.89}	\N	2025-08-31 16:53:58.369+00	2025-09-01 16:53:58.369+00	2025-09-01 16:53:58.369+00	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
8a5afdf6-05e7-43e8-b368-a0840f42265f	roi_estimation	v0.8	training	{"algorithm": "LSTM", "hidden_units": 128, "sequence_length": 14}	{}	\N	2025-09-02 16:53:58.369+00	\N	\N	\N	\N	2025-09-03 16:53:58.370205+00	2025-09-03 16:53:58.370205+00
\.


--
-- TOC entry 4310 (class 0 OID 16957)
-- Dependencies: 240
-- Data for Name: ml_predictions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_predictions (id, product_id, prediction_type, prediction_data, timeframe_days, input_price, confidence_score, expires_at, created_at) FROM stdin;
\.


--
-- TOC entry 4317 (class 0 OID 17112)
-- Dependencies: 247
-- Data for Name: ml_training_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ml_training_data (id, dataset_name, data_type, data, status, reviewed_by, reviewed_at, review_notes, created_at, updated_at) FROM stdin;
7dd8a9cc-9dc5-4404-91a5-c04bf1de9a6f	pokemon_tcg_prices_q4_2024	price_history	{"products": ["charizard_151", "pikachu_promo"], "date_range": "2024-10-01 to 2024-12-31", "price_points": 1250}	pending	\N	\N	\N	2025-09-03 16:53:58.374142+00	2025-09-03 16:53:58.374142+00
9ac0295c-1d42-455c-8436-e5d2097b0e45	availability_patterns_holiday_2024	availability_patterns	{"retailers": ["best_buy", "walmart", "costco"], "pattern_count": 890, "seasonal_factor": "holiday_rush"}	approved	a7d94af5-6a3d-4b56-bdbf-52bec13375a1	2025-09-03 16:53:58.374142+00	\N	2025-09-03 16:53:58.374142+00	2025-09-03 16:53:58.374142+00
\.


--
-- TOC entry 4330 (class 0 OID 17418)
-- Dependencies: 260
-- Data for Name: permission_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permission_audit_log (id, actor_user_id, target_user_id, action, permission_or_role, old_value, new_value, reason, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- TOC entry 4325 (class 0 OID 17294)
-- Dependencies: 255
-- Data for Name: post_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_comments (id, post_id, user_id, user_name, user_avatar, content, likes, is_public, moderation_status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4326 (class 0 OID 17321)
-- Dependencies: 256
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.post_likes (id, post_id, user_id, liked_at) FROM stdin;
\.


--
-- TOC entry 4300 (class 0 OID 16771)
-- Dependencies: 230
-- Data for Name: price_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.price_history (id, product_id, retailer_id, price, original_price, in_stock, availability_status, recorded_at) FROM stdin;
9d0022bc-d872-4a1d-ae29-f3cd1ebe1373	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.99	143.64	t	in_stock	2025-08-04 22:19:06.331+00
643935b3-0291-42df-87b6-6d174dfae012	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.18	143.64	t	in_stock	2025-08-05 22:19:06.331+00
957b10df-f040-460c-9ad9-fdf6a7d8684a	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	142.10	143.64	t	in_stock	2025-08-06 22:19:06.331+00
cd540b93-8aa3-4ab5-893e-ac0fdea4b63f	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.61	143.64	t	in_stock	2025-08-07 22:19:06.331+00
4fb162a2-4dd6-4368-ad11-f4339adb35fc	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	148.03	143.64	t	in_stock	2025-08-08 22:19:06.331+00
98f33b2d-ad51-444c-8db4-bad20759c6b8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.60	143.64	t	in_stock	2025-08-09 22:19:06.331+00
9253327b-7b3c-447e-a73a-790d14f8ee70	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.60	143.64	f	out_of_stock	2025-08-10 22:19:06.331+00
0d3e0964-2223-4301-87f7-b3a734381b63	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.03	143.64	t	in_stock	2025-08-11 22:19:06.331+00
3ebf660e-65c8-42fe-8068-bb3dfc9af130	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	151.77	143.64	t	in_stock	2025-08-12 22:19:06.331+00
aaa06d84-b5d3-4569-9fed-8438a1a156e5	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	142.14	143.64	f	out_of_stock	2025-08-13 22:19:06.331+00
661e8f59-2e34-44c8-b72d-a399b11348af	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.57	143.64	t	in_stock	2025-08-14 22:19:06.331+00
f54c1d77-1f17-43fe-bb2e-6908715a642d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.94	143.64	f	out_of_stock	2025-08-15 22:19:06.331+00
22275355-c7b2-4f75-9fda-2888a6e02e64	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	141.47	143.64	f	out_of_stock	2025-08-16 22:19:06.331+00
cc6c56c7-3353-409e-85ae-30061bc029f2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	152.52	143.64	t	in_stock	2025-08-17 22:19:06.331+00
def71e1e-24ef-4fbf-9d52-2a09a778d4f3	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	148.79	143.64	t	in_stock	2025-08-18 22:19:06.331+00
716993d2-e011-4104-bc62-7312cb237d85	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.87	143.64	t	in_stock	2025-08-19 22:19:06.331+00
ff641899-ed5e-4fc6-a9d5-2ccad97de66c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	141.83	143.64	t	in_stock	2025-08-20 22:19:06.331+00
01facaca-3ad0-4cc2-9d8b-67653e6841f2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.77	143.64	t	in_stock	2025-08-21 22:19:06.331+00
0037d3d1-e4bd-456e-9076-224185b85f96	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	140.03	143.64	f	out_of_stock	2025-08-22 22:19:06.331+00
2a39ae57-8c39-4a11-ad76-0b83aef5bc32	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	148.54	143.64	t	in_stock	2025-08-23 22:19:06.331+00
e6639c01-2d9f-4d6d-a5c7-a54c0349e34c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	149.59	143.64	t	in_stock	2025-08-24 22:19:06.331+00
dee793dd-2e19-4454-a339-f3c5aad169f8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.81	143.64	f	out_of_stock	2025-08-25 22:19:06.331+00
cd6a793a-de9f-4929-a2d6-9e856c4bd49c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.54	143.64	f	out_of_stock	2025-08-26 22:19:06.331+00
e985ad18-57ab-49c6-9bda-1ac138058e26	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.42	143.64	t	in_stock	2025-08-27 22:19:06.331+00
fdb1fc4a-040c-41e2-9610-8f004ad5604c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.43	143.64	t	in_stock	2025-08-28 22:19:06.331+00
c85d088c-8671-404e-ad9c-c381d87af216	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	149.27	143.64	f	out_of_stock	2025-08-29 22:19:06.331+00
9af7647a-a8ff-45d3-b6e0-c12b01cba7ef	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.47	143.64	f	out_of_stock	2025-08-30 22:19:06.331+00
f7b4cae6-9fa3-45f5-b955-e834ef3d1c13	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	133.44	143.64	f	out_of_stock	2025-08-31 22:19:06.331+00
d3319606-89a0-4cbf-899d-56f04a2ae026	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.72	143.64	t	in_stock	2025-09-01 22:19:06.331+00
6aa99a88-8c9d-466b-81a1-2f01984df763	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.47	143.64	t	in_stock	2025-09-02 22:19:06.331+00
209893d3-e608-4223-8426-113ed2cd3d88	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.40	143.64	t	in_stock	2025-09-03 22:19:06.331+00
e9cf1473-f0c5-4efc-8e41-4f8479f292d6	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.27	143.64	f	out_of_stock	2025-08-04 22:19:06.331+00
7aa837f5-8e9e-46cf-889f-87cf003dab7d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.01	143.64	t	in_stock	2025-08-05 22:19:06.331+00
5f3799bb-5933-4bb7-88f3-1d7106af96c8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	148.84	143.64	t	in_stock	2025-08-06 22:19:06.331+00
13d6ab99-d8c6-4844-afcc-a7f876fd431b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	133.18	143.64	f	out_of_stock	2025-08-07 22:19:06.331+00
85d7ae7e-9efd-408f-b1f9-9d43cd72dbad	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	141.80	143.64	t	in_stock	2025-08-08 22:19:06.331+00
9af0dba8-0970-48ce-a838-143b344994a8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	145.02	143.64	t	in_stock	2025-08-09 22:19:06.331+00
395b4217-d531-4ae1-809d-82a4b33e6615	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	151.39	143.64	t	in_stock	2025-08-10 22:19:06.331+00
f6ae7047-8869-46f3-b6d8-48ac8279f464	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	150.70	143.64	t	in_stock	2025-08-11 22:19:06.331+00
312de2f7-de46-4870-9f48-803da4636256	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	152.12	143.64	t	in_stock	2025-08-12 22:19:06.331+00
3d96f92e-b9ea-4264-a906-652d54867513	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.08	143.64	f	out_of_stock	2025-08-13 22:19:06.331+00
da677e32-2d0d-48b8-8a31-113709f9ccf4	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.37	143.64	t	in_stock	2025-08-14 22:19:06.331+00
1e61b67f-76e5-4be9-9419-70da6240b540	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	137.51	143.64	f	out_of_stock	2025-08-15 22:19:06.331+00
5f0ddb79-c29d-4bcd-a9b6-cea989c6d885	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	149.53	143.64	t	in_stock	2025-08-16 22:19:06.331+00
9f0e6c5e-cf22-469d-9ec2-4faf516b30e3	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	142.69	143.64	f	out_of_stock	2025-08-17 22:19:06.331+00
c3bc64a6-94b0-41b2-b954-ec7288298289	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	137.94	143.64	t	in_stock	2025-08-18 22:19:06.331+00
1aec2112-60d0-492e-b85c-0d0168b6853c	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	146.21	143.64	t	in_stock	2025-08-19 22:19:06.331+00
f9da48e6-eb89-450f-b719-6aed629970eb	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	134.04	143.64	t	in_stock	2025-08-20 22:19:06.331+00
314ff4be-3b7e-4de3-bb85-e516ffcefb03	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	143.13	143.64	t	in_stock	2025-08-21 22:19:06.331+00
a0203598-e885-46d4-9e3d-06da1cbe49a9	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	150.14	143.64	t	in_stock	2025-08-22 22:19:06.331+00
9bb7a9e2-c284-403b-975d-6c23ae5f4dca	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	134.09	143.64	t	in_stock	2025-08-23 22:19:06.331+00
3b09b250-1891-405e-adbf-37580e8c4d4b	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	136.22	143.64	t	in_stock	2025-08-24 22:19:06.331+00
562e6995-80cd-45e6-a427-42bfb3d45ca3	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.28	143.64	f	out_of_stock	2025-08-25 22:19:06.331+00
388d101d-e1cd-4e9b-bcb2-3dcc41580b62	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	147.20	143.64	t	in_stock	2025-08-26 22:19:06.331+00
846a1650-68d9-41f5-80f3-d5926f533739	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.21	143.64	t	in_stock	2025-08-27 22:19:06.331+00
6e81a8d6-96db-4447-9ff6-23aab18f54c7	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	150.00	143.64	f	out_of_stock	2025-08-28 22:19:06.331+00
a7197b2e-3fda-49ed-8099-37bf39e0bed8	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	140.70	143.64	t	in_stock	2025-08-29 22:19:06.331+00
86cf77b1-929c-4262-aa39-f5704992d1a0	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	153.72	143.64	f	out_of_stock	2025-08-30 22:19:06.331+00
b978680e-b20a-439e-891e-07d5b790214e	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	145.62	143.64	f	out_of_stock	2025-08-31 22:19:06.331+00
9b7874a9-e215-4751-ac78-00513d49484d	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	143.43	143.64	t	in_stock	2025-09-01 22:19:06.331+00
9e9f2d89-f7dc-4ce7-af0b-6b198eba4072	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	146.66	143.64	t	in_stock	2025-09-02 22:19:06.331+00
44041188-b69c-4e64-b5f1-ec4312826dd2	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	146.61	143.64	t	in_stock	2025-09-03 22:19:06.331+00
97614e24-445c-4219-b9df-855ccf58ad75	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.45	143.64	t	in_stock	2025-08-04 22:19:06.331+00
34ffe844-24ce-4932-b898-fab6969b9b35	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.88	143.64	t	in_stock	2025-08-05 22:19:06.331+00
499abb94-2630-4bf5-a752-1107af8ea38c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.09	143.64	t	in_stock	2025-08-06 22:19:06.331+00
71127820-b9ef-44e5-8e30-8e330f95a0ef	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.43	143.64	t	in_stock	2025-08-07 22:19:06.331+00
29e976dd-b4bb-46c0-872c-5341e5358be4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.17	143.64	t	in_stock	2025-08-08 22:19:06.331+00
e54503ed-ff3a-402b-8676-543896da1e46	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	138.49	143.64	t	in_stock	2025-08-09 22:19:06.331+00
8f03726a-0c4d-497e-a8f5-ef9d6a04b27c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.18	143.64	t	in_stock	2025-08-10 22:19:06.331+00
8e9c2344-792b-41b2-b947-509001443a10	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.17	143.64	t	in_stock	2025-08-11 22:19:06.331+00
7346f0a8-4060-49eb-a56d-2038daf84a1f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	138.52	143.64	t	in_stock	2025-08-12 22:19:06.331+00
f4aec007-57f6-422b-899f-b5d94b28398b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.86	143.64	t	in_stock	2025-08-13 22:19:06.331+00
de119d47-ebd6-444e-97a6-625b4724f06a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	134.10	143.64	t	in_stock	2025-08-14 22:19:06.331+00
d15d8c97-6182-432b-9f9e-904d90fb7473	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.77	143.64	t	in_stock	2025-08-15 22:19:06.331+00
4c022adf-c043-4a4f-afce-8cd20b428ea0	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.50	143.64	t	in_stock	2025-08-16 22:19:06.331+00
3dd31735-6f55-4363-9794-7a05588f5e09	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	153.16	143.64	t	in_stock	2025-08-17 22:19:06.331+00
f5522396-6646-4069-9c1b-22a1bac797ff	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.48	143.64	t	in_stock	2025-08-18 22:19:06.331+00
9f014a9c-9a77-421b-930d-89861b47aaa1	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.05	143.64	t	in_stock	2025-08-19 22:19:06.331+00
92f3324a-bc7e-4a6b-b072-d130445fd6ae	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.51	143.64	f	out_of_stock	2025-08-20 22:19:06.331+00
e480994a-4a85-4169-b2ca-e4081e8c4a24	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.24	143.64	f	out_of_stock	2025-08-21 22:19:06.331+00
ee35214c-be08-4d20-8332-b0a58d55d7d0	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	137.37	143.64	t	in_stock	2025-08-22 22:19:06.331+00
18397c15-c524-4f42-a8de-9237051f2f88	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	143.97	143.64	t	in_stock	2025-08-23 22:19:06.331+00
45743b8e-71f4-4c1f-8604-f49723aab324	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	144.35	143.64	f	out_of_stock	2025-08-24 22:19:06.331+00
c4a091c2-32b8-4139-8604-ddb3d97d6d0e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	147.47	143.64	t	in_stock	2025-08-25 22:19:06.331+00
e1b4aa09-2aae-40c4-83dd-4718f37c7afd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	138.53	143.64	t	in_stock	2025-08-26 22:19:06.331+00
c0d41b83-d6a3-4ce9-85a7-3cd6f02f9ba4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	149.88	143.64	t	in_stock	2025-08-27 22:19:06.331+00
0bc4339e-fa5e-4068-906f-3998359bee7a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	141.57	143.64	f	out_of_stock	2025-08-28 22:19:06.331+00
6e9e0e26-0247-422f-90f3-543f4d19191e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.27	143.64	t	in_stock	2025-08-29 22:19:06.331+00
53502d3c-9d5a-4e0c-8b39-2708581b85dd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	135.37	143.64	f	out_of_stock	2025-08-30 22:19:06.331+00
ec4256a6-1c6a-4510-939f-69876694b7cb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	150.10	143.64	t	in_stock	2025-08-31 22:19:06.331+00
aed9ef86-65ef-42cc-b6f8-b090c019a6da	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	139.93	143.64	t	in_stock	2025-09-01 22:19:06.331+00
60beb62f-1140-4a54-9710-2133e874347f	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	136.40	143.64	t	in_stock	2025-09-02 22:19:06.331+00
d3d83209-d85b-4f42-857f-dd4a3e431ca3	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	146.40	143.64	t	in_stock	2025-09-03 22:19:06.331+00
4ebebc97-988d-4b62-a7da-92742608d859	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	151.59	143.64	f	out_of_stock	2025-08-04 22:19:06.331+00
a1bc3aee-ae43-4102-8299-bf7d1f58edcf	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	153.77	143.64	t	in_stock	2025-08-05 22:19:06.331+00
40efe2c7-5907-415e-9269-9b81387c99e7	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	140.98	143.64	t	in_stock	2025-08-06 22:19:06.331+00
dc1e393a-31c2-4fb4-af28-b735e8e2f5ea	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	133.92	143.64	t	in_stock	2025-08-07 22:19:06.331+00
e0b0f67f-2956-4cc5-9c61-386591c10cbd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	136.41	143.64	f	out_of_stock	2025-08-08 22:19:06.331+00
e79f63e8-b809-4e9b-b410-c67bf70b9304	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.83	143.64	f	out_of_stock	2025-08-09 22:19:06.331+00
2ff91897-9ee6-4552-bdd9-d4d1ae0393f9	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	151.17	143.64	t	in_stock	2025-08-10 22:19:06.331+00
bc8a8430-a641-4c14-8687-8e60cb69ab6a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	144.36	143.64	t	in_stock	2025-08-11 22:19:06.331+00
f8f41804-7269-4095-b0ad-d70e7e4785dc	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	146.52	143.64	t	in_stock	2025-08-12 22:19:06.331+00
c1ace185-60c6-4b2b-be36-55f9fddb89d1	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	144.79	143.64	t	in_stock	2025-08-13 22:19:06.331+00
c8a42534-de91-4a8b-8c77-7f26e49e6534	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	153.66	143.64	f	out_of_stock	2025-08-14 22:19:06.331+00
7a47d2e9-6871-47c6-b365-e87ea32e634d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.80	143.64	t	in_stock	2025-08-15 22:19:06.331+00
bf72ee8b-cde6-42aa-855c-82dbe3ab0b36	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	147.66	143.64	t	in_stock	2025-08-16 22:19:06.331+00
1c47f0d3-162e-4f42-a1a1-1fcb7124d34c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	140.88	143.64	t	in_stock	2025-08-17 22:19:06.331+00
402605aa-2444-4c8e-b56c-2b86e1bd6513	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	140.50	143.64	t	in_stock	2025-08-18 22:19:06.331+00
0e241e99-321c-46e2-9168-d27ed8718ea8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.57	143.64	t	in_stock	2025-08-19 22:19:06.331+00
d4641f3f-c222-4fc3-a6c2-c586f1f49f41	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	145.15	143.64	t	in_stock	2025-08-20 22:19:06.331+00
b06fc73d-e9a2-48a5-861a-9f33082a7b8a	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	146.96	143.64	t	in_stock	2025-08-21 22:19:06.331+00
00c57ca7-c1fd-401a-8046-5c0d245fbbb8	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	138.64	143.64	t	in_stock	2025-08-22 22:19:06.331+00
d6e1cb14-8bfb-4f0e-a914-64795d6068b4	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	149.26	143.64	t	in_stock	2025-08-23 22:19:06.331+00
c86aac61-dee9-4d31-8791-b4de17d8b992	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	154.40	143.64	t	in_stock	2025-08-24 22:19:06.331+00
43eb599f-f5eb-4895-b025-c983a7047739	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	136.17	143.64	f	out_of_stock	2025-08-25 22:19:06.331+00
63cd3547-20b5-4c18-bbc1-36f449c8b226	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	148.40	143.64	t	in_stock	2025-08-26 22:19:06.331+00
909ef2b9-a8e2-46ca-ad9b-18ce60d07f0d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	145.48	143.64	t	in_stock	2025-08-27 22:19:06.331+00
ca464ae9-76db-4fc7-b5a6-9d9568f30a8b	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	139.58	143.64	t	in_stock	2025-08-28 22:19:06.331+00
b5b354cf-17ba-495b-8d7d-1c3f7408e8fd	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	148.46	143.64	f	out_of_stock	2025-08-29 22:19:06.331+00
ee640082-8d18-4f7d-b9bf-38005db55078	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	148.04	143.64	t	in_stock	2025-08-30 22:19:06.331+00
99899ea4-87f1-4fd8-9288-db1aca9431b7	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	150.20	143.64	t	in_stock	2025-08-31 22:19:06.331+00
d02b6526-efea-4d48-842e-acd4d37aa560	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	143.82	143.64	t	in_stock	2025-09-01 22:19:06.331+00
7f1a9a87-6302-4b45-a7df-23f30b1c0f2e	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	152.68	143.64	t	in_stock	2025-09-02 22:19:06.331+00
d40a2662-5325-44ad-9bbc-eb746de46eaf	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	142.27	143.64	t	in_stock	2025-09-03 22:19:06.331+00
07e4eba8-18fa-417e-89da-1445e848ba5d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.62	49.99	t	in_stock	2025-08-04 22:19:06.331+00
90f937e6-154f-4f13-91ec-08a7354cb8fb	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.27	49.99	t	in_stock	2025-08-05 22:19:06.331+00
c61e66b9-5dbe-4887-b4a7-1a7eafcd9559	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.44	49.99	t	in_stock	2025-08-06 22:19:06.331+00
d3768220-c25b-4049-b68b-0e2f3e2af30d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.43	49.99	t	in_stock	2025-08-07 22:19:06.331+00
aa8c90ab-44e8-44a5-a179-5906d0e508bd	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.40	49.99	t	in_stock	2025-08-08 22:19:06.331+00
4673c99d-9c4d-44e2-bc8f-d298d2fdf671	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.89	49.99	t	in_stock	2025-08-09 22:19:06.331+00
133f32e1-143f-4522-9c93-6b989de55849	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.52	49.99	t	in_stock	2025-08-10 22:19:06.331+00
8dda4fe3-70a3-4c6d-9009-362de7d64bad	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.56	49.99	f	out_of_stock	2025-08-11 22:19:06.331+00
354f39fd-7ffa-44cc-8686-19eed8b7185a	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	48.33	49.99	t	in_stock	2025-08-12 22:19:06.331+00
e2d58c88-86f4-481c-b875-8d3a637adfa5	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.72	49.99	t	in_stock	2025-08-13 22:19:06.331+00
f24fd931-40d0-4afc-b8db-7de0b6f9224d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.25	49.99	t	in_stock	2025-08-14 22:19:06.331+00
2d90f174-b7b5-486d-8f6b-705f2c7dfd72	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.24	49.99	t	in_stock	2025-08-15 22:19:06.331+00
68f5af67-d94e-4e53-b9bd-c407107a34c4	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	50.80	49.99	f	out_of_stock	2025-08-16 22:19:06.331+00
74091727-f03e-46f4-9e0b-c4a5add48d33	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.04	49.99	f	out_of_stock	2025-08-17 22:19:06.331+00
d86bca4b-ac4c-4cfb-bd52-e443f3781533	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.44	49.99	t	in_stock	2025-08-18 22:19:06.331+00
9c9cb844-92d0-4125-9865-48a36a6b2c58	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	47.97	49.99	f	out_of_stock	2025-08-19 22:19:06.331+00
fb1a2417-b57f-42c4-a6b0-92aab84381ba	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	48.74	49.99	t	in_stock	2025-08-20 22:19:06.331+00
179802bc-3306-4bfe-be30-f9ea84b8f01e	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.73	49.99	t	in_stock	2025-08-21 22:19:06.331+00
f4c260cd-a674-4492-b89c-2eefa771cc10	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.36	49.99	t	in_stock	2025-08-22 22:19:06.331+00
55f5cc51-4282-4806-9e8e-2f28ce46a1c7	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.80	49.99	t	in_stock	2025-08-23 22:19:06.331+00
e35fd47c-55bb-4766-a47a-fac1bb180e5c	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.49	49.99	t	in_stock	2025-08-24 22:19:06.331+00
de40523b-1e4b-41e4-8cae-1e8a8f637e07	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	48.55	49.99	t	in_stock	2025-08-25 22:19:06.331+00
4ea7c0d9-cade-4bc4-ba38-71283fe6ec47	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.60	49.99	t	in_stock	2025-08-26 22:19:06.331+00
4ac38a81-c5af-43c0-adf0-7bde65d87400	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	50.73	49.99	t	in_stock	2025-08-27 22:19:06.331+00
1e2a4b2f-5e5a-43ae-a347-ba3f5f581dc5	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.73	49.99	f	out_of_stock	2025-08-28 22:19:06.331+00
72c5324f-c3a6-4409-af11-378bfd05e774	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	53.42	49.99	t	in_stock	2025-08-29 22:19:06.331+00
26b2659d-5327-46f8-a7fe-a7e9d9cd33e1	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.93	49.99	t	in_stock	2025-08-30 22:19:06.331+00
92f8c47a-6cf0-4a6c-aad7-aa354e989aa4	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	50.83	49.99	t	in_stock	2025-08-31 22:19:06.331+00
d1af2f88-8b6a-47a2-8caa-b25dc83fb25c	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	49.20	49.99	t	in_stock	2025-09-01 22:19:06.331+00
5545c3f1-2745-4b6f-8605-b79052c22aa9	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	52.46	49.99	t	in_stock	2025-09-02 22:19:06.331+00
2c0e894f-2a3e-407c-97ac-b8a0077246d4	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	46.47	49.99	t	in_stock	2025-09-03 22:19:06.331+00
7404d600-a064-4e41-b04d-bc2395ebd0ff	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	50.66	49.99	f	out_of_stock	2025-08-04 22:19:06.331+00
d1b0c466-517a-47cb-85fd-b08fe598dc96	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.24	49.99	f	out_of_stock	2025-08-05 22:19:06.331+00
21413ca8-a64a-48ae-a181-9d4dbbdc1837	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.81	49.99	t	in_stock	2025-08-06 22:19:06.331+00
60645df0-0c81-47dd-a87b-7784aab568fc	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.16	49.99	t	in_stock	2025-08-07 22:19:06.331+00
23b1face-399d-4adc-ae59-eb0853d9ebcc	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	46.73	49.99	t	in_stock	2025-08-08 22:19:06.331+00
ebedaa01-4b0b-48d3-9070-ed314811734b	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.52	49.99	f	out_of_stock	2025-08-09 22:19:06.331+00
cd52a24b-6db2-436c-af86-b885195f4293	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.70	49.99	t	in_stock	2025-08-10 22:19:06.331+00
d94b16d3-0da4-41c9-8887-dcb8d216b1d3	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.46	49.99	t	in_stock	2025-08-11 22:19:06.331+00
8e4f6b22-8ae0-4a0c-bcd8-987ebc43ac87	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.87	49.99	f	out_of_stock	2025-08-12 22:19:06.331+00
b42050db-63ef-411f-b1ef-64b446e8e3a8	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.40	49.99	f	out_of_stock	2025-08-13 22:19:06.331+00
f9e78760-c468-4577-82d3-ef41d4d13d1a	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.75	49.99	t	in_stock	2025-08-14 22:19:06.331+00
791333cb-44ea-4496-94e7-3896f4217078	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	49.04	49.99	f	out_of_stock	2025-08-15 22:19:06.331+00
0dd02a72-6604-499f-819d-a38b66a642c5	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.14	49.99	t	in_stock	2025-08-16 22:19:06.331+00
a3495341-560b-4ddb-9003-d27a2c4d0374	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.87	49.99	t	in_stock	2025-08-17 22:19:06.331+00
d3bf95e6-b978-48b2-a97f-6bcebe32c348	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.08	49.99	t	in_stock	2025-08-18 22:19:06.331+00
e39d1a01-91c3-4ef8-a6f9-c230ef03d8a6	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.29	49.99	f	out_of_stock	2025-08-19 22:19:06.331+00
66315280-3300-42d1-bbe6-7ddc0e108918	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.49	49.99	f	out_of_stock	2025-08-20 22:19:06.331+00
1b2ca5ff-668b-4917-9f2d-cfbc4802cee5	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	49.93	49.99	t	in_stock	2025-08-21 22:19:06.331+00
4121cb25-9adf-4edc-b58c-4d4945f18ce6	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	46.46	49.99	t	in_stock	2025-08-22 22:19:06.331+00
c3d83fe8-2647-4f6d-bea6-e6f4a10d76f0	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	49.08	49.99	f	out_of_stock	2025-08-23 22:19:06.331+00
d8b8ccec-ce10-43ea-a320-ed732f6c8c84	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.04	49.99	t	in_stock	2025-08-24 22:19:06.331+00
b14d3dbf-791d-4ebc-91b0-7732ae5ef6f2	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	50.26	49.99	t	in_stock	2025-08-25 22:19:06.331+00
beb98c68-5fcd-45ac-8419-5992bdcb6f4a	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	51.73	49.99	f	out_of_stock	2025-08-26 22:19:06.331+00
910a30ab-67b2-4d4f-a12a-1cdcde100adc	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	46.61	49.99	t	in_stock	2025-08-27 22:19:06.331+00
de13197f-1cb7-40c6-b3ef-6dde28640dde	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	53.20	49.99	t	in_stock	2025-08-28 22:19:06.331+00
02f21c74-b547-4e42-bc37-2275ebc83b56	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	53.69	49.99	t	in_stock	2025-08-29 22:19:06.331+00
6dbfd2da-c224-4085-9c02-bd5fd19f1b0a	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	50.66	49.99	t	in_stock	2025-08-30 22:19:06.331+00
60635248-b7dc-479e-9390-433b277d5fe4	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.59	49.99	t	in_stock	2025-08-31 22:19:06.331+00
b7cfd952-1b2b-41ef-a1d0-a1e197121bb9	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	52.03	49.99	t	in_stock	2025-09-01 22:19:06.331+00
b07c2822-34ec-42dc-bb05-7dd178f5e714	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	48.19	49.99	f	out_of_stock	2025-09-02 22:19:06.331+00
ecbce80d-2ced-45f0-a613-6525d2065be7	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	47.63	49.99	t	in_stock	2025-09-03 22:19:06.331+00
\.


--
-- TOC entry 4294 (class 0 OID 16594)
-- Dependencies: 224
-- Data for Name: product_availability; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_availability (id, product_id, retailer_id, in_stock, price, original_price, availability_status, product_url, cart_url, stock_level, store_locations, last_checked, last_in_stock, last_price_change, created_at, updated_at) FROM stdin;
55ccd58f-fac1-4999-8943-e7100fbfa0bf	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c07d2d13-331a-4543-9e1b-a71d35558b0e	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bab64c86-c85c-4301-89f5-b18ab6dbfb2a	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	132.97	143.64	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-base-booster-box	\N	11	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b0db8cae-8e90-42b1-af88-57e6029354ce	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-base-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6064a3c3-cd21-4f95-859a-63cedfdd95b7	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	157.65	143.64	in_stock	https://www.gamestop.com/products/pokemon-scarlet-violet-base-booster-box	\N	13	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4f656adc-7f9c-458e-87ed-1895afaf2bb6	0c302b6d-ebd4-44f9-8be4-4b0402d170cc	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	130.29	143.64	in_stock	https://www.target.com/products/pokemon-scarlet-violet-base-booster-box	\N	2	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bb7f7f54-388d-489a-aa74-83dc0a986cc5	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	150.04	143.64	in_stock	https://www.bestbuy.com/products/pokemon-paldea-evolved-booster-box	https://www.bestbuy.com/cart/add/SV02-BB-EN	30	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
fda132f8-a809-4d56-b0cd-a2922dd7cc7d	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	d6856801-fdef-4480-bacb-739d0f8eeade	t	147.37	143.64	in_stock	https://www.walmart.com/products/pokemon-paldea-evolved-booster-box	\N	12	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
474b2348-cd4d-4ac8-b6fd-94f9fdd8c5bb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	144.92	143.64	in_stock	https://www.costco.com/products/pokemon-paldea-evolved-booster-box	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c6197be8-8d5f-49c1-ad0c-d94b4c6ee5cb	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	139.87	143.64	in_stock	https://www.samsclub.com/products/pokemon-paldea-evolved-booster-box	\N	30	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b1f27949-6362-4e81-ae18-e0c4e7be493c	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-paldea-evolved-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3b3c961b-b7f6-49ef-96c2-8c262f41fc38	36d49c84-21d3-4c4a-b3f6-a55db2f359c7	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	139.55	143.64	in_stock	https://www.target.com/products/pokemon-paldea-evolved-booster-box	\N	40	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8e9343df-6017-416c-a709-510a85a37f1d	f94dae6d-305a-4948-8a58-0b93e0739f94	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4a0d01f0-5bd2-439a-b7fa-dccf79c90f61	f94dae6d-305a-4948-8a58-0b93e0739f94	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
281892bb-68af-4efb-b2c9-a73be181fe0a	f94dae6d-305a-4948-8a58-0b93e0739f94	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	48.91	49.99	in_stock	https://www.costco.com/products/pokemon-151-elite-trainer-box	\N	9	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
5b70cb09-762b-4495-80d1-185daf203217	f94dae6d-305a-4948-8a58-0b93e0739f94	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	47.53	49.99	low_stock	https://www.samsclub.com/products/pokemon-151-elite-trainer-box	\N	23	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6a5f8af4-e74c-4750-97a7-14acc110656b	f94dae6d-305a-4948-8a58-0b93e0739f94	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	52.78	49.99	in_stock	https://www.gamestop.com/products/pokemon-151-elite-trainer-box	\N	30	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
72352e94-c265-4e16-b884-0008c31d949d	f94dae6d-305a-4948-8a58-0b93e0739f94	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-151-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c00066b5-2bc5-42f4-b6de-5c32b9dd825b	9948cf7e-41d4-4863-b36e-ec6372a7118b	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	119.99	out_of_stock	https://www.bestbuy.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6666351f-59b8-4fdd-b1a0-9f6d0f5a7f09	9948cf7e-41d4-4863-b36e-ec6372a7118b	d6856801-fdef-4480-bacb-739d0f8eeade	t	117.02	119.99	in_stock	https://www.walmart.com/products/charizard-ex-super-premium-collection	\N	5	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
0d406ba2-3618-4126-a305-1b42db974d97	9948cf7e-41d4-4863-b36e-ec6372a7118b	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	125.73	119.99	low_stock	https://www.costco.com/products/charizard-ex-super-premium-collection	\N	43	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7937ec1f-21e8-4acf-994a-b56bddf2ebf8	9948cf7e-41d4-4863-b36e-ec6372a7118b	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	127.02	119.99	in_stock	https://www.samsclub.com/products/charizard-ex-super-premium-collection	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b45486e6-0425-48b3-9123-6ab73c569254	9948cf7e-41d4-4863-b36e-ec6372a7118b	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	119.99	out_of_stock	https://www.gamestop.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
ff7f1bb5-a0c9-4739-b9f3-7796526c113c	9948cf7e-41d4-4863-b36e-ec6372a7118b	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	119.99	out_of_stock	https://www.target.com/products/charizard-ex-super-premium-collection	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
65d1aedd-0ddf-4533-9ec5-c790519d787e	a9337f94-3157-4709-8026-5454ead6d708	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	4.22	3.99	in_stock	https://www.bestbuy.com/products/pokemon-scarlet-violet-booster-pack	https://www.bestbuy.com/cart/add/SV01-BP-EN	6	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
81539360-5698-495a-baaa-e1e08a812174	a9337f94-3157-4709-8026-5454ead6d708	d6856801-fdef-4480-bacb-739d0f8eeade	t	3.60	3.99	in_stock	https://www.walmart.com/products/pokemon-scarlet-violet-booster-pack	\N	34	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7ecd3091-0b02-4e05-9768-bc34c35d32c7	a9337f94-3157-4709-8026-5454ead6d708	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	3.67	3.99	in_stock	https://www.costco.com/products/pokemon-scarlet-violet-booster-pack	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3ee7880f-d0b0-449e-8ec7-a78b9d1a5a0c	a9337f94-3157-4709-8026-5454ead6d708	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	3.99	out_of_stock	https://www.samsclub.com/products/pokemon-scarlet-violet-booster-pack	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
69c700a1-7444-499f-828a-25c3ce05ca87	a9337f94-3157-4709-8026-5454ead6d708	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	3.99	3.99	in_stock	https://www.gamestop.com/products/pokemon-scarlet-violet-booster-pack	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d6841827-1f97-4735-9153-db3857054ed3	a9337f94-3157-4709-8026-5454ead6d708	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	4.32	3.99	in_stock	https://www.target.com/products/pokemon-scarlet-violet-booster-pack	\N	31	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
758838e4-0ed3-4c57-9346-b739f76849ca	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	152.88	143.64	in_stock	https://www.bestbuy.com/products/pokemon-obsidian-flames-booster-box	https://www.bestbuy.com/cart/add/SV03-BB-EN	7	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
9b0784cc-01f9-4394-95b5-8e2043ab70df	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8c3bcac6-b103-465a-b14c-efc19210e703	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	147.76	143.64	in_stock	https://www.costco.com/products/pokemon-obsidian-flames-booster-box	\N	36	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
a312b277-4dec-43cd-b42c-42d9e510689f	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	147.83	143.64	in_stock	https://www.samsclub.com/products/pokemon-obsidian-flames-booster-box	\N	20	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7debe415-89b6-4ae5-ab43-12aa334905d8	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-obsidian-flames-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
efc289df-8629-447e-b07b-a611ced65e31	e1074fa4-1fd7-44c7-a55f-96fa0402aca5	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	130.79	143.64	in_stock	https://www.target.com/products/pokemon-obsidian-flames-booster-box	\N	49	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
e758c56f-2afa-4e84-a33f-34c19f10d82e	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	132.69	143.64	in_stock	https://www.bestbuy.com/products/pokemon-paradox-rift-booster-box	https://www.bestbuy.com/cart/add/SV04-BB-EN	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6e442a19-27f0-425d-aacb-4e5aaa8914f3	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	d6856801-fdef-4480-bacb-739d0f8eeade	t	142.03	143.64	in_stock	https://www.walmart.com/products/pokemon-paradox-rift-booster-box	\N	12	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
f37d2b64-8acc-4f3c-8cb0-bd2023306421	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	156.31	143.64	in_stock	https://www.costco.com/products/pokemon-paradox-rift-booster-box	\N	21	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
933aabab-3279-4927-984a-7c33a915ae74	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
19736ac6-7c80-4cd4-8290-41e4056675b6	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	143.64	out_of_stock	https://www.gamestop.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
ade73d0e-bf73-460e-b7e3-74bf3f2a46da	6ef2d0a5-7263-4206-9db1-e5520e8abc0a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-paradox-rift-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
ccc4af21-2966-45b4-b7cd-4e897e85548e	d3399ef0-4d30-475a-940c-1d1b11481b37	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	46.51	49.99	low_stock	https://www.bestbuy.com/products/pokemon-paldean-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SV4.5-ETB-EN	14	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
0fdf6702-9eb7-423d-9045-6e44ec34dbb7	d3399ef0-4d30-475a-940c-1d1b11481b37	d6856801-fdef-4480-bacb-739d0f8eeade	t	47.89	49.99	in_stock	https://www.walmart.com/products/pokemon-paldean-fates-elite-trainer-box	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
2cffaca6-1e20-4d15-9f2c-e995a56f715a	d3399ef0-4d30-475a-940c-1d1b11481b37	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	47.92	49.99	in_stock	https://www.costco.com/products/pokemon-paldean-fates-elite-trainer-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
482baf31-8697-4e4c-bedf-43a217eec385	d3399ef0-4d30-475a-940c-1d1b11481b37	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	48.15	49.99	in_stock	https://www.samsclub.com/products/pokemon-paldean-fates-elite-trainer-box	\N	7	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6c5c6162-6c23-4462-8661-c42723030017	d3399ef0-4d30-475a-940c-1d1b11481b37	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	52.33	49.99	in_stock	https://www.gamestop.com/products/pokemon-paldean-fates-elite-trainer-box	\N	40	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4c447098-5fd6-4428-b7a9-52b5f5bc58c0	d3399ef0-4d30-475a-940c-1d1b11481b37	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	49.77	49.99	in_stock	https://www.target.com/products/pokemon-paldean-fates-elite-trainer-box	\N	31	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c33f83a7-d856-426f-86c1-f6bc04d239eb	89730910-09ee-4454-acb5-b5979e0d4ab7	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	140.40	143.64	in_stock	https://www.bestbuy.com/products/pokemon-temporal-forces-booster-box	https://www.bestbuy.com/cart/add/SV05-BB-EN	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
974c379c-eea2-43d3-bee5-cfcdea784242	89730910-09ee-4454-acb5-b5979e0d4ab7	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
fe76c309-73e9-4f9a-bf00-0c2fef2745d5	89730910-09ee-4454-acb5-b5979e0d4ab7	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	f	\N	143.64	out_of_stock	https://www.costco.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
a0b39052-b70b-4161-9baa-da0637e039ba	89730910-09ee-4454-acb5-b5979e0d4ab7	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	132.82	143.64	in_stock	https://www.samsclub.com/products/pokemon-temporal-forces-booster-box	\N	1	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
9b69c258-4396-40ef-abd2-158f9b2efdbf	89730910-09ee-4454-acb5-b5979e0d4ab7	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	135.12	143.64	in_stock	https://www.gamestop.com/products/pokemon-temporal-forces-booster-box	\N	5	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bc7209b1-16f2-4906-a741-8fc76c1d477e	89730910-09ee-4454-acb5-b5979e0d4ab7	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-temporal-forces-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
cab811c8-e408-4f76-bea7-7a28e6b83c3b	454b81ef-7486-4fa8-b4f7-12284cec758a	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	51.96	49.99	in_stock	https://www.bestbuy.com/products/pokemon-crown-zenith-elite-trainer-box	https://www.bestbuy.com/cart/add/SWSH12.5-ETB-EN	29	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
735c25c9-2f61-4e79-89af-697e37286f6a	454b81ef-7486-4fa8-b4f7-12284cec758a	d6856801-fdef-4480-bacb-739d0f8eeade	t	50.63	49.99	low_stock	https://www.walmart.com/products/pokemon-crown-zenith-elite-trainer-box	\N	16	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4b0a0598-8e94-48c2-8941-0c0008110db4	454b81ef-7486-4fa8-b4f7-12284cec758a	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	52.38	49.99	in_stock	https://www.costco.com/products/pokemon-crown-zenith-elite-trainer-box	\N	7	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
adf22a30-edd8-4866-bdef-12b2b80a5949	454b81ef-7486-4fa8-b4f7-12284cec758a	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	53.54	49.99	in_stock	https://www.samsclub.com/products/pokemon-crown-zenith-elite-trainer-box	\N	19	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6de93453-fc5d-48c0-9469-e156e5d6a621	454b81ef-7486-4fa8-b4f7-12284cec758a	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	49.31	49.99	in_stock	https://www.gamestop.com/products/pokemon-crown-zenith-elite-trainer-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
87d993f6-1051-4595-9ff7-e43e3e604578	454b81ef-7486-4fa8-b4f7-12284cec758a	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-crown-zenith-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
15bdfe17-b06a-4a83-a7da-8aeab712d80f	d78dec22-022a-4177-b8be-026905a38689	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	131.53	143.64	in_stock	https://www.bestbuy.com/products/pokemon-evolving-skies-booster-box	https://www.bestbuy.com/cart/add/SWSH07-BB-EN	18	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
20fc0afb-5bcf-4180-934b-439fb8516590	d78dec22-022a-4177-b8be-026905a38689	d6856801-fdef-4480-bacb-739d0f8eeade	t	135.92	143.64	low_stock	https://www.walmart.com/products/pokemon-evolving-skies-booster-box	\N	19	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1e1bc821-2db0-4410-a84e-7873a7a4e13d	d78dec22-022a-4177-b8be-026905a38689	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	153.70	143.64	in_stock	https://www.costco.com/products/pokemon-evolving-skies-booster-box	\N	39	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7187dd93-8e6d-4669-8788-cd072d69dac2	d78dec22-022a-4177-b8be-026905a38689	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	145.29	143.64	in_stock	https://www.samsclub.com/products/pokemon-evolving-skies-booster-box	\N	15	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
97201f01-a992-42e9-81ff-717100ee81a2	d78dec22-022a-4177-b8be-026905a38689	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	133.74	143.64	in_stock	https://www.gamestop.com/products/pokemon-evolving-skies-booster-box	\N	1	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
44080dab-9f4b-4e28-91c8-fe05cc74208b	d78dec22-022a-4177-b8be-026905a38689	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-evolving-skies-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8df92241-53a6-4168-93f2-e563cb26af35	090cb184-ca13-4246-9db9-a923c68ade86	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	135.44	143.64	in_stock	https://www.bestbuy.com/products/pokemon-brilliant-stars-booster-box	https://www.bestbuy.com/cart/add/SWSH09-BB-EN	18	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4951c3c8-f89d-4b3f-a0c3-176a7805912b	090cb184-ca13-4246-9db9-a923c68ade86	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bfc382d9-d6b8-4f11-a3cc-87a066ea49bc	090cb184-ca13-4246-9db9-a923c68ade86	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	135.90	143.64	in_stock	https://www.costco.com/products/pokemon-brilliant-stars-booster-box	\N	22	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
f5b06944-64d6-458b-b1ee-36a00ec40e79	090cb184-ca13-4246-9db9-a923c68ade86	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	143.64	out_of_stock	https://www.samsclub.com/products/pokemon-brilliant-stars-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1f14ab6b-7eb8-4b27-a341-ec375fed0f14	090cb184-ca13-4246-9db9-a923c68ade86	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	152.20	143.64	in_stock	https://www.gamestop.com/products/pokemon-brilliant-stars-booster-box	\N	38	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
821cf8a9-a0df-4c2d-800d-4e3027e5a53b	090cb184-ca13-4246-9db9-a923c68ade86	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	132.53	143.64	in_stock	https://www.target.com/products/pokemon-brilliant-stars-booster-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6ac17680-d507-4188-9f6f-3f37d952ee57	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	153.33	143.64	in_stock	https://www.bestbuy.com/products/pokemon-lost-origin-booster-box	https://www.bestbuy.com/cart/add/SWSH11-BB-EN	38	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
9dea4669-9c8f-4167-b63a-255141108085	b0cfc9f0-5aad-471b-809d-aab2c03485e1	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-lost-origin-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
719faf06-8215-42a3-b5ea-9a9266b63596	b0cfc9f0-5aad-471b-809d-aab2c03485e1	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	141.89	143.64	in_stock	https://www.costco.com/products/pokemon-lost-origin-booster-box	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d3b482ef-691f-43a9-97d9-15568115e019	b0cfc9f0-5aad-471b-809d-aab2c03485e1	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	145.77	143.64	in_stock	https://www.samsclub.com/products/pokemon-lost-origin-booster-box	\N	24	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c5c6bae2-f487-46d6-b719-709d9ca2f423	b0cfc9f0-5aad-471b-809d-aab2c03485e1	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	131.43	143.64	low_stock	https://www.gamestop.com/products/pokemon-lost-origin-booster-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
966d3a37-afa0-4a36-8ae2-883e4d5d2ae9	b0cfc9f0-5aad-471b-809d-aab2c03485e1	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	148.22	143.64	in_stock	https://www.target.com/products/pokemon-lost-origin-booster-box	\N	1	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
93f5b611-9635-4a11-a7d0-7c219d8d235b	d4cab033-1755-4548-b385-6ab1a9376a85	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	143.64	out_of_stock	https://www.bestbuy.com/products/pokemon-astral-radiance-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
c412ffd7-c5f4-445c-b557-c5f06fea2757	d4cab033-1755-4548-b385-6ab1a9376a85	d6856801-fdef-4480-bacb-739d0f8eeade	t	142.64	143.64	in_stock	https://www.walmart.com/products/pokemon-astral-radiance-booster-box	\N	50	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
5cf20179-7b75-4040-a339-f2b5e49390e1	d4cab033-1755-4548-b385-6ab1a9376a85	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	130.54	143.64	in_stock	https://www.costco.com/products/pokemon-astral-radiance-booster-box	\N	11	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
69723fb3-4ae3-45eb-bddf-d9f53d050274	d4cab033-1755-4548-b385-6ab1a9376a85	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	152.66	143.64	in_stock	https://www.samsclub.com/products/pokemon-astral-radiance-booster-box	\N	49	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
02ff6648-bea4-4c07-83ca-76aab0870739	d4cab033-1755-4548-b385-6ab1a9376a85	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	137.64	143.64	in_stock	https://www.gamestop.com/products/pokemon-astral-radiance-booster-box	\N	28	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
35d84216-051a-4da9-bce2-2d8843a47887	d4cab033-1755-4548-b385-6ab1a9376a85	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	131.75	143.64	low_stock	https://www.target.com/products/pokemon-astral-radiance-booster-box	\N	38	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b052660d-a1c8-40fc-8f74-fce6dea467db	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	139.06	143.64	in_stock	https://www.bestbuy.com/products/pokemon-fusion-strike-booster-box	https://www.bestbuy.com/cart/add/SWSH08-BB-EN	39	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8f5bf13e-fcb5-49d0-ab26-55f9d5a6eef0	cd48f66e-2e5c-4756-b2f0-f358eaac01da	d6856801-fdef-4480-bacb-739d0f8eeade	t	145.11	143.64	low_stock	https://www.walmart.com/products/pokemon-fusion-strike-booster-box	\N	20	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6d697ef4-19c8-4d6c-bf36-2220301955bf	cd48f66e-2e5c-4756-b2f0-f358eaac01da	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	133.45	143.64	in_stock	https://www.costco.com/products/pokemon-fusion-strike-booster-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3101265b-700c-4118-97f5-5df25503f708	cd48f66e-2e5c-4756-b2f0-f358eaac01da	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	146.50	143.64	in_stock	https://www.samsclub.com/products/pokemon-fusion-strike-booster-box	\N	50	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d9cdfbdb-4898-4af6-b09d-c546da87f1f8	cd48f66e-2e5c-4756-b2f0-f358eaac01da	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	152.88	143.64	low_stock	https://www.gamestop.com/products/pokemon-fusion-strike-booster-box	\N	27	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8b3bd26b-d365-433a-9ac3-715641481160	cd48f66e-2e5c-4756-b2f0-f358eaac01da	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	143.64	out_of_stock	https://www.target.com/products/pokemon-fusion-strike-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
0bc51b33-0714-44f0-bae2-4582af177551	23f77789-99f9-4d89-a7f6-b48f9578c04f	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
dad4e73b-7ed9-4e93-87f9-ade3d2cd5957	23f77789-99f9-4d89-a7f6-b48f9578c04f	d6856801-fdef-4480-bacb-739d0f8eeade	t	50.16	49.99	low_stock	https://www.walmart.com/products/pokemon-celebrations-elite-trainer-box	\N	14	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
79b200a4-be4f-428e-8515-fb5a5919e4ae	23f77789-99f9-4d89-a7f6-b48f9578c04f	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	50.90	49.99	low_stock	https://www.costco.com/products/pokemon-celebrations-elite-trainer-box	\N	39	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
78a1a747-2569-4b71-af6c-6e1d420948d5	23f77789-99f9-4d89-a7f6-b48f9578c04f	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-celebrations-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
d330b6f4-32ad-4df1-bb99-f3a31ffef54c	23f77789-99f9-4d89-a7f6-b48f9578c04f	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	51.51	49.99	in_stock	https://www.gamestop.com/products/pokemon-celebrations-elite-trainer-box	\N	37	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
7f14f6ec-fa01-4f6f-9238-6dd10a329211	23f77789-99f9-4d89-a7f6-b48f9578c04f	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	51.32	49.99	in_stock	https://www.target.com/products/pokemon-celebrations-elite-trainer-box	\N	49	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
21789672-f1e0-4ae1-8873-b61dee06b33e	234ee314-1f17-4753-be1b-c868e441db7e	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	53.38	49.99	in_stock	https://www.bestbuy.com/products/pokemon-shining-fates-elite-trainer-box	https://www.bestbuy.com/cart/add/SWSH4.5-ETB-EN	20	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
8f4ca2ce-e514-4d14-a6e2-516abf8314a4	234ee314-1f17-4753-be1b-c868e441db7e	d6856801-fdef-4480-bacb-739d0f8eeade	t	53.61	49.99	in_stock	https://www.walmart.com/products/pokemon-shining-fates-elite-trainer-box	\N	46	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
bb7e6214-77c0-41b4-856a-01e22e6f37f8	234ee314-1f17-4753-be1b-c868e441db7e	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	47.87	49.99	in_stock	https://www.costco.com/products/pokemon-shining-fates-elite-trainer-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
94595486-ffd0-4c85-8e44-e510a53d9d35	234ee314-1f17-4753-be1b-c868e441db7e	74a9feae-664a-4c3d-9d09-e77cbc978fa0	f	\N	49.99	out_of_stock	https://www.samsclub.com/products/pokemon-shining-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
6c57100d-4391-4e1d-8d55-6e932a0ae820	234ee314-1f17-4753-be1b-c868e441db7e	5da1a13c-803f-4e97-ad09-006ef8b1c2de	f	\N	49.99	out_of_stock	https://www.gamestop.com/products/pokemon-shining-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
b8f6f6e6-bac5-4dc9-a4ba-059d6a207036	234ee314-1f17-4753-be1b-c868e441db7e	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	46.89	49.99	in_stock	https://www.target.com/products/pokemon-shining-fates-elite-trainer-box	\N	2	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
33edd7bd-540f-4a21-9ad2-01ea47bced21	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c3755fe7-87a1-41c0-aee4-d2c90170d47f	f	\N	49.99	out_of_stock	https://www.bestbuy.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
108b36bd-e4f6-4a93-ab2d-9e64de239ec5	8ed8702f-15d5-4cf3-9555-3972d88e6c23	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	49.99	out_of_stock	https://www.walmart.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1317b3c9-3683-4a68-a260-bfdcf8eade84	8ed8702f-15d5-4cf3-9555-3972d88e6c23	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	54.93	49.99	low_stock	https://www.costco.com/products/pokemon-hidden-fates-elite-trainer-box	\N	3	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3710b062-294a-4f4d-9910-d3e7521cec80	8ed8702f-15d5-4cf3-9555-3972d88e6c23	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	46.01	49.99	low_stock	https://www.samsclub.com/products/pokemon-hidden-fates-elite-trainer-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
4e8ee146-b44e-42fe-b35c-2dc9f7cf820b	8ed8702f-15d5-4cf3-9555-3972d88e6c23	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	53.54	49.99	in_stock	https://www.gamestop.com/products/pokemon-hidden-fates-elite-trainer-box	\N	23	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
526d9c8c-1043-4f3d-aeea-e3dae2d58e08	8ed8702f-15d5-4cf3-9555-3972d88e6c23	a3d4e08f-d21d-4bad-b83c-8499566c2930	f	\N	49.99	out_of_stock	https://www.target.com/products/pokemon-hidden-fates-elite-trainer-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
70340da9-f972-4b74-a1c0-807b99aa1827	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c3755fe7-87a1-41c0-aee4-d2c90170d47f	t	146.90	143.64	in_stock	https://www.bestbuy.com/products/pokemon-chilling-reign-booster-box	https://www.bestbuy.com/cart/add/SWSH06-BB-EN	19	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
46be8e13-3293-42a9-9ea7-11d79169f0cd	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	d6856801-fdef-4480-bacb-739d0f8eeade	f	\N	143.64	out_of_stock	https://www.walmart.com/products/pokemon-chilling-reign-booster-box	\N	0	[]	2025-09-03 22:19:06.32312+00	\N	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
1c0743a4-71ab-4152-826d-69fdbc41fce2	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	t	141.85	143.64	in_stock	https://www.costco.com/products/pokemon-chilling-reign-booster-box	\N	34	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
dc32dab1-47b2-4fef-b773-8298df686c59	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	74a9feae-664a-4c3d-9d09-e77cbc978fa0	t	154.17	143.64	in_stock	https://www.samsclub.com/products/pokemon-chilling-reign-booster-box	\N	25	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
3b9771b2-ac94-484c-a292-3271c8d2b4ba	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	5da1a13c-803f-4e97-ad09-006ef8b1c2de	t	133.40	143.64	in_stock	https://www.gamestop.com/products/pokemon-chilling-reign-booster-box	\N	45	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
37eac3e3-ce71-499e-b3a0-216c93d9a787	57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	a3d4e08f-d21d-4bad-b83c-8499566c2930	t	130.01	143.64	in_stock	https://www.target.com/products/pokemon-chilling-reign-booster-box	\N	47	[]	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00	2025-09-03 22:19:06.32312+00
\.


--
-- TOC entry 4292 (class 0 OID 16545)
-- Dependencies: 222
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_categories (id, name, slug, description, parent_id, sort_order, created_at, updated_at) FROM stdin;
9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Booster Boxes	booster-boxes	Complete booster boxes containing multiple booster packs	\N	1	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
74f7c000-1c1a-4d83-bae0-387388e8f517	Booster Packs	booster-packs	Individual booster packs	\N	2	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
9cecfdc2-8343-41e2-b988-c85781aa3d84	Elite Trainer Boxes	elite-trainer-boxes	Elite Trainer Boxes with booster packs and accessories	\N	3	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
8a65f1e2-a485-43c8-b89f-124eb057914f	Collection Boxes	collection-boxes	Special collection boxes and premium products	\N	4	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
3cfd90d9-067a-4acc-9916-36cd81d9168c	Starter Decks	starter-decks	Theme decks and starter products	\N	5	2025-09-03 22:19:06.311217+00	2025-09-03 22:19:06.311217+00
\.


--
-- TOC entry 4293 (class 0 OID 16565)
-- Dependencies: 223
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.products (id, name, slug, sku, upc, category_id, set_name, series, release_date, msrp, image_url, description, metadata, is_active, popularity_score, created_at, updated_at) FROM stdin;
0c302b6d-ebd4-44f9-8be4-4b0402d170cc	Pokémon Scarlet & Violet Base Set Booster Box	pokemon-scarlet-violet-base-booster-box	SV01-BB-EN	820650850011	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	143.64	https://images.pokemontcg.io/sv1/logo.png	Scarlet & Violet Base Set Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV01", "pack_count": 36, "cards_per_pack": 11, "rarity_distribution": {"common": 7, "uncommon": 3, "rare_or_higher": 1}}	t	95	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
36d49c84-21d3-4c4a-b3f6-a55db2f359c7	Pokémon Paldea Evolved Booster Box	pokemon-paldea-evolved-booster-box	SV02-BB-EN	820650850028	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Paldea Evolved	Scarlet & Violet	2023-06-09	143.64	https://images.pokemontcg.io/sv2/logo.png	Paldea Evolved Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV02", "pack_count": 36, "cards_per_pack": 11}	t	88	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
f94dae6d-305a-4948-8a58-0b93e0739f94	Pokémon 151 Elite Trainer Box	pokemon-151-elite-trainer-box	SV3.5-ETB-EN	820650851001	9cecfdc2-8343-41e2-b988-c85781aa3d84	Pokémon 151	Scarlet & Violet	2023-09-22	49.99	https://images.pokemontcg.io/sv3pt5/logo.png	Pokémon 151 Elite Trainer Box with 9 booster packs and accessories	{"includes": ["9 Pokémon 151 booster packs", "65 card sleeves", "45 Energy cards", "Player's guide", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "Collector's box"], "language": "English", "set_code": "SV3.5", "pack_count": 9, "cards_per_pack": 11}	t	100	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
9948cf7e-41d4-4863-b36e-ec6372a7118b	Charizard ex Super Premium Collection	charizard-ex-super-premium-collection	SV-CHAR-SPC	820650852001	8a65f1e2-a485-43c8-b89f-124eb057914f	Special Collection	Scarlet & Violet	2023-12-01	119.99	https://images.pokemontcg.io/sv-promo/charizard-ex.png	Charizard ex Super Premium Collection with exclusive cards and accessories	{"includes": ["1 foil promo card featuring Charizard ex", "1 foil promo card featuring Charmander", "1 foil promo card featuring Charmeleon", "16 Pokémon TCG booster packs", "1 playmat featuring Charizard ex", "65 card sleeves featuring Charizard ex", "1 metal coin featuring Charizard ex", "6 damage-counter dice", "1 competition-legal coin-flip die", "2 condition markers", "1 collector's box"], "language": "English", "set_code": "SV-PROMO", "pack_count": 16}	t	92	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
a9337f94-3157-4709-8026-5454ead6d708	Pokémon Scarlet & Violet Booster Pack	pokemon-scarlet-violet-booster-pack	SV01-BP-EN	820650850035	74f7c000-1c1a-4d83-bae0-387388e8f517	Scarlet & Violet Base Set	Scarlet & Violet	2023-03-31	3.99	https://images.pokemontcg.io/sv1/pack.png	Single Scarlet & Violet Base Set booster pack	{"language": "English", "set_code": "SV01", "cards_per_pack": 11}	t	75	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
b0cfc9f0-5aad-471b-809d-aab2c03485e1	Pokémon Lost Origin Booster Box	pokemon-lost-origin-booster-box	SWSH11-BB-EN	0820650460233	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Lost Origin	Sword & Shield	2022-09-09	143.64	https://images.pokemontcg.io/swsh11/logo.png	Lost Origin Booster Box featuring the Lost Zone mechanic	{"language": "English", "set_code": "SWSH11", "pack_count": 36, "cards_per_pack": 10}	t	91	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
d4cab033-1755-4548-b385-6ab1a9376a85	Pokémon Astral Radiance Booster Box	pokemon-astral-radiance-booster-box	SWSH10-BB-EN	0820650460134	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Astral Radiance	Sword & Shield	2022-05-27	143.64	https://images.pokemontcg.io/swsh10/logo.png	Astral Radiance Booster Box featuring Hisuian Pokémon	{"language": "English", "set_code": "SWSH10", "pack_count": 36, "cards_per_pack": 10}	t	88	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
cd48f66e-2e5c-4756-b2f0-f358eaac01da	Pokémon Fusion Strike Booster Box	pokemon-fusion-strike-booster-box	SWSH08-BB-EN	0820650459275	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Fusion Strike	Sword & Shield	2021-11-12	143.64	https://images.pokemontcg.io/swsh8/logo.png	Fusion Strike Booster Box featuring Mew VMAX and Gengar VMAX	{"language": "English", "set_code": "SWSH08", "pack_count": 36, "cards_per_pack": 10}	t	86	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
23f77789-99f9-4d89-a7f6-b48f9578c04f	Pokémon Celebrations Elite Trainer Box	pokemon-celebrations-elite-trainer-box	SWSH25-ETB-EN	0820650459299	9cecfdc2-8343-41e2-b988-c85781aa3d84	Celebrations	Sword & Shield	2021-10-08	49.99	https://images.pokemontcg.io/swsh45/logo.png	25th Anniversary Celebrations Elite Trainer Box with special mini-packs	{"language": "English", "pack_count": 10}	t	97	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
234ee314-1f17-4753-be1b-c868e441db7e	Pokémon Shining Fates Elite Trainer Box	pokemon-shining-fates-elite-trainer-box	SWSH4.5-ETB-EN	0820650457448	9cecfdc2-8343-41e2-b988-c85781aa3d84	Shining Fates	Sword & Shield	2021-02-19	49.99	https://images.pokemontcg.io/swsh45/logo.png	Shining Fates Elite Trainer Box featuring shiny vault cards	{"language": "English", "pack_count": 10}	t	92	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
8ed8702f-15d5-4cf3-9555-3972d88e6c23	Pokémon Hidden Fates Elite Trainer Box	pokemon-hidden-fates-elite-trainer-box	SM11.5-ETB-EN	0820650451491	9cecfdc2-8343-41e2-b988-c85781aa3d84	Hidden Fates	Sun & Moon	2019-09-20	49.99	https://images.pokemontcg.io/sm115/logo.png	Hidden Fates Elite Trainer Box with the iconic shiny vault	{"language": "English", "pack_count": 10}	t	99	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
57fa35d9-1ffa-4e6a-bb3f-9cf5ad8fc0d9	Pokémon Chilling Reign Booster Box	pokemon-chilling-reign-booster-box	SWSH06-BB-EN	0820650458858	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Chilling Reign	Sword & Shield	2021-06-18	143.64	https://images.pokemontcg.io/swsh6/logo.png	Chilling Reign Booster Box featuring the Calyrex forms	{"language": "English", "set_code": "SWSH06", "pack_count": 36, "cards_per_pack": 10}	t	84	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
e1074fa4-1fd7-44c7-a55f-96fa0402aca5	Pokémon Obsidian Flames Booster Box	pokemon-obsidian-flames-booster-box	SV03-BB-EN	820650850059	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Obsidian Flames	Scarlet & Violet	2023-08-11	143.64	https://images.pokemontcg.io/sv3/logo.png	Obsidian Flames Booster Box containing 36 booster packs	{"language": "English", "set_code": "SV03", "pack_count": 36, "cards_per_pack": 11}	t	90	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
6ef2d0a5-7263-4206-9db1-e5520e8abc0a	Pokémon Paradox Rift Booster Box	pokemon-paradox-rift-booster-box	SV04-BB-EN	820650850066	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Paradox Rift	Scarlet & Violet	2023-11-03	143.64	https://images.pokemontcg.io/sv4/logo.png	Paradox Rift Booster Box with 36 booster packs	{"language": "English", "set_code": "SV04", "pack_count": 36, "cards_per_pack": 11}	t	89	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
d3399ef0-4d30-475a-940c-1d1b11481b37	Pokémon Paldean Fates Elite Trainer Box	pokemon-paldean-fates-elite-trainer-box	SV4.5-ETB-EN	0820650852441	9cecfdc2-8343-41e2-b988-c85781aa3d84	Paldean Fates	Scarlet & Violet	2024-01-26	49.99	https://images.pokemontcg.io/sv4pt5/logo.png	Paldean Fates Elite Trainer Box including 9 booster packs and accessories	{"includes": ["9 Paldean Fates booster packs", "Card sleeves", "Energy cards", "Dice", "Markers"], "language": "English", "set_code": "SV4.5", "pack_count": 9}	t	93	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
89730910-09ee-4454-acb5-b5979e0d4ab7	Pokémon Temporal Forces Booster Box	pokemon-temporal-forces-booster-box	SV05-BB-EN	0820650852519	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Temporal Forces	Scarlet & Violet	2024-03-22	143.64	https://images.pokemontcg.io/sv5/logo.png	Temporal Forces Booster Box with 36 booster packs	{"language": "English", "set_code": "SV05", "pack_count": 36, "cards_per_pack": 11}	t	87	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
454b81ef-7486-4fa8-b4f7-12284cec758a	Pokémon Crown Zenith Elite Trainer Box	pokemon-crown-zenith-elite-trainer-box	SWSH12.5-ETB-EN	0820650852625	9cecfdc2-8343-41e2-b988-c85781aa3d84	Crown Zenith	Sword & Shield	2023-01-20	49.99	https://images.pokemontcg.io/swsh12pt5/logo.png	Crown Zenith Elite Trainer Box featuring special Galarian Gallery cards	{"language": "English", "set_code": "SWSH12.5", "pack_count": 10}	t	98	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
d78dec22-022a-4177-b8be-026905a38689	Pokémon Evolving Skies Booster Box	pokemon-evolving-skies-booster-box	SWSH07-BB-EN	0820650453693	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Evolving Skies	Sword & Shield	2021-08-27	143.64	https://images.pokemontcg.io/swsh7/logo.png	Evolving Skies Booster Box featuring Eeveelutions and Dragon-type Pokémon	{"language": "English", "set_code": "SWSH07", "pack_count": 36, "cards_per_pack": 10}	t	100	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
090cb184-ca13-4246-9db9-a923c68ade86	Pokémon Brilliant Stars Booster Box	pokemon-brilliant-stars-booster-box	SWSH09-BB-EN	0820650459541	9b3af238-74c0-4be9-b2e5-a752bb8fbd85	Brilliant Stars	Sword & Shield	2022-02-25	143.64	https://images.pokemontcg.io/swsh9/logo.png	Brilliant Stars Booster Box featuring the Trainer Gallery subset	{"language": "English", "set_code": "SWSH09", "pack_count": 36, "cards_per_pack": 10}	t	94	2025-09-03 22:19:06.313785+00	2025-09-03 22:19:06.313785+00
\.


--
-- TOC entry 4291 (class 0 OID 16523)
-- Dependencies: 221
-- Data for Name: retailers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retailers (id, name, slug, website_url, api_type, api_config, is_active, rate_limit_per_minute, health_score, last_health_check, supported_features, created_at, updated_at) FROM stdin;
c3755fe7-87a1-41c0-aee4-d2c90170d47f	Best Buy	best-buy	https://www.bestbuy.com	official	{"api_key": "placeholder", "base_url": "https://api.bestbuy.com/v1"}	t	60	95	\N	["cart_links", "inventory_check", "price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
d6856801-fdef-4480-bacb-739d0f8eeade	Walmart	walmart	https://www.walmart.com	affiliate	{"api_key": "placeholder", "affiliate_id": "placeholder"}	t	100	90	\N	["affiliate_links", "price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
c48d6a15-dd8a-4e97-aa2e-81d78f7c4ad2	Costco	costco	https://www.costco.com	scraping	{"base_url": "https://www.costco.com", "user_agent": "BoosterBeacon/1.0"}	t	30	85	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
74a9feae-664a-4c3d-9d09-e77cbc978fa0	Sam's Club	sams-club	https://www.samsclub.com	scraping	{"base_url": "https://www.samsclub.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
5da1a13c-803f-4e97-ad09-006ef8b1c2de	GameStop	gamestop	https://www.gamestop.com	scraping	{"base_url": "https://www.gamestop.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
a3d4e08f-d21d-4bad-b83c-8499566c2930	Target	target	https://www.target.com	scraping	{"base_url": "https://www.target.com", "user_agent": "BoosterBeacon/1.0"}	t	30	80	\N	["price_tracking"]	2025-09-03 22:19:06.308694+00	2025-09-03 22:19:06.308694+00
\.


--
-- TOC entry 4328 (class 0 OID 17363)
-- Dependencies: 258
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, slug, description, permissions, is_system_role, categories, level, is_active, created_by, created_at, updated_at) FROM stdin;
9425e23e-c63c-434e-a688-0e786cd19608	Super Administrator	super_admin	Full system access with all permissions	[]	t	["user_management","system_administration","ml_operations","analytics","content_management","security","billing","monitoring"]	100	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6fc7d6b5-cde0-4c33-9206-d20f107f1906	Administrator	admin	Administrative access with most permissions	[]	t	["user_management","system_administration","analytics","content_management","security","monitoring"]	80	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
96520317-38af-41b0-b46e-3890d4d99f25	User Manager	user_manager	Manage users and basic administrative tasks	[]	t	["user_management","analytics"]	60	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
8c185a4e-5962-4d59-af7f-56b68fda06df	Content Manager	content_manager	Manage products, retailers, and content	[]	t	["content_management","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
6814f358-63ad-4530-a185-9c5cd7dbf0c2	ML Engineer	ml_engineer	Manage machine learning models and data	[]	t	["ml_operations","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
7dff1611-3ec6-4d08-bc90-2d5db769de78	Analyst	analyst	View and analyze system data and metrics	[]	t	["analytics"]	40	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
58b9d7f9-b295-4b7a-8abc-9e650d4586b2	Support Agent	support_agent	Provide customer support and basic user management	[]	t	["user_management"]	30	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
cf9919c8-4c2f-4768-8c0c-3bc770a34e5b	Billing Manager	billing_manager	Manage billing, subscriptions, and financial data	[]	t	["billing","analytics"]	50	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
4c762ab2-3f74-43ec-906b-bfdb46b58b21	Security Officer	security_officer	Manage security, audit logs, and compliance	[]	t	["security","monitoring"]	70	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
2d0c24b1-6468-4cd9-833e-fc310409aea1	User	user	Standard user with no administrative permissions	[]	t	[]	0	t	\N	2025-09-03 16:36:02.66059+00	2025-09-03 16:36:02.66059+00
\.


--
-- TOC entry 4313 (class 0 OID 17017)
-- Dependencies: 243
-- Data for Name: seasonal_patterns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.seasonal_patterns (id, product_id, category_id, pattern_type, pattern_name, avg_price_change, availability_change, demand_multiplier, historical_occurrences, confidence, last_updated) FROM stdin;
\.


--
-- TOC entry 4322 (class 0 OID 17215)
-- Dependencies: 252
-- Data for Name: social_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_shares (id, user_id, alert_id, platform, share_type, metadata, shared_at) FROM stdin;
\.


--
-- TOC entry 4331 (class 0 OID 17455)
-- Dependencies: 261
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, slug, description, price, billing_period, stripe_price_id, features, limits, is_active, trial_days, created_at, updated_at) FROM stdin;
55fa1671-a03e-4b75-a836-84c1f5a88b84	Free	free	Basic alerts for casual collectors	0.00	monthly	\N	["Up to 2 product watches", "Basic email alerts", "Web push notifications", "Community support"]	{"max_watches": 2, "api_rate_limit": 1000, "max_alerts_per_day": 50}	t	0	2025-09-03 22:19:06.350966+00	2025-09-03 22:19:06.350966+00
ada80866-db4e-4443-81b5-69793f42e7d9	Pro	pro-monthly	Advanced features with limited auto-purchase and ML insights	40.00	monthly	price_1S2uGyCR3n2urghaaMu0rJcf	["Up to 10 product watches", "Higher alert priority", "SMS & Discord notifications", "Auto-purchase (limited capacity)", "ML insights (limited: basic price trend + risk)", "Extended price history (12 months)", "Advanced filtering", "Browser extension access"]	{"max_watches": 10, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-09-03 22:19:06.350966+00	2025-09-03 22:19:06.350966+00
394eb3e5-5f5f-45be-8914-b762ae9f25d4	Premium	premium-monthly	Full auto-purchase, full ML, and highest queue priority	100.00	monthly	price_1S2uIkCR3n2urghaSnHaGzow	["Unlimited product watches", "Fastest alert delivery and queue priority", "SMS & Discord notifications", "Auto-purchase (full capacity & priority)", "Full ML: price predictions, sellout risk, ROI", "Full price history access", "Advanced filtering", "Browser extension access", "Premium support", "One-time $300 setup fee"]	{"max_watches": null, "api_rate_limit": null, "max_alerts_per_day": null}	t	7	2025-09-03 22:19:06.350966+00	2025-09-03 22:19:06.350966+00
\.


--
-- TOC entry 4302 (class 0 OID 16814)
-- Dependencies: 232
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_health (id, service_name, status, metrics, message, checked_at) FROM stdin;
1980b98b-f183-45aa-ae57-8b4025e3e0d7	api_server	healthy	{"error_rate": 0.02, "response_time": 45, "uptime_percentage": 99.8}	\N	2025-09-03 16:53:58.37726+00
d19c69f7-49b0-40da-bead-8047cd9d2350	database	healthy	{"query_time": 12, "connection_pool": 8, "uptime_percentage": 99.9}	\N	2025-09-03 16:53:58.37726+00
b541cf95-9c8a-4394-8df5-b5d30cbb0958	retailer_monitoring	healthy	{"success_rate": 98.5, "avg_check_time": 2.3, "active_monitors": 4}	\N	2025-09-03 16:53:58.37726+00
\.


--
-- TOC entry 4318 (class 0 OID 17133)
-- Dependencies: 248
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_metrics (id, metric_name, metric_type, value, labels, recorded_at) FROM stdin;
3c802948-0f8e-492d-88c0-dff25cdf27e4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:36.212+00
1695bdb1-2765-4c19-a26e-084c4d42b365	uptime	gauge	309.459464	{}	2025-09-03 16:36:36.212+00
0d1258c5-8d93-468e-a339-4b355ed35026	memory_usage	gauge	75.570000	{}	2025-09-03 16:36:36.212+00
9a2765b6-8abb-4553-84e9-8869a040d12b	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:36.212+00
4e3a89f2-6edb-4eed-a9ad-e7cadac60073	cpu_usage	gauge	6.000000	{}	2025-09-03 16:36:58.34+00
d2c8d491-5e7f-48fc-922f-0ee7ca343eb7	uptime	gauge	248.100242	{}	2025-09-03 16:36:58.341+00
4de06082-95a8-4707-9774-4ee6b4bf76fd	memory_usage	gauge	75.680000	{}	2025-09-03 16:36:58.34+00
efe07c33-9f0c-405b-9cd3-a904a9d646fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:36:58.341+00
31fe1c93-cb08-4c5f-9d97-5d675f8a84af	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:36.212+00
65f93504-e136-41de-b03c-b19121f38d51	memory_usage	gauge	75.830000	{}	2025-09-03 16:37:36.212+00
b0af6be9-90c2-43f0-b255-6ef5f650c0de	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:36.212+00
8d116f32-15ae-4daf-847f-b4d379c6ba64	uptime	gauge	369.458978	{}	2025-09-03 16:37:36.212+00
0f03de57-b8e4-400e-a640-1501056f4f1b	cpu_usage	gauge	6.000000	{}	2025-09-03 16:37:58.346+00
4605f34f-cf0b-44ed-b844-bc8e987d994f	memory_usage	gauge	75.730000	{}	2025-09-03 16:37:58.346+00
19f45d60-ddb5-4ed0-9807-26a7668c7571	disk_usage	gauge	45.200000	{}	2025-09-03 16:37:58.346+00
733ca3c5-1cfc-4bc9-bf30-dd81e206c078	uptime	gauge	308.106181	{}	2025-09-03 16:37:58.346+00
958dd4cc-7532-44e4-ba8d-838bd699454b	memory_usage	gauge	75.930000	{}	2025-09-03 16:38:36.213+00
738e7053-9eb8-491b-b6a2-1535a9e381cd	cpu_usage	gauge	6.000000	{}	2025-09-03 16:38:36.213+00
5a32f3df-c841-456b-a22d-0c72a9bec3e4	disk_usage	gauge	45.200000	{}	2025-09-03 16:38:36.213+00
3f609f44-0d80-45fb-81f7-d4f7f2485ce7	uptime	gauge	429.459813	{}	2025-09-03 16:38:36.213+00
629e4293-0840-4cec-8c5e-79d45cc5adb7	memory_usage	gauge	75.930000	{}	2025-09-03 16:38:58.346+00
4df21ba8-6dd4-49dd-a86c-f3c81dd84201	cpu_usage	gauge	6.000000	{}	2025-09-03 16:38:58.346+00
12aa3cc5-432f-4469-a8a0-31e38175a772	disk_usage	gauge	45.200000	{}	2025-09-03 16:38:58.346+00
b0ed47cc-8c9f-45c8-a501-98293f4638f3	uptime	gauge	368.105434	{}	2025-09-03 16:38:58.346+00
71d54afb-aac6-4432-8cd0-71b9c4982fb1	cpu_usage	gauge	6.000000	{}	2025-09-03 16:39:36.213+00
ae2d401b-1291-4057-aa2b-3a67f13fb897	memory_usage	gauge	75.900000	{}	2025-09-03 16:39:36.213+00
13c332bc-38e6-4e89-819e-04020f0e47c5	disk_usage	gauge	45.200000	{}	2025-09-03 16:39:36.213+00
b65a6867-ae3b-49e8-9390-b270da074d94	uptime	gauge	489.460450	{}	2025-09-03 16:39:36.213+00
52842366-5165-4db4-ad63-b1a94130c9fc	cpu_usage	gauge	6.000000	{}	2025-09-03 16:39:58.346+00
02c0af50-cfee-413e-a1fe-bc06ee7e1340	memory_usage	gauge	75.830000	{}	2025-09-03 16:39:58.346+00
47d5cbd7-c46d-4fa5-82da-c8b24ea758a8	disk_usage	gauge	45.200000	{}	2025-09-03 16:39:58.346+00
16e09ad7-92b4-460d-bafe-9da2e98615a0	uptime	gauge	428.105690	{}	2025-09-03 16:39:58.346+00
5e16855a-b10b-4afc-809d-15877c8ffaaf	cpu_usage	gauge	6.000000	{}	2025-09-03 16:40:36.213+00
bfc21ada-d92e-4ef9-af68-a06a7fa569d6	memory_usage	gauge	75.990000	{}	2025-09-03 16:40:36.213+00
b93f937c-72e6-4ec2-8fc2-c5bfec91ae32	disk_usage	gauge	45.200000	{}	2025-09-03 16:40:36.213+00
d1dd662c-78a9-4d84-af8e-cc17c7b140f2	uptime	gauge	549.460244	{}	2025-09-03 16:40:36.213+00
7badb281-dae4-49e2-955d-ef3c67f158f1	cpu_usage	gauge	6.000000	{}	2025-09-03 16:40:58.346+00
2df7574f-ce2f-4ea7-931b-8056f102f90e	memory_usage	gauge	76.020000	{}	2025-09-03 16:40:58.346+00
94674ee2-bfcb-42bb-b3b0-828a8ec51737	disk_usage	gauge	45.200000	{}	2025-09-03 16:40:58.346+00
870d6935-e945-4049-989d-5b636d9b2d74	uptime	gauge	488.105702	{}	2025-09-03 16:40:58.346+00
44735896-2136-437b-bf84-411ddd6d46d3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:41:36.213+00
a3ac4b27-dada-4bd7-b96f-a13d79d532dc	memory_usage	gauge	75.880000	{}	2025-09-03 16:41:36.213+00
17aeab3b-688f-4154-9c21-6e04d2959ec3	disk_usage	gauge	45.200000	{}	2025-09-03 16:41:36.213+00
817d2778-a9b1-4b9b-9870-8ca825a8fb62	uptime	gauge	609.460277	{}	2025-09-03 16:41:36.213+00
4038caa6-ca99-4948-8017-dd6ae2f543b9	cpu_usage	gauge	6.000000	{}	2025-09-03 16:41:58.346+00
02810cab-8f02-4a7d-a786-d729238f29df	memory_usage	gauge	75.910000	{}	2025-09-03 16:41:58.347+00
e84ac495-6a7c-43b2-860e-7cdc8379178d	disk_usage	gauge	45.200000	{}	2025-09-03 16:41:58.347+00
1b637501-a490-46ad-90da-e754be0f073c	uptime	gauge	548.106349	{}	2025-09-03 16:41:58.347+00
dd6b7556-51c4-48d8-98e2-8a71f68db110	cpu_usage	gauge	6.000000	{}	2025-09-03 16:42:36.213+00
4391b6c3-769a-4c2e-9d49-9fac9464ed21	memory_usage	gauge	75.910000	{}	2025-09-03 16:42:36.213+00
21b3f84e-8814-4e4f-a2d2-c62d1eef7db0	disk_usage	gauge	45.200000	{}	2025-09-03 16:42:36.213+00
7329560b-4969-4bf3-975e-8b0ea63c3a95	uptime	gauge	669.459834	{}	2025-09-03 16:42:36.213+00
1856b91f-77f7-439f-bdfb-cad6c82778aa	cpu_usage	gauge	6.000000	{}	2025-09-03 16:42:58.347+00
42fac545-50c7-4494-9212-52c57bbcffe7	memory_usage	gauge	75.820000	{}	2025-09-03 16:42:58.347+00
0b5b211a-1beb-4f85-9446-a7b9ddbd51a6	disk_usage	gauge	45.200000	{}	2025-09-03 16:42:58.347+00
72b4e205-7f2b-4753-9e75-34da9755cbbc	uptime	gauge	608.106409	{}	2025-09-03 16:42:58.347+00
395d88e8-bf58-44bb-bbc0-343919cfcd53	memory_usage	gauge	75.880000	{}	2025-09-03 16:43:36.213+00
796d50e7-9a0f-4677-b6ab-cacf2b1fc3ae	disk_usage	gauge	45.200000	{}	2025-09-03 16:43:36.214+00
fd7a9466-6660-46fa-8228-4c35986f5f1b	uptime	gauge	729.460647	{}	2025-09-03 16:43:36.214+00
b9ebe36f-8f5a-4ccb-819d-172c839bdd23	cpu_usage	gauge	6.000000	{}	2025-09-03 16:43:36.213+00
84d7944e-c9c9-48b2-8511-5232c7b13bd4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:43:58.347+00
b22138ba-261c-46a8-a771-7622db63083e	memory_usage	gauge	75.810000	{}	2025-09-03 16:43:58.347+00
d2ee125c-534b-4090-9a1b-d59c62af5be4	disk_usage	gauge	45.200000	{}	2025-09-03 16:43:58.347+00
b35f23a8-9e5c-43b5-9e1b-15148ae5d822	uptime	gauge	668.107077	{}	2025-09-03 16:43:58.347+00
29b31041-a25a-4f93-a0db-2e410bd0af3a	cpu_usage	gauge	6.000000	{}	2025-09-03 16:44:36.213+00
f147b249-208b-4b70-9698-eb928b5a3959	memory_usage	gauge	76.420000	{}	2025-09-03 16:44:36.213+00
ac034995-408a-43f7-a2de-360e97bc1f54	disk_usage	gauge	45.200000	{}	2025-09-03 16:44:36.213+00
911970f2-e565-4605-8944-6bb280464432	uptime	gauge	789.460514	{}	2025-09-03 16:44:36.213+00
d4efed9c-0fca-4a01-bea4-e5798bb20fce	cpu_usage	gauge	6.000000	{}	2025-09-03 16:44:58.347+00
8948a660-8d0f-418d-9fd3-99564d799fcc	memory_usage	gauge	76.340000	{}	2025-09-03 16:44:58.347+00
f71e7e15-8ea2-4972-9048-ff53638c7c73	disk_usage	gauge	45.200000	{}	2025-09-03 16:44:58.348+00
dd6ced7e-cafc-4022-94bd-3a4515aecf3d	uptime	gauge	728.107637	{}	2025-09-03 16:44:58.348+00
8202453b-2d7b-4785-b8dd-1dab0cb72740	cpu_usage	gauge	6.000000	{}	2025-09-03 16:45:36.213+00
6904bba2-bde0-41c3-b463-062551afb48e	memory_usage	gauge	76.750000	{}	2025-09-03 16:45:36.214+00
4791b2b1-1709-4832-93ff-5410e43236c6	disk_usage	gauge	45.200000	{}	2025-09-03 16:45:36.214+00
c6cb4161-8ad5-4d12-8906-ec5a15bcccbe	uptime	gauge	849.460687	{}	2025-09-03 16:45:36.214+00
ba1fc3b6-1977-4b52-b9a4-d128fbf82f24	cpu_usage	gauge	6.000000	{}	2025-09-03 16:45:58.348+00
246b0eba-4de4-4288-bbf2-2362cf4f0755	memory_usage	gauge	76.770000	{}	2025-09-03 16:45:58.348+00
5806108c-f82d-4c73-bcf7-f7e124dbc6bb	disk_usage	gauge	45.200000	{}	2025-09-03 16:45:58.348+00
2a12fb66-40f5-4906-8101-8ab0c709a108	uptime	gauge	788.107618	{}	2025-09-03 16:45:58.348+00
461c6d90-136b-4671-a6f5-b51f36d960a3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:46:36.213+00
6de51c31-0838-44fd-bfdb-28fd6da88786	memory_usage	gauge	76.910000	{}	2025-09-03 16:46:36.214+00
fa9bd97d-8f76-4f6e-8114-53b782254989	disk_usage	gauge	45.200000	{}	2025-09-03 16:46:36.214+00
4d0b1ece-6414-4ec9-9cae-afe51b4a6c98	uptime	gauge	909.460662	{}	2025-09-03 16:46:36.214+00
9567752d-07f4-4187-8d28-693de7089523	cpu_usage	gauge	6.000000	{}	2025-09-03 16:46:58.349+00
e7cbfe09-784e-4722-8cad-98359f589fd3	memory_usage	gauge	76.460000	{}	2025-09-03 16:46:58.349+00
978e6634-96d8-4b8e-b945-c613587ab0b4	disk_usage	gauge	45.200000	{}	2025-09-03 16:46:58.349+00
41f4f5ce-6cb4-4b4d-99d2-69e17078e6d0	uptime	gauge	848.109197	{}	2025-09-03 16:46:58.349+00
f53cfbfb-fef5-428f-b50e-cb4d623c5a28	cpu_usage	gauge	6.000000	{}	2025-09-03 16:47:36.214+00
d815f760-115e-4ee4-a8a8-af9da4689875	memory_usage	gauge	76.440000	{}	2025-09-03 16:47:36.214+00
98ebeb56-883d-4e3d-ac52-6d892d2c500a	disk_usage	gauge	45.200000	{}	2025-09-03 16:47:36.214+00
df8c3123-2107-40bf-a47c-22c0464cea5d	uptime	gauge	969.461411	{}	2025-09-03 16:47:36.214+00
35ba4a98-3e2d-4859-9c92-e9a8a38efa94	cpu_usage	gauge	6.000000	{}	2025-09-03 16:47:58.35+00
0924aa26-7132-4ed5-ad06-5f9f40d321f5	memory_usage	gauge	76.460000	{}	2025-09-03 16:47:58.35+00
07069f3e-b973-4ab7-adb6-5519a0a5cbd3	disk_usage	gauge	45.200000	{}	2025-09-03 16:47:58.35+00
d5caac0f-f079-4b79-8ed4-54264ec1cc93	uptime	gauge	908.109400	{}	2025-09-03 16:47:58.35+00
90ef54f5-0826-4a8f-88f9-4258454b64ec	cpu_usage	gauge	6.000000	{}	2025-09-03 16:48:36.215+00
d97f9450-a425-4e38-b7d3-fcc68a953625	disk_usage	gauge	45.200000	{}	2025-09-03 16:48:36.215+00
44678f0b-2356-4d5b-bcbc-556f09e5bca4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:49:36.215+00
b15578a9-8163-445d-b130-0a0c47ac902d	uptime	gauge	1029.461810	{}	2025-09-03 16:48:36.215+00
cb56c4d0-2cf1-4324-8130-5902f5b7c7ca	disk_usage	gauge	45.200000	{}	2025-09-03 16:49:36.215+00
df1d8c40-4523-4497-ae6c-063e714d1e1e	memory_usage	gauge	76.390000	{}	2025-09-03 16:48:58.35+00
5fba1d39-3646-4dc2-a6bc-c3965b1e422f	uptime	gauge	1028.112035	{}	2025-09-03 16:49:58.352+00
93452c38-6d2e-4eb1-96c6-c16f02ffaf97	cpu_usage	gauge	6.000000	{}	2025-09-03 16:48:58.35+00
d0f3533d-a10c-4251-aa94-371a5f43313c	cpu_usage	gauge	6.000000	{}	2025-09-03 16:49:58.352+00
ae03ce59-9cfd-4156-b98f-f8eab42fb501	disk_usage	gauge	45.200000	{}	2025-09-03 16:48:58.35+00
38dde6f2-ce08-4e2e-aecf-d168642a33fe	disk_usage	gauge	45.200000	{}	2025-09-03 16:49:58.352+00
7636af42-9b87-4ba6-bd1b-2b370cbeb310	uptime	gauge	968.110089	{}	2025-09-03 16:48:58.35+00
1a66b0ac-854e-401b-8d46-7d4d0f116d38	memory_usage	gauge	76.500000	{}	2025-09-03 16:49:58.352+00
fc53b25d-4ece-4f30-9c29-abe646c8db60	uptime	gauge	1089.462308	{}	2025-09-03 16:49:36.215+00
85254410-25a7-4fd6-ab62-f79ed59ddf34	memory_usage	gauge	76.890000	{}	2025-09-03 16:50:36.215+00
88939c22-aaa8-4a6a-8ea3-3e25c5b1722f	uptime	gauge	1209.461963	{}	2025-09-03 16:51:36.215+00
a5b2626f-92ae-4086-8a73-1c1d051c350d	memory_usage	gauge	76.490000	{}	2025-09-03 16:52:36.215+00
f5732cd5-1ae0-49c7-9d21-71e7c67a7705	memory_usage	gauge	76.390000	{}	2025-09-03 16:53:36.216+00
8e92afaa-5774-461a-b0f9-b0cfa3ba738a	memory_usage	gauge	76.400000	{}	2025-09-03 16:54:36.216+00
1ef2969e-b51f-4677-9f7a-f09479accb9f	memory_usage	gauge	77.340000	{}	2025-09-03 16:55:36.217+00
9ea5703c-811b-4687-861c-7d852eb2310f	memory_usage	gauge	77.550000	{}	2025-09-03 16:56:36.217+00
aaf04adb-ea06-4a89-b227-187bb57bb3f2	cpu_usage	gauge	6.000000	{}	2025-09-03 16:57:36.217+00
c583016d-c1c3-42eb-bfeb-6a806b1b00d0	disk_usage	gauge	45.200000	{}	2025-09-03 16:50:36.215+00
25f41f13-2bea-40e9-827f-d05b2bb7d752	memory_usage	gauge	76.830000	{}	2025-09-03 16:51:36.215+00
c0c54375-df58-4fdc-94f0-04f88e23f92a	uptime	gauge	1269.462529	{}	2025-09-03 16:52:36.215+00
6958620c-4a77-4fd8-97b4-6482400dfb89	disk_usage	gauge	45.200000	{}	2025-09-03 16:53:36.216+00
47fbbd27-43fa-4f04-a934-884e230e892a	cpu_usage	gauge	6.000000	{}	2025-09-03 16:54:36.216+00
bab548c8-3025-4574-8659-1bbff5e377d7	uptime	gauge	1449.463962	{}	2025-09-03 16:55:36.217+00
9dce3151-544f-4020-ac28-a279a607a486	cpu_usage	gauge	6.000000	{}	2025-09-03 16:56:36.217+00
5a969cb1-206e-4251-b82d-6a6a9f0dffcf	uptime	gauge	1569.463926	{}	2025-09-03 16:57:36.217+00
1618c1d2-2938-4e08-81a5-75f0ae3bbdaa	cpu_usage	gauge	6.000000	{}	2025-09-03 16:50:36.215+00
c768e98c-9aaa-4052-b77c-6483ef4fc628	cpu_usage	gauge	6.000000	{}	2025-09-03 16:51:36.215+00
c0d9e31f-366a-453a-bee2-ea27ece5c16c	disk_usage	gauge	45.200000	{}	2025-09-03 16:52:36.215+00
87b60b73-fcd7-4807-9a3a-9a20688c0876	cpu_usage	gauge	6.000000	{}	2025-09-03 16:53:36.216+00
4e0b7007-57a7-4c14-ae4f-b26e34bfd25a	uptime	gauge	1389.463555	{}	2025-09-03 16:54:36.216+00
9524cd9f-0a77-49d1-a18f-df6cae49511f	disk_usage	gauge	45.200000	{}	2025-09-03 16:55:36.217+00
94679b9b-c52c-416f-9ad2-877a6b55d995	disk_usage	gauge	45.200000	{}	2025-09-03 16:56:36.217+00
9af066df-8321-46bf-9a12-08e38df63fd6	memory_usage	gauge	77.620000	{}	2025-09-03 16:57:36.217+00
f6e014d5-7fd5-4806-aa3d-792eea380086	uptime	gauge	1149.462075	{}	2025-09-03 16:50:36.215+00
a84c2895-11c7-472d-ba73-b4c532d2aeda	disk_usage	gauge	45.200000	{}	2025-09-03 16:51:36.215+00
7ccb0354-b4c3-4427-9a26-0a85e70753b7	cpu_usage	gauge	6.000000	{}	2025-09-03 16:52:36.215+00
99fd1d87-b7af-4604-802d-23c61189a6cf	uptime	gauge	1329.463145	{}	2025-09-03 16:53:36.216+00
0d4fe496-8d6d-481d-9cb5-77af0b227b88	disk_usage	gauge	45.200000	{}	2025-09-03 16:54:36.216+00
af14e1d7-d5e4-4a09-8ffc-b9d26d88a61d	cpu_usage	gauge	6.000000	{}	2025-09-03 16:55:36.217+00
d55b816e-541a-46c7-af33-2c9f7176481c	uptime	gauge	1509.463941	{}	2025-09-03 16:56:36.217+00
66f772f5-4ae4-43a7-aa1f-226538e40f59	disk_usage	gauge	45.200000	{}	2025-09-03 16:57:36.217+00
dc2cd04a-852c-4984-956b-39993ed2e6a9	memory_usage	gauge	76.910000	{}	2025-09-03 16:50:58.352+00
7c9e0c03-9af5-4754-bfc5-732216a618b1	uptime	gauge	1148.113165	{}	2025-09-03 16:51:58.353+00
e14bbee6-5894-49c7-b77c-10e862f5dc30	memory_usage	gauge	76.510000	{}	2025-09-03 16:52:58.354+00
e99bbe07-bb25-4f7e-a96d-96a886510c43	uptime	gauge	1268.113535	{}	2025-09-03 16:53:58.354+00
34024502-6841-4696-be4a-d9152356073d	memory_usage	gauge	76.370000	{}	2025-09-03 16:54:58.354+00
35ddd4af-b6b5-4c24-bc70-07b145fb9525	uptime	gauge	1388.114307	{}	2025-09-03 16:55:58.355+00
738ff6ac-17b4-423f-b18a-c1ab93396dbd	disk_usage	gauge	45.200000	{}	2025-09-03 16:56:58.355+00
6b8e51b9-c72a-42d6-aa3c-fdfe2a093eac	uptime	gauge	1508.115367	{}	2025-09-03 16:57:58.356+00
91cc7563-40bc-4ed3-a0ad-72cfcd324084	uptime	gauge	1088.112187	{}	2025-09-03 16:50:58.352+00
ad4ca451-4298-471d-82e7-be176b75d0a4	cpu_usage	gauge	6.000000	{}	2025-09-03 16:51:58.353+00
e9379543-6c19-4e2b-bf8f-10e806de848b	disk_usage	gauge	45.200000	{}	2025-09-03 16:52:58.354+00
cd61ce44-004a-4be7-aa6e-7a697f77bf47	disk_usage	gauge	45.200000	{}	2025-09-03 16:53:58.354+00
10617a79-e2a3-48b7-b798-02c3aa343483	cpu_usage	gauge	6.000000	{}	2025-09-03 16:54:58.354+00
5c4dbafc-9872-4fb2-a9b8-9222baf77c71	disk_usage	gauge	45.200000	{}	2025-09-03 16:55:58.355+00
5cc5b36f-b160-4d57-9538-1aacb0d63207	cpu_usage	gauge	6.000000	{}	2025-09-03 16:56:58.355+00
1fd04c1f-6c63-4b7e-84ba-53fd3c1a424d	disk_usage	gauge	45.200000	{}	2025-09-03 16:57:58.356+00
7a94d813-5996-4d91-a62e-aa5573b74951	cpu_usage	gauge	6.000000	{}	2025-09-03 16:50:58.352+00
5623e58e-0559-4a44-9fca-ff2138d060a0	disk_usage	gauge	45.200000	{}	2025-09-03 16:51:58.353+00
c30fe19d-4b51-44a1-aa73-85ec8b8851c8	cpu_usage	gauge	6.000000	{}	2025-09-03 16:52:58.354+00
b345020d-42d0-4043-b17b-7e19ce9019d5	memory_usage	gauge	76.840000	{}	2025-09-03 16:53:58.354+00
d8b9c807-9254-4806-b8ff-8e2da1f9433c	disk_usage	gauge	45.200000	{}	2025-09-03 16:54:58.354+00
a8d91430-c233-470d-a60f-94fd99383671	memory_usage	gauge	77.750000	{}	2025-09-03 16:55:58.355+00
ed71f53b-e8db-4594-a221-97862189597c	memory_usage	gauge	77.660000	{}	2025-09-03 16:56:58.355+00
4e03288c-cfd4-49b9-a175-b39393efefec	memory_usage	gauge	77.410000	{}	2025-09-03 16:57:58.356+00
57a94809-32c6-42d3-a322-ae81e16973a6	disk_usage	gauge	45.200000	{}	2025-09-03 16:50:58.352+00
2bf194e7-76cd-46fc-a691-498931d6d6d3	memory_usage	gauge	76.510000	{}	2025-09-03 16:51:58.353+00
50a4c9e5-7af4-4249-b1c4-0e10bc4ba707	uptime	gauge	1208.113528	{}	2025-09-03 16:52:58.354+00
9b09020c-c369-4ecd-aa69-60f9f67a7f77	cpu_usage	gauge	6.000000	{}	2025-09-03 16:53:58.354+00
77f2a215-bcdc-46d0-b4c9-a115788e72f0	uptime	gauge	1328.114132	{}	2025-09-03 16:54:58.354+00
8a5b5b54-db6b-4a81-b3e8-2eec3f18c9c3	cpu_usage	gauge	6.000000	{}	2025-09-03 16:55:58.354+00
ae4c1a07-7b87-43ac-aed0-2e8e9c01af12	uptime	gauge	1448.114582	{}	2025-09-03 16:56:58.355+00
90e1245b-8dda-4c99-87b6-46f3fc0b46c2	cpu_usage	gauge	6.000000	{}	2025-09-03 16:57:58.356+00
ed01d5ab-a889-41b6-94f1-41970b068823	cpu_usage	gauge	6.000000	{}	2025-09-03 16:58:36.218+00
2875c1da-aa02-49fc-81b0-e041cb12b878	uptime	gauge	1689.466714	{}	2025-09-03 16:59:36.22+00
1d230758-7692-4039-ae50-b1ea5a269269	cpu_usage	gauge	6.000000	{}	2025-09-03 17:00:36.219+00
8109c091-71a4-457e-8559-4819c73bdb14	uptime	gauge	1809.465741	{}	2025-09-03 17:01:36.219+00
f53f34be-6bc6-4ecb-b862-7bce2f975874	disk_usage	gauge	45.200000	{}	2025-09-03 17:02:36.219+00
91d1845a-5fe5-4b5d-bfee-87d9267b3cdc	memory_usage	gauge	77.130000	{}	2025-09-03 17:03:36.22+00
e613a6a4-7482-4074-833c-7020d7dc067c	memory_usage	gauge	76.730000	{}	2025-09-03 17:04:36.22+00
71cd9b27-3d96-4018-a5f5-a156ae03fb86	cpu_usage	gauge	6.000000	{}	2025-09-03 17:05:36.221+00
d25d4831-5e09-4169-b488-746399a097f7	uptime	gauge	2109.467788	{}	2025-09-03 17:06:36.221+00
3371205f-c7b5-4d6c-b1e3-d79c1695d750	cpu_usage	gauge	6.000000	{}	2025-09-03 17:49:13.549+00
45f56c25-749c-4c3d-91ec-5c0822f51f62	memory_usage	gauge	74.380000	{}	2025-09-03 17:49:13.549+00
eefea8a0-a3e6-4725-8eb0-164000123a83	disk_usage	gauge	45.200000	{}	2025-09-03 17:49:13.549+00
1700a00c-3d54-42ce-b8ce-9ff3bcb1e395	uptime	gauge	69.351909	{}	2025-09-03 17:49:13.549+00
05bed622-ca87-486a-8ce3-d8920ba57c8c	uptime	gauge	129.352361	{}	2025-09-03 17:50:13.55+00
2ed66c06-c2d1-40f0-a757-a976ef764c06	uptime	gauge	189.353844	{}	2025-09-03 17:51:13.551+00
d8af877f-dd9b-4a60-9654-16495a995c44	disk_usage	gauge	45.200000	{}	2025-09-03 17:52:13.55+00
37648ab8-e0cb-4f9d-8928-649b70e9806f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:53:13.555+00
adc6e688-a32b-45a7-ae8b-cbb7687d037b	cpu_usage	gauge	6.000000	{}	2025-09-03 18:25:38.088+00
91704d68-4297-45b3-be58-e6d6646f1027	memory_usage	gauge	69.490000	{}	2025-09-03 18:25:38.089+00
9c63ec59-9bed-4261-a54d-c3253eb117b7	disk_usage	gauge	45.200000	{}	2025-09-03 18:25:38.089+00
8e1dc14b-d12f-4f03-a4bc-dc1c51fd730e	uptime	gauge	69.232184	{}	2025-09-03 18:25:38.089+00
b0a363d2-b265-46df-868b-a4ed489d7358	uptime	gauge	129.231973	{}	2025-09-03 18:26:38.088+00
50e31809-7d08-4931-aa19-18745ca09d2d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:27:38.089+00
63f0832c-730a-4c0b-80f6-d125dda49223	uptime	gauge	249.234122	{}	2025-09-03 18:28:38.091+00
52621e95-2cfc-4d17-85fc-43a843773565	cpu_usage	gauge	6.000000	{}	2025-09-03 18:29:38.096+00
e3f55673-1768-4898-adc5-38717a4c8bd7	uptime	gauge	369.239983	{}	2025-09-03 18:30:38.096+00
9c0cad8c-5136-49e6-872c-9847e5c4a24f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:34:38.098+00
0b7b76b9-23ca-461d-9d2d-22e786f5e95a	memory_usage	gauge	64.770000	{}	2025-09-03 18:34:38.098+00
44a79de9-55e6-4b1d-9cd0-521a44a5ef44	disk_usage	gauge	45.200000	{}	2025-09-03 18:34:38.098+00
4f5a04bc-6db1-4bf0-a62d-3fd62ec86fa4	uptime	gauge	609.241256	{}	2025-09-03 18:34:38.098+00
228492a9-36c6-4b3e-8019-c5215cebcf93	uptime	gauge	669.243544	{}	2025-09-03 18:35:38.1+00
4abca9a5-b301-41f8-8cdb-a4b99554ddc6	cpu_usage	gauge	6.000000	{}	2025-09-03 18:46:36.591+00
dbf8a728-a41b-475e-a9c2-8fe296f98fab	memory_usage	gauge	69.510000	{}	2025-09-03 18:46:36.591+00
fed8bfdd-4d42-4b15-b5b4-49043d47966b	disk_usage	gauge	45.200000	{}	2025-09-03 18:46:36.591+00
32cd1a40-1a36-4b5d-aac0-a14a0f12d001	uptime	gauge	68.948844	{}	2025-09-03 18:46:36.591+00
19624da4-9cb5-40ef-ba5a-5e0446786399	cpu_usage	gauge	6.000000	{}	2025-09-03 18:49:04.666+00
c097a3bd-3c6f-4c87-a5dd-f3e613772222	memory_usage	gauge	64.330000	{}	2025-09-03 18:49:04.666+00
a8913fe1-69c0-41eb-8802-b19dacd67c29	disk_usage	gauge	45.200000	{}	2025-09-03 18:49:04.666+00
4e567f05-9134-463b-879b-2c3f3c160e43	uptime	gauge	69.196963	{}	2025-09-03 18:49:04.667+00
39c5c6fa-6011-4157-8068-dffc260e092a	uptime	gauge	129.196145	{}	2025-09-03 18:50:04.666+00
8616dd93-0945-4ee0-8296-18a7d1b8b123	uptime	gauge	189.195945	{}	2025-09-03 18:51:04.665+00
b37fdd36-e97a-41f5-a63a-527a61980b11	disk_usage	gauge	45.200000	{}	2025-09-03 18:52:04.667+00
a0673e67-9c5a-4b61-a53d-9efbf1af7c23	cpu_usage	gauge	6.000000	{}	2025-09-03 18:53:04.667+00
0e5bd295-a99c-43bf-a05a-4fb700d5fbe4	uptime	gauge	369.197139	{}	2025-09-03 18:54:04.667+00
c173b9f8-a69c-4b7d-8ba7-d1f0929af960	cpu_usage	gauge	6.000000	{}	2025-09-03 18:59:30.075+00
e2205e8c-4b02-42c9-8ee0-f236a6fe59d9	memory_usage	gauge	67.880000	{}	2025-09-03 18:59:30.075+00
4bb0d98e-8afe-440c-923a-74f9afcb1651	disk_usage	gauge	45.200000	{}	2025-09-03 18:59:30.075+00
534c6be9-6510-44fd-8ae8-fdcce78f4339	uptime	gauge	69.074141	{}	2025-09-03 18:59:30.075+00
df79894b-a5c9-421a-94e8-5ccf3f144af0	cpu_usage	gauge	6.000000	{}	2025-09-03 19:18:37.465+00
32047568-e95e-4026-858a-089ae2755d05	memory_usage	gauge	67.530000	{}	2025-09-03 19:18:37.466+00
93a2c134-9795-45a2-a5e3-b6394f632781	disk_usage	gauge	45.200000	{}	2025-09-03 19:18:37.466+00
ad126027-4c63-4d8a-82bb-0080f1bfad45	uptime	gauge	69.040327	{}	2025-09-03 19:18:37.466+00
f187d352-744e-4d28-b7e6-513dcd2acd8c	uptime	gauge	129.040185	{}	2025-09-03 19:19:37.466+00
2e8c7663-5211-4199-8467-5d0b52750e04	disk_usage	gauge	45.200000	{}	2025-09-03 19:20:37.467+00
f4760940-a5c1-44b3-8817-2ce5b81bd0d2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:21:37.468+00
4db25c5d-eebd-4044-a185-9e89dce702ec	uptime	gauge	309.047343	{}	2025-09-03 19:22:37.473+00
cbb29218-1ef4-4e9d-9869-67c6b1850c0f	memory_usage	gauge	68.140000	{}	2025-09-03 19:23:37.473+00
9c21b4f3-0e46-419b-aaf8-d1c21391d1f4	uptime	gauge	429.048043	{}	2025-09-03 19:24:37.474+00
6882f55b-9cb9-43a3-8977-56dd4fbffd08	disk_usage	gauge	45.200000	{}	2025-09-03 19:25:37.474+00
3c6f737a-639f-4225-8a6e-5d5906193cc6	memory_usage	gauge	68.290000	{}	2025-09-03 19:26:37.473+00
211efd3e-8cda-45d7-b9a5-84f4672c0cdf	memory_usage	gauge	68.170000	{}	2025-09-03 19:27:37.475+00
b63dd5e9-22e1-461f-a88d-427f9ba0a2cf	memory_usage	gauge	68.160000	{}	2025-09-03 19:28:37.476+00
227d44b2-4c78-4d38-a07f-5eb4bb494cc0	uptime	gauge	68.968708	{}	2025-09-03 19:32:52.834+00
731f12d2-58f2-48dd-81bf-7a28b6e990d3	disk_usage	gauge	45.200000	{}	2025-09-03 19:33:52.834+00
ac31a206-6746-4893-9f24-49faa0658446	memory_usage	gauge	67.860000	{}	2025-09-03 19:34:52.834+00
21827b26-24ce-43b7-a31b-57e287bfbf5e	disk_usage	gauge	45.200000	{}	2025-09-03 19:35:52.834+00
1c50cb2f-b6ea-422b-9b30-058793ab8417	cpu_usage	gauge	6.000000	{}	2025-09-03 19:36:52.84+00
764ca5a8-3e87-4691-9940-a3c93ae031cb	uptime	gauge	368.975498	{}	2025-09-03 19:37:52.841+00
5b127ef0-9711-4ee9-8d90-72ad53702d78	cpu_usage	gauge	6.000000	{}	2025-09-03 19:38:52.841+00
3ee3fff0-3098-4001-b34d-ad4c4a7d9073	uptime	gauge	488.976124	{}	2025-09-03 19:39:52.841+00
9118064a-8705-4f48-aaa1-5c6799a7fd63	disk_usage	gauge	45.200000	{}	2025-09-03 19:40:52.841+00
f61bf6b5-6ce1-4d04-83dd-3e72efa0ca7f	disk_usage	gauge	45.200000	{}	2025-09-03 19:41:52.841+00
2ea82cac-b5d4-405f-b5bc-74e2ce475ee9	disk_usage	gauge	45.200000	{}	2025-09-03 19:42:52.84+00
2b14a6ab-ba85-4885-9ef8-7126a87d2b93	uptime	gauge	728.975737	{}	2025-09-03 19:43:52.841+00
6d5c7e2c-2c2b-4225-8a55-6c375aa81c48	memory_usage	gauge	68.320000	{}	2025-09-03 19:44:52.84+00
71f4b035-cb25-4ea9-9c17-30480036f3fb	uptime	gauge	848.975548	{}	2025-09-03 19:45:52.841+00
73c76503-5324-435e-ada2-10640ddf67b2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:46:52.84+00
6e9bef52-9be3-4661-b583-e9283f3c2ce4	uptime	gauge	968.976505	{}	2025-09-03 19:47:52.842+00
bdca1e69-4c70-4b47-8a1b-717cd99feeaf	cpu_usage	gauge	6.000000	{}	2025-09-03 19:48:52.841+00
cf7a49e4-e90e-4db9-af70-c72ed7c77eec	disk_usage	gauge	45.200000	{}	2025-09-03 19:49:52.842+00
e95ba39b-1e16-4668-a3cd-f0f4bf22013e	memory_usage	gauge	68.440000	{}	2025-09-03 19:50:52.842+00
be861ea9-d8cc-4fbb-bacf-247a65323a9a	cpu_usage	gauge	6.000000	{}	2025-09-03 19:51:52.842+00
3b4761b3-8297-4ff1-9b29-96a698f5a715	uptime	gauge	1268.977048	{}	2025-09-03 19:52:52.842+00
dbb4d9cf-6533-4fea-bba9-db7604d55090	disk_usage	gauge	45.200000	{}	2025-09-03 19:53:52.842+00
c6ff69fe-9cd9-455f-8c8a-af4cf3b00516	cpu_usage	gauge	6.000000	{}	2025-09-03 22:10:05.396+00
15dfcd0b-17d1-4c41-b381-3c3ad19b19bc	uptime	gauge	69.328221	{}	2025-09-03 22:10:05.396+00
f1b8be26-b8d6-4f26-be7e-d4687a8ea3f2	disk_usage	gauge	45.200000	{}	2025-09-03 22:11:05.397+00
89a1a9d4-a412-4253-97e3-dbd75cabe69e	uptime	gauge	189.329793	{}	2025-09-03 22:12:05.398+00
0411d0eb-bbb1-40f3-a282-9feb05f38bec	disk_usage	gauge	45.200000	{}	2025-09-03 22:13:05.398+00
56e1c25a-c15e-409f-b393-ad6b08b1b95c	memory_usage	gauge	72.340000	{}	2025-09-03 22:14:05.403+00
bf65f882-42aa-4a6f-b9af-73e68aa4d26e	cpu_usage	gauge	6.000000	{}	2025-09-03 22:16:12.169+00
e4744be0-8026-42a2-a59c-9106a2aaa1a4	memory_usage	gauge	74.650000	{}	2025-09-03 22:16:12.169+00
e5f647b6-1170-4775-8334-cde7e6c20b85	disk_usage	gauge	45.200000	{}	2025-09-03 22:16:12.169+00
500042a8-f970-493c-a7e7-8050a3bd5485	uptime	gauge	69.165921	{}	2025-09-03 22:16:12.169+00
a1880f20-0073-4120-a650-9bc9da3474d2	uptime	gauge	129.165722	{}	2025-09-03 22:17:12.169+00
f1c77bf6-bd16-403d-9a5b-36db4db1b08a	uptime	gauge	189.166052	{}	2025-09-03 22:18:12.169+00
a3b1a000-1d22-490b-83f2-a164b2f8fde0	disk_usage	gauge	45.200000	{}	2025-09-03 22:19:12.171+00
162a8336-ba7e-4b6c-998a-f8a9ba17bf6b	disk_usage	gauge	45.200000	{}	2025-09-03 16:58:36.218+00
12a4a02e-da43-46f9-aa27-fa7872c6ab19	disk_usage	gauge	45.200000	{}	2025-09-03 16:59:36.22+00
baea5735-735e-43e1-8e6f-8468b8a710d9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:49:27.515+00
f399410a-2ee3-4477-80db-66e59c228057	memory_usage	gauge	74.350000	{}	2025-09-03 17:49:27.515+00
40985f3f-1879-4a96-8216-355e9fce3e39	disk_usage	gauge	45.200000	{}	2025-09-03 17:49:27.515+00
b409d95f-4967-45ff-8758-402d95ca6ac4	memory_usage	gauge	74.980000	{}	2025-09-03 17:50:27.515+00
551762e7-85a6-4a67-898b-2892c3013b99	cpu_usage	gauge	6.000000	{}	2025-09-03 17:51:27.516+00
a6a84e9e-af5b-4ca4-9bee-87416df919c5	uptime	gauge	248.008572	{}	2025-09-03 17:52:27.517+00
ac7d293f-d2ed-442f-b602-e2edd9b02090	cpu_usage	gauge	6.000000	{}	2025-09-03 17:53:27.524+00
805d2158-6f59-4674-ad28-8cb6be55f15f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:26:38.088+00
0cd936e6-f756-4f7a-b48a-63f386ef78d4	uptime	gauge	189.232937	{}	2025-09-03 18:27:38.089+00
89c0b5a3-e12d-4f92-beb1-10415134671e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:28:38.091+00
760449ca-1102-488c-8ae5-1c1ce8e80453	uptime	gauge	309.239843	{}	2025-09-03 18:29:38.096+00
dcb80716-27da-4b25-8119-f48778a4b929	disk_usage	gauge	45.200000	{}	2025-09-03 18:30:38.096+00
f58ead89-ea45-47ae-ada1-2e33960fb97f	cpu_usage	gauge	6.000000	{}	2025-09-03 18:35:38.1+00
88988fbf-a1c3-434c-bb06-5514905e744a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:50:04.666+00
8cfe7c57-cfa5-4981-b8e5-1c5c5e246755	cpu_usage	gauge	6.000000	{}	2025-09-03 18:51:04.665+00
19070a34-3048-47f7-bf17-ec0691a68417	uptime	gauge	249.197199	{}	2025-09-03 18:52:04.667+00
91283943-1552-4d08-afe3-9f077c69a0fd	disk_usage	gauge	45.200000	{}	2025-09-03 18:53:04.667+00
9e683998-9f2f-48b0-b7d7-d015da48d27d	memory_usage	gauge	64.730000	{}	2025-09-03 18:54:04.667+00
0a7564c0-24be-4f73-930e-be42316d2767	cpu_usage	gauge	6.000000	{}	2025-09-03 19:00:30.074+00
14959e0c-2574-4ac3-a2a0-016453c587c5	uptime	gauge	189.074307	{}	2025-09-03 19:01:30.075+00
e7e95855-d772-4024-9415-db0b1278b0b6	cpu_usage	gauge	6.000000	{}	2025-09-03 19:02:30.076+00
d8e8cf5c-1b86-46a9-9983-2c9071aa31a0	uptime	gauge	309.074804	{}	2025-09-03 19:03:30.076+00
e9e5ba61-9ee2-468a-a724-8615601971af	disk_usage	gauge	45.200000	{}	2025-09-03 19:04:30.075+00
dd9e6d01-1317-4492-8032-28eb3c16b1f4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:05:30.076+00
1654998b-77ba-46bc-b3d3-4e814b415325	uptime	gauge	489.075076	{}	2025-09-03 19:06:30.076+00
cc095702-81f3-4390-a463-25bd008c07c1	cpu_usage	gauge	6.000000	{}	2025-09-03 19:19:37.465+00
40d6a792-76fd-4fe2-a51c-748bbe08fbf2	uptime	gauge	189.041228	{}	2025-09-03 19:20:37.467+00
77c0208c-7cf0-47b5-a532-41bee9601c23	disk_usage	gauge	45.200000	{}	2025-09-03 19:21:37.468+00
18a79157-ef39-4207-9a21-1bcca66f0568	disk_usage	gauge	45.200000	{}	2025-09-03 19:22:37.473+00
bbcd9a98-e319-4dfc-b47f-1302adc2d0c0	disk_usage	gauge	45.200000	{}	2025-09-03 19:32:52.834+00
45facab1-f731-43f5-bcf7-11a82098973b	uptime	gauge	128.968605	{}	2025-09-03 19:33:52.834+00
a7f2c7ca-eba0-4cc3-9c93-4762debd128e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:34:52.834+00
13177cc4-cae7-4f22-9be2-d9807f4b4ede	uptime	gauge	248.968926	{}	2025-09-03 19:35:52.834+00
8032a1b7-7b1f-4390-8c9e-1eb5da5ec122	memory_usage	gauge	68.270000	{}	2025-09-03 19:36:52.84+00
edce9231-35b0-4496-84c2-576124bd4cd3	memory_usage	gauge	68.190000	{}	2025-09-03 19:37:52.841+00
0f6ff111-041f-4990-b0a2-bf6f1cbd57b5	disk_usage	gauge	45.200000	{}	2025-09-03 19:38:52.841+00
38e2b864-89c8-495c-ac99-578a63507be2	disk_usage	gauge	45.200000	{}	2025-09-03 19:39:52.841+00
2b8db020-a9c5-4bb7-86d9-04e34b06410b	cpu_usage	gauge	6.000000	{}	2025-09-03 19:40:52.841+00
5792c382-01f0-48f5-91b1-3db84ee6e134	uptime	gauge	608.976130	{}	2025-09-03 19:41:52.841+00
da4bbd0d-b3d9-4805-928b-4945874ebe63	uptime	gauge	668.975303	{}	2025-09-03 19:42:52.84+00
2198561d-a596-478b-9ce0-57f7a809508a	disk_usage	gauge	45.200000	{}	2025-09-03 19:43:52.841+00
ececb330-e955-413a-aa57-a69695718bf5	cpu_usage	gauge	6.000000	{}	2025-09-03 19:44:52.84+00
18271016-3faa-4219-915f-0d2cbba5cdd5	disk_usage	gauge	45.200000	{}	2025-09-03 19:45:52.841+00
7684670d-3713-4642-bc12-b1aaefcfbb32	disk_usage	gauge	45.200000	{}	2025-09-03 19:46:52.84+00
29bf35d3-e770-4cbe-982b-9a83cccf2586	cpu_usage	gauge	6.000000	{}	2025-09-03 19:47:52.841+00
5b2fa2a3-dda7-4b9c-bb1c-2201ad88a620	uptime	gauge	1028.975739	{}	2025-09-03 19:48:52.841+00
4ff8caa0-0330-4c39-9f97-ca7726a5f572	memory_usage	gauge	68.260000	{}	2025-09-03 19:49:52.842+00
db3a169e-2e55-497c-83db-b65768bf39ee	cpu_usage	gauge	6.000000	{}	2025-09-03 19:50:52.842+00
b09744c9-f438-4cc1-a62e-23f60542540d	uptime	gauge	1208.977123	{}	2025-09-03 19:51:52.842+00
202d8c59-b317-4d26-a9d1-fe508d158507	disk_usage	gauge	45.200000	{}	2025-09-03 19:52:52.842+00
bb3ff4be-2e0c-477e-b08a-06d2eea46755	cpu_usage	gauge	6.000000	{}	2025-09-03 19:53:52.842+00
90a21f87-858b-4ae7-ab82-43f2958ae4e4	memory_usage	gauge	72.030000	{}	2025-09-03 22:10:05.396+00
e6e264c2-7975-4cf4-90bc-91f5c8208aa5	disk_usage	gauge	45.200000	{}	2025-09-03 22:10:05.396+00
eefb33fe-f144-4190-abdb-2cfc4fe21f74	uptime	gauge	129.328964	{}	2025-09-03 22:11:05.397+00
f06d0938-9391-4226-a8fb-7778100f3754	memory_usage	gauge	72.380000	{}	2025-09-03 22:12:05.398+00
ed500ca6-7a39-4dbe-99f7-ba7c979a44e8	memory_usage	gauge	72.420000	{}	2025-09-03 22:13:05.398+00
895c8737-5df7-42a9-9832-934084a689b6	uptime	gauge	309.335464	{}	2025-09-03 22:14:05.403+00
2cbbc202-7c5e-4189-b6c2-3ee29857e1c8	cpu_usage	gauge	6.000000	{}	2025-09-03 22:17:12.169+00
cce72b6c-5504-4d07-934f-b5443919ea18	cpu_usage	gauge	6.000000	{}	2025-09-03 22:18:12.169+00
bf8ee21e-4ff5-4a11-aa54-c922c0f81417	uptime	gauge	249.167799	{}	2025-09-03 22:19:12.171+00
18a4372a-3439-4232-a207-c7f848642277	disk_usage	gauge	45.200000	{}	2025-09-03 22:20:12.176+00
439f3083-b641-4e87-a0a0-b5065f9c5bf2	memory_usage	gauge	77.580000	{}	2025-09-03 16:58:36.218+00
8ecb4883-a8fe-442c-a0d8-b2a07ea834ff	memory_usage	gauge	77.730000	{}	2025-09-03 16:59:36.22+00
a3f17fe1-dbb4-4f13-978d-e4114c3ce481	disk_usage	gauge	45.200000	{}	2025-09-03 17:00:36.219+00
45ac46ad-29be-4c75-8a4d-74ba339b005f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:01:36.219+00
6a1d6916-0bb5-4b07-baac-a599679fb84c	uptime	gauge	1869.466244	{}	2025-09-03 17:02:36.219+00
bbe61130-6afb-47d6-b10e-02c64df7313e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:03:36.22+00
2675a6a9-232b-4c26-81c6-f8361ba6f41c	uptime	gauge	1989.467490	{}	2025-09-03 17:04:36.22+00
cdcbdc96-208c-4ffa-b9ba-80e20085a2c1	disk_usage	gauge	45.200000	{}	2025-09-03 17:05:36.221+00
ac414b67-ed77-4266-9f24-6519e86b7853	disk_usage	gauge	45.200000	{}	2025-09-03 17:06:36.221+00
f3824755-58a4-4161-b6ca-c608acb75275	uptime	gauge	68.007429	{}	2025-09-03 17:49:27.515+00
77d96717-83af-442d-83f2-4b262bb313b0	cpu_usage	gauge	6.000000	{}	2025-09-03 17:50:27.515+00
3ff221c7-8d31-49ea-a606-ab0d242d123d	uptime	gauge	188.008019	{}	2025-09-03 17:51:27.516+00
b7b9d5b5-eff4-4d78-a8b8-cd00f8a9a27e	disk_usage	gauge	45.200000	{}	2025-09-03 17:52:27.517+00
98849cb2-b66b-48c9-9784-e7dad72363af	memory_usage	gauge	75.230000	{}	2025-09-03 17:53:27.524+00
3178b127-82b7-4f67-9cfa-eb679b46680d	memory_usage	gauge	74.920000	{}	2025-09-03 18:26:38.088+00
293ee845-fb5e-48c6-9d32-95609eec0781	disk_usage	gauge	45.200000	{}	2025-09-03 18:27:38.089+00
e448ba2c-4cb2-4003-9d05-a2e34436db10	disk_usage	gauge	45.200000	{}	2025-09-03 18:28:38.091+00
2d74987b-0c33-4720-b19a-269d9678875c	disk_usage	gauge	45.200000	{}	2025-09-03 18:29:38.096+00
61825128-71ad-4e91-912a-3041b3d3de0e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:30:38.096+00
c2af9ddc-3516-49b7-99fe-48c155238e9a	memory_usage	gauge	70.470000	{}	2025-09-03 18:35:38.1+00
63bba86d-6df4-4807-ba75-ed23cd574cab	memory_usage	gauge	64.540000	{}	2025-09-03 18:50:04.666+00
a8f7e67e-5af1-4db8-96b2-e56ff61d49b8	memory_usage	gauge	64.810000	{}	2025-09-03 18:51:04.665+00
49aa1b8a-35c1-4aab-bbb0-caf0de611ada	memory_usage	gauge	65.030000	{}	2025-09-03 18:52:04.667+00
9f41496f-9f98-4cf1-85eb-b92984582bc2	memory_usage	gauge	65.010000	{}	2025-09-03 18:53:04.667+00
48d9391d-1936-42e6-b451-0337c4558df2	cpu_usage	gauge	6.000000	{}	2025-09-03 18:54:04.667+00
bceab078-eeb9-418e-ae26-d94e4072a710	memory_usage	gauge	68.740000	{}	2025-09-03 19:00:30.074+00
97c55e44-7f8c-438c-aedb-d57589e81dfc	memory_usage	gauge	68.690000	{}	2025-09-03 19:01:30.075+00
8a68a564-e1e4-4b65-a679-94580af4e7d7	disk_usage	gauge	45.200000	{}	2025-09-03 19:02:30.076+00
747cc2e6-5449-4835-926a-f0b3a8cb86f7	disk_usage	gauge	45.200000	{}	2025-09-03 19:03:30.076+00
59db97e2-bec7-4ae9-bbf2-fc641dd2cab2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:04:30.075+00
90c109c7-bc7b-44e8-af16-09516d9d88b8	uptime	gauge	429.074738	{}	2025-09-03 19:05:30.076+00
420b4357-ae7c-4532-8467-f6067eabc132	cpu_usage	gauge	6.000000	{}	2025-09-03 19:06:30.076+00
0ddf8d9f-d9e7-4fb9-b3b3-37ac6540ca88	memory_usage	gauge	67.520000	{}	2025-09-03 19:19:37.465+00
149e21d2-da52-4da0-831b-38980ef72d8c	memory_usage	gauge	67.830000	{}	2025-09-03 19:20:37.467+00
122b56b1-d3af-4ffa-acc3-f14bccc9dadd	memory_usage	gauge	67.890000	{}	2025-09-03 19:21:37.468+00
eea2c15d-056b-4e88-8e53-0e9526319fe2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:22:37.473+00
510162e3-10c2-4bcb-8267-6d08a13c3a7c	memory_usage	gauge	67.910000	{}	2025-09-03 19:32:52.834+00
c363b213-b103-4095-bb01-3315944802a5	cpu_usage	gauge	6.000000	{}	2025-09-03 19:33:52.834+00
d6cbd1c8-145f-4557-9914-1d18e2e226ba	uptime	gauge	188.968887	{}	2025-09-03 19:34:52.834+00
3569844f-ab7d-4795-9baa-64b39c16fe1f	memory_usage	gauge	68.350000	{}	2025-09-03 19:35:52.834+00
772aff23-16fd-49f3-9f82-3ae4a8b5665d	disk_usage	gauge	45.200000	{}	2025-09-03 19:36:52.84+00
9bc66451-b6ec-43db-951b-8bc11ba5d211	cpu_usage	gauge	6.000000	{}	2025-09-03 19:37:52.84+00
422673b5-8c14-44e6-b764-76cf6572dbe6	uptime	gauge	428.976146	{}	2025-09-03 19:38:52.841+00
ae953613-6018-41bb-8021-064710a405c7	cpu_usage	gauge	6.000000	{}	2025-09-03 19:39:52.841+00
be02cf81-fef6-4f50-905d-e70b590f6100	uptime	gauge	548.976003	{}	2025-09-03 19:40:52.841+00
1e3760d7-73a5-4514-a3f4-a2c3f77617c4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:41:52.841+00
858e41e2-3dad-4734-be6a-e176bbadf199	cpu_usage	gauge	6.000000	{}	2025-09-03 22:11:05.397+00
2a0eb627-81c2-4da2-b868-180e50a1d144	cpu_usage	gauge	6.000000	{}	2025-09-03 22:12:05.398+00
48df7bf5-fd59-438e-9323-da78cf8327aa	uptime	gauge	249.330092	{}	2025-09-03 22:13:05.398+00
a5093a68-b3cd-4539-bc93-4636d7836173	disk_usage	gauge	45.200000	{}	2025-09-03 22:14:05.403+00
c8c4110d-cb61-40fc-8d8d-0336fd81ac3d	memory_usage	gauge	74.740000	{}	2025-09-03 22:17:12.169+00
21f04e19-bf57-46aa-bb69-5c9de4647676	memory_usage	gauge	74.670000	{}	2025-09-03 22:18:12.169+00
e4e85c3f-8ece-4a46-97fd-bbe949e05a72	cpu_usage	gauge	6.000000	{}	2025-09-03 22:19:12.171+00
9c91b0fd-dcba-46df-8881-3fa421a87274	uptime	gauge	309.172874	{}	2025-09-03 22:20:12.176+00
7b1fbe62-88f2-4d78-842f-0b243c7bdf52	uptime	gauge	1629.465376	{}	2025-09-03 16:58:36.218+00
5bd3af0e-b2d3-435f-844f-65cec0138f70	cpu_usage	gauge	6.000000	{}	2025-09-03 16:59:36.22+00
207ac82f-c59c-479b-ac5d-aa6ae59b5b35	uptime	gauge	1749.466056	{}	2025-09-03 17:00:36.219+00
bc1e715f-20bc-48ce-873b-c9095097b76f	disk_usage	gauge	45.200000	{}	2025-09-03 17:01:36.219+00
fb61be77-8dbd-452c-b9ee-2c782c585fd7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:02:36.219+00
a0f2de85-a417-43d4-84e6-3dfe257fc901	uptime	gauge	1929.466925	{}	2025-09-03 17:03:36.22+00
af67a2cb-e226-4883-a73d-3d11943b839f	disk_usage	gauge	45.200000	{}	2025-09-03 17:04:36.22+00
23a101f4-fe28-4379-b700-4b61acd95d3c	memory_usage	gauge	77.160000	{}	2025-09-03 17:05:36.221+00
15e906d6-275b-4c5b-a3d0-6321e068ded4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:06:36.221+00
b215b67b-3e39-4ccf-826b-04f7fbfafa2c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:50:13.55+00
2536f46a-cc35-484c-aa69-0607fe438371	cpu_usage	gauge	6.000000	{}	2025-09-03 17:51:13.55+00
61f60293-2c24-459d-a1c0-2ca2eb605639	uptime	gauge	249.352346	{}	2025-09-03 17:52:13.55+00
99032f33-6b8a-4516-bb70-b7b71d71c1be	disk_usage	gauge	45.200000	{}	2025-09-03 17:53:13.555+00
bb06498d-accd-4fc4-9276-8e1b39439826	disk_usage	gauge	45.200000	{}	2025-09-03 18:26:38.088+00
22e71650-2fc8-4b76-9457-234d9cd4f89f	memory_usage	gauge	74.930000	{}	2025-09-03 18:27:38.089+00
afcfc18a-bd27-446d-8f95-8844f910180a	memory_usage	gauge	74.870000	{}	2025-09-03 18:28:38.091+00
5e53d09c-1600-4a12-80e2-0bdd8e38d5a1	memory_usage	gauge	74.720000	{}	2025-09-03 18:29:38.096+00
40c224c1-df94-4dd4-adf2-7e452f82f83d	memory_usage	gauge	75.300000	{}	2025-09-03 18:30:38.096+00
84e7722c-e02c-4f35-a91d-8e7dd363c599	disk_usage	gauge	45.200000	{}	2025-09-03 18:35:38.1+00
08f750a2-5b68-4b28-8bca-1d71409b3398	disk_usage	gauge	45.200000	{}	2025-09-03 18:50:04.666+00
096adcb1-a3c5-4786-899a-bdeb9e41af1b	disk_usage	gauge	45.200000	{}	2025-09-03 18:51:04.665+00
05823d57-4cab-41a9-8cc4-fed1921ad000	cpu_usage	gauge	6.000000	{}	2025-09-03 18:52:04.667+00
c95d10f1-9eed-4ae6-9702-d5591b53d012	uptime	gauge	309.197155	{}	2025-09-03 18:53:04.667+00
858bc9b8-725f-46d9-8b64-091c13e11424	disk_usage	gauge	45.200000	{}	2025-09-03 18:54:04.667+00
2c7763da-5bc8-480c-9063-9b8fec7fe6e3	disk_usage	gauge	45.200000	{}	2025-09-03 19:00:30.075+00
f92773be-0881-4300-b37b-2e965b8a5c8d	disk_usage	gauge	45.200000	{}	2025-09-03 19:01:30.075+00
030b2b98-38dc-4289-9bdc-9cde5473b7d1	memory_usage	gauge	68.720000	{}	2025-09-03 19:02:30.076+00
e39ae644-68b7-4805-94f0-f1b124d96ea0	memory_usage	gauge	68.720000	{}	2025-09-03 19:03:30.076+00
3ac9fb19-d4e9-4fa3-9246-1f670745d8ea	memory_usage	gauge	68.460000	{}	2025-09-03 19:04:30.075+00
77e136a7-04ee-42ff-8276-b260b6e76f75	disk_usage	gauge	45.200000	{}	2025-09-03 19:05:30.076+00
c5ac5b53-2775-4e9e-83a8-38012f1ca36b	memory_usage	gauge	68.480000	{}	2025-09-03 19:06:30.076+00
08d6b272-38c4-42a0-8341-1acc3f6259bf	disk_usage	gauge	45.200000	{}	2025-09-03 19:19:37.466+00
ac5bed5c-2f43-4d95-8580-7a1d4483c3cd	cpu_usage	gauge	6.000000	{}	2025-09-03 19:20:37.467+00
f79d526b-8ff2-4102-83dc-7904e004a405	uptime	gauge	249.042096	{}	2025-09-03 19:21:37.468+00
3f38e322-1524-4892-819a-c74c69279cee	memory_usage	gauge	68.150000	{}	2025-09-03 19:22:37.473+00
96510857-6fa0-4c20-a595-9fd14d29c064	cpu_usage	gauge	6.000000	{}	2025-09-03 19:32:52.834+00
db7b975a-f1d3-4da3-9337-266f1b8335f0	memory_usage	gauge	67.890000	{}	2025-09-03 19:33:52.834+00
2827d9da-6a2d-4426-afe6-fd24d9703e7f	disk_usage	gauge	45.200000	{}	2025-09-03 19:34:52.834+00
57655b12-f680-469b-b6ba-b5224a1bcc7e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:35:52.834+00
cf45b048-5cb4-4a42-8b0b-4e6425cf1d56	uptime	gauge	308.974913	{}	2025-09-03 19:36:52.84+00
8bf61177-345d-4c58-9a8b-0963ff03dc8b	disk_usage	gauge	45.200000	{}	2025-09-03 19:37:52.841+00
afefc198-1758-40c4-b31f-de4c9d2da4ef	memory_usage	gauge	68.210000	{}	2025-09-03 19:38:52.841+00
4fa55c3c-5af9-4290-8f12-2812888455f2	memory_usage	gauge	68.130000	{}	2025-09-03 19:39:52.841+00
f0a68461-ae94-4e7f-bf6d-6bce5fb3b379	memory_usage	gauge	68.430000	{}	2025-09-03 19:40:52.841+00
56b14eed-570f-4d99-add7-47bb89482f9f	memory_usage	gauge	68.300000	{}	2025-09-03 19:41:52.841+00
5fbeb48d-d1a7-4cee-81c6-ce12ffbef76d	memory_usage	gauge	72.410000	{}	2025-09-03 22:11:05.397+00
98008b04-3eee-4164-91ab-a287422d91a3	disk_usage	gauge	45.200000	{}	2025-09-03 22:12:05.398+00
48a636d2-7da9-4451-8df3-4729b81f7bb6	cpu_usage	gauge	6.000000	{}	2025-09-03 22:13:05.398+00
d2d3580f-46e5-4d52-937d-e841aeb6a4ac	cpu_usage	gauge	6.000000	{}	2025-09-03 22:14:05.403+00
ed359a43-46db-4b19-a823-e83f4c33c714	disk_usage	gauge	45.200000	{}	2025-09-03 22:17:12.169+00
c361f0bc-2df2-42ab-921c-b34375e0db90	disk_usage	gauge	45.200000	{}	2025-09-03 22:18:12.169+00
2b51235b-463d-48f1-9b35-ed1f490faf3b	memory_usage	gauge	74.760000	{}	2025-09-03 22:19:12.171+00
4a4d54c9-508f-4faa-b2b2-596a6a1fcc56	memory_usage	gauge	73.160000	{}	2025-09-03 22:20:12.176+00
152115f4-80f8-4cd9-911d-375138467e7b	memory_usage	gauge	77.560000	{}	2025-09-03 16:58:58.356+00
a62d7691-d332-49d1-9006-1cc557e11e3b	disk_usage	gauge	45.200000	{}	2025-09-03 16:59:58.358+00
bc2d2e45-7c84-45d2-ac21-7910b2e0d98c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:00:58.359+00
63faf7cb-e4ab-4097-86ef-db8a5f5121f2	uptime	gauge	1748.119501	{}	2025-09-03 17:01:58.36+00
bccec84f-896b-4847-8306-497405880f03	disk_usage	gauge	45.200000	{}	2025-09-03 17:02:58.36+00
47916e18-56d2-40bb-b974-a863b8781cb7	memory_usage	gauge	77.120000	{}	2025-09-03 17:03:58.36+00
895118b3-51c8-4f5b-a81f-ef7c0784c537	uptime	gauge	1928.121136	{}	2025-09-03 17:04:58.361+00
0ec7f319-e0d6-4965-8c9d-7d667df21849	cpu_usage	gauge	6.000000	{}	2025-09-03 17:05:58.362+00
ba20a386-0580-4c97-9186-63aa7ba46e1c	memory_usage	gauge	75.120000	{}	2025-09-03 17:50:13.55+00
addd5a0c-ae31-43bf-8d89-209cf5fbc993	memory_usage	gauge	75.460000	{}	2025-09-03 17:51:13.55+00
d41f882e-3ff4-4b4a-ab61-3b4d92884bf7	memory_usage	gauge	75.400000	{}	2025-09-03 17:52:13.55+00
e160e128-2b2c-4112-9ee1-1c0631734fac	memory_usage	gauge	75.510000	{}	2025-09-03 17:53:13.555+00
dad9eca1-d07f-418b-a60d-c5077b1e2741	cpu_usage	gauge	6.000000	{}	2025-09-03 18:26:50.187+00
efb4d334-1d0b-404d-b478-86a8aa654469	memory_usage	gauge	74.850000	{}	2025-09-03 18:26:50.187+00
45bf2e44-07df-4272-9440-6d8a01e70d04	uptime	gauge	68.198442	{}	2025-09-03 18:26:50.187+00
9399d6b0-e5c0-4c24-b144-75bc1776037d	memory_usage	gauge	74.890000	{}	2025-09-03 18:27:50.188+00
6c0aa62c-4b63-4fa8-9ec3-6be1bdbeb121	memory_usage	gauge	74.840000	{}	2025-09-03 18:28:50.188+00
f3d1c175-c18e-4bea-a9db-b09f1d535cea	memory_usage	gauge	75.120000	{}	2025-09-03 18:29:50.188+00
a724e335-3db6-46ae-aa92-98e1c052b7d6	memory_usage	gauge	75.360000	{}	2025-09-03 18:30:50.195+00
fe7291c8-6e35-470c-ac20-46e7526774e7	cpu_usage	gauge	6.000000	{}	2025-09-03 18:36:05.743+00
9bdfde73-d891-4f5a-9d10-a8fddbcfafe3	memory_usage	gauge	70.100000	{}	2025-09-03 18:36:05.743+00
6c31d348-42b7-47f8-b0dc-72cb1e788ff1	cpu_usage	gauge	6.000000	{}	2025-09-03 18:55:56.048+00
ec1b030f-60db-47ac-bc01-86dee0a36ce6	memory_usage	gauge	64.720000	{}	2025-09-03 18:55:56.048+00
b78f907c-9c5d-45ae-b3af-c7fe79bb1405	disk_usage	gauge	45.200000	{}	2025-09-03 18:55:56.048+00
15f0e0b0-4344-4344-b07d-e515c8ba0787	uptime	gauge	68.980998	{}	2025-09-03 18:55:56.048+00
cd138524-98dc-4a07-aae5-d8b8263ad696	uptime	gauge	128.980816	{}	2025-09-03 18:56:56.048+00
83e5f2b2-052d-4546-bed2-68817ab250c2	uptime	gauge	129.073520	{}	2025-09-03 19:00:30.075+00
f393ab40-cdb8-488b-8ee2-c8bfb1d64b6e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:01:30.075+00
e79aecc5-87b1-4a3c-8a4f-48252f52c6eb	uptime	gauge	249.074701	{}	2025-09-03 19:02:30.076+00
c80b4cc1-4891-40ee-92e0-4caaab321216	cpu_usage	gauge	6.000000	{}	2025-09-03 19:03:30.076+00
65839a63-ed92-478c-b84c-3aad17b7fee9	uptime	gauge	369.074395	{}	2025-09-03 19:04:30.075+00
d2cbf79f-a9da-4874-82ac-d2d814cfebec	memory_usage	gauge	68.670000	{}	2025-09-03 19:05:30.076+00
33ee87f7-0540-4a4b-92a6-1111c1eab5b3	disk_usage	gauge	45.200000	{}	2025-09-03 19:06:30.076+00
6d0405b8-e135-46d4-bdb2-0bdb9a8ab4d4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:23:37.473+00
4f63d864-1d4d-4b41-8145-7a3623949fdc	memory_usage	gauge	68.030000	{}	2025-09-03 19:24:37.474+00
95d13c0b-c337-4780-9730-06f689b14900	memory_usage	gauge	68.260000	{}	2025-09-03 19:25:37.474+00
dbfd2fdd-ca2d-494e-a419-290fee6ae0ec	cpu_usage	gauge	6.000000	{}	2025-09-03 19:26:37.473+00
b9b1a66b-16f3-4c9e-8841-fd957a408739	uptime	gauge	609.049130	{}	2025-09-03 19:27:37.475+00
b7b18886-c0ae-4a2d-ba7e-99c5a0146cb2	cpu_usage	gauge	6.000000	{}	2025-09-03 19:28:37.476+00
fa6d57f9-079c-4696-aed3-c33d45722a48	cpu_usage	gauge	6.000000	{}	2025-09-03 19:42:52.84+00
a3a3eb2a-cfae-418b-82a8-70eb3ed4abd5	memory_usage	gauge	68.380000	{}	2025-09-03 19:43:52.841+00
bde24dce-c7cb-452e-8764-77b112fd0183	disk_usage	gauge	45.200000	{}	2025-09-03 19:44:52.84+00
abdbf64c-c947-4ce0-8eee-907b6ef4eb10	memory_usage	gauge	68.460000	{}	2025-09-03 19:45:52.841+00
0ac815f8-26f8-48c2-8d21-b828f1a221a0	uptime	gauge	908.975090	{}	2025-09-03 19:46:52.84+00
82f71241-63bb-464c-86c0-a0c9e91f3905	disk_usage	gauge	45.200000	{}	2025-09-03 19:47:52.842+00
28b96502-74aa-48d4-89b3-049bf7ea945f	memory_usage	gauge	68.330000	{}	2025-09-03 19:48:52.841+00
6ba3b6d7-021b-4578-8ffc-70fe2ebcecac	uptime	gauge	1088.977238	{}	2025-09-03 19:49:52.842+00
2ecdf4d1-100e-4294-a1ea-51c3e722635a	disk_usage	gauge	45.200000	{}	2025-09-03 19:50:52.842+00
da0260e8-974d-46e0-9e11-a1ba1a27cfce	memory_usage	gauge	68.550000	{}	2025-09-03 19:51:52.842+00
3a53a89c-7757-4d62-b9ed-48eea60ad4f6	cpu_usage	gauge	6.000000	{}	2025-09-03 19:52:52.842+00
f2576999-40fa-4132-82ed-31f5deb15665	uptime	gauge	1328.976807	{}	2025-09-03 19:53:52.842+00
db4a173a-39d2-4948-90ea-ab432aac5792	cpu_usage	gauge	6.000000	{}	2025-09-03 22:20:12.176+00
fe2136f1-3dc4-4220-9b7d-ea04ceeb6380	cpu_usage	gauge	6.000000	{}	2025-09-03 16:58:58.356+00
a67ea2c4-9d46-44e7-bd8f-831a2c5cbebe	uptime	gauge	1628.117564	{}	2025-09-03 16:59:58.358+00
1abc87ba-1ca9-407e-b3dc-6e06782864e8	memory_usage	gauge	77.010000	{}	2025-09-03 17:00:58.359+00
8856a57c-67fa-4394-bc81-827fa8eef3bc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:01:58.36+00
928e94c1-9a63-4a45-8ceb-1fa1a0ba10d8	uptime	gauge	1808.119512	{}	2025-09-03 17:02:58.36+00
d6b864d1-8849-4f3f-b9cd-4776e7e16d4e	disk_usage	gauge	45.200000	{}	2025-09-03 17:03:58.36+00
b6b275f6-e553-468e-9ab1-7c1402d16336	disk_usage	gauge	45.200000	{}	2025-09-03 17:04:58.361+00
e7a09ccb-040f-4381-b746-a6083b62f5fa	disk_usage	gauge	45.200000	{}	2025-09-03 17:05:58.362+00
d39967be-0cf0-4e4d-ac72-e01a0b1cd39d	disk_usage	gauge	45.200000	{}	2025-09-03 17:50:13.55+00
c122c76f-4189-4faf-b315-ea9b4cd11dd5	disk_usage	gauge	45.200000	{}	2025-09-03 17:51:13.55+00
9aab627e-5e90-41a3-aee8-b5a09fbdb8d1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:52:13.55+00
aaeff1ba-7593-4afc-85f8-a9e3459c1392	uptime	gauge	309.357754	{}	2025-09-03 17:53:13.555+00
0fc7ccd5-bcb9-482b-955c-5bc1d14e055d	disk_usage	gauge	45.200000	{}	2025-09-03 18:26:50.187+00
0e6e720b-c06c-4e35-8959-e803f0928b83	cpu_usage	gauge	6.000000	{}	2025-09-03 18:27:50.187+00
cbb8de96-ce5e-4e5f-918e-10bc8e89bdc7	uptime	gauge	188.198657	{}	2025-09-03 18:28:50.188+00
707669dd-4b30-4100-9b8b-a1420c9d8c34	disk_usage	gauge	45.200000	{}	2025-09-03 18:29:50.189+00
82b0aec0-ef2b-40c6-8e64-a1d871afd8d6	disk_usage	gauge	45.200000	{}	2025-09-03 18:30:50.195+00
d7969dff-9d85-4e14-994e-82194ff9d068	disk_usage	gauge	45.200000	{}	2025-09-03 18:36:05.743+00
dcafa2e2-a38f-44a5-82b2-df6944625835	cpu_usage	gauge	6.000000	{}	2025-09-03 18:56:56.048+00
a3a3736e-5194-40ef-9c26-7ec047ff9a39	memory_usage	gauge	68.660000	{}	2025-09-03 19:07:30.076+00
6b23c719-ca08-4f51-b512-7abe3c9cdbe2	disk_usage	gauge	45.200000	{}	2025-09-03 19:23:37.473+00
2552ff3a-eeed-4bf5-9477-a471e8818a85	cpu_usage	gauge	6.000000	{}	2025-09-03 19:24:37.473+00
0a20ac66-13ce-4f0d-a766-dbb64f6cc812	uptime	gauge	489.048141	{}	2025-09-03 19:25:37.474+00
e14067dd-1307-4e68-86f2-a0c4e488dc1c	disk_usage	gauge	45.200000	{}	2025-09-03 19:26:37.474+00
741a4712-2788-46f8-b187-3a1abbaa43b4	cpu_usage	gauge	6.000000	{}	2025-09-03 19:27:37.475+00
c9b207bd-355d-421c-903c-d3b5465386ec	uptime	gauge	669.050150	{}	2025-09-03 19:28:37.476+00
6a83de07-857d-4700-9060-82ff0a2408b8	memory_usage	gauge	68.270000	{}	2025-09-03 19:42:52.84+00
27cb6c4d-cf0d-4606-bced-0b508248e1af	cpu_usage	gauge	6.000000	{}	2025-09-03 19:43:52.841+00
f3f7c20b-754f-46e0-9af3-a44d27356128	uptime	gauge	788.975383	{}	2025-09-03 19:44:52.84+00
af6bf345-11da-4c6d-92ed-588dd7658b0b	cpu_usage	gauge	6.000000	{}	2025-09-03 19:45:52.841+00
7228f2de-f3d0-4e4c-ae4c-8310df6e4274	memory_usage	gauge	68.370000	{}	2025-09-03 19:46:52.84+00
86c8dda5-efd0-437e-84bb-ddff408aeed3	memory_usage	gauge	68.300000	{}	2025-09-03 19:47:52.842+00
4625ee99-2f57-4121-b334-0fd01845ff7b	disk_usage	gauge	45.200000	{}	2025-09-03 19:48:52.841+00
8f3be31b-4701-48c4-905d-5d839443e93e	cpu_usage	gauge	6.000000	{}	2025-09-03 19:49:52.842+00
df75a087-e66d-4e25-92e9-b0a8de9153ba	uptime	gauge	1148.976887	{}	2025-09-03 19:50:52.842+00
cf6bf71e-361c-4152-955f-e48b15d99b89	disk_usage	gauge	45.200000	{}	2025-09-03 19:51:52.842+00
4d43c392-4a73-4c00-a7a2-2dce797f34c1	memory_usage	gauge	68.290000	{}	2025-09-03 19:52:52.842+00
3019ab3c-9306-4f64-8d5c-e98042ebc194	memory_usage	gauge	70.040000	{}	2025-09-03 19:53:52.842+00
31c8575c-c899-4a79-bda2-9f0b7d248227	uptime	gauge	1568.116239	{}	2025-09-03 16:58:58.357+00
90901a37-320a-4a07-8db4-7414275ab946	memory_usage	gauge	77.400000	{}	2025-09-03 16:59:58.358+00
13184740-621d-4183-93b6-07b0c09a6c94	disk_usage	gauge	45.200000	{}	2025-09-03 17:50:27.515+00
b1193f65-cfda-4bfc-a02d-9ad986e4d7c0	disk_usage	gauge	45.200000	{}	2025-09-03 17:51:27.516+00
7aace998-5ccc-4e3d-9acd-8d38649cbaea	cpu_usage	gauge	6.000000	{}	2025-09-03 17:52:27.517+00
8ac794b9-87ed-49e0-aa2d-fb00a272fe49	uptime	gauge	308.016112	{}	2025-09-03 17:53:27.524+00
ecffc8aa-87fa-4b74-88ac-e004d2455ff2	disk_usage	gauge	45.200000	{}	2025-09-03 18:27:50.188+00
3454be98-668b-4652-ad6f-bbc5bd191c33	cpu_usage	gauge	6.000000	{}	2025-09-03 18:28:50.187+00
a291221b-8240-4167-9624-15f4cd1c3eda	uptime	gauge	248.199536	{}	2025-09-03 18:29:50.189+00
37a0572d-8d1f-4e98-bb65-8f3dfeb4ec80	cpu_usage	gauge	6.000000	{}	2025-09-03 18:30:50.195+00
881c31cb-627e-44e5-b35b-8b0d04778335	uptime	gauge	68.374480	{}	2025-09-03 18:36:05.743+00
2969c330-2b71-4984-93a9-a1f676085348	memory_usage	gauge	64.610000	{}	2025-09-03 18:56:56.048+00
1988b199-eeff-437b-bffc-a4d2e8a33708	cpu_usage	gauge	6.000000	{}	2025-09-03 19:07:30.076+00
72a08ea5-cec4-413a-9247-483485d538cf	uptime	gauge	369.047262	{}	2025-09-03 19:23:37.473+00
80592a7d-5eb8-4828-bf56-16a36dc59786	disk_usage	gauge	45.200000	{}	2025-09-03 19:24:37.474+00
6130d85e-17cb-47d5-8a52-9de63a16513d	cpu_usage	gauge	6.000000	{}	2025-09-03 19:25:37.474+00
9fd5a878-6c24-42b7-9220-94aea4283e94	uptime	gauge	549.047955	{}	2025-09-03 19:26:37.474+00
993c4c7e-6151-4b35-8c7d-223820122783	disk_usage	gauge	45.200000	{}	2025-09-03 19:27:37.475+00
9e05312f-c9ef-4ac9-b099-0dbbeb66c47a	disk_usage	gauge	45.200000	{}	2025-09-03 19:28:37.476+00
0a927c09-d4b7-44e1-96b4-eec756a2b63a	cpu_usage	gauge	6.000000	{}	2025-09-03 19:54:52.841+00
62f0431c-9156-458f-9415-45f58be57768	uptime	gauge	1448.977900	{}	2025-09-03 19:55:52.843+00
a143cd70-47fd-4939-801a-192ae0f5fe0c	disk_usage	gauge	45.200000	{}	2025-09-03 19:56:52.843+00
a9f3d2d8-2ad9-4633-a457-987b982cc286	cpu_usage	gauge	6.000000	{}	2025-09-03 19:57:52.844+00
c525e3f7-5b5f-4779-99ba-dea018d86baa	uptime	gauge	1628.979000	{}	2025-09-03 19:58:52.844+00
a9be3d89-4b51-4a4f-a3f9-8851c97d2bd8	memory_usage	gauge	71.440000	{}	2025-09-03 19:59:52.845+00
a1e69dc8-1a85-4974-a18c-c0f4470bec93	cpu_usage	gauge	6.000000	{}	2025-09-03 20:00:52.846+00
6de25d3f-1c75-486c-a134-e772fd628f19	uptime	gauge	1808.982347	{}	2025-09-03 20:01:52.847+00
92c52fca-0dab-42dc-9dac-4bf0619918e7	disk_usage	gauge	45.200000	{}	2025-09-03 20:02:52.847+00
dcb1e9db-059f-48ad-9f20-9a01e7993586	cpu_usage	gauge	6.000000	{}	2025-09-03 20:03:52.849+00
3ce9f76c-3fee-4ad6-96ad-11ee36b8485f	disk_usage	gauge	45.200000	{}	2025-09-03 20:04:52.85+00
30d0f38d-4f29-4361-bdd1-4f052d927d28	disk_usage	gauge	45.200000	{}	2025-09-03 16:58:58.357+00
0f731d25-3b61-4dbc-add0-791689711995	cpu_usage	gauge	6.000000	{}	2025-09-03 16:59:58.358+00
e46a2a11-9276-449b-83b2-57ce3280aa12	uptime	gauge	1688.118572	{}	2025-09-03 17:00:58.359+00
ff5a4ed8-0a45-4452-b3cc-d51dd694a45f	disk_usage	gauge	45.200000	{}	2025-09-03 17:01:58.36+00
3ad5eb8a-7df3-45bb-ad03-279f8c3e5903	cpu_usage	gauge	6.000000	{}	2025-09-03 17:02:58.36+00
97a65b23-1de0-45a5-98ab-b95ccec215f4	uptime	gauge	1868.120054	{}	2025-09-03 17:03:58.36+00
544aa8ff-8fb9-4245-91ac-8d0ab06a91a7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:04:58.361+00
85b74caf-cb01-4e1d-91b8-9e854842db8b	uptime	gauge	1988.121847	{}	2025-09-03 17:05:58.362+00
b59a4e71-9f0e-4e5e-a74e-399751a73add	memory_usage	gauge	80.520000	{}	2025-09-03 17:06:58.363+00
5f08c24c-398e-41b7-9aba-1dddf4d185c4	uptime	gauge	128.006954	{}	2025-09-03 17:50:27.515+00
7207918c-efe0-4404-8ae8-7ad150ac7b5f	memory_usage	gauge	75.390000	{}	2025-09-03 17:51:27.516+00
8c715a76-93bf-4660-9f32-dc1544f495a2	memory_usage	gauge	75.400000	{}	2025-09-03 17:52:27.517+00
9cc1ab8c-fbcd-45f6-a632-361eaca89b83	disk_usage	gauge	45.200000	{}	2025-09-03 17:53:27.524+00
2d0ccc6a-d4dc-4d47-8658-987b9b49686e	uptime	gauge	128.198785	{}	2025-09-03 18:27:50.188+00
f3f36932-75bf-4076-adf7-13ab1895d462	disk_usage	gauge	45.200000	{}	2025-09-03 18:28:50.188+00
9d7c852b-b9ad-488c-9e75-1157f4f8f573	cpu_usage	gauge	6.000000	{}	2025-09-03 18:29:50.188+00
ce2fc85e-2331-4049-a7b1-67cfaa738b70	uptime	gauge	308.206194	{}	2025-09-03 18:30:50.195+00
02cfdbd7-ad8e-4752-8133-ee62d75f09c8	memory_usage	gauge	70.040000	{}	2025-09-03 18:36:38.101+00
483488c5-5132-4634-8a09-9844787f34ec	disk_usage	gauge	45.200000	{}	2025-09-03 18:36:38.101+00
4ad4cf3a-3b58-4512-b027-484bc8d02755	disk_usage	gauge	45.200000	{}	2025-09-03 18:37:38.102+00
4f364891-41e5-4fdb-a1b0-d31548feeda0	uptime	gauge	789.245064	{}	2025-09-03 18:37:38.102+00
da3c0a8d-eeaa-4292-9592-f845dc5673e0	cpu_usage	gauge	6.000000	{}	2025-09-03 18:38:38.102+00
18a80aaa-30cf-498d-a85e-6e82b0f6032e	memory_usage	gauge	70.050000	{}	2025-09-03 18:38:38.102+00
f9b6aad6-2583-4e60-992c-f8fb2f505c6d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:39:38.102+00
58c5a80b-3762-4104-9d77-dbeef12cd12b	uptime	gauge	909.245526	{}	2025-09-03 18:39:38.102+00
9427ba04-02cf-48e1-bff2-507294eaa325	cpu_usage	gauge	6.000000	{}	2025-09-03 18:40:38.102+00
a93ffe8e-e198-4e92-b0a6-bd0c58545021	uptime	gauge	969.245579	{}	2025-09-03 18:40:38.102+00
9398429d-b675-42c9-88a9-d58657b82f30	disk_usage	gauge	45.200000	{}	2025-09-03 18:41:38.103+00
17b2d0d4-9549-4fc7-9ca1-7808e4bb23d7	uptime	gauge	1029.246470	{}	2025-09-03 18:41:38.103+00
9f5225dd-9348-4df0-bab6-9da067c8090a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:42:38.104+00
bc88fca3-1511-4a01-8721-d7c30f405aa6	memory_usage	gauge	65.450000	{}	2025-09-03 18:42:38.104+00
dd91f8ce-a967-49b3-804f-22e02e17726c	disk_usage	gauge	45.200000	{}	2025-09-03 18:43:38.105+00
0ef23ac7-40a2-4232-852b-f44bcf4f2dcb	uptime	gauge	1149.248413	{}	2025-09-03 18:43:38.105+00
900acc49-254b-468a-83b8-fcd20c259607	cpu_usage	gauge	6.000000	{}	2025-09-03 18:44:38.105+00
a2d3f4af-8838-44b5-8a1d-a647c200a32e	disk_usage	gauge	45.200000	{}	2025-09-03 18:44:38.105+00
8658eba8-0b1d-4614-8176-eb469d8fa6c7	disk_usage	gauge	45.200000	{}	2025-09-03 18:56:56.048+00
02ab761d-8ac5-4f2b-bf81-aa3416c23764	uptime	gauge	549.075517	{}	2025-09-03 19:07:30.077+00
b904ae5a-c0f2-438d-9191-357631b88e07	disk_usage	gauge	45.200000	{}	2025-09-03 19:54:52.842+00
fe2a8c48-c94b-4e01-83f9-3ec300126544	memory_usage	gauge	72.790000	{}	2025-09-03 19:55:52.843+00
0b88b93e-1a06-491f-90eb-e09947433410	memory_usage	gauge	71.550000	{}	2025-09-03 19:56:52.843+00
d5003013-2ade-4d0a-9e90-b8fe500ca3e3	memory_usage	gauge	71.400000	{}	2025-09-03 19:57:52.844+00
ddcac467-bb65-4d22-8d3a-53ca65d53ab6	disk_usage	gauge	45.200000	{}	2025-09-03 19:58:52.844+00
218c16b3-6820-44f4-954f-44a194de46b3	cpu_usage	gauge	6.000000	{}	2025-09-03 19:59:52.845+00
9d09da62-ff36-407d-a5f8-ecb5c106c4b7	uptime	gauge	1748.981099	{}	2025-09-03 20:00:52.846+00
822b89ea-6a98-449f-9c79-6f3b10d06020	memory_usage	gauge	74.130000	{}	2025-09-03 20:01:52.847+00
659b6cb3-164c-4418-9f22-c4cba7808300	uptime	gauge	1868.982393	{}	2025-09-03 20:02:52.847+00
517dc441-a8a1-4a3f-a4eb-d949cbc790d3	memory_usage	gauge	73.410000	{}	2025-09-03 20:03:52.849+00
04d0f347-4dcf-45f2-ae75-6c65d491da62	uptime	gauge	1988.985174	{}	2025-09-03 20:04:52.85+00
52a782fd-2941-4082-b835-60e282fd0e3c	memory_usage	gauge	76.800000	{}	2025-09-03 17:00:36.219+00
178ea446-acec-4fc8-a9a2-9140478c700e	memory_usage	gauge	77.040000	{}	2025-09-03 17:01:36.219+00
df99fccb-5466-4c2d-ab78-16ccbc7398fa	memory_usage	gauge	77.140000	{}	2025-09-03 17:02:36.219+00
5d667bb4-bc58-4bea-bacf-81f6ba1cd584	disk_usage	gauge	45.200000	{}	2025-09-03 17:03:36.22+00
7b45de76-7205-471a-95d9-a10cb12fe6d8	cpu_usage	gauge	6.000000	{}	2025-09-03 17:04:36.22+00
8c684642-e481-451a-9eeb-4c7053104c0e	uptime	gauge	2049.468047	{}	2025-09-03 17:05:36.221+00
2bcb2492-124e-46e4-b30c-e36cea4a9f62	memory_usage	gauge	77.130000	{}	2025-09-03 17:06:36.221+00
b0831fff-964b-4493-b564-4e29fd384219	memory_usage	gauge	75.280000	{}	2025-09-03 17:54:13.555+00
950b8b99-bd74-4930-9943-6a88b54090e8	uptime	gauge	429.358211	{}	2025-09-03 17:55:13.556+00
1b2b0779-5c17-4929-bc5b-3608908b8581	disk_usage	gauge	45.200000	{}	2025-09-03 17:56:13.556+00
9c6b56cf-595d-431f-bc5b-a5b180607d60	cpu_usage	gauge	6.000000	{}	2025-09-03 17:57:13.556+00
ef6cc8f9-0a8c-4686-9f78-3760e6e2c0ef	uptime	gauge	609.358561	{}	2025-09-03 17:58:13.556+00
ccc98f65-da37-49c7-9775-8aa62fa85d41	memory_usage	gauge	75.100000	{}	2025-09-03 17:59:13.556+00
c413f8ba-450c-420a-8830-37980b92ab14	cpu_usage	gauge	6.000000	{}	2025-09-03 18:00:13.557+00
b6546104-ac49-4c0b-a3a6-2633af0d30d3	uptime	gauge	789.359829	{}	2025-09-03 18:01:13.557+00
75f78142-de3b-4a3e-8177-1b2d4d91ff31	disk_usage	gauge	45.200000	{}	2025-09-03 18:02:13.557+00
76796ee3-8964-45b4-9fa3-3c894edfe888	memory_usage	gauge	74.790000	{}	2025-09-03 18:03:13.558+00
fd1959c8-5f5b-4125-a379-3e84dee6f978	cpu_usage	gauge	6.000000	{}	2025-09-03 18:04:13.558+00
5818e9b5-8620-4e7b-8d64-08bcea6c70b5	uptime	gauge	1029.360547	{}	2025-09-03 18:05:13.558+00
cf9834d3-c878-44c6-b93e-664a67fd0872	memory_usage	gauge	75.260000	{}	2025-09-03 18:06:13.559+00
8a12a203-1630-48cb-8950-c68b128643eb	cpu_usage	gauge	6.000000	{}	2025-09-03 18:36:38.101+00
3c548717-767e-4b83-83ef-a5d8e044b65c	cpu_usage	gauge	6.000000	{}	2025-09-03 18:37:38.101+00
7513f06c-d0a5-4817-98f4-bf76361b2d03	uptime	gauge	849.245132	{}	2025-09-03 18:38:38.102+00
1330e200-eac0-45ed-aede-9a44e6e5a8d6	disk_usage	gauge	45.200000	{}	2025-09-03 18:39:38.102+00
7059cc98-190c-49d7-80e3-d4c5e332338a	disk_usage	gauge	45.200000	{}	2025-09-03 18:40:38.102+00
e89da9cb-55e5-4f10-a18b-27b2fed42740	cpu_usage	gauge	6.000000	{}	2025-09-03 18:41:38.103+00
89f0b838-43e0-46be-a9bc-c1527845501d	uptime	gauge	1089.247237	{}	2025-09-03 18:42:38.104+00
228da3d5-0ce2-4d79-8cdf-37cb12cb2646	memory_usage	gauge	65.350000	{}	2025-09-03 18:43:38.105+00
b06c0f85-8534-402a-84e0-3a20e0bcae1f	memory_usage	gauge	65.270000	{}	2025-09-03 18:44:38.105+00
4999bb45-6f9f-429d-9705-2bf7fc6a064a	disk_usage	gauge	45.200000	{}	2025-09-03 19:07:30.077+00
e047d578-0f77-474c-ae9c-b6946c4c1b48	memory_usage	gauge	69.880000	{}	2025-09-03 19:54:52.841+00
eeb2353c-c833-469b-a53a-c3cc0f629b43	cpu_usage	gauge	6.000000	{}	2025-09-03 19:55:52.843+00
aacc6db8-c9f5-460d-adf5-934a477bc203	uptime	gauge	1508.977564	{}	2025-09-03 19:56:52.843+00
ae69ebb4-5f96-49d7-8301-714623441fe6	disk_usage	gauge	45.200000	{}	2025-09-03 19:57:52.844+00
79c54ed3-87e3-4b1b-a59b-cbff3a514678	memory_usage	gauge	71.400000	{}	2025-09-03 19:58:52.844+00
c4e18e72-bd04-4cd5-96ae-f6148085683d	disk_usage	gauge	45.200000	{}	2025-09-03 19:59:52.845+00
06e9bca4-edf1-410f-9199-30e57e30a590	disk_usage	gauge	45.200000	{}	2025-09-03 17:00:58.359+00
db39f074-72a3-48bb-b91e-640b1551e416	memory_usage	gauge	77.150000	{}	2025-09-03 17:01:58.36+00
7bbd9e4c-3bb4-439b-b3da-265143332c72	memory_usage	gauge	76.840000	{}	2025-09-03 17:02:58.36+00
93a8abbf-b19b-4d1c-8a09-fb7213b2b751	cpu_usage	gauge	6.000000	{}	2025-09-03 17:03:58.36+00
7a561ff9-8447-41bb-b4c7-3b3b38c9b745	memory_usage	gauge	76.740000	{}	2025-09-03 17:04:58.361+00
c3dfecc4-92a5-4e0d-80e7-4b55241547b0	memory_usage	gauge	77.790000	{}	2025-09-03 17:05:58.362+00
a968738e-0c3a-4927-815e-df16aa4e8564	cpu_usage	gauge	6.000000	{}	2025-09-03 17:54:13.555+00
32ff6cf6-65ed-41fc-a8cb-2a19eeec6e15	cpu_usage	gauge	6.000000	{}	2025-09-03 17:55:13.555+00
f8b746f0-d5d9-4bec-ac97-419e7691b316	uptime	gauge	489.358895	{}	2025-09-03 17:56:13.556+00
d4146555-29b5-4848-90fe-7daa8eba3280	disk_usage	gauge	45.200000	{}	2025-09-03 17:57:13.557+00
b0dbefb4-3655-4ca4-9167-7e79de54780e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:58:13.556+00
04e2f48e-4f63-40e9-88d7-305d073752fb	uptime	gauge	669.359033	{}	2025-09-03 17:59:13.556+00
4da21533-d76d-4fae-a4fa-a338905f60da	disk_usage	gauge	45.200000	{}	2025-09-03 18:00:13.557+00
25043142-358b-4fd7-9d87-a3ae94ed9ed6	memory_usage	gauge	74.820000	{}	2025-09-03 18:01:13.557+00
ae8dd4ca-282c-439b-9aa5-c0e6d3b531de	cpu_usage	gauge	6.000000	{}	2025-09-03 18:02:13.557+00
29b963ea-78f1-460d-a990-0cd9875897a9	uptime	gauge	909.360392	{}	2025-09-03 18:03:13.558+00
d1310a79-8e02-43a3-a67c-f088e951feed	memory_usage	gauge	74.810000	{}	2025-09-03 18:04:13.558+00
958a6791-2c96-45bc-819d-a601067a9368	memory_usage	gauge	75.710000	{}	2025-09-03 18:05:13.558+00
8df9e310-d96c-4a2a-af34-8186ee5951d5	disk_usage	gauge	45.200000	{}	2025-09-03 18:06:13.559+00
8678cb01-ddd8-4f11-b7ae-e3924a8f0345	uptime	gauge	729.244554	{}	2025-09-03 18:36:38.101+00
d73306ea-b709-42f4-94a1-29457d4b5818	memory_usage	gauge	70.120000	{}	2025-09-03 18:37:38.102+00
bf388ede-bfe2-451a-ab1d-d85058f0f26c	disk_usage	gauge	45.200000	{}	2025-09-03 18:38:38.102+00
da6c7dee-62f6-41d7-8860-8ac77b916cb6	memory_usage	gauge	69.960000	{}	2025-09-03 18:39:38.102+00
39e4a285-63f7-498e-b2a7-175395c03648	memory_usage	gauge	70.420000	{}	2025-09-03 18:40:38.102+00
d521346a-0d45-4554-8d65-28e4e59aeba4	memory_usage	gauge	65.510000	{}	2025-09-03 18:41:38.103+00
e0f56d77-322b-4e74-9332-4fc116ebb431	disk_usage	gauge	45.200000	{}	2025-09-03 18:42:38.104+00
573c1167-864a-4f8f-bd09-aea905a8145d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:43:38.105+00
295d6581-bbea-47aa-9fca-5cc4474cd589	uptime	gauge	1209.248664	{}	2025-09-03 18:44:38.105+00
2ca86fc9-d181-4a2b-9c2e-0f1961fcea3a	uptime	gauge	1388.976426	{}	2025-09-03 19:54:52.842+00
3aa10f6b-f34b-4393-a92d-6adbaf62a341	disk_usage	gauge	45.200000	{}	2025-09-03 19:55:52.843+00
48f82743-0b05-442c-ab5e-a60a3431735c	cpu_usage	gauge	6.000000	{}	2025-09-03 19:56:52.843+00
cc930b05-9fb9-4d10-9506-cc91cc1ce5bc	uptime	gauge	1568.978934	{}	2025-09-03 19:57:52.844+00
385fb79a-bd55-4d30-b96a-8fc3e0de2e98	cpu_usage	gauge	6.000000	{}	2025-09-03 19:58:52.844+00
5c3514cd-8af4-4fd2-a486-6b98e99f0c25	uptime	gauge	1688.979852	{}	2025-09-03 19:59:52.845+00
5e717742-4951-430b-9a53-aeecde1ca642	disk_usage	gauge	45.200000	{}	2025-09-03 20:00:52.846+00
f1b54236-975d-4deb-9eec-e20f51177742	disk_usage	gauge	45.200000	{}	2025-09-03 20:01:52.847+00
eab6c182-0af4-42e1-86e8-cb67965b6ac0	memory_usage	gauge	71.520000	{}	2025-09-03 20:02:52.847+00
916fd47a-1073-4a0a-963e-5c92904b6e03	uptime	gauge	1928.983856	{}	2025-09-03 20:03:52.849+00
dd4cabe9-f214-4323-ab0d-72de0b2a8c81	memory_usage	gauge	73.470000	{}	2025-09-03 20:04:52.85+00
593d72dd-c3c3-4bcf-8c96-7b0aedac84cd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:06:58.363+00
0893102a-0363-4391-a7d1-34eeb64d6325	disk_usage	gauge	45.200000	{}	2025-09-03 17:54:13.555+00
fa43c723-4aba-42f7-a486-8b4bfd41d3fa	disk_usage	gauge	45.200000	{}	2025-09-03 17:55:13.556+00
50e1b3c4-a8ad-41b8-8955-2fdad02d73c6	memory_usage	gauge	75.230000	{}	2025-09-03 17:56:13.556+00
a55d2163-2da1-4907-b52a-dea522662699	memory_usage	gauge	75.210000	{}	2025-09-03 17:57:13.556+00
38fd8e2b-5a24-43c7-b847-4859659c685f	memory_usage	gauge	75.190000	{}	2025-09-03 17:58:13.556+00
115af0da-7dc1-4667-9ba8-aa8a54e7fc42	cpu_usage	gauge	6.000000	{}	2025-09-03 17:59:13.556+00
13a45bac-62d8-4fca-9c90-56718fc2c79a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:37:05.744+00
0677e501-c2f6-4b2d-9db9-2b1352f1b645	uptime	gauge	188.376412	{}	2025-09-03 18:38:05.745+00
6abfbccb-b0cf-4405-90e9-68d7e469bc11	cpu_usage	gauge	6.000000	{}	2025-09-03 18:39:05.746+00
dbc428a1-b101-4682-9624-a28c53baafc5	memory_usage	gauge	70.700000	{}	2025-09-03 18:40:05.751+00
a81177eb-85db-48f5-a78d-4e2623142d18	memory_usage	gauge	71.970000	{}	2025-09-03 20:00:52.846+00
43c08327-4da4-44f9-8f1e-003743e15c7d	cpu_usage	gauge	6.000000	{}	2025-09-03 20:01:52.847+00
2e51a069-5c28-4f80-b2ef-0ef03e4a25c6	cpu_usage	gauge	6.000000	{}	2025-09-03 20:02:52.847+00
37ef5706-fe19-4551-bd92-16a5fea57364	disk_usage	gauge	45.200000	{}	2025-09-03 20:03:52.849+00
d907a157-a14a-4f6a-aa5d-fd0551530dea	cpu_usage	gauge	6.000000	{}	2025-09-03 20:04:52.85+00
7a416cc0-395a-42e0-bbdd-a160b7fff21a	disk_usage	gauge	45.200000	{}	2025-09-03 17:06:58.363+00
a6ec7fef-6afe-452c-b9ea-f37824eadda1	uptime	gauge	369.357701	{}	2025-09-03 17:54:13.555+00
a3a83037-b16d-4c7e-80dc-6922a2c2b917	memory_usage	gauge	75.740000	{}	2025-09-03 17:55:13.555+00
33626b8c-4a44-435a-a570-ce9c80bbd2d9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:56:13.556+00
bdc3104b-55c6-4c75-9106-67250c87f3ba	uptime	gauge	549.359220	{}	2025-09-03 17:57:13.557+00
3eed3566-5372-4b88-9ab1-39d83a411812	disk_usage	gauge	45.200000	{}	2025-09-03 17:58:13.556+00
96a50edf-4a1d-469b-aec7-25cdfd261f7b	disk_usage	gauge	45.200000	{}	2025-09-03 17:59:13.556+00
125b0a8a-f8d0-41c7-a25c-908c6f4b61f2	memory_usage	gauge	70.110000	{}	2025-09-03 18:37:05.744+00
398c8e92-55ff-4546-85eb-1b7f57084993	disk_usage	gauge	45.200000	{}	2025-09-03 18:38:05.745+00
e85d4367-266e-4d27-8688-14cb3831e21a	disk_usage	gauge	45.200000	{}	2025-09-03 18:39:05.746+00
57d02880-7bfc-4b0c-9aa3-253fd06b9ba4	disk_usage	gauge	45.200000	{}	2025-09-03 18:40:05.751+00
d3999f84-bc63-4d6a-becd-106f2b9d3eb0	uptime	gauge	2048.122778	{}	2025-09-03 17:06:58.363+00
4896ae26-f6ff-4088-9c84-cddda7ec4eaa	cpu_usage	gauge	6.000000	{}	2025-09-03 17:54:27.524+00
ac87095f-210a-428d-bac4-16ace962d72b	disk_usage	gauge	45.200000	{}	2025-09-03 17:55:27.525+00
85019642-0b78-4a91-a122-8b80b1d7261d	memory_usage	gauge	75.210000	{}	2025-09-03 17:56:27.526+00
e2e46ab7-d5b6-4e8e-b8ad-def8d83b8914	uptime	gauge	548.019306	{}	2025-09-03 17:57:27.527+00
8576239a-8cfc-490f-b0b6-455df384d31b	disk_usage	gauge	45.200000	{}	2025-09-03 17:58:27.529+00
885d2ac0-b8f3-4ad5-899f-3aff2a091a81	memory_usage	gauge	75.050000	{}	2025-09-03 17:59:27.53+00
abd0bc4c-9dc6-470f-8bf6-1ea7d9af2ad0	uptime	gauge	128.375530	{}	2025-09-03 18:37:05.744+00
c2e27a77-cfcd-43c2-9095-1614ed4f6eb2	cpu_usage	gauge	6.000000	{}	2025-09-03 18:38:05.745+00
1397ff4a-987d-4f15-95b1-5a8819cf5feb	uptime	gauge	248.377534	{}	2025-09-03 18:39:05.746+00
701cbdd9-7c31-42d7-918b-77139c98ab18	cpu_usage	gauge	6.000000	{}	2025-09-03 18:40:05.751+00
74fef9b4-1be9-4e69-a355-b76fdfeb4bb3	memory_usage	gauge	80.120000	{}	2025-09-03 17:07:36.221+00
8be7605b-b5c1-4198-a78c-5f058ea11eae	uptime	gauge	2229.467882	{}	2025-09-03 17:08:36.221+00
bdd8e51d-eae5-4007-8db1-09774b775f44	cpu_usage	gauge	6.000000	{}	2025-09-03 17:09:36.221+00
ead6c676-13b4-47fa-b818-1e3256c7cf4b	uptime	gauge	2349.468163	{}	2025-09-03 17:10:36.221+00
36297ecd-83c5-466c-b470-db98989be65d	disk_usage	gauge	45.200000	{}	2025-09-03 17:11:36.221+00
8ea22fe9-785c-44a5-b04a-4a6ae7c0003f	memory_usage	gauge	73.530000	{}	2025-09-03 17:12:36.22+00
e740de99-d085-4022-9a0c-cc0bbcdbed85	cpu_usage	gauge	6.000000	{}	2025-09-03 17:13:36.221+00
0a31e880-087e-4274-9cca-d3c360c26d59	uptime	gauge	2589.468058	{}	2025-09-03 17:14:36.221+00
86ff9aeb-b5d1-4b0b-b805-847567172cf2	memory_usage	gauge	75.220000	{}	2025-09-03 17:54:27.524+00
6a17db26-03fa-4475-9c54-a80ad217e97a	uptime	gauge	428.016571	{}	2025-09-03 17:55:27.525+00
7e65e53f-f303-4c72-a1b2-254f62df01fc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:56:27.526+00
60f1de7c-bac0-4478-bd0e-328448e4958b	disk_usage	gauge	45.200000	{}	2025-09-03 17:57:27.527+00
54635bcd-af81-42fd-bb1c-3bfda26eca10	memory_usage	gauge	75.050000	{}	2025-09-03 17:58:27.529+00
6f8a6cd2-445d-49ea-85c1-85ec63e9bdf0	uptime	gauge	668.021710	{}	2025-09-03 17:59:27.53+00
169970be-9766-41a7-8bc7-62811826f851	cpu_usage	gauge	6.000000	{}	2025-09-03 18:00:27.53+00
3ad2eeb5-4454-497a-860b-935a1452b03b	disk_usage	gauge	45.200000	{}	2025-09-03 18:01:27.53+00
2ece1b96-db65-40c6-81cb-3fc62b8e9b94	cpu_usage	gauge	6.000000	{}	2025-09-03 18:02:27.531+00
212618b7-d799-42fe-b841-2af6f0f66282	cpu_usage	gauge	6.000000	{}	2025-09-03 18:03:27.532+00
f1dbb1de-ada8-49f6-bdf6-ebeb520bce7f	uptime	gauge	968.023437	{}	2025-09-03 18:04:27.531+00
8c86c25d-b27f-48cd-9282-074de256f897	disk_usage	gauge	45.200000	{}	2025-09-03 18:05:27.532+00
81c16fd1-0399-41db-9d83-aaef8118b9dd	cpu_usage	gauge	6.000000	{}	2025-09-03 18:06:27.532+00
9fd4feb2-a7dc-4a58-b653-aa569c80dca2	disk_usage	gauge	45.200000	{}	2025-09-03 18:37:05.744+00
ef331e35-59ab-4a4d-9623-d7e5974f82ba	memory_usage	gauge	70.110000	{}	2025-09-03 18:38:05.745+00
20395fed-ee74-478d-95ee-36930dcacc80	memory_usage	gauge	70.040000	{}	2025-09-03 18:39:05.746+00
25f47245-208e-460b-818d-08ce3fe9b30c	uptime	gauge	308.382555	{}	2025-09-03 18:40:05.751+00
236d6964-7a71-41df-84f4-04d97e2d7ec1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:07:36.221+00
d114cdd1-0aeb-4d4a-8dfe-f99df59c2820	disk_usage	gauge	45.200000	{}	2025-09-03 17:08:36.221+00
292611b6-3a52-41f3-93e5-ae4a8545ef9a	memory_usage	gauge	79.950000	{}	2025-09-03 17:09:36.221+00
813b7d5c-fc08-49bd-890b-9343774339a6	disk_usage	gauge	45.200000	{}	2025-09-03 17:10:36.221+00
3d97f592-5fe2-4964-9aea-0f79f71f4b2d	memory_usage	gauge	73.880000	{}	2025-09-03 17:11:36.22+00
69497139-d446-4fd7-aeab-af3ff8afcf78	disk_usage	gauge	45.200000	{}	2025-09-03 17:12:36.22+00
98e35d0f-ac4d-40b7-abc2-e32e7efaed0d	memory_usage	gauge	73.490000	{}	2025-09-03 17:13:36.221+00
e6d3ccf4-3408-4e3c-853a-330d6c8ea879	memory_usage	gauge	73.510000	{}	2025-09-03 17:14:36.221+00
0d8f4e92-c80e-459a-a4d1-b86de4072424	disk_usage	gauge	45.200000	{}	2025-09-03 17:54:27.524+00
6ce9b273-3a82-4d04-87dc-c327a69b28b1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:55:27.525+00
526b7d07-448a-4336-84d2-c79b15a5e949	disk_usage	gauge	45.200000	{}	2025-09-03 17:56:27.526+00
851ce068-7cf3-423a-9d41-2e5146c489e0	memory_usage	gauge	75.230000	{}	2025-09-03 17:57:27.527+00
b8d910d9-671c-4b10-bd92-9853637e37f1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:58:27.529+00
b08304d6-07f6-4a6f-9ac1-03c39742dcde	cpu_usage	gauge	6.000000	{}	2025-09-03 17:59:27.53+00
5a198919-d6fb-47e4-9706-66f6780519c7	disk_usage	gauge	45.200000	{}	2025-09-03 18:00:27.53+00
d2cb15c8-30f8-4667-bf9d-d1b3edf9bea6	cpu_usage	gauge	6.000000	{}	2025-09-03 18:01:27.53+00
f13bcd40-4af8-482f-a5df-33b7165630f3	uptime	gauge	848.022909	{}	2025-09-03 18:02:27.531+00
1529c2ee-1f90-42d0-b515-a9cf056960fb	memory_usage	gauge	74.840000	{}	2025-09-03 18:03:27.532+00
edb9b1b8-0673-4b62-b85c-779b362f3235	memory_usage	gauge	74.800000	{}	2025-09-03 18:04:27.531+00
60c19e2b-1dca-45d2-9894-322ee288abf6	memory_usage	gauge	75.230000	{}	2025-09-03 18:05:27.532+00
9c220060-78ad-42cc-a9d6-f97c03b9de6e	uptime	gauge	1088.024047	{}	2025-09-03 18:06:27.532+00
0572fab4-6e27-4e80-bf20-c22f0c62f588	uptime	gauge	2169.468543	{}	2025-09-03 17:07:36.221+00
892718eb-007f-467b-88c5-84694281ccfc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:08:36.221+00
5ae5424b-e5d1-4772-b993-350f5474d5e7	uptime	gauge	2289.467913	{}	2025-09-03 17:09:36.221+00
e3bc98e5-7418-45d1-af6b-75134fe34cd7	memory_usage	gauge	73.680000	{}	2025-09-03 17:10:36.221+00
4b74e76b-ff21-4f16-aea2-4170c19cd4e2	cpu_usage	gauge	6.000000	{}	2025-09-03 17:11:36.22+00
2f4ca8af-026f-46cb-9a33-276c2f3af12a	uptime	gauge	2469.467082	{}	2025-09-03 17:12:36.22+00
3cfcabcd-fb43-45b9-932c-d4c18a25b750	disk_usage	gauge	45.200000	{}	2025-09-03 17:13:36.221+00
1db7fbcb-7b7d-4949-bfb9-231314cac727	cpu_usage	gauge	6.000000	{}	2025-09-03 17:14:36.221+00
d0b96b46-fcfa-49ab-8a87-063861a82ce8	uptime	gauge	368.016447	{}	2025-09-03 17:54:27.525+00
68359b1d-23a6-4341-b633-c4de9f4186e6	memory_usage	gauge	75.670000	{}	2025-09-03 17:55:27.525+00
50ec496b-9d12-4292-ab2f-c23a392181d5	uptime	gauge	488.018111	{}	2025-09-03 17:56:27.526+00
c14682bb-fed2-4419-a995-71d87faa0766	cpu_usage	gauge	6.000000	{}	2025-09-03 17:57:27.527+00
2c82278f-526f-40d8-858e-70db204dc8c2	uptime	gauge	608.020676	{}	2025-09-03 17:58:27.529+00
70133665-f38a-4c47-a9b3-80910be059e3	disk_usage	gauge	45.200000	{}	2025-09-03 17:59:27.53+00
e9ef07f0-d62b-4c28-97e0-cddb07d4ba2d	memory_usage	gauge	75.200000	{}	2025-09-03 18:00:27.53+00
62ec8bff-59f3-40fe-b06d-5d5485cbc3d7	uptime	gauge	788.022343	{}	2025-09-03 18:01:27.53+00
3d73aba9-d330-4482-aa57-a6e97a80ed52	disk_usage	gauge	45.200000	{}	2025-09-03 18:02:27.531+00
cb7012f1-0c7b-47c0-aaf2-1c7ebd5cc162	disk_usage	gauge	45.200000	{}	2025-09-03 18:03:27.532+00
3a2d122d-8f25-4bf5-b2dd-31098714b5ae	cpu_usage	gauge	6.000000	{}	2025-09-03 18:04:27.531+00
71dbc44c-ed20-46ca-8a74-8813dceea871	uptime	gauge	1028.023922	{}	2025-09-03 18:05:27.532+00
8ce09bc1-7386-41cc-97f3-bf0a8c7140bc	disk_usage	gauge	45.200000	{}	2025-09-03 18:06:27.532+00
a353fc5e-ad96-4f7a-b9e0-7930d387ab31	disk_usage	gauge	45.200000	{}	2025-09-03 17:07:36.221+00
20878942-e971-4f6a-9e0c-25bfc121064c	memory_usage	gauge	79.960000	{}	2025-09-03 17:08:36.221+00
9fb905e0-2c97-4a3d-9835-ec786020e6a4	disk_usage	gauge	45.200000	{}	2025-09-03 17:09:36.221+00
8068179f-2ea6-4804-a6f1-72a128807ecd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:10:36.221+00
ad4e9379-1e1f-458e-b32d-e0124a2af3c3	uptime	gauge	2409.467594	{}	2025-09-03 17:11:36.221+00
ce1347b7-0c85-45fc-9bb5-f9c6c02ac00c	cpu_usage	gauge	6.000000	{}	2025-09-03 17:12:36.22+00
dd1ad1c9-89e4-4b81-823c-71a4f2f54920	uptime	gauge	2529.467712	{}	2025-09-03 17:13:36.221+00
d9a22324-15f5-4c71-bfeb-3aad0adae1d8	disk_usage	gauge	45.200000	{}	2025-09-03 17:14:36.221+00
fc93079c-382a-4c59-9f72-64bbe08ca364	memory_usage	gauge	76.080000	{}	2025-09-03 18:00:13.557+00
e3596281-30f4-4886-af1a-1760834382ed	cpu_usage	gauge	6.000000	{}	2025-09-03 18:01:13.557+00
f202489c-42df-4761-8eaa-2f4634322372	uptime	gauge	849.360087	{}	2025-09-03 18:02:13.557+00
42aed1aa-d076-4d8d-8d15-218d67339e2a	disk_usage	gauge	45.200000	{}	2025-09-03 18:03:13.558+00
e7a6074a-9845-4bad-8e32-fe4f2404d45b	disk_usage	gauge	45.200000	{}	2025-09-03 18:04:13.558+00
3b90f3b6-37a2-4edf-b275-d0120b877000	cpu_usage	gauge	6.000000	{}	2025-09-03 18:05:13.558+00
23ee16e0-ffbe-4b5f-abaf-2cdaf43a4379	uptime	gauge	1089.361612	{}	2025-09-03 18:06:13.559+00
faabcc97-3093-44fd-a9f0-551bc9db0faa	memory_usage	gauge	79.840000	{}	2025-09-03 17:07:58.362+00
100b15e2-7979-48ab-a55c-6d834cad30e0	uptime	gauge	2168.122447	{}	2025-09-03 17:08:58.363+00
06645b6d-55c6-4c45-a13f-8fa524da5cb5	disk_usage	gauge	45.200000	{}	2025-09-03 17:09:58.363+00
8953881f-413d-427e-a474-6dc9e4c9bf4b	uptime	gauge	729.359537	{}	2025-09-03 18:00:13.557+00
01aa07e1-c2db-484a-8fde-e31ca4469ac5	disk_usage	gauge	45.200000	{}	2025-09-03 18:01:13.557+00
93063b9f-8e4a-4acb-bbea-8928c2805bd1	memory_usage	gauge	74.820000	{}	2025-09-03 18:02:13.557+00
42c7211c-4aeb-4ec4-90a0-f0f01e983c39	cpu_usage	gauge	6.000000	{}	2025-09-03 18:03:13.558+00
1125b234-e8b1-421e-bbb6-925d306a4214	uptime	gauge	969.360463	{}	2025-09-03 18:04:13.558+00
09ac95d2-d741-4412-bdbc-97820384c5b1	disk_usage	gauge	45.200000	{}	2025-09-03 18:05:13.558+00
627bcda1-0afa-4d8a-8fc5-512ba932cec5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:06:13.559+00
c32b9313-5f40-408f-a9f9-6117feb5096b	uptime	gauge	2108.121918	{}	2025-09-03 17:07:58.362+00
eb8f84c0-d3c2-4764-ad09-80c3d2cc2025	cpu_usage	gauge	6.000000	{}	2025-09-03 17:08:58.363+00
2f6d05e1-a0e0-4eee-90d8-7567dcff1880	memory_usage	gauge	79.980000	{}	2025-09-03 17:09:58.363+00
ee012111-4d0b-4ecc-b476-6c1e0f403da8	uptime	gauge	728.021665	{}	2025-09-03 18:00:27.53+00
44084259-0841-40bf-b10f-04defe4ab2c8	memory_usage	gauge	74.890000	{}	2025-09-03 18:01:27.53+00
989b8f45-487c-4818-a82e-a3e9d4ac5b66	memory_usage	gauge	74.780000	{}	2025-09-03 18:02:27.531+00
1fb291ec-32ad-4415-8c86-832adf081570	uptime	gauge	908.023937	{}	2025-09-03 18:03:27.532+00
6d497e94-d0ff-4592-b1a7-06407e2a9fea	disk_usage	gauge	45.200000	{}	2025-09-03 18:04:27.531+00
6e211289-0593-4e6b-b9b6-6428d8869743	cpu_usage	gauge	6.000000	{}	2025-09-03 18:05:27.532+00
0d660b70-dd23-4bcb-8d08-d721ae844da3	memory_usage	gauge	75.290000	{}	2025-09-03 18:06:27.532+00
e796b422-8602-40d3-8994-98cfadf97156	disk_usage	gauge	45.200000	{}	2025-09-03 17:07:58.362+00
221edaa3-1fab-483c-a59b-6715a102f5bf	memory_usage	gauge	79.950000	{}	2025-09-03 17:08:58.363+00
4aa10899-41f9-428f-aed8-e1c4d22776d9	uptime	gauge	2228.122903	{}	2025-09-03 17:09:58.363+00
b579e2ce-342a-44f1-afce-1358d1e93d05	cpu_usage	gauge	6.000000	{}	2025-09-03 18:07:13.56+00
9069e2f9-8ce7-4e5e-89ba-bea4eda65476	uptime	gauge	1209.363598	{}	2025-09-03 18:08:13.561+00
dbeed448-46a0-445f-aca7-e0895608e47b	disk_usage	gauge	45.200000	{}	2025-09-03 18:09:13.562+00
e0f5f6eb-c30a-41c0-9cab-2962221d2275	memory_usage	gauge	69.650000	{}	2025-09-03 18:10:13.563+00
1db6f0b9-3c25-4474-b222-8fc3f225ded5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:11:13.564+00
25bbf5d2-1419-4996-9d20-74254d9f4a3c	uptime	gauge	1449.368303	{}	2025-09-03 18:12:13.566+00
7a1df8c0-e8c2-4fa4-bbb5-b9cf2b3be5ee	memory_usage	gauge	69.540000	{}	2025-09-03 18:13:13.567+00
86fd848e-0449-4f71-9650-73937cd831f5	cpu_usage	gauge	6.000000	{}	2025-09-03 18:14:13.568+00
925d0922-01cb-4816-96b2-1cd1f87aaaf2	uptime	gauge	1629.371522	{}	2025-09-03 18:15:13.569+00
f610c3b6-2594-492a-9c8f-c5e95243d658	memory_usage	gauge	69.550000	{}	2025-09-03 18:16:13.57+00
a8746a0c-84f5-4799-8f06-2481f5f3f327	memory_usage	gauge	69.460000	{}	2025-09-03 18:17:13.571+00
c3966036-c66d-411e-afbc-6a66ea0acc63	cpu_usage	gauge	6.000000	{}	2025-09-03 18:18:13.571+00
fbe849bb-c3cb-40d1-af5c-0daaca723782	cpu_usage	gauge	6.000000	{}	2025-09-03 17:07:58.362+00
5746d62b-e513-42c6-9d2e-8f99393d5a0d	disk_usage	gauge	45.200000	{}	2025-09-03 17:08:58.363+00
2a5edd04-1659-4a0e-a511-f444de268fd5	cpu_usage	gauge	6.000000	{}	2025-09-03 17:09:58.363+00
5cc6504b-3c58-4df5-b176-456986305ea0	memory_usage	gauge	75.270000	{}	2025-09-03 18:07:13.56+00
57d7667b-7ae3-4be9-8c1f-8541e2db0897	memory_usage	gauge	69.430000	{}	2025-09-03 18:08:13.561+00
b3ac7986-6a5d-4a9a-9978-a2892580c9f6	memory_usage	gauge	69.380000	{}	2025-09-03 18:09:13.562+00
aeae42ec-000e-46d5-9cc5-8ca7617c465f	uptime	gauge	1329.365581	{}	2025-09-03 18:10:13.563+00
979dd128-6120-4e7e-818e-7ac7e0203241	disk_usage	gauge	45.200000	{}	2025-09-03 18:11:13.564+00
a7d68c6d-943a-4c3f-9f02-6a0105a5ae24	memory_usage	gauge	69.710000	{}	2025-09-03 18:12:13.566+00
3d7912a7-7d36-4657-b01c-7a31d83b8236	uptime	gauge	1509.369883	{}	2025-09-03 18:13:13.567+00
4ab32e1d-537a-40e8-a4f8-d58c05457756	disk_usage	gauge	45.200000	{}	2025-09-03 18:14:13.568+00
0c9dc365-8d0a-4f73-8665-4e68ce7dad80	memory_usage	gauge	69.690000	{}	2025-09-03 18:15:13.569+00
ab1aa279-b17a-43af-af7e-48ac6febcabb	cpu_usage	gauge	6.000000	{}	2025-09-03 18:16:13.57+00
96774761-f531-41b7-ac8c-bc652b25b637	uptime	gauge	1749.373588	{}	2025-09-03 18:17:13.571+00
b9980662-4a56-4205-b318-b241da9fbf07	disk_usage	gauge	45.200000	{}	2025-09-03 18:18:13.571+00
cc6d240b-a188-4589-b90a-3012f781eeae	cpu_usage	gauge	6.000000	{}	2025-09-03 17:15:57.652+00
eb3a530a-1d2b-415f-89c2-c61d666102df	memory_usage	gauge	73.550000	{}	2025-09-03 17:15:57.652+00
aaa1b317-20a7-42c6-9ef5-3af8e4cb4c37	disk_usage	gauge	45.200000	{}	2025-09-03 17:15:57.652+00
2c048d53-fac5-4e5e-9906-0901f44557fb	uptime	gauge	69.177471	{}	2025-09-03 17:15:57.652+00
d567945e-f155-485f-8811-f2ef3dcb49e6	uptime	gauge	129.178474	{}	2025-09-03 17:16:57.653+00
abbb9092-bf91-43dc-8dc3-a77db7b1fd1c	memory_usage	gauge	73.390000	{}	2025-09-03 17:17:57.654+00
4f0f973c-2f4b-4eff-a256-8ad0b0589b89	memory_usage	gauge	73.430000	{}	2025-09-03 17:18:57.655+00
60177094-40fa-4e45-8b4c-3a4ab972d8bb	disk_usage	gauge	45.200000	{}	2025-09-03 17:19:57.659+00
ef850883-0710-4e8b-92e2-be42553211f7	cpu_usage	gauge	6.000000	{}	2025-09-03 17:20:57.659+00
2373de2e-cdc7-42c5-bd67-6e68a244d78b	uptime	gauge	429.185337	{}	2025-09-03 17:21:57.66+00
bcbc7b93-e38c-43fc-8e06-535c3c30ccd0	disk_usage	gauge	45.200000	{}	2025-09-03 17:22:57.661+00
6510877d-0324-4ef4-b84f-0677456b9a63	disk_usage	gauge	45.200000	{}	2025-09-03 18:07:13.56+00
b833150c-09db-4e3e-8e57-6aad22b67afe	cpu_usage	gauge	6.000000	{}	2025-09-03 18:08:13.561+00
38b3192c-e1aa-40af-ae75-fa98af0c3483	uptime	gauge	1269.365035	{}	2025-09-03 18:09:13.562+00
53c7cfb3-ffe7-4dec-b2dd-e2e0824007ee	disk_usage	gauge	45.200000	{}	2025-09-03 18:10:13.563+00
a93b57ef-8071-4359-9490-3deab54afd05	memory_usage	gauge	69.730000	{}	2025-09-03 18:11:13.564+00
334bdbf0-98f3-4535-b662-b591e06ac283	cpu_usage	gauge	6.000000	{}	2025-09-03 18:12:13.566+00
4e1d3d51-f6b5-4697-be2e-b013e68a879e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:13:13.567+00
6a0c80b0-3831-48ad-9d75-0412ab2f673c	uptime	gauge	1569.371083	{}	2025-09-03 18:14:13.568+00
56c887b1-84ef-4044-bf8f-c50301dd974e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:15:13.569+00
63fd6f7e-e80d-4ca3-b5e8-aca5e2fc1a69	uptime	gauge	1689.373051	{}	2025-09-03 18:16:13.57+00
e872e324-4cff-48b9-9a38-b684a5b0572a	cpu_usage	gauge	6.000000	{}	2025-09-03 18:17:13.571+00
a0f562ca-5450-4962-b777-654721a53be2	uptime	gauge	1809.373791	{}	2025-09-03 18:18:13.571+00
be334deb-a194-4e03-ab51-ba8398200c94	cpu_usage	gauge	6.000000	{}	2025-09-03 17:16:57.653+00
8d7cfbec-fdd6-4b08-8dea-965d13cdbfb8	uptime	gauge	189.179006	{}	2025-09-03 17:17:57.654+00
f00f1e09-74ff-4b06-8797-59b66346324f	disk_usage	gauge	45.200000	{}	2025-09-03 17:18:57.655+00
6d36a95e-93e2-4ac5-99df-6a603ab2f11d	memory_usage	gauge	73.340000	{}	2025-09-03 17:19:57.659+00
96c5dfd1-f696-4a8c-86e2-7ee3c465599e	memory_usage	gauge	73.480000	{}	2025-09-03 17:20:57.66+00
080b7989-3817-4ba6-86f3-c035eb6feaf5	memory_usage	gauge	73.480000	{}	2025-09-03 17:21:57.66+00
07e93c27-27ea-43de-9db8-60ca815dd2f4	uptime	gauge	489.186048	{}	2025-09-03 17:22:57.661+00
dfa54aeb-b5e8-4204-92c1-332c8444374b	uptime	gauge	1149.362512	{}	2025-09-03 18:07:13.56+00
4ecdbff2-dc03-4ecb-a7c8-9b632f86c73f	disk_usage	gauge	45.200000	{}	2025-09-03 18:08:13.561+00
972d3d3a-b6e9-4f98-9672-6e42f49597c7	cpu_usage	gauge	6.000000	{}	2025-09-03 18:09:13.562+00
b3c16b68-f711-45b5-a94b-f5ab82285848	cpu_usage	gauge	6.000000	{}	2025-09-03 18:10:13.563+00
ac1cf103-1f0a-4558-873e-44622d7375a3	uptime	gauge	1389.366537	{}	2025-09-03 18:11:13.564+00
8a0d0905-ec9d-4538-b555-01bad9bb7ed8	disk_usage	gauge	45.200000	{}	2025-09-03 18:12:13.566+00
4ff1200d-6ce5-4f0c-9d34-eab3c972f03c	disk_usage	gauge	45.200000	{}	2025-09-03 18:13:13.567+00
9539ea33-6d2a-455a-b582-8b988b1589d7	memory_usage	gauge	69.450000	{}	2025-09-03 18:14:13.568+00
910ba5f6-b593-451a-9d23-f5750e45b5f0	disk_usage	gauge	45.200000	{}	2025-09-03 18:15:13.569+00
ea393711-2455-4652-bfb0-f67e1825b695	disk_usage	gauge	45.200000	{}	2025-09-03 18:16:13.57+00
9a5413e9-af5d-44e5-964c-0786a1a8c451	disk_usage	gauge	45.200000	{}	2025-09-03 18:17:13.571+00
288c21bc-bb4d-4fdb-ba19-c07dba87e187	memory_usage	gauge	69.450000	{}	2025-09-03 18:18:13.571+00
eabdfb0a-1b4e-4568-ba12-e881a470cf38	memory_usage	gauge	73.550000	{}	2025-09-03 17:16:57.653+00
5ace40fe-84c6-42ae-86e5-39df46b4d595	cpu_usage	gauge	6.000000	{}	2025-09-03 17:17:57.654+00
81e133a1-7a1a-40c7-80f9-a728802a4afa	uptime	gauge	249.180038	{}	2025-09-03 17:18:57.655+00
eb687907-f990-4a2b-904b-10e92a4a58c4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:19:57.659+00
2a385943-0f33-4274-8c36-d0228dcc15c0	uptime	gauge	369.184574	{}	2025-09-03 17:20:57.66+00
a8dbddb4-a7f4-4e77-9cac-ae7f50953432	disk_usage	gauge	45.200000	{}	2025-09-03 17:21:57.66+00
25997b9d-8821-406b-b9cb-ab82f45997a1	memory_usage	gauge	73.510000	{}	2025-09-03 17:22:57.661+00
85cb48eb-bf53-41df-a5f2-cd2d67b808a0	cpu_usage	gauge	6.000000	{}	2025-09-03 18:19:55.008+00
2cf6d1c1-13c7-4e31-87e0-2fc6198a0a78	memory_usage	gauge	70.240000	{}	2025-09-03 18:19:55.008+00
27d15cea-8017-43ce-ae19-2bddf3353f48	uptime	gauge	67.944511	{}	2025-09-03 18:19:55.009+00
5001f8ec-c1bb-4c03-ad7f-e240fb893a8d	disk_usage	gauge	45.200000	{}	2025-09-03 17:16:57.653+00
2471561c-cbe9-474e-9646-4acf1ff126df	disk_usage	gauge	45.200000	{}	2025-09-03 17:17:57.654+00
ba021b83-7ab8-4d02-833f-2fb82658f2ee	cpu_usage	gauge	6.000000	{}	2025-09-03 17:18:57.655+00
10c265b0-4c9d-41d2-bed2-fbd69b8b0881	uptime	gauge	309.184296	{}	2025-09-03 17:19:57.659+00
8e84707d-e378-41d5-b39a-406acea47f78	disk_usage	gauge	45.200000	{}	2025-09-03 17:20:57.66+00
a20131f7-4c47-44ba-be21-d448dc9aff0f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:21:57.66+00
5851af99-3611-4bf5-a7a8-456c0dfc3c39	cpu_usage	gauge	6.000000	{}	2025-09-03 17:22:57.661+00
c994aac7-3388-4bb6-8ab7-2f5a42bd0c9d	disk_usage	gauge	45.200000	{}	2025-09-03 18:19:55.009+00
1bbf7112-8d46-48d7-8236-e8008ce89630	memory_usage	gauge	73.510000	{}	2025-09-03 17:23:57.661+00
2f6a5f2c-3b75-4bbd-88b0-66d1ed2c5e30	uptime	gauge	609.186876	{}	2025-09-03 17:24:57.662+00
2cd23b75-439d-474c-a15f-ea6988075648	disk_usage	gauge	45.200000	{}	2025-09-03 17:25:57.663+00
44e3c031-099d-491e-98ac-ae4f49d9cfe0	disk_usage	gauge	45.200000	{}	2025-09-03 17:26:57.663+00
fcbe8b10-4ad9-40d2-8d3e-db032ddefee9	disk_usage	gauge	45.200000	{}	2025-09-03 17:27:57.665+00
062a51cf-cd46-4c29-9bdf-9f3c9f015428	cpu_usage	gauge	6.000000	{}	2025-09-03 17:28:57.666+00
fcf14e4f-cd2a-494e-96ba-ae778bd37e55	uptime	gauge	909.190355	{}	2025-09-03 17:29:57.665+00
daa2ca23-89d4-4685-8344-833313fd17fd	disk_usage	gauge	45.200000	{}	2025-09-03 17:30:57.666+00
1744df53-1cd0-4a74-a459-f5a91dc99b8b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:31:57.667+00
24cd93d5-9348-4f8f-8f60-d80f8dce486c	uptime	gauge	1089.192565	{}	2025-09-03 17:32:57.668+00
72e0fd3f-aa1b-4762-98fb-b53086f40f7c	memory_usage	gauge	79.000000	{}	2025-09-03 17:33:57.668+00
3b9ec0a2-c04d-4b91-a3c3-73b1ff6e6a48	cpu_usage	gauge	6.000000	{}	2025-09-03 17:34:57.669+00
def2efb6-fb4a-456e-b82e-0040be90cb58	uptime	gauge	1269.194585	{}	2025-09-03 17:35:57.67+00
889c4765-2c3f-4a0d-adfa-56f789e8e0eb	memory_usage	gauge	79.230000	{}	2025-09-03 17:36:57.67+00
58f22014-c053-4966-939f-07b511774886	cpu_usage	gauge	6.000000	{}	2025-09-03 17:37:57.671+00
c91735ee-6ba6-48bb-9c46-3cf1b9512c7e	cpu_usage	gauge	6.000000	{}	2025-09-03 18:21:49.691+00
483cbeed-1dd7-4d34-bf18-c44dd8d66553	memory_usage	gauge	70.280000	{}	2025-09-03 18:21:49.691+00
88af6154-594c-4d2f-a827-b2933fe388dc	uptime	gauge	68.127091	{}	2025-09-03 18:21:49.691+00
f4d96af7-641a-49fb-ac5f-541c27d3f709	cpu_usage	gauge	6.000000	{}	2025-09-03 17:23:57.661+00
f68bf990-baf5-4780-8e28-fd818489f36d	disk_usage	gauge	45.200000	{}	2025-09-03 17:24:57.662+00
88cd1712-20cb-4f58-80ba-4936c6d5ec63	cpu_usage	gauge	6.000000	{}	2025-09-03 17:25:57.663+00
e4819dce-e111-4483-ae3f-db3008fa2239	cpu_usage	gauge	6.000000	{}	2025-09-03 17:26:57.663+00
03399bde-61ab-4162-8872-61e261812f8d	uptime	gauge	789.189898	{}	2025-09-03 17:27:57.665+00
31fbd92e-a5bc-4d7a-b616-c01dc82be3dc	disk_usage	gauge	45.200000	{}	2025-09-03 17:28:57.666+00
9e314934-1998-4ef9-b02e-2182b7da2b46	memory_usage	gauge	73.270000	{}	2025-09-03 17:29:57.665+00
1714a085-a281-46e8-98ea-007a39126866	memory_usage	gauge	79.090000	{}	2025-09-03 17:30:57.666+00
9b6165b7-9f79-4a2a-9581-1079720bbe05	disk_usage	gauge	45.200000	{}	2025-09-03 17:31:57.667+00
1b5c0aa3-8d80-4e2b-9ca1-d3fdde8ebb74	cpu_usage	gauge	6.000000	{}	2025-09-03 17:32:57.667+00
ba9a3291-6ed6-4d83-9200-b8a9f415370c	uptime	gauge	1149.193574	{}	2025-09-03 17:33:57.669+00
ff8a9ce7-11ed-4d6a-b745-0a9bc6d1c205	disk_usage	gauge	45.200000	{}	2025-09-03 17:34:57.669+00
795decb9-2601-4ea4-8832-969100ce836f	cpu_usage	gauge	6.000000	{}	2025-09-03 17:35:57.669+00
26d986f9-1670-4c1f-9a42-10ff45b8b568	uptime	gauge	1329.195144	{}	2025-09-03 17:36:57.67+00
b6a526bb-f30b-4f2f-ad9c-89139af15e67	memory_usage	gauge	70.630000	{}	2025-09-03 17:37:57.671+00
ee709e3e-7593-460a-802b-deb833e35d09	disk_usage	gauge	45.200000	{}	2025-09-03 18:21:49.691+00
0a15b3b4-f379-46ce-8af9-d168c44aeab2	uptime	gauge	549.186378	{}	2025-09-03 17:23:57.661+00
6ad01ea6-a1b0-4861-ac7a-cf5b268b0d41	memory_usage	gauge	73.440000	{}	2025-09-03 17:24:57.662+00
080ba86e-9f31-4204-b38c-e90c8b2a77d9	memory_usage	gauge	73.290000	{}	2025-09-03 17:25:57.663+00
3ff50c4b-05fd-45a2-9ce4-5f812d801dcc	uptime	gauge	729.188507	{}	2025-09-03 17:26:57.664+00
17b57c47-d80e-499e-910c-9ad81f551601	cpu_usage	gauge	6.000000	{}	2025-09-03 17:27:57.665+00
d30d63f4-b05a-42ca-8251-dd0974c9f211	uptime	gauge	849.190754	{}	2025-09-03 17:28:57.666+00
0354ef2e-c075-4603-81ad-1041c473b55a	disk_usage	gauge	45.200000	{}	2025-09-03 17:29:57.665+00
d3cac468-ee13-4041-acec-b41034829f5b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:30:57.666+00
801992ad-7028-4db7-b364-0e35e490e596	uptime	gauge	1029.191988	{}	2025-09-03 17:31:57.667+00
59646754-93a8-412e-bc0f-e7784855684f	disk_usage	gauge	45.200000	{}	2025-09-03 17:32:57.668+00
6b064bf2-3dc2-44b4-a9be-0bbed2ab5179	cpu_usage	gauge	6.000000	{}	2025-09-03 17:33:57.668+00
708e52d0-2c6a-4fb5-b20b-c4cb82132c22	uptime	gauge	1209.193943	{}	2025-09-03 17:34:57.669+00
e074298f-ffd9-4507-8fec-a87be44ed43c	memory_usage	gauge	79.260000	{}	2025-09-03 17:35:57.669+00
c6706d36-d4b3-494b-ab8c-89a1f5734be5	disk_usage	gauge	45.200000	{}	2025-09-03 17:36:57.67+00
d8b3eabb-e71e-4ae2-837f-b7346af424f0	disk_usage	gauge	45.200000	{}	2025-09-03 17:37:57.671+00
d0532994-ee21-4ceb-8950-934296b1019d	cpu_usage	gauge	6.000000	{}	2025-09-03 18:22:49.692+00
13937912-20b8-4113-be57-e493a12cecca	disk_usage	gauge	45.200000	{}	2025-09-03 17:23:57.661+00
c3d1bd23-f8fe-4eae-916f-1f934f4b8cb4	cpu_usage	gauge	6.000000	{}	2025-09-03 17:24:57.662+00
629a556a-601b-4458-9128-4e2dc1dc36a1	uptime	gauge	669.187821	{}	2025-09-03 17:25:57.663+00
fe1a93fc-9c50-4b43-95fc-0dfa6faa1c84	memory_usage	gauge	73.500000	{}	2025-09-03 17:26:57.663+00
9044d786-8e5b-434c-91bb-6da09a6e63c7	memory_usage	gauge	73.470000	{}	2025-09-03 17:27:57.665+00
bc2c7d0c-d302-4a4a-b821-e05a2137bab3	memory_usage	gauge	73.500000	{}	2025-09-03 17:28:57.666+00
59064047-9b82-45b7-b979-3bb383932649	cpu_usage	gauge	6.000000	{}	2025-09-03 17:29:57.665+00
f09aa6f5-024f-407e-b134-c91a1ed0d58a	uptime	gauge	969.191058	{}	2025-09-03 17:30:57.666+00
0066939d-34fc-406b-b5d3-b45f58a5d07a	memory_usage	gauge	79.090000	{}	2025-09-03 17:31:57.667+00
91090694-2e39-426f-92c3-2fda79d9f25e	memory_usage	gauge	79.030000	{}	2025-09-03 17:32:57.667+00
4b196780-ab90-448c-aa9a-0a19e2c8b3dc	disk_usage	gauge	45.200000	{}	2025-09-03 17:33:57.669+00
541b6742-58d4-48d8-a3d6-066aadbc1ea8	memory_usage	gauge	79.030000	{}	2025-09-03 17:34:57.669+00
88d3ce6e-0da9-4fbc-92f8-ba3c8fe03f9e	disk_usage	gauge	45.200000	{}	2025-09-03 17:35:57.67+00
c755aada-643f-44d8-bb4e-33d75d883543	cpu_usage	gauge	6.000000	{}	2025-09-03 17:36:57.67+00
a9020538-270b-4b5c-b26e-56433f08e4a9	uptime	gauge	1389.195707	{}	2025-09-03 17:37:57.671+00
1f36ad7d-9d78-4452-9f77-147951a9eecf	disk_usage	gauge	45.200000	{}	2025-09-03 18:22:49.692+00
36417aae-1a99-480f-9ad7-2ecbc8002489	memory_usage	gauge	79.130000	{}	2025-09-03 17:31:21.877+00
de4a318e-3ef9-498c-ae48-7c86aa7e4296	uptime	gauge	128.129944	{}	2025-09-03 17:32:21.878+00
ffb275b7-ba7c-4899-9d95-dbc249ceb8bc	cpu_usage	gauge	6.000000	{}	2025-09-03 17:33:21.878+00
8987639c-9835-4f5a-af94-6e2d769983d3	uptime	gauge	248.130245	{}	2025-09-03 17:34:21.878+00
7e2b28cc-99bb-4acc-ba99-3434033aeb84	disk_usage	gauge	45.200000	{}	2025-09-03 17:35:21.896+00
b13f1be4-e9a2-41f2-b116-949c06980a9a	cpu_usage	gauge	6.000000	{}	2025-09-03 17:36:21.896+00
046fa173-5f02-4249-86d5-02970d53c8e2	memory_usage	gauge	70.760000	{}	2025-09-03 18:22:49.692+00
c0251be2-bbab-4abd-b534-d5369a7d0b29	cpu_usage	gauge	6.000000	{}	2025-09-03 17:31:21.877+00
f2666d49-e82b-49e6-8c8d-47c09ec09a14	memory_usage	gauge	79.130000	{}	2025-09-03 17:32:21.877+00
24264319-6b2a-46ad-98e1-5f8dcacdfca1	memory_usage	gauge	79.070000	{}	2025-09-03 17:33:21.878+00
bdcd56fe-a253-419e-a565-66221eb165be	cpu_usage	gauge	6.000000	{}	2025-09-03 17:34:21.878+00
58393ffe-d320-499f-8196-172d873b3909	uptime	gauge	308.148617	{}	2025-09-03 17:35:21.896+00
0b573faf-d572-4189-98ba-cb936d961496	disk_usage	gauge	45.200000	{}	2025-09-03 17:36:21.896+00
cd20be01-35ba-4a49-a75b-85520bfe00c0	uptime	gauge	128.127564	{}	2025-09-03 18:22:49.692+00
2c70287d-e94d-4e8a-a96a-1f120bbb3263	disk_usage	gauge	45.200000	{}	2025-09-03 17:31:21.878+00
99dd1e0f-2d4e-4529-b4ff-5dc4e93ad707	disk_usage	gauge	45.200000	{}	2025-09-03 17:32:21.878+00
ff4ced47-4133-48ff-8330-f96c1be6111d	disk_usage	gauge	45.200000	{}	2025-09-03 17:33:21.878+00
e0e0d6a7-cca0-4945-9de2-ea45236f3dd1	memory_usage	gauge	79.030000	{}	2025-09-03 17:34:21.878+00
bd01913d-aaf5-44d5-82aa-2fbffee5df55	memory_usage	gauge	79.140000	{}	2025-09-03 17:35:21.896+00
f8d33af6-0a7b-4eb3-8f97-512c5bf73e1e	memory_usage	gauge	79.490000	{}	2025-09-03 17:36:21.896+00
710e6b75-94bb-4953-b7c7-00455cb4c0af	uptime	gauge	68.129961	{}	2025-09-03 17:31:21.878+00
40817c41-def0-4764-a6df-d13c621c14a2	cpu_usage	gauge	6.000000	{}	2025-09-03 17:32:21.877+00
ea506bb9-da97-4a5b-916b-1bcad3c27027	uptime	gauge	188.130180	{}	2025-09-03 17:33:21.878+00
e677f4da-30aa-40a6-b74c-a2312f080ad7	disk_usage	gauge	45.200000	{}	2025-09-03 17:34:21.878+00
2f14a29f-be35-4d30-8ddf-e0381db7fb32	cpu_usage	gauge	6.000000	{}	2025-09-03 17:35:21.896+00
4b7c0c27-f188-4d11-93a9-4d6a3593f90e	uptime	gauge	368.148572	{}	2025-09-03 17:36:21.896+00
fe3d5110-4db6-4c81-b071-c2571f6cebd9	cpu_usage	gauge	6.000000	{}	2025-09-03 17:38:57.671+00
5eaad519-da9e-44d2-8192-deba09e229f3	uptime	gauge	1509.197459	{}	2025-09-03 17:39:57.672+00
fcb9a5f2-f066-4423-a53e-863eab8edb15	disk_usage	gauge	45.200000	{}	2025-09-03 17:40:57.673+00
3e02f088-eb78-4e90-a71f-d53a1297fc24	memory_usage	gauge	75.520000	{}	2025-09-03 17:41:57.674+00
b9117f03-7c70-45a7-b915-54e761298d47	cpu_usage	gauge	6.000000	{}	2025-09-03 17:42:57.674+00
4c38d4c7-bae2-4e2e-8329-3439df3f7988	uptime	gauge	1749.198903	{}	2025-09-03 17:43:57.674+00
fee599d4-2852-4f9b-90a6-d4f8ad2829b6	disk_usage	gauge	45.200000	{}	2025-09-03 17:44:57.674+00
221199d9-7df6-47f8-909c-4905df8a7914	cpu_usage	gauge	6.000000	{}	2025-09-03 17:45:57.674+00
fffac2b1-4091-46fe-8578-36f72f214141	uptime	gauge	1929.199173	{}	2025-09-03 17:46:57.674+00
8af9f7d5-29f5-4f7b-8455-a5eb1be777be	memory_usage	gauge	76.370000	{}	2025-09-03 17:38:57.671+00
799c340e-1060-4683-8785-9d6151806de5	memory_usage	gauge	74.950000	{}	2025-09-03 17:39:57.672+00
fae9ae07-0f51-4954-b795-53a814086352	memory_usage	gauge	75.310000	{}	2025-09-03 17:40:57.673+00
3008853d-9ee1-48c7-9cb5-787bfae91675	disk_usage	gauge	45.200000	{}	2025-09-03 17:41:57.674+00
7c3c6e9e-4aee-445d-b08e-46bef6f7a304	disk_usage	gauge	45.200000	{}	2025-09-03 17:42:57.674+00
6b9127fa-a1fa-4524-80c7-594a09557db2	memory_usage	gauge	75.780000	{}	2025-09-03 17:43:57.674+00
c4aff36a-f867-47bc-add7-146701fe3d8e	memory_usage	gauge	74.730000	{}	2025-09-03 17:44:57.674+00
a9dc8fa0-25ad-486a-bad1-679643469a8b	memory_usage	gauge	69.380000	{}	2025-09-03 17:45:57.674+00
29e8a401-008b-4d39-903d-98eb2ffcb34b	disk_usage	gauge	45.200000	{}	2025-09-03 17:46:57.674+00
9bca934f-8695-46a4-8408-d4793599582e	uptime	gauge	1449.196557	{}	2025-09-03 17:38:57.672+00
89a5b4e0-6121-460c-a598-15876b8e40a0	disk_usage	gauge	45.200000	{}	2025-09-03 17:39:57.672+00
fce4ae47-dc85-4c73-8c4a-b8cdda4dae3e	cpu_usage	gauge	6.000000	{}	2025-09-03 17:40:57.673+00
85dffb14-f790-47bd-a911-1e540456baab	uptime	gauge	1629.198934	{}	2025-09-03 17:41:57.674+00
c4ab9ca6-d1c0-40ad-9e34-d0adb0a1f722	memory_usage	gauge	69.660000	{}	2025-09-03 17:42:57.674+00
7d91ed18-0fa6-4112-b19f-25b6c8f5a509	cpu_usage	gauge	6.000000	{}	2025-09-03 17:43:57.674+00
d3abe193-3a28-4271-83e4-3465be6d48e8	uptime	gauge	1809.198974	{}	2025-09-03 17:44:57.674+00
ddc29f95-ebfe-4d68-972a-b473f5ee3697	disk_usage	gauge	45.200000	{}	2025-09-03 17:45:57.674+00
97271414-8b80-401d-9a9c-092086162181	cpu_usage	gauge	6.000000	{}	2025-09-03 17:46:57.674+00
b0ec73ec-05a4-41ce-a948-c185826dbd54	disk_usage	gauge	45.200000	{}	2025-09-03 17:38:57.672+00
ac9c68e5-d876-430b-91fd-0e6e2a1c3410	cpu_usage	gauge	6.000000	{}	2025-09-03 17:39:57.672+00
309b457e-be8f-409b-bb9d-a06fde29fcd8	uptime	gauge	1569.198065	{}	2025-09-03 17:40:57.673+00
d71ce269-5c80-407d-afa1-f018347e00ef	cpu_usage	gauge	6.000000	{}	2025-09-03 17:41:57.674+00
078ae03f-d1ff-46a8-a458-cfc73b02494d	uptime	gauge	1689.199280	{}	2025-09-03 17:42:57.674+00
04ee2b2c-d2dc-4d84-974c-d693aa46fb91	disk_usage	gauge	45.200000	{}	2025-09-03 17:43:57.674+00
440c1c06-07ed-4869-8e5d-2353d6b55492	cpu_usage	gauge	6.000000	{}	2025-09-03 17:44:57.674+00
8c56fa39-c143-4c5f-b813-d991ae742d5b	uptime	gauge	1869.199001	{}	2025-09-03 17:45:57.674+00
3786a258-f6c4-433c-8e6f-c638889021f2	memory_usage	gauge	70.310000	{}	2025-09-03 17:46:57.674+00
8c85cc30-28e9-477e-8d2c-404778cc91a1	cpu_usage	gauge	6.000000	{}	2025-09-03 17:39:23.806+00
26ebe056-6cff-4f48-a7e1-68f5417523dc	memory_usage	gauge	75.370000	{}	2025-09-03 17:39:23.806+00
f60af6e3-9040-4861-b6d3-cef212220f11	uptime	gauge	68.061418	{}	2025-09-03 17:39:23.806+00
02c86c92-611c-4d24-a2e1-cd3d0d8a548b	memory_usage	gauge	75.940000	{}	2025-09-03 17:40:23.805+00
5ddc8442-3b42-4bab-bf33-0e4ee46f2d77	disk_usage	gauge	45.200000	{}	2025-09-03 17:41:23.806+00
af6d2068-bace-4835-b683-0ce0f1f1e48c	disk_usage	gauge	45.200000	{}	2025-09-03 17:42:23.806+00
800ce171-2b79-48f1-a877-c596f7d1d5d9	disk_usage	gauge	45.200000	{}	2025-09-03 17:39:23.806+00
05d91215-4be2-4ee9-8bbb-7e17ef0c6be5	cpu_usage	gauge	6.000000	{}	2025-09-03 17:40:23.805+00
377c33d9-e54d-4934-a050-e319e14c8ca0	uptime	gauge	188.060981	{}	2025-09-03 17:41:23.806+00
9592603a-aebd-400e-aed3-292b4df76954	memory_usage	gauge	75.600000	{}	2025-09-03 17:42:23.806+00
41e4600e-d2b1-474a-84cf-6c852b6e1326	disk_usage	gauge	45.200000	{}	2025-09-03 17:40:23.805+00
e36ec16a-fd6e-4c68-8460-21e79986dffd	cpu_usage	gauge	6.000000	{}	2025-09-03 17:41:23.805+00
89d4effd-7509-4eb7-9d04-5604d97b601b	cpu_usage	gauge	6.000000	{}	2025-09-03 17:42:23.806+00
66d39e8b-d955-4d3a-8515-4136b1f1eba0	uptime	gauge	128.060097	{}	2025-09-03 17:40:23.805+00
4d6958ef-9395-4bb6-8880-f60b7d4ba1ff	memory_usage	gauge	75.640000	{}	2025-09-03 17:41:23.805+00
daf4a31e-f83b-499b-abdb-458dd741a747	uptime	gauge	248.061567	{}	2025-09-03 17:42:23.806+00
d3e2442d-f582-479d-9cb2-17385aa5bfeb	cpu_usage	gauge	6.000000	{}	2025-09-03 17:44:34.867+00
b4ee41ec-9a53-47b0-bfee-4952c1e79fb5	memory_usage	gauge	74.730000	{}	2025-09-03 17:44:34.867+00
96785670-a783-464c-a686-3f939805ba94	disk_usage	gauge	45.200000	{}	2025-09-03 17:44:34.867+00
a8f0bf05-4139-42d9-b92f-d393075847db	uptime	gauge	67.975370	{}	2025-09-03 17:44:34.867+00
a59b9e8b-60b2-4f7d-8734-db284048f3c3	memory_usage	gauge	76.600000	{}	2025-09-03 16:48:36.215+00
763cea63-655e-43b6-a8b8-51c1a79f1f6d	memory_usage	gauge	76.550000	{}	2025-09-03 16:49:36.215+00
\.


--
-- TOC entry 4323 (class 0 OID 17239)
-- Dependencies: 253
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimonials (id, user_id, user_name, user_avatar, content, rating, is_verified, is_public, is_featured, tags, metadata, moderation_status, moderation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4332 (class 0 OID 17475)
-- Dependencies: 262
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, product_id, retailer_slug, rule_id, user_id_hash, status, price_paid, msrp, qty, alert_at, added_to_cart_at, purchased_at, lead_time_ms, failure_reason, region, session_fingerprint, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4309 (class 0 OID 16942)
-- Dependencies: 239
-- Data for Name: trend_analysis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trend_analysis (id, product_id, price_trend, availability_trend, demand_score, volatility_score, analyzed_at) FROM stdin;
\.


--
-- TOC entry 4305 (class 0 OID 16851)
-- Dependencies: 235
-- Data for Name: unsubscribe_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unsubscribe_tokens (id, token, user_id, email_type, expires_at, used_at, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4329 (class 0 OID 17385)
-- Dependencies: 259
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, user_id, role_id, assigned_by, assignment_reason, assigned_at, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4301 (class 0 OID 16792)
-- Dependencies: 231
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, refresh_token, device_info, ip_address, user_agent, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4297 (class 0 OID 16673)
-- Dependencies: 227
-- Data for Name: user_watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_watch_packs (id, user_id, watch_pack_id, customizations, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4286 (class 0 OID 16477)
-- Dependencies: 216
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, subscription_tier, created_at, updated_at, email_verified, verification_token, reset_token, reset_token_expires, failed_login_attempts, locked_until, last_login, shipping_addresses, payment_methods, retailer_credentials, notification_settings, quiet_hours, timezone, zip_code, push_subscriptions, role, last_admin_login, admin_permissions, first_name, last_name, preferences, newsletter_subscription, terms_accepted, direct_permissions, role_last_updated, role_updated_by, permission_metadata, stripe_customer_id, subscription_id, subscription_status, subscription_start_date, subscription_end_date, trial_end_date, cancel_at_period_end, subscription_plan_id) FROM stdin;
84a8557a-b08e-405e-b391-16def0d2020d	test@boosterbeacon.com	$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq9w5KS	pro	2025-09-03 16:31:17.756398+00	2025-09-03 16:31:17.756398+00	f	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	[]	\N	\N	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
a7d94af5-6a3d-4b56-bdbf-52bec13375a1	admin@boosterbeacon.com	$2b$12$ftfCcN.wcekmC0SGMXUvB.1zzyHlyl5UyqD65Ryk/YKgax5P3L8j6	pro	2025-09-03 16:53:58.366645+00	2025-09-03 16:53:58.366645+00	t	\N	\N	\N	0	\N	\N	[]	[]	{}	{"sms": true, "email": true, "discord": true, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	super_admin	\N	["user_management", "user_suspend", "user_delete", "ml_model_training", "ml_data_review", "system_monitoring", "analytics_view", "audit_log_view"]	Admin	User	{}	f	f	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
0b5d6a4f-8fd8-439b-9d75-6e0933be5b7e	derekmihlfeith@gmail.com	$2b$12$Cuy.tpIf2h6fhYRnCUfU8OwiHQ.5gCW0xEwLP48F3WHQCG5IOBfBu	free	2025-09-03 17:06:05.918057+00	2025-09-03 19:32:08.897+00	t	\N	2851a820ce70f1433cd59c4c3a8911e0e4e01f67807699393bf983d29ed0d916	2025-09-03 19:22:54.035+00	0	\N	2025-09-03 19:32:08.897+00	{}	{}	{}	{"sms": false, "email": true, "discord": false, "web_push": true}	{"days": [], "enabled": false, "end_time": "08:00", "timezone": "UTC", "start_time": "22:00"}	UTC	\N	[]	user	\N	{}	Derek	Mihlfeith	{}	t	t	[]	\N	\N	{}	\N	\N	\N	\N	\N	\N	f	\N
\.


--
-- TOC entry 4296 (class 0 OID 16656)
-- Dependencies: 226
-- Data for Name: watch_packs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watch_packs (id, name, slug, description, product_ids, is_active, auto_update, update_criteria, subscriber_count, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4295 (class 0 OID 16624)
-- Dependencies: 225
-- Data for Name: watches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watches (id, user_id, product_id, retailer_ids, max_price, availability_type, zip_code, radius_miles, is_active, alert_preferences, last_alerted, alert_count, created_at, updated_at, auto_purchase) FROM stdin;
\.


--
-- TOC entry 4320 (class 0 OID 17171)
-- Dependencies: 250
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, user_id, name, url, secret, events, headers, retry_config, filters, is_active, total_calls, successful_calls, failed_calls, last_triggered, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4345 (class 0 OID 0)
-- Dependencies: 217
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 17, true);


--
-- TOC entry 4346 (class 0 OID 0)
-- Dependencies: 219
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 3977 (class 2606 OID 17076)
-- Name: admin_audit_log admin_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3885 (class 2606 OID 16761)
-- Name: alert_deliveries alert_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_pkey PRIMARY KEY (id);


--
-- TOC entry 3871 (class 2606 OID 16715)
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- TOC entry 3937 (class 2606 OID 16928)
-- Name: availability_snapshots availability_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 4078 (class 2606 OID 17500)
-- Name: billing_events billing_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.billing_events
    ADD CONSTRAINT billing_events_pkey PRIMARY KEY (id);


--
-- TOC entry 4038 (class 2606 OID 17360)
-- Name: comment_likes comment_likes_comment_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_user_id_unique UNIQUE (comment_id, user_id);


--
-- TOC entry 4040 (class 2606 OID 17348)
-- Name: comment_likes comment_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4022 (class 2606 OID 17284)
-- Name: community_posts community_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4086 (class 2606 OID 17516)
-- Name: conversion_analytics conversion_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversion_analytics
    ADD CONSTRAINT conversion_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4006 (class 2606 OID 17207)
-- Name: csv_operations csv_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_pkey PRIMARY KEY (id);


--
-- TOC entry 3971 (class 2606 OID 17051)
-- Name: data_quality_metrics data_quality_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3997 (class 2606 OID 17162)
-- Name: discord_servers discord_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_pkey PRIMARY KEY (id);


--
-- TOC entry 4000 (class 2606 OID 17169)
-- Name: discord_servers discord_servers_user_id_server_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_server_id_unique UNIQUE (user_id, server_id);


--
-- TOC entry 3930 (class 2606 OID 16872)
-- Name: email_bounces email_bounces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_bounces
    ADD CONSTRAINT email_bounces_pkey PRIMARY KEY (id);


--
-- TOC entry 3934 (class 2606 OID 16882)
-- Name: email_complaints email_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_complaints
    ADD CONSTRAINT email_complaints_pkey PRIMARY KEY (id);


--
-- TOC entry 3917 (class 2606 OID 16850)
-- Name: email_delivery_logs email_delivery_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3908 (class 2606 OID 16840)
-- Name: email_preferences email_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 3911 (class 2606 OID 16898)
-- Name: email_preferences email_preferences_unsubscribe_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_unsubscribe_token_unique UNIQUE (unsubscribe_token);


--
-- TOC entry 3958 (class 2606 OID 17006)
-- Name: engagement_metrics engagement_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3962 (class 2606 OID 17013)
-- Name: engagement_metrics engagement_metrics_product_id_metrics_date_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_metrics_date_unique UNIQUE (product_id, metrics_date);


--
-- TOC entry 4089 (class 2606 OID 17542)
-- Name: external_product_map external_product_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_pkey PRIMARY KEY (id);


--
-- TOC entry 4092 (class 2606 OID 17549)
-- Name: external_product_map external_product_map_retailer_slug_external_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_retailer_slug_external_id_unique UNIQUE (retailer_slug, external_id);


--
-- TOC entry 3816 (class 2606 OID 16508)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3814 (class 2606 OID 16501)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3954 (class 2606 OID 16985)
-- Name: ml_model_metrics ml_model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_model_metrics
    ADD CONSTRAINT ml_model_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 3981 (class 2606 OID 17111)
-- Name: ml_models ml_models_name_version_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_name_version_unique UNIQUE (name, version);


--
-- TOC entry 3983 (class 2606 OID 17101)
-- Name: ml_models ml_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_pkey PRIMARY KEY (id);


--
-- TOC entry 3948 (class 2606 OID 16966)
-- Name: ml_predictions ml_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_pkey PRIMARY KEY (id);


--
-- TOC entry 3988 (class 2606 OID 17124)
-- Name: ml_training_data ml_training_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_pkey PRIMARY KEY (id);


--
-- TOC entry 4063 (class 2606 OID 17427)
-- Name: permission_audit_log permission_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 4027 (class 2606 OID 17307)
-- Name: post_comments post_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_pkey PRIMARY KEY (id);


--
-- TOC entry 4031 (class 2606 OID 17327)
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 17339)
-- Name: post_likes post_likes_post_id_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_user_id_unique UNIQUE (post_id, user_id);


--
-- TOC entry 3889 (class 2606 OID 16777)
-- Name: price_history price_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3844 (class 2606 OID 16607)
-- Name: product_availability product_availability_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_pkey PRIMARY KEY (id);


--
-- TOC entry 3847 (class 2606 OID 16619)
-- Name: product_availability product_availability_product_id_retailer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_retailer_id_unique UNIQUE (product_id, retailer_id);


--
-- TOC entry 3825 (class 2606 OID 16555)
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 3828 (class 2606 OID 16557)
-- Name: product_categories product_categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_slug_unique UNIQUE (slug);


--
-- TOC entry 3832 (class 2606 OID 16578)
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- TOC entry 3837 (class 2606 OID 16580)
-- Name: products products_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_unique UNIQUE (slug);


--
-- TOC entry 3840 (class 2606 OID 16582)
-- Name: products products_upc_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_upc_unique UNIQUE (upc);


--
-- TOC entry 3819 (class 2606 OID 16540)
-- Name: retailers retailers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_pkey PRIMARY KEY (id);


--
-- TOC entry 3822 (class 2606 OID 16542)
-- Name: retailers retailers_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retailers
    ADD CONSTRAINT retailers_slug_unique UNIQUE (slug);


--
-- TOC entry 4046 (class 2606 OID 17379)
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- TOC entry 4048 (class 2606 OID 17377)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4050 (class 2606 OID 17381)
-- Name: roles roles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_slug_unique UNIQUE (slug);


--
-- TOC entry 3966 (class 2606 OID 17027)
-- Name: seasonal_patterns seasonal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_pkey PRIMARY KEY (id);


--
-- TOC entry 4010 (class 2606 OID 17225)
-- Name: social_shares social_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_pkey PRIMARY KEY (id);


--
-- TOC entry 4066 (class 2606 OID 17468)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4068 (class 2606 OID 17470)
-- Name: subscription_plans subscription_plans_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_slug_unique UNIQUE (slug);


--
-- TOC entry 4070 (class 2606 OID 17472)
-- Name: subscription_plans subscription_plans_stripe_price_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_stripe_price_id_unique UNIQUE (stripe_price_id);


--
-- TOC entry 3904 (class 2606 OID 16824)
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- TOC entry 3994 (class 2606 OID 17143)
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4016 (class 2606 OID 17256)
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- TOC entry 4076 (class 2606 OID 17485)
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3943 (class 2606 OID 16948)
-- Name: trend_analysis trend_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_pkey PRIMARY KEY (id);


--
-- TOC entry 3922 (class 2606 OID 16861)
-- Name: unsubscribe_tokens unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3925 (class 2606 OID 16894)
-- Name: unsubscribe_tokens unsubscribe_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_token_unique UNIQUE (token);


--
-- TOC entry 4054 (class 2606 OID 17396)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4058 (class 2606 OID 17413)
-- Name: user_roles user_roles_user_id_role_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_id_unique UNIQUE (user_id, role_id);


--
-- TOC entry 3897 (class 2606 OID 16802)
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3900 (class 2606 OID 16809)
-- Name: user_sessions user_sessions_refresh_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_unique UNIQUE (refresh_token);


--
-- TOC entry 3864 (class 2606 OID 16684)
-- Name: user_watch_packs user_watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3867 (class 2606 OID 16696)
-- Name: user_watch_packs user_watch_packs_user_id_watch_pack_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_watch_pack_id_unique UNIQUE (user_id, watch_pack_id);


--
-- TOC entry 3798 (class 2606 OID 16489)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 3800 (class 2606 OID 16510)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3803 (class 2606 OID 16487)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3808 (class 2606 OID 17522)
-- Name: users users_stripe_customer_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_stripe_customer_id_unique UNIQUE (stripe_customer_id);


--
-- TOC entry 3810 (class 2606 OID 17524)
-- Name: users users_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_subscription_id_unique UNIQUE (subscription_id);


--
-- TOC entry 3859 (class 2606 OID 16668)
-- Name: watch_packs watch_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_pkey PRIMARY KEY (id);


--
-- TOC entry 3862 (class 2606 OID 16670)
-- Name: watch_packs watch_packs_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watch_packs
    ADD CONSTRAINT watch_packs_slug_unique UNIQUE (slug);


--
-- TOC entry 3851 (class 2606 OID 16639)
-- Name: watches watches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_pkey PRIMARY KEY (id);


--
-- TOC entry 3856 (class 2606 OID 16651)
-- Name: watches watches_user_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_product_id_unique UNIQUE (user_id, product_id);


--
-- TOC entry 4002 (class 2606 OID 17187)
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 3973 (class 1259 OID 17083)
-- Name: admin_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_action_created_at_index ON public.admin_audit_log USING btree (action, created_at);


--
-- TOC entry 3974 (class 1259 OID 17082)
-- Name: admin_audit_log_admin_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_admin_user_id_created_at_index ON public.admin_audit_log USING btree (admin_user_id, created_at);


--
-- TOC entry 3975 (class 1259 OID 17085)
-- Name: admin_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_created_at_index ON public.admin_audit_log USING btree (created_at);


--
-- TOC entry 3978 (class 1259 OID 17084)
-- Name: admin_audit_log_target_type_target_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_audit_log_target_type_target_id_index ON public.admin_audit_log USING btree (target_type, target_id);


--
-- TOC entry 3882 (class 1259 OID 16767)
-- Name: alert_deliveries_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_alert_id_index ON public.alert_deliveries USING btree (alert_id);


--
-- TOC entry 3883 (class 1259 OID 16768)
-- Name: alert_deliveries_channel_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_channel_index ON public.alert_deliveries USING btree (channel);


--
-- TOC entry 3886 (class 1259 OID 16770)
-- Name: alert_deliveries_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_sent_at_index ON public.alert_deliveries USING btree (sent_at);


--
-- TOC entry 3887 (class 1259 OID 16769)
-- Name: alert_deliveries_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_deliveries_status_index ON public.alert_deliveries USING btree (status);


--
-- TOC entry 3869 (class 1259 OID 16744)
-- Name: alerts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_created_at_index ON public.alerts USING btree (created_at);


--
-- TOC entry 3872 (class 1259 OID 16742)
-- Name: alerts_priority_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_priority_index ON public.alerts USING btree (priority);


--
-- TOC entry 3873 (class 1259 OID 16737)
-- Name: alerts_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_product_id_index ON public.alerts USING btree (product_id);


--
-- TOC entry 3874 (class 1259 OID 16738)
-- Name: alerts_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_retailer_id_index ON public.alerts USING btree (retailer_id);


--
-- TOC entry 3875 (class 1259 OID 16743)
-- Name: alerts_scheduled_for_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_scheduled_for_index ON public.alerts USING btree (scheduled_for);


--
-- TOC entry 3876 (class 1259 OID 16740)
-- Name: alerts_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_index ON public.alerts USING btree (status);


--
-- TOC entry 3877 (class 1259 OID 16746)
-- Name: alerts_status_priority_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_status_priority_created_at_index ON public.alerts USING btree (status, priority, created_at);


--
-- TOC entry 3878 (class 1259 OID 16741)
-- Name: alerts_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_type_index ON public.alerts USING btree (type);


--
-- TOC entry 3879 (class 1259 OID 16736)
-- Name: alerts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_index ON public.alerts USING btree (user_id);


--
-- TOC entry 3880 (class 1259 OID 16745)
-- Name: alerts_user_id_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_user_id_status_index ON public.alerts USING btree (user_id, status);


--
-- TOC entry 3881 (class 1259 OID 16739)
-- Name: alerts_watch_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alerts_watch_id_index ON public.alerts USING btree (watch_id);


--
-- TOC entry 3938 (class 1259 OID 16939)
-- Name: availability_snapshots_product_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_product_id_snapshot_time_index ON public.availability_snapshots USING btree (product_id, snapshot_time);


--
-- TOC entry 3939 (class 1259 OID 16940)
-- Name: availability_snapshots_retailer_id_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_retailer_id_snapshot_time_index ON public.availability_snapshots USING btree (retailer_id, snapshot_time);


--
-- TOC entry 3940 (class 1259 OID 16941)
-- Name: availability_snapshots_snapshot_time_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX availability_snapshots_snapshot_time_index ON public.availability_snapshots USING btree (snapshot_time);


--
-- TOC entry 4036 (class 1259 OID 17361)
-- Name: comment_likes_comment_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_comment_id_index ON public.comment_likes USING btree (comment_id);


--
-- TOC entry 4041 (class 1259 OID 17362)
-- Name: comment_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX comment_likes_user_id_index ON public.comment_likes USING btree (user_id);


--
-- TOC entry 4019 (class 1259 OID 17293)
-- Name: community_posts_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_created_at_index ON public.community_posts USING btree (created_at);


--
-- TOC entry 4020 (class 1259 OID 17292)
-- Name: community_posts_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_is_featured_is_public_index ON public.community_posts USING btree (is_featured, is_public);


--
-- TOC entry 4023 (class 1259 OID 17291)
-- Name: community_posts_type_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_type_moderation_status_index ON public.community_posts USING btree (type, moderation_status);


--
-- TOC entry 4024 (class 1259 OID 17290)
-- Name: community_posts_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX community_posts_user_id_index ON public.community_posts USING btree (user_id);


--
-- TOC entry 4083 (class 1259 OID 17519)
-- Name: conversion_analytics_event_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_date_index ON public.conversion_analytics USING btree (event_date);


--
-- TOC entry 4084 (class 1259 OID 17518)
-- Name: conversion_analytics_event_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_event_type_index ON public.conversion_analytics USING btree (event_type);


--
-- TOC entry 4087 (class 1259 OID 17517)
-- Name: conversion_analytics_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX conversion_analytics_user_id_index ON public.conversion_analytics USING btree (user_id);


--
-- TOC entry 4004 (class 1259 OID 17214)
-- Name: csv_operations_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_created_at_index ON public.csv_operations USING btree (created_at);


--
-- TOC entry 4007 (class 1259 OID 17213)
-- Name: csv_operations_user_id_operation_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX csv_operations_user_id_operation_type_index ON public.csv_operations USING btree (user_id, operation_type);


--
-- TOC entry 3968 (class 1259 OID 17058)
-- Name: data_quality_metrics_assessed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_assessed_at_index ON public.data_quality_metrics USING btree (assessed_at);


--
-- TOC entry 3969 (class 1259 OID 17059)
-- Name: data_quality_metrics_overall_quality_score_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_overall_quality_score_index ON public.data_quality_metrics USING btree (overall_quality_score);


--
-- TOC entry 3972 (class 1259 OID 17057)
-- Name: data_quality_metrics_product_id_data_source_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_quality_metrics_product_id_data_source_index ON public.data_quality_metrics USING btree (product_id, data_source);


--
-- TOC entry 3998 (class 1259 OID 17170)
-- Name: discord_servers_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX discord_servers_user_id_is_active_index ON public.discord_servers USING btree (user_id, is_active);


--
-- TOC entry 3927 (class 1259 OID 16909)
-- Name: email_bounces_bounce_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_bounce_type_index ON public.email_bounces USING btree (bounce_type);


--
-- TOC entry 3928 (class 1259 OID 16895)
-- Name: email_bounces_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_message_id_index ON public.email_bounces USING btree (message_id);


--
-- TOC entry 3931 (class 1259 OID 16914)
-- Name: email_bounces_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_bounces_timestamp_index ON public.email_bounces USING btree ("timestamp");


--
-- TOC entry 3932 (class 1259 OID 16896)
-- Name: email_complaints_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_message_id_index ON public.email_complaints USING btree (message_id);


--
-- TOC entry 3935 (class 1259 OID 16910)
-- Name: email_complaints_timestamp_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_complaints_timestamp_index ON public.email_complaints USING btree ("timestamp");


--
-- TOC entry 3913 (class 1259 OID 16916)
-- Name: email_delivery_logs_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_alert_id_index ON public.email_delivery_logs USING btree (alert_id);


--
-- TOC entry 3914 (class 1259 OID 16921)
-- Name: email_delivery_logs_email_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_email_type_index ON public.email_delivery_logs USING btree (email_type);


--
-- TOC entry 3915 (class 1259 OID 16918)
-- Name: email_delivery_logs_message_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_message_id_index ON public.email_delivery_logs USING btree (message_id);


--
-- TOC entry 3918 (class 1259 OID 16920)
-- Name: email_delivery_logs_sent_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_sent_at_index ON public.email_delivery_logs USING btree (sent_at);


--
-- TOC entry 3919 (class 1259 OID 16912)
-- Name: email_delivery_logs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_delivery_logs_user_id_index ON public.email_delivery_logs USING btree (user_id);


--
-- TOC entry 3909 (class 1259 OID 16915)
-- Name: email_preferences_unsubscribe_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_unsubscribe_token_index ON public.email_preferences USING btree (unsubscribe_token);


--
-- TOC entry 3912 (class 1259 OID 16911)
-- Name: email_preferences_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX email_preferences_user_id_index ON public.email_preferences USING btree (user_id);


--
-- TOC entry 3956 (class 1259 OID 17015)
-- Name: engagement_metrics_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_metrics_date_index ON public.engagement_metrics USING btree (metrics_date);


--
-- TOC entry 3959 (class 1259 OID 17014)
-- Name: engagement_metrics_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_index ON public.engagement_metrics USING btree (product_id);


--
-- TOC entry 3960 (class 1259 OID 17016)
-- Name: engagement_metrics_product_id_metrics_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX engagement_metrics_product_id_metrics_date_index ON public.engagement_metrics USING btree (product_id, metrics_date);


--
-- TOC entry 4090 (class 1259 OID 17550)
-- Name: external_product_map_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_product_map_product_id_index ON public.external_product_map USING btree (product_id);


--
-- TOC entry 4079 (class 1259 OID 17501)
-- Name: idx_billing_events_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_customer ON public.billing_events USING btree (stripe_customer_id);


--
-- TOC entry 4080 (class 1259 OID 17503)
-- Name: idx_billing_events_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_invoice ON public.billing_events USING btree (invoice_id);


--
-- TOC entry 4081 (class 1259 OID 17502)
-- Name: idx_billing_events_subscription; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_subscription ON public.billing_events USING btree (subscription_id);


--
-- TOC entry 4082 (class 1259 OID 17504)
-- Name: idx_billing_events_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_billing_events_type ON public.billing_events USING btree (event_type);


--
-- TOC entry 4071 (class 1259 OID 17487)
-- Name: idx_transactions_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_product ON public.transactions USING btree (product_id);


--
-- TOC entry 4072 (class 1259 OID 17488)
-- Name: idx_transactions_retailer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_retailer ON public.transactions USING btree (retailer_slug);


--
-- TOC entry 4073 (class 1259 OID 17489)
-- Name: idx_transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_status ON public.transactions USING btree (status);


--
-- TOC entry 4074 (class 1259 OID 17486)
-- Name: idx_transactions_user_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transactions_user_hash ON public.transactions USING btree (user_id_hash);


--
-- TOC entry 3792 (class 1259 OID 16490)
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- TOC entry 3793 (class 1259 OID 16829)
-- Name: idx_users_push_subscriptions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_push_subscriptions ON public.users USING btree (id);


--
-- TOC entry 3794 (class 1259 OID 17525)
-- Name: idx_users_stripe_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_stripe_customer ON public.users USING btree (stripe_customer_id);


--
-- TOC entry 3795 (class 1259 OID 17526)
-- Name: idx_users_subscription_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_subscription_status ON public.users USING btree (subscription_status);


--
-- TOC entry 3951 (class 1259 OID 16988)
-- Name: ml_model_metrics_last_evaluated_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_last_evaluated_at_index ON public.ml_model_metrics USING btree (last_evaluated_at);


--
-- TOC entry 3952 (class 1259 OID 16986)
-- Name: ml_model_metrics_model_name_model_version_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_model_name_model_version_index ON public.ml_model_metrics USING btree (model_name, model_version);


--
-- TOC entry 3955 (class 1259 OID 16987)
-- Name: ml_model_metrics_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_model_metrics_prediction_type_index ON public.ml_model_metrics USING btree (prediction_type);


--
-- TOC entry 3979 (class 1259 OID 17107)
-- Name: ml_models_name_status_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_name_status_created_at_index ON public.ml_models USING btree (name, status, created_at);


--
-- TOC entry 3984 (class 1259 OID 17108)
-- Name: ml_models_status_deployed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_status_deployed_at_index ON public.ml_models USING btree (status, deployed_at);


--
-- TOC entry 3985 (class 1259 OID 17109)
-- Name: ml_models_trained_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_models_trained_by_index ON public.ml_models USING btree (trained_by);


--
-- TOC entry 3946 (class 1259 OID 16973)
-- Name: ml_predictions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_expires_at_index ON public.ml_predictions USING btree (expires_at);


--
-- TOC entry 3949 (class 1259 OID 16972)
-- Name: ml_predictions_product_id_prediction_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_index ON public.ml_predictions USING btree (product_id, prediction_type);


--
-- TOC entry 3950 (class 1259 OID 16974)
-- Name: ml_predictions_product_id_prediction_type_timeframe_days_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_predictions_product_id_prediction_type_timeframe_days_index ON public.ml_predictions USING btree (product_id, prediction_type, timeframe_days);


--
-- TOC entry 3986 (class 1259 OID 17131)
-- Name: ml_training_data_dataset_name_data_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_dataset_name_data_type_index ON public.ml_training_data USING btree (dataset_name, data_type);


--
-- TOC entry 3989 (class 1259 OID 17132)
-- Name: ml_training_data_reviewed_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_reviewed_by_index ON public.ml_training_data USING btree (reviewed_by);


--
-- TOC entry 3990 (class 1259 OID 17130)
-- Name: ml_training_data_status_data_type_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ml_training_data_status_data_type_created_at_index ON public.ml_training_data USING btree (status, data_type, created_at);


--
-- TOC entry 4059 (class 1259 OID 17440)
-- Name: permission_audit_log_action_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_action_created_at_index ON public.permission_audit_log USING btree (action, created_at);


--
-- TOC entry 4060 (class 1259 OID 17439)
-- Name: permission_audit_log_actor_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_actor_user_id_created_at_index ON public.permission_audit_log USING btree (actor_user_id, created_at);


--
-- TOC entry 4061 (class 1259 OID 17441)
-- Name: permission_audit_log_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_created_at_index ON public.permission_audit_log USING btree (created_at);


--
-- TOC entry 4064 (class 1259 OID 17438)
-- Name: permission_audit_log_target_user_id_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX permission_audit_log_target_user_id_created_at_index ON public.permission_audit_log USING btree (target_user_id, created_at);


--
-- TOC entry 4025 (class 1259 OID 17320)
-- Name: post_comments_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_created_at_index ON public.post_comments USING btree (created_at);


--
-- TOC entry 4028 (class 1259 OID 17318)
-- Name: post_comments_post_id_moderation_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_post_id_moderation_status_index ON public.post_comments USING btree (post_id, moderation_status);


--
-- TOC entry 4029 (class 1259 OID 17319)
-- Name: post_comments_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_comments_user_id_index ON public.post_comments USING btree (user_id);


--
-- TOC entry 4032 (class 1259 OID 17340)
-- Name: post_likes_post_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_post_id_index ON public.post_likes USING btree (post_id);


--
-- TOC entry 4035 (class 1259 OID 17341)
-- Name: post_likes_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX post_likes_user_id_index ON public.post_likes USING btree (user_id);


--
-- TOC entry 3890 (class 1259 OID 16788)
-- Name: price_history_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_index ON public.price_history USING btree (product_id);


--
-- TOC entry 3891 (class 1259 OID 16791)
-- Name: price_history_product_id_retailer_id_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_product_id_retailer_id_recorded_at_index ON public.price_history USING btree (product_id, retailer_id, recorded_at);


--
-- TOC entry 3892 (class 1259 OID 16790)
-- Name: price_history_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_recorded_at_index ON public.price_history USING btree (recorded_at);


--
-- TOC entry 3893 (class 1259 OID 16789)
-- Name: price_history_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX price_history_retailer_id_index ON public.price_history USING btree (retailer_id);


--
-- TOC entry 3841 (class 1259 OID 16622)
-- Name: product_availability_in_stock_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_in_stock_index ON public.product_availability USING btree (in_stock);


--
-- TOC entry 3842 (class 1259 OID 16623)
-- Name: product_availability_last_checked_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_last_checked_index ON public.product_availability USING btree (last_checked);


--
-- TOC entry 3845 (class 1259 OID 16620)
-- Name: product_availability_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_product_id_index ON public.product_availability USING btree (product_id);


--
-- TOC entry 3848 (class 1259 OID 16621)
-- Name: product_availability_retailer_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_availability_retailer_id_index ON public.product_availability USING btree (retailer_id);


--
-- TOC entry 3823 (class 1259 OID 16564)
-- Name: product_categories_parent_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_parent_id_index ON public.product_categories USING btree (parent_id);


--
-- TOC entry 3826 (class 1259 OID 16563)
-- Name: product_categories_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX product_categories_slug_index ON public.product_categories USING btree (slug);


--
-- TOC entry 3829 (class 1259 OID 16590)
-- Name: products_category_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_category_id_index ON public.products USING btree (category_id);


--
-- TOC entry 3830 (class 1259 OID 16592)
-- Name: products_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_is_active_index ON public.products USING btree (is_active);


--
-- TOC entry 3833 (class 1259 OID 16593)
-- Name: products_release_date_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_release_date_index ON public.products USING btree (release_date);


--
-- TOC entry 3834 (class 1259 OID 16591)
-- Name: products_set_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_set_name_index ON public.products USING btree (set_name);


--
-- TOC entry 3835 (class 1259 OID 16588)
-- Name: products_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_slug_index ON public.products USING btree (slug);


--
-- TOC entry 3838 (class 1259 OID 16589)
-- Name: products_upc_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX products_upc_index ON public.products USING btree (upc);


--
-- TOC entry 3817 (class 1259 OID 16544)
-- Name: retailers_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_is_active_index ON public.retailers USING btree (is_active);


--
-- TOC entry 3820 (class 1259 OID 16543)
-- Name: retailers_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retailers_slug_index ON public.retailers USING btree (slug);


--
-- TOC entry 4042 (class 1259 OID 17384)
-- Name: roles_created_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_created_by_index ON public.roles USING btree (created_by);


--
-- TOC entry 4043 (class 1259 OID 17382)
-- Name: roles_is_system_role_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_is_system_role_is_active_index ON public.roles USING btree (is_system_role, is_active);


--
-- TOC entry 4044 (class 1259 OID 17383)
-- Name: roles_level_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX roles_level_index ON public.roles USING btree (level);


--
-- TOC entry 3963 (class 1259 OID 17039)
-- Name: seasonal_patterns_category_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_category_id_pattern_type_index ON public.seasonal_patterns USING btree (category_id, pattern_type);


--
-- TOC entry 3964 (class 1259 OID 17040)
-- Name: seasonal_patterns_pattern_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_pattern_name_index ON public.seasonal_patterns USING btree (pattern_name);


--
-- TOC entry 3967 (class 1259 OID 17038)
-- Name: seasonal_patterns_product_id_pattern_type_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX seasonal_patterns_product_id_pattern_type_index ON public.seasonal_patterns USING btree (product_id, pattern_type);


--
-- TOC entry 4008 (class 1259 OID 17237)
-- Name: social_shares_alert_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_alert_id_index ON public.social_shares USING btree (alert_id);


--
-- TOC entry 4011 (class 1259 OID 17238)
-- Name: social_shares_shared_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_shared_at_index ON public.social_shares USING btree (shared_at);


--
-- TOC entry 4012 (class 1259 OID 17236)
-- Name: social_shares_user_id_platform_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX social_shares_user_id_platform_index ON public.social_shares USING btree (user_id, platform);


--
-- TOC entry 3902 (class 1259 OID 16827)
-- Name: system_health_checked_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_checked_at_index ON public.system_health USING btree (checked_at);


--
-- TOC entry 3905 (class 1259 OID 16825)
-- Name: system_health_service_name_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_service_name_index ON public.system_health USING btree (service_name);


--
-- TOC entry 3906 (class 1259 OID 16826)
-- Name: system_health_status_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_health_status_index ON public.system_health USING btree (status);


--
-- TOC entry 3991 (class 1259 OID 17144)
-- Name: system_metrics_metric_name_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_name_recorded_at_index ON public.system_metrics USING btree (metric_name, recorded_at);


--
-- TOC entry 3992 (class 1259 OID 17145)
-- Name: system_metrics_metric_type_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_metric_type_recorded_at_index ON public.system_metrics USING btree (metric_type, recorded_at);


--
-- TOC entry 3995 (class 1259 OID 17146)
-- Name: system_metrics_recorded_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX system_metrics_recorded_at_index ON public.system_metrics USING btree (recorded_at);


--
-- TOC entry 4013 (class 1259 OID 17264)
-- Name: testimonials_is_featured_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_is_featured_is_public_index ON public.testimonials USING btree (is_featured, is_public);


--
-- TOC entry 4014 (class 1259 OID 17263)
-- Name: testimonials_moderation_status_is_public_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_moderation_status_is_public_index ON public.testimonials USING btree (moderation_status, is_public);


--
-- TOC entry 4017 (class 1259 OID 17265)
-- Name: testimonials_rating_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_rating_index ON public.testimonials USING btree (rating);


--
-- TOC entry 4018 (class 1259 OID 17262)
-- Name: testimonials_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX testimonials_user_id_index ON public.testimonials USING btree (user_id);


--
-- TOC entry 3941 (class 1259 OID 16955)
-- Name: trend_analysis_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_analyzed_at_index ON public.trend_analysis USING btree (analyzed_at);


--
-- TOC entry 3944 (class 1259 OID 16956)
-- Name: trend_analysis_product_id_analyzed_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_analyzed_at_index ON public.trend_analysis USING btree (product_id, analyzed_at);


--
-- TOC entry 3945 (class 1259 OID 16954)
-- Name: trend_analysis_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trend_analysis_product_id_index ON public.trend_analysis USING btree (product_id);


--
-- TOC entry 3920 (class 1259 OID 16919)
-- Name: unsubscribe_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_expires_at_index ON public.unsubscribe_tokens USING btree (expires_at);


--
-- TOC entry 3923 (class 1259 OID 16913)
-- Name: unsubscribe_tokens_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_token_index ON public.unsubscribe_tokens USING btree (token);


--
-- TOC entry 3926 (class 1259 OID 16917)
-- Name: unsubscribe_tokens_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX unsubscribe_tokens_user_id_index ON public.unsubscribe_tokens USING btree (user_id);


--
-- TOC entry 4051 (class 1259 OID 17416)
-- Name: user_roles_assigned_by_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_assigned_by_index ON public.user_roles USING btree (assigned_by);


--
-- TOC entry 4052 (class 1259 OID 17417)
-- Name: user_roles_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_expires_at_index ON public.user_roles USING btree (expires_at);


--
-- TOC entry 4055 (class 1259 OID 17415)
-- Name: user_roles_role_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_role_id_is_active_index ON public.user_roles USING btree (role_id, is_active);


--
-- TOC entry 4056 (class 1259 OID 17414)
-- Name: user_roles_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_roles_user_id_is_active_index ON public.user_roles USING btree (user_id, is_active);


--
-- TOC entry 3894 (class 1259 OID 16812)
-- Name: user_sessions_expires_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_expires_at_index ON public.user_sessions USING btree (expires_at);


--
-- TOC entry 3895 (class 1259 OID 16813)
-- Name: user_sessions_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_is_active_index ON public.user_sessions USING btree (is_active);


--
-- TOC entry 3898 (class 1259 OID 16811)
-- Name: user_sessions_refresh_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_refresh_token_index ON public.user_sessions USING btree (refresh_token);


--
-- TOC entry 3901 (class 1259 OID 16810)
-- Name: user_sessions_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_sessions_user_id_index ON public.user_sessions USING btree (user_id);


--
-- TOC entry 3865 (class 1259 OID 16697)
-- Name: user_watch_packs_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_user_id_index ON public.user_watch_packs USING btree (user_id);


--
-- TOC entry 3868 (class 1259 OID 16698)
-- Name: user_watch_packs_watch_pack_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_watch_packs_watch_pack_id_index ON public.user_watch_packs USING btree (watch_pack_id);


--
-- TOC entry 3796 (class 1259 OID 16511)
-- Name: users_email_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_index ON public.users USING btree (email);


--
-- TOC entry 3801 (class 1259 OID 17064)
-- Name: users_last_admin_login_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_last_admin_login_index ON public.users USING btree (last_admin_login);


--
-- TOC entry 3804 (class 1259 OID 16522)
-- Name: users_reset_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_reset_token_index ON public.users USING btree (reset_token);


--
-- TOC entry 3805 (class 1259 OID 17449)
-- Name: users_role_created_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_created_at_index ON public.users USING btree (role, created_at);


--
-- TOC entry 3806 (class 1259 OID 17063)
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- TOC entry 3811 (class 1259 OID 17527)
-- Name: users_subscription_plan_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_subscription_plan_id_index ON public.users USING btree (subscription_plan_id);


--
-- TOC entry 3812 (class 1259 OID 16521)
-- Name: users_verification_token_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_verification_token_index ON public.users USING btree (verification_token);


--
-- TOC entry 3857 (class 1259 OID 16672)
-- Name: watch_packs_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_is_active_index ON public.watch_packs USING btree (is_active);


--
-- TOC entry 3860 (class 1259 OID 16671)
-- Name: watch_packs_slug_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watch_packs_slug_index ON public.watch_packs USING btree (slug);


--
-- TOC entry 3849 (class 1259 OID 16654)
-- Name: watches_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_is_active_index ON public.watches USING btree (is_active);


--
-- TOC entry 3852 (class 1259 OID 16653)
-- Name: watches_product_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_product_id_index ON public.watches USING btree (product_id);


--
-- TOC entry 3853 (class 1259 OID 16652)
-- Name: watches_user_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_index ON public.watches USING btree (user_id);


--
-- TOC entry 3854 (class 1259 OID 16655)
-- Name: watches_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_user_id_is_active_index ON public.watches USING btree (user_id, is_active);


--
-- TOC entry 4003 (class 1259 OID 17193)
-- Name: webhooks_user_id_is_active_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_user_id_is_active_index ON public.webhooks USING btree (user_id, is_active);


--
-- TOC entry 4122 (class 2606 OID 17077)
-- Name: admin_audit_log admin_audit_log_admin_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_user_id_foreign FOREIGN KEY (admin_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4106 (class 2606 OID 16762)
-- Name: alert_deliveries alert_deliveries_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_deliveries
    ADD CONSTRAINT alert_deliveries_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4102 (class 2606 OID 16721)
-- Name: alerts alerts_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4103 (class 2606 OID 16726)
-- Name: alerts alerts_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4104 (class 2606 OID 16716)
-- Name: alerts alerts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4105 (class 2606 OID 16731)
-- Name: alerts alerts_watch_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_watch_id_foreign FOREIGN KEY (watch_id) REFERENCES public.watches(id) ON DELETE SET NULL;


--
-- TOC entry 4114 (class 2606 OID 16929)
-- Name: availability_snapshots availability_snapshots_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4115 (class 2606 OID 16934)
-- Name: availability_snapshots availability_snapshots_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_snapshots
    ADD CONSTRAINT availability_snapshots_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4136 (class 2606 OID 17349)
-- Name: comment_likes comment_likes_comment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_comment_id_foreign FOREIGN KEY (comment_id) REFERENCES public.post_comments(id) ON DELETE CASCADE;


--
-- TOC entry 4137 (class 2606 OID 17354)
-- Name: comment_likes comment_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_likes
    ADD CONSTRAINT comment_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4131 (class 2606 OID 17285)
-- Name: community_posts community_posts_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community_posts
    ADD CONSTRAINT community_posts_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4127 (class 2606 OID 17208)
-- Name: csv_operations csv_operations_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.csv_operations
    ADD CONSTRAINT csv_operations_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4121 (class 2606 OID 17052)
-- Name: data_quality_metrics data_quality_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_quality_metrics
    ADD CONSTRAINT data_quality_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4125 (class 2606 OID 17163)
-- Name: discord_servers discord_servers_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.discord_servers
    ADD CONSTRAINT discord_servers_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4111 (class 2606 OID 16899)
-- Name: email_delivery_logs email_delivery_logs_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE SET NULL;


--
-- TOC entry 4112 (class 2606 OID 16888)
-- Name: email_delivery_logs email_delivery_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_delivery_logs
    ADD CONSTRAINT email_delivery_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4110 (class 2606 OID 16883)
-- Name: email_preferences email_preferences_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_preferences
    ADD CONSTRAINT email_preferences_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4118 (class 2606 OID 17007)
-- Name: engagement_metrics engagement_metrics_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement_metrics
    ADD CONSTRAINT engagement_metrics_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4143 (class 2606 OID 17543)
-- Name: external_product_map external_product_map_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_product_map
    ADD CONSTRAINT external_product_map_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4123 (class 2606 OID 17102)
-- Name: ml_models ml_models_trained_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_models
    ADD CONSTRAINT ml_models_trained_by_foreign FOREIGN KEY (trained_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4117 (class 2606 OID 16967)
-- Name: ml_predictions ml_predictions_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_predictions
    ADD CONSTRAINT ml_predictions_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4124 (class 2606 OID 17125)
-- Name: ml_training_data ml_training_data_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ml_training_data
    ADD CONSTRAINT ml_training_data_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 4141 (class 2606 OID 17428)
-- Name: permission_audit_log permission_audit_log_actor_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_actor_user_id_foreign FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- TOC entry 4142 (class 2606 OID 17433)
-- Name: permission_audit_log permission_audit_log_target_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permission_audit_log
    ADD CONSTRAINT permission_audit_log_target_user_id_foreign FOREIGN KEY (target_user_id) REFERENCES public.users(id);


--
-- TOC entry 4132 (class 2606 OID 17308)
-- Name: post_comments post_comments_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4133 (class 2606 OID 17313)
-- Name: post_comments post_comments_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_comments
    ADD CONSTRAINT post_comments_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4134 (class 2606 OID 17328)
-- Name: post_likes post_likes_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.community_posts(id) ON DELETE CASCADE;


--
-- TOC entry 4135 (class 2606 OID 17333)
-- Name: post_likes post_likes_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4107 (class 2606 OID 16778)
-- Name: price_history price_history_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4108 (class 2606 OID 16783)
-- Name: price_history price_history_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.price_history
    ADD CONSTRAINT price_history_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4096 (class 2606 OID 16608)
-- Name: product_availability product_availability_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4097 (class 2606 OID 16613)
-- Name: product_availability product_availability_retailer_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_availability
    ADD CONSTRAINT product_availability_retailer_id_foreign FOREIGN KEY (retailer_id) REFERENCES public.retailers(id) ON DELETE CASCADE;


--
-- TOC entry 4094 (class 2606 OID 16558)
-- Name: product_categories product_categories_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_categories_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4095 (class 2606 OID 16583)
-- Name: products products_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE SET NULL;


--
-- TOC entry 4119 (class 2606 OID 17033)
-- Name: seasonal_patterns seasonal_patterns_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.product_categories(id) ON DELETE CASCADE;


--
-- TOC entry 4120 (class 2606 OID 17028)
-- Name: seasonal_patterns seasonal_patterns_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.seasonal_patterns
    ADD CONSTRAINT seasonal_patterns_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4128 (class 2606 OID 17231)
-- Name: social_shares social_shares_alert_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_alert_id_foreign FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- TOC entry 4129 (class 2606 OID 17226)
-- Name: social_shares social_shares_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_shares
    ADD CONSTRAINT social_shares_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4130 (class 2606 OID 17257)
-- Name: testimonials testimonials_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4116 (class 2606 OID 16949)
-- Name: trend_analysis trend_analysis_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trend_analysis
    ADD CONSTRAINT trend_analysis_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4113 (class 2606 OID 16904)
-- Name: unsubscribe_tokens unsubscribe_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unsubscribe_tokens
    ADD CONSTRAINT unsubscribe_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4138 (class 2606 OID 17407)
-- Name: user_roles user_roles_assigned_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_assigned_by_foreign FOREIGN KEY (assigned_by) REFERENCES public.users(id);


--
-- TOC entry 4139 (class 2606 OID 17402)
-- Name: user_roles user_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4140 (class 2606 OID 17397)
-- Name: user_roles user_roles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4109 (class 2606 OID 16803)
-- Name: user_sessions user_sessions_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4100 (class 2606 OID 16685)
-- Name: user_watch_packs user_watch_packs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4101 (class 2606 OID 16690)
-- Name: user_watch_packs user_watch_packs_watch_pack_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_watch_packs
    ADD CONSTRAINT user_watch_packs_watch_pack_id_foreign FOREIGN KEY (watch_pack_id) REFERENCES public.watch_packs(id) ON DELETE CASCADE;


--
-- TOC entry 4093 (class 2606 OID 17444)
-- Name: users users_role_updated_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_updated_by_foreign FOREIGN KEY (role_updated_by) REFERENCES public.users(id);


--
-- TOC entry 4098 (class 2606 OID 16645)
-- Name: watches watches_product_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_product_id_foreign FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- TOC entry 4099 (class 2606 OID 16640)
-- Name: watches watches_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4126 (class 2606 OID 17188)
-- Name: webhooks webhooks_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2025-09-03 22:20:12 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict ShhA6We53d3MEfqu2sKKv3JEQdLsi6k5VYYFajuUJCua6ekSlt96v8axBAzdg1e

